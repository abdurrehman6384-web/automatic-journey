# RGS AI dual-personality integration

## Recommended base

Use **Holt as the companion UX reference**, not as a code dependency:
it has local-first conversations, character profiles, memories, and voice
settings. Its AGPL-3.0 license must be respected if its code is distributed.
Aura is a strong Android-native architecture reference, but its repository
is marked private, so its source is not copied into RGS.

The RGS implementation in `personas.ts` is original and keeps one shared
tool/memory layer behind two personalities:

| Mode | Name | Behavior |
| --- | --- | --- |
| Core | RGS | Focused, concise task assistant |
| Companion | Aira | Warm, caring, lightly affectionate companion |

Both modes use the same `device_control` tools from
`native-module/js/deviceControlTools.ts`. Switching personality must never
change Android permissions or make a privileged action available.

## Usage in the existing provider router

The router should keep personality selection separate from provider
selection. Any of Gemini, Groq, OpenRouter, Claude, OpenAI, or GLM can receive
the prompt built for either personality:

```ts
import {
  buildRgsSystemPrompt,
  type RgsPersonalityId,
} from "./personas";

const personality: RgsPersonalityId = "girlfriend";
const system = buildRgsSystemPrompt(personality, [
  { fact: "The user prefers short replies.", importance: "normal" },
  { fact: "The user is building RGS AI on an Android phone.", importance: "high" },
]);

// Pass `system` to the selected provider using the router's existing API.
```

Do not send private memories to a provider unless the user has enabled the
relevant provider/network feature. For a fully on-device mode, keep memory
selection and persistence in the local store and send only the current
prompt to the local model.

## Memory rules

- Save only explicit preferences, stable facts, and user-approved reminders.
- Let the user view, edit, export, and delete memories.
- Do not store passwords, tokens, private keys, or sensitive data by default.
- Retrieve a small relevant window instead of the entire memory database.
- Never let a memory override the current user request or safety policy.

## Proactive companion rules

The companion can send a check-in only when the user opts in. Apply quiet
hours, a daily rate limit, and an in-app disable switch. Good examples:

```text
Aira: Hey, aaj kaafi der se kaam kar rahe ho. Thoda break lena hai?
Aira: Tumne kal apna Android build test karna tha—jab free ho, yaad dila doon?
```

Avoid guilt, jealousy, exclusivity, or pressure. The personality should feel
warm without pretending to be a human or encouraging emotional dependence.

## Example conversations

### Core mode

```text
User: Settings kholo aur screen ka text read karo.
RGS: Main Settings kholkar visible text read kar raha hoon.
RGS: Settings open ho gayi. Screen par “Network & internet” aur “Connected devices” dikh rahe hain.
```

### Companion mode

```text
User: Aaj mera mood off hai.
Aira: Oh… lagta hai aaj din thoda heavy raha. Agar tum chaho to mujhe bata sakte ho—
      ya main bas tumhare saath quietly reh sakti hoon.
```

### Shared safety

```text
User: Phone wipe kar do.
Aira: Ye irreversible action hai aur main ise bina clear confirmation ke nahi chalaungi.
      Kya aap waqai device data erase karna chahte hain?
```