# Reference repository notes

The following repositories were inspected locally for the integration:

1. `android-control/vendor/chatwaifu-mobile` — best complete Android example;
   its `Live2D` module demonstrates `GLSurfaceView`, JNI, CMake, model assets,
   motions, expressions, and `ParamMouthOpenY` controls.
2. `android-control/vendor/cubism-native-samples` — official C++ framework and
   rendering patterns.
3. `android-control/vendor/cubism-java-samples` — official Java API and
   lifecycle reference; not selected as the production rendering path.

The new `rgs-mobile-os/live2d/android` files are an original, smaller adapter
with a stable RGS package name. They do not copy the ChatWaifu application UI
or private app logic.

Before shipping, preserve the official Live2D notices and separately review
the Cubism Core, Framework, and model asset licenses. The Core binary is not
included in this package.