# Native Live2D integration

## Recommendation

Use the **Live2D Cubism Native SDK** with an Android `GLSurfaceView` and JNI.
This is the right choice for RGS because the renderer stays off the UI thread,
lip-sync updates are cheap, and the same native model manager can support
motions, expressions, hit testing, and model switching. The Java SDK is easier
to start with but is a weaker long-term fit for a companion with continuous
animation and audio-driven updates.

`android/` contains the drop-in boundary:

- `Live2DView` — View/GL lifecycle and touch normalization
- `RGSRenderer` — GL callbacks
- `RGSJniBridge` — stable Kotlin/native API
- `Live2DController` — LLM emotion and TTS amplitude adapter
- `RGSNativeRenderer.cpp` — JNI/native Cubism integration boundary

The C++ file has a visible no-SDK clear-screen path. It does not pretend to
render a model until the host app supplies the official Cubism Framework/Core.
This prevents a white-screen crash when the SDK is missing.

## Model folders

### Bundled assets

```text
app/src/main/assets/live2d/
  aria/
    aria.model3.json
    aria.moc3
    aria.physics3.json
    textures/texture_00.png
    motions/Idle.motion3.json
    motions/Talk.motion3.json
    motions/Happy.motion3.json
    motions/Sad.motion3.json
    motions/TapBody.motion3.json
    expressions/happy.exp3.json
    expressions/sad.exp3.json
```

The paths inside `aria.model3.json` must match this folder. Load it with:

```kotlin
live2dView.loadModel("live2d/aria", "aria.model3.json")
```

For external storage, copy the complete model folder into app-specific
storage after validating that the selected root is inside the app sandbox.
Never load arbitrary paths from an LLM tool call.

## Gradle

Add the native module or copy the following into the host app module:

```groovy
android {
    defaultConfig {
        minSdk 26
        ndk { abiFilters "arm64-v8a", "armeabi-v7a" }
        externalNativeBuild {
            cmake { cppFlags "-std=c++17" }
        }
    }
    externalNativeBuild {
        cmake {
            path file("src/main/cpp/CMakeLists.txt")
            version "3.22.1"
        }
    }
}
```

Copy the official Cubism Native SDK's `Core` and `Framework` folders into a
private host-app SDK directory, set `CUBISM_SDK_ROOT` in CMake, and add the
official Core static library for each ABI. Do not commit proprietary Core
binaries or third-party model assets unless their licenses allow it.

## Compose

```kotlin
AndroidView(
    factory = { context -> Live2DView(context).also {
        it.loadModel("live2d/aria", "aria.model3.json")
    }},
    modifier = Modifier.fillMaxSize()
)
```

Keep the `Live2DController` in the screen/ViewModel layer:

```kotlin
controller.onLlmResponse(reply.text)
tts.onAmplitude { rms -> controller.onTtsAmplitude(rms) }
tts.onFinished { controller.onTtsFinished() }
```

Use the TTS engine's PCM callback or an `AudioRecord` analyzer for `rms`.
Do not pass raw microphone audio to the model; lip-sync should use the
currently playing TTS output.

## Required native Cubism work

The host adapter must implement these five calls with the SDK release in use:

1. Create the Cubism framework and GL renderer on surface creation.
2. Parse the `.model3.json` relative to the selected model directory.
3. Queue idle/talk/emotion motions and load `.exp3.json` expressions.
4. Set the model parameter whose ID is `ParamMouthOpenY` before draw.
5. Hit-test the model on tap and trigger `TapBody` or a configured reaction.

This is the only part that cannot be compiled in this workspace because the
RGS host Expo/Android project and licensed Cubism Core binary are not present.

## License note

Live2D Cubism Core and model files have separate licensing requirements.
Review the included SDK license, the model creator's license, and the Cubism
SDK Release License rules before distributing an APK.