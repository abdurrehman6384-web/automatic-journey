# RGS Mobile OS integration package

This package includes the Android device-control module, the dual-personality
prompt layer, and the native Live2D companion adapter. See
`live2d/GRADLE_CMAKE_INTEGRATION.md` for Cubism setup and
`PERSONALITY_INTEGRATION.md` for the RGS/Aira routing contract.
# RGS AI Mobile — Deep OS Integration module

Mobile counterpart to Iris/Ultron's desktop OS control: screen lock,
screenshots, screen-reading + tap/type/scroll automation, and voice control
— for your own phone, built on Android's real, documented APIs.

## Start here

Read `INTEGRATION_PROMPT.md` — it has the full plan, an honest table of
what's actually possible on Android vs. what isn't (shutdown and unlock in
particular don't work the way you'd expect — worth reading before you
build anything), and a step-by-step integration path for RGS AI Mobile's
Expo/EAS Build setup.

## What's inside

- `reference/opendroid-subset/` — real, working, Apache-2.0 Kotlin pulled
  from an existing open-source Android AI agent
  ([yashab-cyber/opendroid](https://github.com/yashab-cyber/opendroid)):
  the AccessibilityService, the action-executor catalog, and the
  voice/wake-word pipeline.
- `native-module/` — original code written for this task: the React
  Native bridge + Expo config plugin that lets RGS AI Mobile's JS call into
  the above, since opendroid itself is a pure native app with no RN layer.
- `native-module/android/command/CommandProcessor.java` — the merged,
  allow-listed command parser/executor. It accepts structured AI intents
  or a small set of voice phrases and dispatches documented Android system
  and accessibility actions.
- `orb-ui/` — the Ultron orb Next.js interface, kept as the visual control
  surface for the mobile assistant.

## CommandProcessor

The React Native bridge exposes `DeviceControl.processCommand(command)`.
Prefer structured JSON from the model:

```json
{"action":"lock_screen"}
{"action":"click_text","text":"Allow"}
{"action":"type_text","field":"Search","text":"weather"}
{"action":"scroll","direction":"forward"}
{"action":"open_notifications"}
{"action":"open_quick_settings"}
{"action":"toggle_split_screen"}
{"action":"open_settings","page":"accessibility"}
{"action":"open_app","package":"com.android.settings"}
```

The parser also accepts simple phrases such as `go home`, `screenshot`,
`click Allow`, and `type hello`. Unknown actions are rejected. Commands
that need root, device-owner privileges, or an unavoidable user
confirmation (for example silent reboot, Wi-Fi toggling, or APK
installation) return `UNSUPPORTED` rather than pretending they worked.

Add `CommandProcessor.java` to the same Android source set as
`RGSAccessibilityService.kt`; the package names in the supplied module are
`com.rgsai.mobile.*`.
