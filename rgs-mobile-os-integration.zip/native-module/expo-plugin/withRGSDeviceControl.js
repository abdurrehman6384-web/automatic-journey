const {
  withAndroidManifest,
  withStringsXml,
  AndroidConfig,
} = require('@expo/config-plugins');

/**
 * Expo config plugin for RGS AI Mobile's OS-integration module.
 *
 * Expo Go cannot run this — it has custom native code (an AccessibilityService
 * + a foreground Service). This plugin only works with `expo prebuild` /
 * a custom dev client / EAS Build with a native project, which matches
 * the project's existing EAS Build workflow.
 *
 * Usage in app.json / app.config.js:
 *   { "plugins": ["./native-module/expo-plugin/withRGSDeviceControl"] }
 *
 * What this plugin does NOT do: request the accessibility permission for
 * you (there's no programmatic way to — Android requires the user to
 * enable it by hand in Settings, see RGSDeviceControlModule.openAccessibilitySettings()),
 * or hide the foreground-service notification / screenshot notification /
 * screen-recording indicator. Those are OS-level, not something a manifest
 * entry can turn off.
 */
const ACCESSIBILITY_SERVICE_NAME = 'com.rgsai.mobile.accessibility.RGSAccessibilityService';

const REQUIRED_PERMISSIONS = [
  'android.permission.RECORD_AUDIO',       // voice control
  'android.permission.FOREGROUND_SERVICE',
  'android.permission.FOREGROUND_SERVICE_MICROPHONE',
  'android.permission.FOREGROUND_SERVICE_SPECIAL_USE',
  'android.permission.POST_NOTIFICATIONS', // Android 13+ needs this for the foreground-service notification
  'android.permission.RECEIVE_BOOT_COMPLETED', // only if you want voice control to auto-restart after reboot
];

function withRGSAndroidPermissions(config) {
  return AndroidConfig.Permissions.withPermissions(config, REQUIRED_PERMISSIONS);
}

function withRGSAccessibilityString(config) {
  return withStringsXml(config, (config) => {
    config.modResults = AndroidConfig.Strings.setStringItem(
      [
        {
          $: { name: 'rgs_accessibility_service_desc' },
          _: 'Lets RGS AI read what\u2019s on your screen and perform actions you ask it for — lock the screen, take a screenshot, tap, scroll, and type in apps on your behalf. You can turn this off anytime in Settings > Accessibility.',
        },
      ],
      config.modResults
    );
    return config;
  });
}

function withRGSAndroidManifest(config) {
  return withAndroidManifest(config, (config) => {
    const app = config.modResults.manifest.application[0];

    app.service = app.service || [];

    // Accessibility service — screen reading + global actions (lock, screenshot, etc.)
    app.service.push({
      $: {
        'android:name': ACCESSIBILITY_SERVICE_NAME,
        'android:permission': 'android.permission.BIND_ACCESSIBILITY_SERVICE',
        'android:exported': 'true',
      },
      'intent-filter': [
        {
          action: [{ $: { 'android:name': 'android.accessibilityservice.AccessibilityService' } }],
        },
      ],
      'meta-data': [
        {
          $: {
            'android:name': 'android.accessibilityservice',
            'android:resource': '@xml/rgs_accessibility_service_config',
          },
        },
      ],
    });

    // Voice foreground service — wire the class name up once you've ported
    // OpenDroidService.kt to com.rgsai.mobile.voice.RGSVoiceService.
    app.service.push({
      $: {
        'android:name': 'com.rgsai.mobile.voice.RGSVoiceService',
        'android:foregroundServiceType': 'microphone|specialUse',
        'android:exported': 'false',
      },
      property: [
        {
          $: {
            'android:name': 'android.app.PROPERTY_SPECIAL_USE_FGS_SUBTYPE',
            'android:value': 'RGS AI voice assistant loop; mic only used while actively listening',
          },
        },
      ],
    });

    return config;
  });
}

module.exports = function withRGSDeviceControl(config) {
  config = withRGSAndroidPermissions(config);
  config = withRGSAccessibilityString(config);
  config = withRGSAndroidManifest(config);
  return config;
};

/*
You still need to hand-add one raw XML resource file after prebuild (config
plugins can inject manifest/strings but not arbitrary raw-resource XML files
cleanly): copy
  reference/opendroid-subset/manifest/accessibility_service_config.xml
to
  android/app/src/main/res/xml/rgs_accessibility_service_config.xml
and point its android:description at @string/rgs_accessibility_service_desc
(the string this plugin creates above).
*/
