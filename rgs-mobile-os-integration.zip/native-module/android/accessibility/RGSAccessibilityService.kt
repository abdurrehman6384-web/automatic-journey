package com.rgsai.mobile.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Minimal, honest AccessibilityService for RGS AI Mobile.
 *
 * This only wraps Android's *documented* global actions:
 *  - GLOBAL_ACTION_LOCK_SCREEN     (API 28+) really locks the device.
 *  - GLOBAL_ACTION_TAKE_SCREENSHOT (API 28+) really takes a screenshot
 *    (saved to the gallery, with the normal screenshot notification —
 *    it is not silent or hidden).
 *  - GLOBAL_ACTION_POWER_DIALOG    opens the power menu; the user still
 *    has to tap "Power off" / "Restart" themselves. There is no API for
 *    a non-privileged app to silently power off or reboot the device —
 *    see INTEGRATION_PROMPT.md §2 for why, and the Device Owner /
 *    Shizuku alternatives if you need real silent reboot.
 *
 * For reading the screen (to let an LLM understand what's on it) and
 * dispatching taps/swipes/typing, port
 * `reference/opendroid-subset/accessibility/OpenDroidAccessibilityService.kt`,
 * `AccessibilityNodeTraversal.kt`, and `GenericAppAutomator.kt` — this file
 * intentionally stays small so it's easy to read end-to-end; extend it
 * with the tree-walking logic from that reference once this compiles and
 * the service shows up correctly in Settings → Accessibility.
 */
class RGSAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        private var instance: RGSAccessibilityService? = null

        fun getInstance(): RGSAccessibilityService? = instance

        fun isRunning(): Boolean = instance != null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this

        // Keep these flags minimal on purpose. Add
        // AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS and
        // report view ids only once you actually implement screen-reading —
        // requesting more than you use just makes the Play Console /
        // reviewers (and the user reading the permission prompt) trust the
        // app less.
        val info = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPES_ALL_MASK
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.DEFAULT or
                AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
            notificationTimeout = 100
        }
        serviceInfo = info
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally empty in this minimal version — wire in
        // AccessibilityNodeTraversal.kt here once you're ready to expose
        // screen content to the JS side.
    }

    override fun onInterrupt() {
        // Required override; nothing to clean up for global-action-only use.
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance === this) instance = null
    }

    /** True on success. False if the OS refused (rare) or API < 28. */
    fun lockScreen(): Boolean {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.P) return false
        return performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
    }

    /** Real screenshot, saved to the gallery — visible to the user, not hidden. */
    fun takeScreenshot(): Boolean {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.P) return false
        return performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
    }

    /** Opens the power dialog; the user must tap Power off/Restart themselves. */
    fun openPowerDialog(): Boolean = performGlobalAction(GLOBAL_ACTION_POWER_DIALOG)

    fun goHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun goBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun openRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)

    /** Root of the current window's accessibility tree — starting point for screen-reading. */
    fun currentScreenRoot(): AccessibilityNodeInfo? = rootInActiveWindow
}
