package com.rgsai.mobile.bridge

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.text.TextUtils
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import com.rgsai.mobile.accessibility.RGSAccessibilityService
// import com.rgsai.mobile.voice.RGSVoiceService // wire up once ported from
// reference/opendroid-subset/core/service/OpenDroidService.kt

/**
 * JS-facing bridge. Every method here is a thin wrapper around a real,
 * documented Android API — nothing here does anything silently or without
 * the OS-level indicator/consent that API normally requires. See
 * INTEGRATION_PROMPT.md §2 for the full capability reality-check.
 *
 * Usage from JS (see js/DeviceControl.ts for a typed wrapper):
 *   import { NativeModules } from 'react-native';
 *   const { RGSDeviceControl } = NativeModules;
 *   await RGSDeviceControl.lockScreen();
 */
class RGSDeviceControlModule(reactContext: ReactApplicationContext) :
    ReactContextBaseJavaModule(reactContext) {

    override fun getName() = "RGSDeviceControl"

    // ─── Accessibility-service-backed actions ───────────────────────────

    @ReactMethod
    fun isAccessibilityServiceEnabled(promise: Promise) {
        promise.resolve(isServiceEnabledInSettings() && RGSAccessibilityService.isRunning())
    }

    /** Opens Settings → Accessibility so the user can grant it (can't be done programmatically). */
    @ReactMethod
    fun openAccessibilitySettings() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        reactApplicationContext.startActivity(intent)
    }

    @ReactMethod
    fun lockScreen(promise: Promise) {
        val service = RGSAccessibilityService.getInstance()
        if (service == null) {
            promise.reject("SERVICE_NOT_RUNNING", "Accessibility service isn't enabled — call openAccessibilitySettings() first.")
            return
        }
        promise.resolve(service.lockScreen())
    }

    @ReactMethod
    fun takeScreenshot(promise: Promise) {
        val service = RGSAccessibilityService.getInstance()
        if (service == null) {
            promise.reject("SERVICE_NOT_RUNNING", "Accessibility service isn't enabled — call openAccessibilitySettings() first.")
            return
        }
        promise.resolve(service.takeScreenshot())
    }

    /**
     * Opens the power dialog. This is the real ceiling for a non-privileged
     * app: the user still has to tap Power off / Restart themselves.
     * See INTEGRATION_PROMPT.md §2 for the Device Owner / Shizuku paths
     * to a real silent reboot, if you deliberately want to set one of those up.
     */
    @ReactMethod
    fun openPowerDialog(promise: Promise) {
        val service = RGSAccessibilityService.getInstance()
        if (service == null) {
            promise.reject("SERVICE_NOT_RUNNING", "Accessibility service isn't enabled — call openAccessibilitySettings() first.")
            return
        }
        promise.resolve(service.openPowerDialog())
    }

    @ReactMethod
    fun goHome(promise: Promise) {
        promise.resolve(RGSAccessibilityService.getInstance()?.goHome() ?: false)
    }

    @ReactMethod
    fun goBack(promise: Promise) {
        promise.resolve(RGSAccessibilityService.getInstance()?.goBack() ?: false)
    }

    // ─── Voice service (wire up after porting OpenDroidService.kt) ──────

    @ReactMethod
    fun startVoiceService(promise: Promise) {
        // val intent = Intent(reactApplicationContext, RGSVoiceService::class.java)
        // reactApplicationContext.startForegroundService(intent)
        promise.reject("NOT_WIRED", "Port core/voice/WakeWordDetector.kt + SpeechRecognitionEngine.kt into RGSVoiceService first, then uncomment this.")
    }

    @ReactMethod
    fun stopVoiceService(promise: Promise) {
        // val intent = Intent(reactApplicationContext, RGSVoiceService::class.java)
        // reactApplicationContext.stopService(intent)
        promise.reject("NOT_WIRED", "Port core/voice/WakeWordDetector.kt + SpeechRecognitionEngine.kt into RGSVoiceService first, then uncomment this.")
    }

    // ─── Helpers ─────────────────────────────────────────────────────────

    /**
     * Accessibility permission has no runtime-request API — Android requires
     * the user to flip it on manually in Settings. This just checks whether
     * they already have.
     */
    private fun isServiceEnabledInSettings(): Boolean {
        val expectedComponent = ComponentName(reactApplicationContext, RGSAccessibilityService::class.java)
        val enabledServices = Settings.Secure.getString(
            reactApplicationContext.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false

        val colonSplitter = TextUtils.SimpleStringSplitter(':')
        colonSplitter.setString(enabledServices)
        while (colonSplitter.hasNext()) {
            val componentName = ComponentName.unflattenFromString(colonSplitter.next())
            if (componentName != null && componentName == expectedComponent) return true
        }
        return false
    }
}
