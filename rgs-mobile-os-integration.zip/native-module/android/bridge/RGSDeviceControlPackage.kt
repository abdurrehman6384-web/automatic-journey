package com.rgsai.mobile.bridge

import com.facebook.react.ReactPackage
import com.facebook.react.bridge.NativeModule
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.uimanager.ViewManager

class RGSDeviceControlPackage : ReactPackage {
    override fun createNativeModules(reactContext: ReactApplicationContext): List<NativeModule> =
        listOf(RGSDeviceControlModule(reactContext))

    override fun createViewManagers(reactContext: ReactApplicationContext): List<ViewManager<*, *>> =
        emptyList()
}

/*
Registration (if you're not using Expo's autolinking / config-plugin path):

// MainApplication.kt, inside getPackages():
override fun getPackages(): List<ReactPackage> =
    PackageList(this).packages.apply {
        add(RGSDeviceControlPackage())
    }

If you use the Expo config plugin in ../expo-plugin/withRGSDeviceControl.js,
the manifest entries are injected automatically at `expo prebuild` / EAS
Build time — you still add this package registration by hand in
MainApplication.kt, since Expo's autolinking only covers npm packages, not
in-repo native modules like this one.
*/
