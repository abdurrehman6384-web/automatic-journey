import { NativeModules, Platform } from 'react-native';

const { RGSDeviceControl } = NativeModules as {
  RGSDeviceControl?: {
    isAccessibilityServiceEnabled(): Promise<boolean>;
    openAccessibilitySettings(): void;
    lockScreen(): Promise<boolean>;
    takeScreenshot(): Promise<boolean>;
    openPowerDialog(): Promise<boolean>;
    goHome(): Promise<boolean>;
    goBack(): Promise<boolean>;
    startVoiceService(): Promise<boolean>;
    stopVoiceService(): Promise<boolean>;
  };
};

function requireModule() {
  if (Platform.OS !== 'android') {
    throw new Error('DeviceControl is Android-only — this whole module has no iOS equivalent.');
  }
  if (!RGSDeviceControl) {
    throw new Error(
      'RGSDeviceControl native module not found. This means the app was ' +
      'built without native code — Expo Go can\u2019t run it. Run `expo prebuild` ' +
      'or an EAS Build with the withRGSDeviceControl plugin enabled.'
    );
  }
  return RGSDeviceControl;
}

/**
 * Thin, typed wrapper for RGS AI Mobile's OS-integration bridge.
 * Every call here maps 1:1 to a real Android API — see
 * INTEGRATION_PROMPT.md §2 for what each one can and can't actually do.
 */
export const DeviceControl = {
  async isReady(): Promise<boolean> {
    return requireModule().isAccessibilityServiceEnabled();
  },

  /** Deep-links to Settings > Accessibility so the user can grant it — required, can't be automated. */
  openSettingsToEnable(): void {
    requireModule().openAccessibilitySettings();
  },

  async lockScreen(): Promise<boolean> {
    return requireModule().lockScreen();
  },

  /** Real screenshot saved to the gallery, with the normal system notification. */
  async takeScreenshot(): Promise<boolean> {
    return requireModule().takeScreenshot();
  },

  /** Opens the power menu — the user still has to tap Power off / Restart. */
  async openPowerDialog(): Promise<boolean> {
    return requireModule().openPowerDialog();
  },

  async goHome(): Promise<boolean> {
    return requireModule().goHome();
  },

  async goBack(): Promise<boolean> {
    return requireModule().goBack();
  },

  async startVoiceControl(): Promise<boolean> {
    return requireModule().startVoiceService();
  },

  async stopVoiceControl(): Promise<boolean> {
    return requireModule().stopVoiceService();
  },
};
