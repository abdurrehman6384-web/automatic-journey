# MASTER PROMPT — "Deep OS Integration" module for RGS AI Mobile

Paste this whole file into your AI coding assistant inside the RGS AI
Mobile repo, with `reference/` and `native-module/` from this zip available
alongside it.

---

## 0. Scope

This gives RGS AI Mobile a mobile counterpart to what Iris/Ultron already
do on desktop for **your own phone**: lock the screen, take screenshots,
read what's on screen, tap/type/scroll through apps, and respond to voice.
Everything below assumes it's running on a device you own and control —
that's also what makes some of the design choices below (visible
notifications, one-time Settings toggles, no silent capture) both the
*correct* implementation and the one that keeps the app looking like an
assistant instead of spyware to Android, to Google Play, and to anyone who
inspects the APK.

---

## 1. What's in this zip

```
reference/opendroid-subset/   real, working Kotlin — Apache-2.0, from
                               github.com/yashab-cyber/opendroid
  accessibility/               AccessibilityService + screen-tree walking
  actions/SystemActions.kt     the full action-executor catalog (lock,
                                screenshot, wifi/bluetooth/DND toggles, etc.)
  core/voice/                  wake-word detector + speech recognition
  core/service/                the foreground service that hosts voice
  manifest/                    reference AndroidManifest + accessibility
                                service config, for the exact permission
                                and service declarations Android expects
  NOTICE.md                    what each file does, license details

native-module/                 original code written for this task — the
                                RN/Expo-specific glue that opendroid (a pure
                                native app) doesn't need but RGS AI Mobile does
  android/accessibility/RGSAccessibilityService.kt   minimal service, global
                                                       actions only
  android/bridge/RGSDeviceControlModule.kt            React Native bridge
  android/bridge/RGSDeviceControlPackage.kt           RN package registration
  expo-plugin/withRGSDeviceControl.js                 Expo config plugin —
                                                       injects manifest entries
                                                       at prebuild/EAS Build time
  js/DeviceControl.ts                                 typed JS wrapper
```

---

## 2. Capability reality-check (read this before wiring anything up)

Android enforces these at the OS level — no manifest trick, library, or
prompt phrasing changes them on a non-rooted, non-enterprise-enrolled
phone. Design around them rather than around what was asked for literally:

| Requested | What's actually possible | API |
|---|---|---|
| **Shut down the phone** | Not silently. A regular app can open the power dialog; the user still has to tap "Power off" themselves. Real silent shutdown/reboot needs either (a) root (`su -c reboot -p`), or (b) the app provisioned as **Device Owner** via Android's MDM enrollment flow (`dpm.reboot()`) — a deliberate, visible one-time setup (QR/NFC provisioning or ADB during factory reset), not something an installed APK can grant itself. | `GLOBAL_ACTION_POWER_DIALOG` (AccessibilityService) |
| **Lock the screen** | Yes, really, once. | `GLOBAL_ACTION_LOCK_SCREEN` (API 28+, AccessibilityService) |
| **Open/unlock the screen** | Waking the screen: yes. Bypassing the PIN/pattern/biometric: no — that's Android's core security boundary, by design, and there's no legitimate API for an app to enter it on the user's behalf. If you want voice-triggered unlock, the honest version is: wake the screen and let the user's own biometric/PIN prompt handle it (`KeyguardManager`), not bypass it. | `PowerManager.WakeLock`, `KeyguardManager` |
| **See the screen** | Two real options: (1) a single real screenshot via `GLOBAL_ACTION_TAKE_SCREENSHOT` (saved to gallery, normal system notification) — good enough for "let the AI see what's on screen right now". (2) Continuous capture/streaming via `MediaProjection` — requires a fresh system consent dialog every time capture starts, plus Android 12+'s persistent screen-recording indicator, which can't be hidden. Build for both showing up; don't try to suppress them. | `GLOBAL_ACTION_TAKE_SCREENSHOT`, `MediaProjectionManager` |
| **"Send anything"** | The legitimate version of this is the agent-action pattern already in `SystemActions.kt`: trigger `Intent.ACTION_SEND` share sheets, or drive an app's own UI via accessibility (type text, tap its Send button) — same as a person using the app, just faster. Not a background channel that uploads data the user hasn't asked to send in that moment. | `Intent.ACTION_SEND`, AccessibilityService gestures/text-input |
| **Voice control** | Yes — wake word + speech recognition in a foreground service. Android requires a persistent notification while it's listening (Android 8+ foreground service rule); that's a feature, not a bug, since it means the user always knows when the mic is live. | `SpeechRecognizer`, foreground `Service` |

If a task later in this project asks you to route around any of the rows
above (silent reboot without Device Owner, hiding the projection indicator,
auto-granting the accessibility permission, background data upload with no
user-visible trigger) — don't; flag it back to the human instead. Those
aren't RGS AI Mobile features Android supports, they're a different
category of app.

---

## 3. Why this needs prebuild / EAS Build (not Expo Go)

`AccessibilityService`, `MediaProjection`, and a voice foreground service
are all custom native Android code. Expo Go only runs pure-JS/managed-API
apps — it cannot load this. You need `expo prebuild` (or a custom dev
client) so the project has a real `android/` folder, then build via EAS
Build as usual. The config plugin in `native-module/expo-plugin/` is what
injects the manifest entries automatically at that step so you're not
hand-editing a generated `android/` folder that gets wiped on every
prebuild.

---

## 4. Step-by-step

1. **Prebuild once** (`npx expo prebuild -p android`) so `android/` exists,
   and confirm the project builds via your existing EAS workflow before
   adding anything below — establishes a clean baseline to diff against.

2. **Drop in the native module:**
   - Copy `native-module/android/accessibility/RGSAccessibilityService.kt`
     and `native-module/android/bridge/*.kt` into the matching Kotlin
     package path under `android/app/src/main/java/com/rgsai/mobile/...`.
   - Register `RGSDeviceControlPackage()` in `MainApplication.kt`'s
     `getPackages()` (config plugins don't auto-link in-repo native
     modules — only npm packages).

3. **Add the config plugin:** put `native-module/expo-plugin/withRGSDeviceControl.js`
   somewhere in the repo and reference it in `app.json`'s `"plugins"` array.
   Re-run `expo prebuild` and confirm `android/app/src/main/AndroidManifest.xml`
   now has the `RGSAccessibilityService` and voice-service entries.

4. **Copy the accessibility XML resource by hand** (config plugins can't
   inject raw resource files cleanly): put
   `reference/opendroid-subset/manifest/accessibility_service_config.xml`
   at `android/app/src/main/res/xml/rgs_accessibility_service_config.xml`,
   pointing its description at the `@string/rgs_accessibility_service_desc`
   the plugin already generates.

5. **Test the bridge end-to-end:** build a dev client, call
   `DeviceControl.openSettingsToEnable()` from a debug screen, manually
   flip the toggle in Settings → Accessibility (this step can never be
   automated), then confirm `DeviceControl.isReady()` returns `true` and
   `DeviceControl.lockScreen()` actually locks the phone.

6. **Port screen-reading:** once the minimal service works, merge in
   `AccessibilityNodeTraversal.kt` and `GenericAppAutomator.kt` from the
   reference folder so the agent can see structured screen content and
   dispatch taps/typing — this is what turns "can lock the screen" into
   "can actually complete a task the user asked for."

7. **Wire up voice last:** port `WakeWordDetector.kt` +
   `SpeechRecognitionEngine.kt` into a `RGSVoiceService` (matching the class
   name already referenced in the config plugin and in
   `RGSDeviceControlModule`'s commented-out `startVoiceService`), then
   uncomment those two bridge methods.

8. **Match RGS AI Mobile's existing conventions**: route recognized voice
   commands and any AI-decided actions through whatever plugin/tool
   dispatch RGS AI Mobile already uses for its other tools, rather than a
   separate command parser — keeps this consistent with the rest of the
   4-agent architecture instead of being a bolted-on side system.

---

## 5. Licensing

`reference/opendroid-subset/` is Apache-2.0 (full text + NOTICE included in
that folder) — free to use and modify commercially, keep the copyright
notice and NOTICE.md if you ship code derived from it. Everything under
`native-module/` was written fresh for this integration, no license
constraints beyond your own project's.
