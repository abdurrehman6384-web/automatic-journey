# RGS AI Mobile — Deep OS Integration module

Mobile counterpart to Iris/Ultron's desktop OS control: screen lock,
screenshots, screen-reading + tap/type/scroll automation, and voice control
— for your own phone, built on Android's real, documented APIs.

## Start here

Read `INTEGRATION_PROMPT.md` — it has the full plan, an honest table of
what's actually possible on Android vs. what isn't (shutdown and unlock in
particular don't work the way you'd expect — worth reading before you
build anything), and a step-by-step integration path for RGS AI Mobile's
Expo/EAS Build setup.

## What's inside

- `reference/opendroid-subset/` — real, working, Apache-2.0 Kotlin pulled
  from an existing open-source Android AI agent
  ([yashab-cyber/opendroid](https://github.com/yashab-cyber/opendroid)):
  the AccessibilityService, the action-executor catalog, and the
  voice/wake-word pipeline.
- `native-module/` — original code written for this task: the React
  Native bridge + Expo config plugin that lets RGS AI Mobile's JS call into
  the above, since opendroid itself is a pure native app with no RN layer.
