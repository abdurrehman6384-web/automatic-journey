# Attribution

The files in this folder are sourced, unmodified, from:

**OpenDroid** — https://github.com/yashab-cyber/opendroid
License: Apache License 2.0 (full text in `LICENSE` in this folder)
Copyright (c) 2026 OpenDroid Contributors

Only a subset of the full project is included here — the parts relevant to
OS-level device control, voice, and accessibility automation. The full
project also includes chat UI, multi-LLM provider routing, Room database,
notification intelligence, WhatsApp/SMS automators, and more — worth
browsing the full repo for ideas beyond this subset.

## Files included and what each does

| File | What it does |
|---|---|
| `accessibility/OpenDroidAccessibilityService.kt` | The core `AccessibilityService` — reads screen content, dispatches taps/swipes/gestures/text-entry, exposes global actions (lock screen, back, home, recents, screenshot, power dialog). |
| `accessibility/AccessibilityNodeTraversal.kt` | Walks the accessibility node tree to turn the current screen into a structured list of interactive elements (buttons, text fields, etc.) an LLM can reason over. |
| `accessibility/GenericAppAutomator.kt` | Generic tap/type/scroll helpers built on top of the accessibility tree, app-agnostic. |
| `actions/SystemActions.kt` | The full action-executor catalog: lock screen, restart (power dialog), Wi-Fi/Bluetooth/flashlight/DND toggles, screenshot, volume/brightness, clipboard, browser, and more — each one honest about what it can and can't actually do (see notes below). |
| `core/voice/WakeWordDetector.kt` | Always-listening wake-word detection running inside a foreground service. |
| `core/voice/SpeechRecognitionEngine.kt` | Speech-to-text after the wake word fires. |
| `core/service/OpenDroidService.kt` | The foreground service that keeps voice + wake-word running, with the persistent notification Android requires for this. |
| `manifest/AndroidManifest-full-reference.xml` | Full manifest for reference — permissions list, service/receiver declarations, the accessibility service's intent-filter and metadata. |
| `manifest/accessibility_service_config.xml` | The XML config Android requires for an `AccessibilityService`, including the mandatory human-readable description shown to the user before they can enable it. |

## Why `SystemActions.kt` is worth reading closely

It's a working, shipped example of exactly the constraints in
`INTEGRATION_PROMPT.md` §2 — e.g. `LockScreenAction` really does lock the
screen via `GLOBAL_ACTION_LOCK_SCREEN`, but `RestartDeviceAction` is honest
that it can only open Android's power dialog and wait for a real tap —
because that's the actual ceiling of what a non-privileged app can do here,
not a choice either project made.
