package com.example

import com.example.data.network.interceptors.BearerAuthInterceptor
import com.example.data.network.interceptors.GeminiApiKeyInterceptor
import com.example.ui.theme.DarkColorScheme
import com.example.ui.theme.LightColorScheme
import com.example.ui.theme.RgsCyan
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testMaterial3ColorSchemes() {
        assertNotNull(DarkColorScheme)
        assertNotNull(LightColorScheme)
        assertEquals(RgsCyan, DarkColorScheme.primary)
        assertNotNull(DarkColorScheme.background)
        assertNotNull(DarkColorScheme.surface)
        assertNotNull(LightColorScheme.primary)
    }

    @Test
    fun testBearerAuthInterceptor() {
        val server = MockWebServer()
        server.enqueue(MockResponse().setBody("{}"))
        server.start()

        val client = OkHttpClient.Builder()
            .addInterceptor(BearerAuthInterceptor("test-groq-key-123"))
            .build()

        val request = Request.Builder().url(server.url("/v1/chat/completions")).build()
        client.newCall(request).execute().use { response ->
            val recorded = server.takeRequest()
            assertEquals("Bearer test-groq-key-123", recorded.getHeader("Authorization"))
        }

        server.shutdown()
    }

    @Test
    fun testThemeStateModeResolution() {
        val state = com.example.ui.theme.ThemeState()
        assertEquals(com.example.ui.theme.ThemeMode.SYSTEM, state.themeMode)

        // Under SYSTEM mode, follows system setting
        assertTrue(state.isDark(systemInDark = true))
        assertFalse(state.isDark(systemInDark = false))

        // Force LIGHT mode
        state.setMode(com.example.ui.theme.ThemeMode.LIGHT)
        assertFalse(state.isDark(systemInDark = true))
        assertFalse(state.isDark(systemInDark = false))

        // Force DARK mode
        state.setMode(com.example.ui.theme.ThemeMode.DARK)
        assertTrue(state.isDark(systemInDark = true))
        assertTrue(state.isDark(systemInDark = false))

        // Dynamic color toggle
        assertFalse(state.dynamicColor)
        state.toggleDynamicColor()
        assertTrue(state.dynamicColor)
    }
}

