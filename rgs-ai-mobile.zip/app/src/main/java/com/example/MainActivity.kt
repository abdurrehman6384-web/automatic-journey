package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.components.BottomNavBar
import com.example.ui.components.BottomTab
import com.example.ui.screens.AgentsScreen
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.HwidAccessGateScreen
import com.example.ui.screens.LicenseScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SystemDashboardScreen
import com.example.ui.screens.VisionScreen
import com.example.ui.theme.RgsAiTheme
import androidx.compose.material3.MaterialTheme
import com.example.ui.viewmodel.RgsViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            RgsAiTheme {
                val navController = rememberNavController()
                val rgsViewModel: RgsViewModel = viewModel()
                val isHwidAccessGranted by rgsViewModel.isHwidAccessGranted.collectAsState()

                if (!isHwidAccessGranted) {
                    HwidAccessGateScreen(
                        viewModel = rgsViewModel,
                        onAccessGranted = {
                            // Seamlessly transitions into main application
                        }
                    )
                } else {
                    val navBackStackEntry by navController.currentBackStackEntryAsState()
                    val currentRoute = navBackStackEntry?.destination?.route ?: BottomTab.Home.route

                    Scaffold(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(MaterialTheme.colorScheme.background),
                        containerColor = MaterialTheme.colorScheme.background,
                        bottomBar = {
                            BottomNavBar(
                                currentRoute = currentRoute,
                                onTabSelected = { targetRoute ->
                                    if (currentRoute != targetRoute) {
                                        navController.navigate(targetRoute) {
                                            popUpTo(BottomTab.Home.route) {
                                                saveState = true
                                            }
                                            launchSingleTop = true
                                            restoreState = true
                                        }
                                    }
                                }
                            )
                        }
                    ) { innerPadding ->
                        NavHost(
                            navController = navController,
                            startDestination = BottomTab.Home.route,
                            modifier = Modifier.padding(innerPadding)
                        ) {
                            composable(BottomTab.Home.route) {
                                HomeScreen(
                                    viewModel = rgsViewModel,
                                    onNavigateToChat = { navController.navigate(BottomTab.Chat.route) },
                                    onNavigateToVision = { navController.navigate(BottomTab.Vision.route) },
                                    onNavigateToTools = { navController.navigate(BottomTab.Tools.route) },
                                    onNavigateToSettings = { navController.navigate(BottomTab.Settings.route) }
                                )
                            }

                            composable(BottomTab.Chat.route) {
                                ChatScreen(viewModel = rgsViewModel)
                            }

                            composable(BottomTab.Vision.route) {
                                VisionScreen(
                                    viewModel = rgsViewModel,
                                    onNavigateToChat = { navController.navigate(BottomTab.Chat.route) }
                                )
                            }

                            composable(BottomTab.Tools.route) {
                                AgentsScreen(
                                    viewModel = rgsViewModel,
                                    onNavigateToChat = { navController.navigate(BottomTab.Chat.route) },
                                    onNavigateToVision = { navController.navigate(BottomTab.Vision.route) }
                                )
                            }

                            composable(BottomTab.System.route) {
                                SystemDashboardScreen()
                            }

                            composable(BottomTab.Settings.route) {
                                SettingsScreen(viewModel = rgsViewModel)
                            }
                        }
                    }
                }
            }
        }
    }
}
