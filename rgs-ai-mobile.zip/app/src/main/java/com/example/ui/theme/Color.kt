package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ========================================================
// RGS AI Cyber Obsidian / Neon Glassmorphism Dark Theme
// ========================================================
val ObsidianBackground = Color(0xFF040711)
val CyberDarkSurface = Color(0xFF080E1E)
val GlassSurface = Color(0xFF0C152B)
val GlassSurfaceVariant = Color(0xFF131E38)
val GlassBorder = Color(0xFF1E2E50)
val GlassBorderGlowing = Color(0xFF00F2FE)

// ========================================================
// Material 3 Light Theme Tokens
// ========================================================
val LightBackground = Color(0xFFF6F8FC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE2E8F0)
val LightBorder = Color(0xFFCBD5E1)
val LightTextPrimary = Color(0xFF0F172A)
val LightTextSecondary = Color(0xFF475569)

// ========================================================
// RGS AI Core Neon System Accents
// ========================================================
val RgsCyan = Color(0xFF00F2FE)
val RgsCyanGlow = Color(0xFF4FACFE)
val RgsPurple = Color(0xFF7F00FF)
val RgsNeonViolet = Color(0xFFA855F7)
val RgsMagenta = Color(0xFFE040FB)
val RgsTerminalGreen = Color(0xFF00FF87)
val RgsAmber = Color(0xFFFF9900)
val RgsVisionSky = Color(0xFF38BDF8)
val RgsRedAlert = Color(0xFFFF3366)

// Compatibility Aliases
val IrisCyan = RgsCyan
val IrisCyanGlow = RgsCyanGlow
val IrisPurple = RgsPurple
val IrisNeonViolet = RgsNeonViolet
val IrisMagenta = RgsMagenta
val IrisTerminalGreen = RgsTerminalGreen
val IrisAmber = RgsAmber
val IrisVisionSky = RgsVisionSky
val IrisRedAlert = RgsRedAlert

// Agent / Tool Specialist Colors
val RgsCoreColor = RgsCyan
val RgsVisionColor = RgsVisionSky
val RgsTerminalColor = RgsTerminalGreen
val RgsTelekinesisColor = RgsAmber
val RgsCyberSecColor = RgsMagenta

val IrisCoreColor = RgsCoreColor
val IrisVisionColor = RgsVisionColor
val IrisTerminalColor = RgsTerminalColor
val IrisTelekinesisColor = RgsTelekinesisColor
val IrisCyberSecColor = RgsCyberSecColor

// Aliases for compatibility
val AgentManagerColor = IrisPurple
val ActionManagerColor = IrisTerminalGreen
val AiCoderColor = IrisCyan
val ApiManagerColor = IrisAmber

// License & Access Tier Accents
val StarterTierColor = Color(0xFF3B82F6)
val ProTierColor = Color(0xFFA855F7)
val GodModeTierColor = Color(0xFFE040FB)
val GeminiTierColor = Color(0xFF38BDF8)

val TextPrimary = Color(0xFFF0F4FC)
val TextSecondary = Color(0xFF8FA1C0)
val CodeBackground = Color(0xFF060913)
val TerminalGreen = Color(0xFF00FF87)

