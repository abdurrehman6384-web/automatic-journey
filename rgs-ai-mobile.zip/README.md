# RGS AI Mobile (Android Native) — Branded by AJWAD DEVELOPER

**RGS AI Mobile** is a mobile cross-platform adaptation of the RGS AI desktop agent system (originally PyQt6 / v6.8). Built natively for Android using **Kotlin**, **Jetpack Compose**, and **Room Database**, it features a 4-Agent architecture and multi-LLM model fallback routing (GLM-4.6, Gemini, Groq, Mistral).

---

## 🚀 Architecture Overview

### 1. The 4-Agent Subsystem
- **Agent Manager (`AGENT_MANAGER`)**: Central coordinator and task router that analyzes prompt intent and delegates work across sub-agents.
- **Action Manager (`ACTION_MANAGER`)**: Executes device-level telemetry checks, memory cleanup routines, and network latency ping diagnostics.
- **AI Coder (`AI_CODER`)**: Specialized code generator (Kotlin, Python, JavaScript, Shell) with syntax highlighting, line numbers, and a built-in sandbox execution simulator.
- **API Manager (`API_MANAGER`)**: Manages multi-LLM provider keys (GLM-4.6, Gemini 3.5 Flash, Groq Llama 3, Mistral AI), priority fallback stack, and thin backend Edge Proxy settings.

---

## 🔑 AI Backend & Edge Proxy Integration

- **Primary Model**: GLM-4.6 (Zhipu AI / Z.ai API) via thin backend Edge Function (`https://rgs-ai-proxy.vercel.app/api/glm-proxy` / Supabase Edge Function).
- **Fallback Rotation**: `GLM-4.6` → `Gemini 3.5 Flash` → `Groq Llama 3` → `Mistral AI`.
- **Zero-Direct-Key Security**: Direct API keys are shielded from client decompilation using thin Edge Proxy routing or BuildConfig secret injection.

---

## 🛡️ HWID Licensing System

- **Device Fingerprint Binding**: Generates unique hardware ID (HWID) per device (e.g. `RGS-HWID-XXXX-YYYY`).
- **Tier Structure**:
  - **STARTER (Rs. 500)**: Agent Manager + Core Chat (2,048 token limit).
  - **PRO (Rs. 1,200)**: Starter + AI Coder Sandbox + Action Manager (8,192 token limit).
  - **GOD MODE (Rs. 2,500)**: Unlimited 4-Agent Orchestration + Full Multi-LLM Stack + Custom Edge Proxy (32,768 token limit).

---

## 📱 Navigation & Screens

1. **💬 Chat Screen**: Chat-first interface with active agent status banner, message history, syntax code viewer, run simulator, and suggestion chips.
2. **🤖 Agents Screen**: Hub displaying status, stats, and quick actions for all 4 agents.
3. **⚙️ Settings Screen**: LLM provider key manager, edge proxy endpoint configuration, latency ping test tool, and system telemetry logs.
4. **🔐 License Screen**: HWID generator viewer, key activation input, tier pricing breakdown (Rs. 500 / Rs. 1,200 / Rs. 2,500), and contact details for AJWAD DEVELOPER.

---

## 🛠️ Build & Deployment Instructions

### Prerequisites
- Android Studio Ladybug or newer
- JDK 17 / Kotlin 2.2.10
- Android SDK 36 (Min SDK 24)

### Local Build (APK)
```bash
./gradlew assembleDebug
```
The generated APK will be located at:
`app/build/outputs/apk/debug/app-debug.apk`

---

*Branded & Engineered by **AJWAD DEVELOPER***.
