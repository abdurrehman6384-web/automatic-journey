"""
╔══════════════════════════════════════════════════════════════╗
║   app_builder.py — bolt.diy-style + 3 GitHub App Builders    ║
║                                                              ║
║   Modes:                                                     ║
║     • bolt         — bolt.diy-style full-project generator   ║
║     • gpt_engineer — GPT-Engineer style (single prompt)      ║
║     • smol         — smol-developer style (smol ai system)   ║
║     • aider         — Aider pair-programming style            ║
║                                                              ║
║   All four use the configured LLM provider to produce a      ║
║   project tree, then optionally write the files to disk.     ║
╚══────────────────────────────────────────────────────────══════╝
"""

from __future__ import annotations
import os
import re
import json
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Dict, Optional

from config import BASE_DIR, DATA_DIR, logger


BOLT_SYSTEM_PROMPT = """You are RGS AI in BOLT.DIY APP-BUILDER MODE.

When the user describes an app, you respond with a COMPLETE, RUNNABLE project.

Output format (STRICT — every file is a markdown header followed by a fenced code block):

### path/to/file.ext
```lang
<file content>
```

### another/file.ext
```lang
<file content>
```

Optionally, include shell commands as:

### run
```sh
<command>
```

Rules:
- Always include README.md with run instructions
- Always include package.json or requirements.txt
- Use modern, popular, well-supported libraries only
- Write production-quality code — no placeholders
- If web app: use Next.js 14 + Tailwind + shadcn/ui by default
- If Python: use FastAPI + Pydantic
- Keep files reasonably small (<500 lines each)
- Prefer TypeScript over JavaScript
"""


GPT_ENGINEER_PROMPT = """You are GPT-ENGINEER. The user gives you a project description.
You output a sequence of files in this exact format:

FILENAME: path/to/file
CONTENT:
<full content>
---
FILENAME: next/file
CONTENT:
<full content>
---

Include all files needed to run the project. No commentary outside this format.
"""


SMOL_PROMPT = """You are SMOL-DEVELOPER. Break the user's request into:
1. A shared context (purpose, tech stack, conventions)
2. Individual files, each prefixed with:  FILE: path/to/file
3. End each file with the line:  ===ENDFILE===

Be minimal but complete. Prefer fewer files, well-factored code.
"""


AIDER_PROMPT = """You are AIDER, a pair-programming AI.
For each change, output:
1. A SEARCH block showing the existing code to find
2. A REPLACE block showing the new code

Use this exact format:
<<<<<<< SEARCH
existing code to find
=======
new code
>>>>>>> REPLACE

If creating a new file, output:
<<<<<<< SEARCH
=======
full new file content
>>>>>>> REPLACE
Filename: path/to/file
"""


PROMPTS = {
    "bolt": BOLT_SYSTEM_PROMPT,
    "gpt_engineer": GPT_ENGINEER_PROMPT,
    "smol": SMOL_PROMPT,
    "aider": AIDER_PROMPT,
}


@dataclass
class GeneratedFile:
    path: str
    content: str
    language: str = "text"


@dataclass
class GeneratedProject:
    files: List[GeneratedFile] = field(default_factory=list)
    run_commands: List[str] = field(default_factory=list)
    notes: str = ""

    def to_dict(self) -> dict:
        return {
            "files": [f.__dict__ for f in self.files],
            "run_commands": self.run_commands,
            "notes": self.notes,
        }

    def write_to_disk(self, base_dir: Path) -> Dict[str, int]:
        """Write all files to disk under base_dir.  Returns {path: bytes}."""
        out = {}
        for f in self.files:
            p = base_dir / f.path
            p.parent.mkdir(parents=True, exist_ok=True)
            # Safety: prevent path traversal
            try:
                p.resolve().relative_to(base_dir.resolve())
            except ValueError:
                continue
            p.write_text(f.content, encoding="utf-8")
            out[str(p)] = len(f.content)
        return out


# ─────────────────────────────────────────────────────────────
#  Parsers — turn the LLM's raw output into a GeneratedProject
# ─────────────────────────────────────────────────────────────
def parse_bolt_output(text: str) -> GeneratedProject:
    proj = GeneratedProject()
    # Pattern: ### path/to/file  then ```lang\n...\n```
    blocks = re.findall(
        r"###\s+(\S+)\s*\n+```\w*\n(.*?)```",
        text, flags=re.S)
    for path, content in blocks:
        path = path.strip()
        if path.lower() in ("run", "shell", "commands"):
            for line in content.strip().split("\n"):
                line = line.strip()
                if line and not line.startswith("#"):
                    proj.run_commands.append(line)
        else:
            proj.files.append(GeneratedFile(path=path, content=content.rstrip()))
    proj.notes = "Parsed bolt.diy output"
    return proj


def parse_gpt_engineer_output(text: str) -> GeneratedProject:
    proj = GeneratedProject()
    blocks = re.split(r"^---\s*$", text, flags=re.M)
    for blk in blocks:
        m = re.match(r"FILENAME:\s*(\S+)\s*\nCONTENT:\s*\n(.*)", blk.strip(), flags=re.S)
        if m:
            proj.files.append(GeneratedFile(
                path=m.group(1).strip(),
                content=m.group(2).rstrip(),
            ))
    proj.notes = "Parsed gpt-engineer output"
    return proj


def parse_smol_output(text: str) -> GeneratedProject:
    proj = GeneratedProject()
    parts = re.split(r"===ENDFILE===\s*", text)
    for part in parts:
        m = re.match(r"FILE:\s*(\S+)\s*\n(.*)", part.strip(), flags=re.S)
        if m:
            proj.files.append(GeneratedFile(
                path=m.group(1).strip(),
                content=m.group(2).rstrip(),
            ))
    proj.notes = "Parsed smol-developer output"
    return proj


def parse_aider_output(text: str) -> GeneratedProject:
    proj = GeneratedProject()
    # Each block: SEARCH/REPLACE + optional Filename: line
    blocks = re.split(r"^>>>>>>> REPLACE\s*$", text, flags=re.M)
    cur_filename = "patch.diff"
    # Find any filename declarations
    fn_match = re.search(r"Filename:\s*(\S+)", text)
    if fn_match:
        cur_filename = fn_match.group(1)
    for blk in blocks:
        m = re.search(r"<<<<<<< SEARCH\n(.*?)\n=======\n(.*?)\n>>>>>>> REPLACE",
                      blk, flags=re.S)
        if m:
            old, new = m.group(1), m.group(2)
            if not old.strip():
                # New file
                proj.files.append(GeneratedFile(
                    path=cur_filename, content=new.rstrip(),
                ))
            else:
                # Patch — we just store the new content
                proj.files.append(GeneratedFile(
                    path=f"patch_{cur_filename}.diff",
                    content=f"--- SEARCH ---\n{old}\n--- REPLACE ---\n{new}",
                ))
    proj.notes = "Parsed aider output"
    return proj


PARSERS = {
    "bolt": parse_bolt_output,
    "gpt_engineer": parse_gpt_engineer_output,
    "smol": parse_smol_output,
    "aider": parse_aider_output,
}


# ─────────────────────────────────────────────────────────────
#  Main entry
# ─────────────────────────────────────────────────────────────
def generate_project(
    description: str,
    mode: str = "bolt",
    provider: str = "openai",
    model: str = "gpt-4o",
    write_to_disk: bool = False,
    out_dir: Optional[Path] = None,
) -> GeneratedProject:
    """High-level: ask the LLM to build a project, parse, optionally save."""
    from ui import _llm_chat  # reuse the unified chat fn

    system = PROMPTS.get(mode, BOLT_SYSTEM_PROMPT)
    messages = [{"role": "user", "content": description}]
    raw = _llm_chat(provider=provider, model=model, system=system,
                    messages=messages, temperature=0.4, max_tokens=8192)

    parser = PARSERS.get(mode, parse_bolt_output)
    proj = parser(raw)
    proj.notes = (proj.notes or "") + f"\n\nMode: {mode}\nProvider: {provider}\nModel: {model}"

    if write_to_disk:
        if out_dir is None:
            out_dir = DATA_DIR / "generated_projects" / mode
        result = proj.write_to_disk(out_dir)
        logger.info(f"Wrote {len(result)} files to {out_dir}")

    return proj


if __name__ == "__main__":
    # Smoke test
    sample = """### README.md
```md
# Demo project
A tiny demo.
```

### main.py
```python
print("hello")
```

### run
```sh
python main.py
```
"""
    proj = parse_bolt_output(sample)
    print(f"Files: {len(proj.files)}")
    for f in proj.files:
        print(f"  {f.path}  ({len(f.content)} bytes)")
    print(f"Run cmds: {proj.run_commands}")
