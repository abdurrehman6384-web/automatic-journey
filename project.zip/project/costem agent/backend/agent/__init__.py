"""RGS AI agents package."""
from .registry import (
    AgentSpec, all_agents, categories, agents_by_category,
    find_agent, search_agents, save_registry_json, stats,
)

__all__ = [
    "AgentSpec", "all_agents", "categories", "agents_by_category",
    "find_agent", "search_agents", "save_registry_json", "stats",
]
