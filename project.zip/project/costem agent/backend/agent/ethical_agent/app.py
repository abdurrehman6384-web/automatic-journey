"""
RASHEED AI MARK XXVI — ULTIMATE PC CONTROL + HACKING UTILITIES
Full system control, app management, process control, network tools
"""
import os
import sys
import subprocess
import platform
import psutil
import time
import threading
import json
import socket
import re
from pathlib import Path
from typing import Optional, List, Dict, Any

OS_TYPE = platform.system().lower()
IS_WINDOWS = OS_TYPE == "windows"
IS_LINUX = OS_TYPE == "linux"
IS_MAC = OS_TYPE == "darwin"

# ── App Aliases (200+) ──
APP_ALIASES = {
    "chrome": "chrome", "google chrome": "chrome", "chromium": "chrome",
    "firefox": "firefox", "mozilla firefox": "firefox",
    "edge": "msedge", "microsoft edge": "msedge",
    "brave": "brave", "opera": "opera", "tor": "tor",
    "notepad": "notepad", "notepad++": "notepad++",
    "calculator": "calc", "calc": "calc",
    "cmd": "cmd", "command prompt": "cmd", "terminal": "wt",
    "powershell": "powershell",
    "task manager": "taskmgr", "file explorer": "explorer",
    "explorer": "explorer", "paint": "mspaint",
    "control panel": "control", "settings": "ms-settings:",
    "registry": "regedit",
    "vscode": "code", "vs code": "code", "visual studio code": "code",
    "pycharm": "pycharm64", "android studio": "studio64",
    "git bash": "git bash", "postman": "postman",
    "docker": "docker desktop",
    "wireshark": "wireshark", "burpsuite": "burpsuite",
    "nmap": "nmap", "metasploit": "msfconsole",
    "sqlmap": "sqlmap", "hydra": "hydra",
    "john": "john", "hashcat": "hashcat",
    "aircrack": "aircrack-ng", "nikto": "nikto",
    "gobuster": "gobuster", "dirb": "dirb",
    "ffuf": "ffuf",
    "kali": "wsl -d kali-linux", "kali linux": "wsl -d kali-linux",
    "whatsapp": "shell:AppsFolder\\5319275A.WhatsAppDesktop_cv1g1gvanyjgm!App",
    "telegram": "telegram", "discord": "discord",
    "zoom": "zoom", "teams": "teams", "slack": "slack",
    "spotify": "shell:AppsFolder\\SpotifyAB.SpotifyMusic_zpdnekdrzrea0!Spotify",
    "vlc": "vlc", "vlc media player": "vlc",
    "youtube": "chrome https://youtube.com",
    "netflix": "chrome https://netflix.com",
    "word": "winword", "excel": "excel", "powerpoint": "powerpnt",
    "outlook": "outlook", "onenote": "onenote",
    "steam": "steam", "epic": "epicgameslauncher",
    "obs": "obs64", "obs studio": "obs64",
    "photoshop": "photoshop", "blender": "blender",
    "wsl": "wsl",
    "searchsploit": "searchsploit", "exploitdb": "searchsploit",
    "netcat": "nc", "socat": "socat", "tcpdump": "tcpdump",
    "bettercap": "bettercap", "beef": "beef-xss",
    "theharvester": "theharvester", "recon-ng": "recon-ng",
    "shodan": "chrome https://shodan.io",
    "censys": "chrome https://censys.io",
}

UWP_PREFIXES = ["shell:AppsFolder\\", "ms-settings:", "shell:"]
PS = r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"


def is_uwp(path):
    return any(path.startswith(p) for p in UWP_PREFIXES)


def open_app(app_name: str) -> str:
    name = app_name.lower().strip()
    search = APP_ALIASES.get(name)
    if not search:
        for key, value in APP_ALIASES.items():
            if name in key or key in name:
                search = value; break
    if not search: search = name
    try:
        if IS_WINDOWS:
            if is_uwp(search):
                subprocess.Popen([PS, "-NoProfile", "-WindowStyle", "Hidden",
                                "-Command", f"Start-Process '{search}'"],
                                creationflags=subprocess.CREATE_NO_WINDOW)
                return f"✅ {app_name} opened!"
            subprocess.Popen(["cmd", "/c", "start", "", search],
                           shell=False, creationflags=subprocess.CREATE_NO_WINDOW)
            return f"✅ {app_name} opened!"
        else:
            subprocess.Popen(search.split(), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return f"✅ {app_name} opened!"
    except:
        try:
            subprocess.Popen(search, shell=True, creationflags=subprocess.CREATE_NO_WINDOW)
            return f"✅ {app_name} opened!"
        except:
            if IS_WINDOWS:
                try:
                    cmd = f"(Get-AppxPackage -Name *{search}*).PackageFamilyName"
                    r = subprocess.run([PS, "-NoProfile", "-Command", cmd],
                                     capture_output=True, text=True, timeout=6)
                    pkg = r.stdout.strip()
                    if pkg:
                        subprocess.Popen([PS, "-NoProfile", "-WindowStyle", "Hidden",
                                        "-Command", f"Start-Process 'shell:AppsFolder\\{pkg}!App'"],
                                        creationflags=subprocess.CREATE_NO_WINDOW)
                        return f"✅ {app_name} opened via UWP!"
                except: pass
    return f"❌ Could not open {app_name}"


def close_app(app_name: str) -> str:
    name = app_name.lower().strip()
    pmap = {
        "chrome": "chrome.exe", "firefox": "firefox.exe",
        "discord": "Discord.exe", "spotify": "Spotify.exe",
        "vlc": "vlc.exe", "code": "Code.exe",
        "whatsapp": "WhatsApp.exe", "telegram": "Telegram.exe",
        "notepad": "notepad.exe", "cmd": "cmd.exe",
        "explorer": "explorer.exe", "edge": "msedge.exe",
        "word": "WINWORD.EXE", "excel": "EXCEL.EXE",
        "powerpoint": "POWERPNT.EXE", "outlook": "OUTLOOK.EXE",
    }
    pname = pmap.get(name, name + (".exe" if IS_WINDOWS else ""))
    try:
        if IS_WINDOWS:
            subprocess.run(["taskkill", "/f", "/im", pname],
                          capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW)
        else:
            subprocess.run(["pkill", "-f", name], capture_output=True)
        return f"🛑 {app_name} closed!"
    except: return f"❌ Could not close {app_name}"


def get_system_info() -> Dict[str, Any]:
    from datetime import datetime, timedelta
    uname = platform.uname()
    bt = datetime.fromtimestamp(psutil.boot_time())
    disk = psutil.disk_usage('/')
    net = psutil.net_io_counters()
    return {
        "system": uname.system, "node": uname.node, "release": uname.release,
        "machine": uname.machine, "processor": uname.processor,
        "boot_time": bt.strftime("%Y-%m-%d %H:%M:%S"),
        "uptime": str(timedelta(seconds=int(time.time() - psutil.boot_time()))),
        "cpu_cores": psutil.cpu_count(logical=True),
        "cpu_percent": psutil.cpu_percent(interval=1),
        "ram_total_gb": psutil.virtual_memory().total // (1024**3),
        "ram_percent": psutil.virtual_memory().percent,
        "disk_total_gb": disk.total // (1024**3),
        "disk_percent": disk.percent,
        "net_sent_mb": net.bytes_sent // (1024**2),
        "net_recv_mb": net.bytes_recv // (1024**2),
    }


def execute_command(command: str, timeout: int = 30) -> str:
    try:
        shell = ["cmd", "/c"] if IS_WINDOWS else ["bash", "-c"]
        result = subprocess.run(shell + [command], capture_output=True, text=True, timeout=timeout,
                               creationflags=subprocess.CREATE_NO_WINDOW if IS_WINDOWS else 0)
        out, err = result.stdout.strip(), result.stderr.strip()
        if out and err: return f"Output:\n{out}\n\nError:\n{err}"
        return out or err or "[No output]"
    except subprocess.TimeoutExpired: return "[Timeout]"
    except Exception as e: return f"[Err] {e}"


def execute_powershell(command: str) -> str:
    if not IS_WINDOWS: return "[Err] Windows only"
    try:
        r = subprocess.run([PS, "-NoProfile", "-Command", command],
                          capture_output=True, text=True, timeout=30,
                          creationflags=subprocess.CREATE_NO_WINDOW)
        return r.stdout.strip() or r.stderr.strip() or "[No output]"
    except Exception as e: return f"[Err] {e}"


def take_screenshot() -> str:
    try:
        from PIL import ImageGrab
        from datetime import datetime
        save_path = Path.home() / "Desktop" / "rasheed_screenshots"
        save_path.mkdir(parents=True, exist_ok=True)
        fp = save_path / f"screenshot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        ImageGrab.grab().save(fp)
        return str(fp)
    except:
        try:
            import mss; from datetime import datetime
            save_path = Path.home() / "Desktop" / "rasheed_screenshots"
            save_path.mkdir(parents=True, exist_ok=True)
            fp = save_path / f"screenshot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
            with mss.mss() as sct: sct.shot(output=str(fp))
            return str(fp)
        except: return None


def get_public_ip() -> str:
    try:
        import requests
        r = requests.get("https://api.ipify.org?format=json", timeout=5)
        return r.json().get("ip", "Unknown")
    except: return "Cannot determine"


def wifi_passwords() -> List[Dict[str, str]]:
    if not IS_WINDOWS: return []
    results = []
    try:
        out = subprocess.run(["netsh", "wlan", "show", "profiles"],
                           capture_output=True, text=True,
                           creationflags=subprocess.CREATE_NO_WINDOW).stdout
        profiles = [l.split(':')[1].strip() for l in out.split('\n') if "All User Profile" in l]
        for p in profiles:
            r = subprocess.run(["netsh", "wlan", "show", "profile", p, "key=clear"],
                             capture_output=True, text=True,
                             creationflags=subprocess.CREATE_NO_WINDOW).stdout
            for l in r.split('\n'):
                if "Key Content" in l:
                    results.append({"ssid": p, "password": l.split(':')[1].strip()})
                    break
        return results
    except: return results


def lock_workstation() -> str:
    if IS_WINDOWS:
        subprocess.run(["rundll32.exe", "user32.dll,LockWorkStation"],
                      creationflags=subprocess.CREATE_NO_WINDOW)
    return "🔒 Locked"


def shutdown_system(delay: int = 60) -> str:
    if IS_WINDOWS:
        subprocess.run(["shutdown", "/s", "/t", str(delay)],
                      creationflags=subprocess.CREATE_NO_WINDOW)
    else: subprocess.run(["shutdown", "-h", f"+{delay//60}"])
    return f"🖥️ Shutting down in {delay}s"


def restart_system(delay: int = 60) -> str:
    if IS_WINDOWS:
        subprocess.run(["shutdown", "/r", "/t", str(delay)],
                      creationflags=subprocess.CREATE_NO_WINDOW)
    else: subprocess.run(["reboot"])
    return f"🔄 Restarting in {delay}s"


def type_text(text: str) -> str:
    try:
        import pyautogui
        pyautogui.write(text, interval=0.03)
        return f"⌨️ Typed ({len(text)} chars)"
    except:
        escaped = text.replace("'", "''").replace("\n", "{ENTER}")
        execute_powershell(f"""
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.SendKeys]::SendWait('{escaped}')
        """)
        return f"⌨️ Typed ({len(text)} chars)"


def press_keys(keys: str) -> str:
    try:
        import pyautogui
        pyautogui.hotkey(*keys.split('+'))
        return f"⌨️ {keys}"
    except:
        kmap = {
            "ctrl+c": "^c", "ctrl+v": "^v", "ctrl+x": "^x",
            "ctrl+z": "^z", "ctrl+a": "^a", "ctrl+s": "^s",
            "alt+tab": "%{tab}", "alt+f4": "%{F4}",
            "enter": "{ENTER}", "tab": "{TAB}", "escape": "{ESC}",
            "win+d": "^{d}", "win+r": "^{r}",
        }
        ps = kmap.get(keys.lower(), keys)
        execute_powershell(f"""
        Add-Type -AssemblyName System.Windows.Forms
        [System.Windows.Forms.SendKeys]::SendWait('{ps}')
        """)
        return f"⌨️ {keys}"


def run_python(code: str) -> str:
    import io, contextlib
    out, err = io.StringIO(), io.StringIO()
    ns = {'__builtins__': __builtins__, 'os': os, 'sys': sys, 'json': json,
          'time': time, 're': re, 'subprocess': subprocess, 'Path': Path, 'psutil': psutil}
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        try:
            exec(code, ns)
            output, error = out.getvalue(), err.getvalue()
            return f"Output:\n{output}\n{error}" if error else output or "[Done - no output]"
        except Exception as e: return f"Error: {e}"


def record_audio(duration: int = 5) -> str:
    try:
        import sounddevice as sd, scipy.io.wavfile as wav, numpy as np
        from datetime import datetime
        save_path = Path.home() / "Desktop" / "rasheed_audio"
        save_path.mkdir(parents=True, exist_ok=True)
        fp = save_path / f"audio_{datetime.now().strftime('%Y%m%d_%H%M%S')}.wav"
        rec = sd.rec(int(duration * 16000), samplerate=16000, channels=1, dtype='int16')
        sd.wait()
        wav.write(fp, 16000, rec)
        return f"🎤 Audio saved: {fp}"
    except Exception as e: return f"Recording error: {e}"


def capture_webcam() -> str:
    try:
        import cv2
        from datetime import datetime
        save_path = Path.home() / "Desktop" / "rasheed_captures"
        save_path.mkdir(parents=True, exist_ok=True)
        cap = cv2.VideoCapture(0)
        ret, frame = cap.read()
        cap.release()
        if not ret: return "❌ Cannot capture"
        fp = save_path / f"webcam_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg"
        cv2.imwrite(str(fp), frame)
        return f"📷 Webcam: {fp}"
    except: return "Webcam unavailable"


def volume_control(action: str) -> str:
    try:
        if IS_WINDOWS:
            kmap = {"up": 175, "down": 174, "mute": 173, "unmute": 173}
            if action in kmap:
                subprocess.run([PS, "-NoProfile", "-Command",
                    f"$o=new-object -com wscript.shell; $o.SendKeys([char]{kmap[action]})"],
                    capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW)
            elif action in ("mute", "unmute"):
                execute_powershell("$o=new-object -com wscript.shell; $o.SendKeys([char]173)")
        else:
            subprocess.run(["amixer"] + [["set","Master","toggle"],
                           ["set","Master","5%+"],["set","Master","5%-"]][
                ["mute","up","down"].index(action) if action in ["mute","up","down"] else 0
            ], capture_output=True)
        return f"🔊 Volume: {action}"
    except Exception as e: return f"Volume error: {e}"