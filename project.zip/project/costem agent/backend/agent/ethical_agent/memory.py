"""
RASHEED AI — Memory Management System
Short-term, long-term, and vector memory with auto-learning
"""
import json
import time
import os
import sqlite3
import threading
import numpy as np
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime
from collections import deque
try:
    from config.settings import DATA_DIR, MEMORY_FILE, VECTOR_MEMORY_DIR, MAX_MEMORY_ITEMS
except:
    DATA_DIR = Path.home() / "Desktop" / "rasheed" / "data"
    MEMORY_FILE = DATA_DIR / "memory.json"
    VECTOR_MEMORY_DIR = DATA_DIR / "vector_memory"
    MAX_MEMORY_ITEMS = 1000

DATA_DIR.mkdir(parents=True, exist_ok=True)
VECTOR_MEMORY_DIR.mkdir(parents=True, exist_ok=True)


class MemoryManager:
    """Manages all memory types for RASHEED"""

    def __init__(self):
        self.lock = threading.Lock()
        self.short_term = deque(maxlen=50)
        self.long_term = {}
        self.conversation_history = []
        self.learned_skills = {}
        self.last_access = {}
        self._load()

    def _load(self):
        """Load memory from disk"""
        try:
            if MEMORY_FILE.exists():
                data = json.loads(MEMORY_FILE.read_text(encoding='utf-8'))
                self.long_term = data.get('long_term', {})
                self.conversation_history = data.get('conversations', [])
                self.learned_skills = data.get('skills', {})
        except: pass

    def _save(self):
        """Save memory to disk"""
        try:
            data = {
                'long_term': self.long_term,
                'conversations': self.conversation_history[-500:],  # Keep last 500
                'skills': self.learned_skills,
                'updated': datetime.now().isoformat()
            }
            MEMORY_FILE.write_text(json.dumps(data, indent=2, default=str), encoding='utf-8')
        except: pass

    def add_conversation(self, role: str, content: str):
        """Add conversation to memory"""
        with self.lock:
            entry = {
                'role': role,
                'content': content[:1000],
                'timestamp': datetime.now().isoformat()
            }
            self.conversation_history.append(entry)
            self.short_term.append(entry)

            # Auto-save every 10 interactions
            if len(self.conversation_history) % 10 == 0:
                self._save()

    def get_context(self, limit: int=10) -> str:
        """Get recent conversation context"""
        with self.lock:
            recent = list(self.conversation_history)[-limit:]
            return self._format_conversations(recent)

    def _format_conversations(self, conversations: List[Dict]) -> str:
        lines = []
        for c in conversations:
            emoji = "🤖" if c['role'] == 'assistant' else "👤"
            lines.append(f"{emoji} {c['role'].upper()}: {c['content'][:200]}")
        return "\n".join(lines)

    def remember(self, key: str, value: Any):
        """Store something in long-term memory"""
        with self.lock:
            self.long_term[key] = {
                'value': value,
                'timestamp': datetime.now().isoformat(),
                'access_count': 0
            }
            self._save()

    def recall(self, key: str) -> Optional[Any]:
        """Retrieve from long-term memory"""
        with self.lock:
            if key in self.long_term:
                self.long_term[key]['access_count'] += 1
                self.long_term[key]['last_accessed'] = datetime.now().isoformat()
                return self.long_term[key]['value']
            # Partial match
            for k, v in self.long_term.items():
                if key.lower() in k.lower():
                    v['access_count'] += 1
                    return v['value']
            return None

    def search_memory(self, query: str) -> List[Dict]:
        """Search all memory for relevant information"""
        results = []
        query = query.lower()

        # Search long-term memory
        for key, data in self.long_term.items():
            if query in key.lower() or query in str(data.get('value', '')).lower():
                results.append({
                    'type': 'long_term',
                    'key': key,
                    'value': str(data['value'])[:200],
                    'timestamp': data.get('timestamp', '')
                })

        # Search conversations
        for c in self.conversation_history:
            if query in c['content'].lower():
                results.append({
                    'type': 'conversation',
                    'role': c['role'],
                    'content': c['content'][:200],
                    'timestamp': c.get('timestamp', '')
                })

        return results[:20]

    def learn_skill(self, name: str, code: str):
        """Learn a new skill/capability"""
        with self.lock:
            self.learned_skills[name] = {
                'code': code,
                'learned': datetime.now().isoformat(),
                'used': 0
            }
            self._save()

    def get_skills(self) -> Dict:
        """Get all learned skills"""
        return self.learned_skills

    def get_stats(self) -> str:
        """Get memory statistics"""
        return (f"🧠 Memory Stats:\n"
                f"  Conversations: {len(self.conversation_history)}\n"
                f"  Long-term items: {len(self.long_term)}\n"
                f"  Skills learned: {len(self.learned_skills)}\n"
                f"  Short-term buffer: {len(self.short_term)}")


class VectorMemory:
    """Simple vector-based memory for semantic search"""

    def __init__(self):
        self.vectors = {}
        self.data = {}
        self._load()

    def _load(self):
        try:
            vec_file = VECTOR_MEMORY_DIR / "vectors.json"
            data_file = VECTOR_MEMORY_DIR / "data.json"
            if vec_file.exists():
                self.vectors = json.loads(vec_file.read_text())
            if data_file.exists():
                self.data = json.loads(data_file.read_text())
        except: pass

    def _save(self):
        try:
            VECTOR_MEMORY_DIR.mkdir(parents=True, exist_ok=True)
            (VECTOR_MEMORY_DIR / "vectors.json").write_text(json.dumps(self.vectors, default=str))
            (VECTOR_MEMORY_DIR / "data.json").write_text(json.dumps(self.data, default=str))
        except: pass

    def store(self, text: str, metadata: Dict=None):
        """Store text with simple hash-based vector"""
        import hashlib
        doc_id = hashlib.md5(text.encode()).hexdigest()[:8]
        self.data[doc_id] = {"text": text[:500], "metadata": metadata or {}, "timestamp": datetime.now().isoformat()}
        self._save()

    def search(self, query: str, top_k: int=5) -> List[Dict]:
        """Simple keyword-based search"""
        query = query.lower()
        results = []
        for doc_id, doc in self.data.items():
            score = 0
            for word in query.split():
                if word in doc['text'].lower():
                    score += 1
            if score > 0:
                results.append({"id": doc_id, "text": doc['text'][:200], "score": score, **doc['metadata']})
        return sorted(results, key=lambda x: x['score'], reverse=True)[:top_k]

    def get_stats(self) -> str:
        return f"  📚 Vector Memory: {len(self.data)} documents"
