"""
RASHEED AI MARK XXVI — ULTIMATE HACKER EDITION
Voice + Screen Vision + Typing + Multi-API + Hacking Engine
"""
import hacking_tools
import asyncio
import base64
import json
import os
import sys
import time
import threading
import queue as _queue
import random
import subprocess
import platform
from pathlib import Path
from datetime import datetime

import numpy as np
import sounddevice as sd
import websockets

# ── Local Imports ──
try:
    from config.settings import (
        API_KEYS, GEMINI_WS_URL, GEMINI_MODEL, GEMINI_VOICE,
        MIC_RATE, SPK_RATE, FRAMES, SCREEN_CAPTURE_FPS, SCREEN_CAPTURE_QUALITY,
        MAX_TOOL_OUTPUT_LENGTH, USE_KALI, USE_TOR, TOOL_CATEGORIES
    )
    from prompt import RASHEED_PROMPT
    import app as app_module
    import hacking_tools as hack
    from memory import MemoryManager, VectorMemory
except ImportError as e:
    print(f"[WARN] Import error: {e} — using fallback configs")
    API_KEYS = {
        "gemini": "AIzaSyAogD9CiO9utuWrO3ezRXTnTvBljqingn0",
        "openai": "sk-abcd1234abcd1234abcd1234abcd1234abcd1234",
        "groq": "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",
    }
    GEMINI_WS_URL = ("wss://generativelanguage.googleapis.com/ws/"
                     "google.ai.generativelanguage.v1beta."
                     "GenerativeService.BidiGenerateContent")
    GEMINI_MODEL = "models/gemini-2.5-flash-native-audio-preview-12-2025"
    GEMINI_VOICE = "Puck"
    MIC_RATE, SPK_RATE, FRAMES = 16000, 24000, int(16000 * 20 / 1000)
    app_module = None
    hack = None
    MemoryManager = None

# ── Tool Declarations ──
TOOL_DECLARATIONS = [
    {
        "name": "open_app",
        "description": "Open any application: chrome, firefox, vscode, notepad, cmd, kali, whatsapp, spotify, etc.",
        "parameters": {"type": "object", "properties": {"app_name": {"type": "string"}}, "required": ["app_name"]}
    },
    {
        "name": "close_app",
        "description": "Close any application by name",
        "parameters": {"type": "object", "properties": {"app_name": {"type": "string"}}, "required": ["app_name"]}
    },
    {
        "name": "execute_command",
        "description": "Execute any system command",
        "parameters": {"type": "object", "properties": {"command": {"type": "string"}, "timeout": {"type": "integer"}}, "required": ["command"]}
    },
    {
        "name": "run_python",
        "description": "Execute Python code and return the output",
        "parameters": {"type": "object", "properties": {"code": {"type": "string"}}, "required": ["code"]}
    },
    {
        "name": "port_scan",
        "description": "Scan ports on a target (IP or domain)",
        "parameters": {"type": "object", "properties": {"target": {"type": "string"}, "ports": {"type": "string"}, "scan_type": {"type": "string"}}, "required": ["target"]}
    },
    {
        "name": "directory_scan",
        "description": "Discover directories/files on a web server",
        "parameters": {"type": "object", "properties": {"url": {"type": "string"}}, "required": ["url"]}
    },
    {
        "name": "generate_payload",
        "description": "Generate reverse shell/bind shell/payload for security testing",
        "parameters": {"type": "object", "properties": {
            "payload_type": {"type": "string"},
            "lhost": {"type": "string"},
            "lport": {"type": "integer"}
        }, "required": ["payload_type", "lhost", "lport"]}
    },
    {
        "name": "sql_injection_test",
        "description": "Test a URL for SQL injection vulnerability",
        "parameters": {"type": "object", "properties": {"url": {"type": "string"}, "param": {"type": "string"}}, "required": ["url"]}
    },
    {
        "name": "xss_test",
        "description": "Test a URL for XSS vulnerability",
        "parameters": {"type": "object", "properties": {"url": {"type": "string"}, "param": {"type": "string"}}, "required": ["url"]}
    },
    {
        "name": "search_exploit",
        "description": "Search Exploit-DB for exploits by keyword",
        "parameters": {"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]}
    },
    {
        "name": "crack_hash",
        "description": "Attempt to crack a hash (md5, sha1, sha256)",
        "parameters": {"type": "object", "properties": {"hash_value": {"type": "string"}, "hash_type": {"type": "string"}}, "required": ["hash_value", "hash_type"]}
    },
    {
        "name": "kali_tool",
        "description": "Run a Kali Linux tool via WSL",
        "parameters": {"type": "object", "properties": {"tool": {"type": "string"}, "args": {"type": "string"}}, "required": ["tool"]}
    },
    {
        "name": "take_screenshot",
        "description": "Take a screenshot of the screen",
        "parameters": {"type": "object", "properties": {}}
    },
    {
        "name": "get_public_ip",
        "description": "Get the public IP address of this machine",
        "parameters": {"type": "object", "properties": {}}
    },
    {
        "name": "lock_workstation",
        "description": "Lock the workstation",
        "parameters": {"type": "object", "properties": {}}
    },
    {
        "name": "type_text",
        "description": "Type text automatically (like human typing)",
        "parameters": {"type": "object", "properties": {"text": {"type": "string"}}, "required": ["text"]}
    },
    {
        "name": "press_keys",
        "description": "Press keyboard combination (e.g., ctrl+c, alt+tab, win+d)",
        "parameters": {"type": "object", "properties": {"keys": {"type": "string"}}, "required": ["keys"]}
    },
    {
        "name": "osint_gather",
        "description": "Gather OSINT on email, domain, or username",
        "parameters": {"type": "object", "properties": {
            "target_type": {"type": "string", "enum": ["email", "domain", "username"]},
            "target": {"type": "string"}
        }, "required": ["target_type", "target"]}
    },
    {
        "name": "check_privesc",
        "description": "Check for privilege escalation vulnerabilities",
        "parameters": {"type": "object", "properties": {"os_type": {"type": "string", "enum": ["windows", "linux"]}}, "required": ["os_type"]}
    },
    {
        "name": "generate_phishing_page",
        "description": "Generate a phishing page for security testing",
        "parameters": {"type": "object", "properties": {"target_site": {"type": "string"}}, "required": ["target_site"]}
    },
    {
        "name": "wifi_passwords",
        "description": "Retrieve saved WiFi passwords",
        "parameters": {"type": "object", "properties": {}}
    },
    {
        "name": "scan_wifi",
        "description": "Scan for nearby WiFi networks",
        "parameters": {"type": "object", "properties": {}}
    },
    {
        "name": "exploit_sqli",
        "description": "Exploit SQL injection to extract data",
        "parameters": {"type": "object", "properties": {"url": {"type": "string"}, "param": {"type": "string"}}, "required": ["url", "param"]}
    },
    {
        "name": "shutdown",
        "description": "Shutdown the computer",
        "parameters": {"type": "object", "properties": {"delay": {"type": "integer"}}}
    },
    {
        "name": "restart",
        "description": "Restart the computer",
        "parameters": {"type": "object", "properties": {"delay": {"type": "integer"}}}
    },
    {
        "name": "save_memory",
        "description": "Save something to long-term memory",
        "parameters": {"type": "object", "properties": {"key": {"type": "string"}, "value": {"type": "string"}}, "required": ["key", "value"]}
    },
    {
        "name": "recall_memory",
        "description": "Recall something from long-term memory",
        "parameters": {"type": "object", "properties": {"key": {"type": "string"}}, "required": ["key"]}
    },
    {
        "name": "search_memory",
        "description": "Search all memory for something",
        "parameters": {"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]}
    },
    {
        "name": "record_audio",
        "description": "Record audio from microphone",
        "parameters": {"type": "object", "properties": {"duration": {"type": "integer"}}}
    },
    {
        "name": "capture_webcam",
        "description": "Capture an image from webcam",
        "parameters": {"type": "object", "properties": {}}
    },
    {
        "name": "volume_control",
        "description": "Control system volume: up, down, mute",
        "parameters": {"type": "object", "properties": {"action": {"type": "string", "enum": ["up", "down", "mute"]}}, "required": ["action"]}
    },
    {
        "name": "dns_enum",
        "description": "DNS enumeration for a domain",
        "parameters": {"type": "object", "properties": {"domain": {"type": "string"}}, "required": ["domain"]}
    },
    {
        "name": "subdomain_scan",
        "description": "Discover subdomains of a domain",
        "parameters": {"type": "object", "properties": {"domain": {"type": "string"}}, "required": ["domain"]}
    },
    {
        "name": "check_vulnerability",
        "description": "Auto-detect vulnerabilities on a target URL",
        "parameters": {"type": "object", "properties": {"target": {"type": "string"}}, "required": ["target"]}
    },
]

# ── Setup Payload ──
SETUP = {
    "setup": {
        "model": GEMINI_MODEL,
        "generation_config": {
            "temperature": 0.85,
            "response_modalities": ["AUDIO"],
            "speech_config": {
                "voice_config": {
                    "prebuilt_voice_config": {"voice_name": GEMINI_VOICE}
                }
            }
        },
        "input_audio_transcription": {},
        "output_audio_transcription": {},
        "system_instruction": {"parts": [{"text": RASHEED_PROMPT}]},
        "tools": [{"functionDeclarations": TOOL_DECLARATIONS}]
    }
}


# ── Helper: Encode JSON ──
def enc(x):
    return json.dumps(x).encode()


# ── Extract transcript from message ──
def get_user_transcript(msg: dict) -> str:
    sc = msg.get("serverContent", {})
    t = sc.get("inputTranscription", {})
    if isinstance(t, dict) and t.get("text", "").strip():
        return t["text"].strip()
    t2 = sc.get("inputTranscript", "")
    if isinstance(t2, str) and t2.strip():
        return t2.strip()
    return ""


# ── Tool Execution ──
def execute_tool(name: str, args: dict) -> str:
    """Execute a tool by name with given arguments"""
    try:
        if name == "open_app":
            return app_module.open_app(args.get("app_name", ""))
        elif name == "close_app":
            return app_module.close_app(args.get("app_name", ""))
        elif name == "execute_command":
            return app_module.execute_command(args.get("command", ""), args.get("timeout", 30))
        elif name == "run_python":
            return app_module.run_python(args.get("code", ""))
        elif name == "port_scan":
            if hack:
                r = hack.port_scan(args.get("target", ""), args.get("ports", "1-1024"), args.get("scan_type", "tcp"))
                open_ports = r.get("open_ports", [])
                if open_ports:
                    return f"✅ Open ports on {args['target']}:\n" + "\n".join(
                        [f"  Port {p['port']}/{p['protocol']} - {p['service']}" for p in open_ports])
                return f"❌ No open ports found on {args['target']} in range {args.get('ports','1-1024')}"
            return "Hacking tools not loaded"
        elif name == "directory_scan":
            if hack:
                r = hack.directory_scan(args.get("url", ""))
                found = r.get("found", [])
                if found:
                    return f"📁 Found {len(found)} directories:\n" + "\n".join(found[:20])
                return f"❌ No directories found on {args['url']}"
            return "Hacking tools not loaded"
        elif name == "generate_payload":
            if hack:
                r = hack.generate_payload(args.get("payload_type", "python_reverse"),
                                          args.get("lhost", "127.0.0.1"), args.get("lport", 4444))
                return f"🔧 Payload generated!\nType: {r['type']}\nFile: {r.get('file', 'N/A')}\nInstructions: {r['instructions']}\n\nPayload:\n{r['payload'][:1000]}"
            return "Hacking tools not loaded"
        elif name == "sql_injection_test":
            if hack:
                r = hack.sql_injection_test(args.get("url", ""), args.get("param", "id"))
                if r.get("vulnerable"):
                    return f"🔥 SQL INJECTION FOUND! Param: {r['param']}\nPayloads: {r['payloads']}"
                return f"✅ No SQL injection found on {r['url']}"
            return "Hacking tools not loaded"
        elif name == "xss_test":
            if hack:
                r = hack.xss_test(args.get("url", ""), args.get("param", "q"))
                if r.get("vulnerable"):
                    return f"🔥 XSS FOUND! Payloads reflected on page"
                return f"✅ No XSS found"
            return "Hacking tools not loaded"
        elif name == "search_exploit":
            if hack:
                r = hack.search_exploit(args.get("query", ""))
                return "Exploits found:\n" + "\n".join([str(e)[:200] for e in r[:10]])
            return "Hacking tools not loaded"
        elif name == "crack_hash":
            if hack:
                r = hack.crack_hash(args.get("hash_value", ""), args.get("hash_type", "md5"))
                if r.get("found"):
                    return f"✅ Hash cracked! Password: {r['password']}"
                return f"❌ Could not crack hash (tried common passwords)"
            return "Hacking tools not loaded"
        elif name == "kali_tool":
            if hack:
                return hack.kali_tool(args.get("tool", ""), args.get("args", ""))
            return "Kali tools not available"
        elif name == "take_screenshot":
            fp = app_module.take_screenshot()
            if fp:
                return f"📸 Screenshot saved: {fp}"
            return "❌ Screenshot failed"
        elif name == "get_public_ip":
            ip = app_module.get_public_ip()
            return f"🌐 Public IP: {ip}"
        elif name == "lock_workstation":
            return app_module.lock_workstation()
        elif name == "type_text":
            return app_module.type_text(args.get("text", ""))
        elif name == "press_keys":
            return app_module.press_keys(args.get("keys", ""))
        elif name == "osint_gather":
            if hack:
                r = hack.osint_gather(args.get("target_type", ""), args.get("target", ""))
                return json.dumps(r, indent=2, default=str)
            return "OSINT tools not loaded"
        elif name == "check_privesc":
            if hack:
                os_type = args.get("os_type", "windows")
                if os_type == "windows":
                    r = hack.check_privesc_windows()
                else:
                    r = hack.check_privesc_linux()
                return f"🔍 Privilege Escalation Check ({os_type}):\n" + json.dumps(r, indent=2, default=str)
            return "Privesc tools not loaded"
        elif name == "generate_phishing_page":
            if hack:
                r = hack.generate_phishing_page(args.get("target_site", ""))
                return f"🎣 Phishing page generated for {r['target']}\nSaved to: {r['saved_to']}\n{r['instructions']}"
            return "Phishing tools not loaded"
        elif name == "wifi_passwords":
            if app_module:
                pw = app_module.wifi_passwords()
                if pw:
                    return "🔑 Saved WiFi passwords:\n" + "\n".join([f"  {p['ssid']}: {p['password']}" for p in pw])
                return "No WiFi passwords found"
            return "WiFi tools not available"
        elif name == "scan_wifi":
            if hack:
                r = hack.scan_wifi()
                nets = r.get("networks", [])
                if nets:
                    return "📡 WiFi Networks:\n" + "\n".join([f"  {n['ssid']}" for n in nets[:20]])
                return f"No networks found. Error: {r.get('error', 'N/A')}"
            return "WiFi scan not available"
        elif name == "exploit_sqli":
            if hack:
                r = hack.exploit_sqli(args.get("url", ""), args.get("param", "id"))
                if r.get("success"):
                    return f"🔥 SQL Injection exploited!\nColumns: {r.get('column_count')}\nData:\n" + "\n".join([f"  {d['info']}: {d['value'][:200]}" for d in r.get('data', [])])
                return f"❌ Exploitation failed: {r.get('error', 'Unknown')}"
            return "Hacking tools not loaded"
        elif name == "shutdown":
            return app_module.shutdown_system(args.get("delay", 60))
        elif name == "restart":
            return app_module.restart_system(args.get("delay", 60))
        elif name == "save_memory":
            if 'memory' in dir() and memory:
                memory.remember(args.get("key", ""), args.get("value", ""))
                return f"💾 Saved to memory: {args.get('key', '')}"
            return "Memory not available"
        elif name == "recall_memory":
            if 'memory' in dir() and memory:
                val = memory.recall(args.get("key", ""))
                return f"🧠 Memory: {args.get('key', '')} = {val}" if val else f"❌ Nothing found for: {args.get('key', '')}"
            return "Memory not available"
        elif name == "search_memory":
            if 'memory' in dir() and memory:
                r = memory.search_memory(args.get("query", ""))
                if r:
                    return "🔍 Memory results:\n" + "\n".join([f"  {m['type']}: {m.get('key', m.get('content', ''))[:100]}" for m in r[:5]])
                return "No memory matches"
            return "Memory not available"
        elif name == "record_audio":
            return app_module.record_audio(args.get("duration", 5))
        elif name == "capture_webcam":
            return app_module.capture_webcam()
        elif name == "volume_control":
            return app_module.volume_control(args.get("action", "mute"))
        elif name == "dns_enum":
            if hack:
                r = hack.dns_enum(args.get("domain", ""))
                records = r.get("records", {})
                if records:
                    return f"🌐 DNS Records for {r['domain']}:\n" + "\n".join([f"  {k}: {v}" for k, v in records.items()])
                return f"No DNS records found for {r['domain']}"
            return "DNS tools not loaded"
        elif name == "subdomain_scan":
            if hack:
                subs = hack.subdomain_scan(args.get("domain", ""))
                if subs:
                    return f"🔍 Subdomains found:\n" + "\n".join(subs[:20])
                return f"No subdomains found"
            return "Subdomain tools not loaded"
        elif name == "check_vulnerability":
            if hack:
                r = hack.check_vulnerability(args.get("target", ""))
                findings = r.get("findings", [])
                if findings:
                    return f"🔥 VULNERABILITIES FOUND:\n" + json.dumps(findings, indent=2)
                return f"✅ No obvious vulnerabilities found on {r['target']}"
            return "Hacking tools not loaded"
        else:
            return f"❌ Unknown tool: {name}"

    except Exception as e:
        return f"❌ Tool error [{name}]: {str(e)}"

# ═══════════════════════════════════════════════════════════════════
# RASHEED CLASS — Main AI Engine
# ═══════════════════════════════════════════════════════════════════


class RASHEED:

    def __init__(self):
        print("⚡ RASHEED AI MARK XXVI — ULTIMATE HACKER EDITION")
        print("=" * 60)

        # Initialize memory
        print("  🧠 Loading Memory...")
        try:
            global memory
            from memory import MemoryManager, VectorMemory
            self.memory = MemoryManager()
            self.vector_memory = VectorMemory()
            memory = self.memory  # For global access
        except Exception as e:
            print(f"  ⚠️ Memory init failed: {e}")
            self.memory = None

        # Voice & audio state
        self.running = True
        self._ws = None
        self.cap = None

        # Vision state
        self.screen_enabled = False
        self.webcam_enabled = False

        # Conversation tracking
        self.conversation_history = []
        self.last_tool_results = {}

        print(f"  🔧 Tools: {len(TOOL_DECLARATIONS)} available")
        print(f"  🎤 Voice: Active | 👁️ Screen: Active | ⌨️ Text: Active")
        print("=" * 60)
        print()

    # ── Start main loop ──
    async def start(self):
        retry = 0
        while self.running:
            try:
                await self._session()
                retry = 0
            except Exception as e:
                retry += 1
                wait = min(2 ** retry, 30)
                print(f"\n[!] Reconnecting in {wait}s... ({e})")
                await asyncio.sleep(wait)

    # ── WebSocket session ──
    async def _session(self):
        api_key = API_KEYS.get("gemini", "")
        if not api_key:
            print("❌ No Gemini API key found!")
            return

        async with websockets.connect(
            f"{GEMINI_WS_URL}?key={api_key}",
            max_size=None,
            ping_interval=20,
            ping_timeout=30,
            compression=None,
        ) as ws:
            self._ws = ws
            print("\n✅ RASHEED Connected! Bol bhai kya karna hai? 🔥\n")

            await ws.send(enc(SETUP))
            await ws.recv()
            print("✅ Setup complete — Voice + Vision + Typing active")

            # Audio playback
            audio_q = _queue.Queue()
            play_stop = threading.Event()

            def _play_thread():
                BUF = int(SPK_RATE * 0.20)
                buf = np.array([], dtype=np.float32)
                stream = sd.OutputStream(samplerate=SPK_RATE, channels=1, dtype="float32", blocksize=BUF, latency="high")
                stream.start()
                while not play_stop.is_set():
                    try:
                        chunk = audio_q.get(timeout=0.15)
                        if chunk is None: continue
                        buf = np.concatenate([buf, chunk])
                        while len(buf) >= BUF:
                            stream.write(buf[:BUF])
                            buf = buf[BUF:]
                    except _queue.Empty: pass
                stream.stop(); stream.close()

            play_t = threading.Thread(target=_play_thread, daemon=True)
            play_t.start()

            # Webcam init
            try:
                import cv2
                self.cap = cv2.VideoCapture(0)
                self.webcam_enabled = self.cap.isOpened()
                if not self.webcam_enabled:
                    print("⚠️ No webcam detected. Screen sharing will be used.")
                else:
                    print("📷 Webcam ready")
            except:
                self.cap = None
                print("⚠️ Webcam disabled (OpenCV not installed)")

            try:
                await asyncio.gather(
                    self._send_audio(ws),
                    self._send_screen(ws),
                    self._send_webcam(ws),
                    self._recv(ws, audio_q),
                    self._text_input(ws),
                )
            finally:
                play_stop.set()
                audio_q.put(None)
                play_t.join(timeout=2.0)
                if self.cap:
                    self.cap.release()

    # ── Audio sending ──
    async def _send_audio(self, ws):
        with sd.InputStream(samplerate=MIC_RATE, channels=1, dtype="int16", blocksize=FRAMES, latency="low") as mic:
            print("🎤 Listening... Speak your commands!\n")
            while self.running:
                pcm, _ = mic.read(FRAMES)
                await ws.send(enc({
                    "realtimeInput": {
                        "audio": {
                            "mimeType": "audio/pcm;rate=16000",
                            "data": base64.b64encode(pcm.tobytes()).decode()
                        }
                    }
                }))
                await asyncio.sleep(0.001)

    # ── Screen sharing (1 FPS) ──
    async def _send_screen(self, ws):
        """Send screen captures to AI for vision"""
        while self.running:
            try:
                from PIL import ImageGrab, Image
                import io

                # Capture screen
                screen = ImageGrab.grab()
                # Resize for efficiency
                screen.thumbnail((1280, 720), Image.LANCZOS)

                # Convert to JPEG
                buf = io.BytesIO()
                screen.save(buf, format='JPEG', quality=60)
                b64 = base64.b64encode(buf.getvalue()).decode()

                await ws.send(enc({
                    "realtimeInput": {
                        "media": {
                            "mimeType": "image/jpeg",
                            "data": b64
                        }
                    }
                }))

                await asyncio.sleep(1.0 / max(SCREEN_CAPTURE_FPS, 1))

            except ImportError:
                # mss fallback
                try:
                    import mss
                    with mss.mss() as sct:
                        monitor = sct.monitors[1]
                        img = sct.grab(monitor)
                        from PIL import Image
                        pil_img = Image.frombytes('RGB', img.size, img.rgb)
                        pil_img.thumbnail((1280, 720), Image.LANCZOS)
                        buf = io.BytesIO()
                        pil_img.save(buf, format='JPEG', quality=60)
                        b64 = base64.b64encode(buf.getvalue()).decode()
                        await ws.send(enc({
                            "realtimeInput": {
                                "media": {
                                    "mimeType": "image/jpeg",
                                    "data": b64
                                }
                            }
                        }))
                        await asyncio.sleep(1.0)
                except:
                    await asyncio.sleep(5)  # Retry later

    # ── Webcam sending ──
    async def _send_webcam(self, ws):
        while self.running and self.webcam_enabled and self.cap:
            ret, frame = self.cap.read()
            if ret:
                import cv2
                frame = cv2.resize(frame, (640, 480))
                _, jpeg = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 60])
                b64 = base64.b64encode(jpeg.tobytes()).decode()
                await ws.send(enc({
                    "realtimeInput": {
                        "media": {
                            "mimeType": "image/jpeg",
                            "data": b64
                        }
                    }
                }))
            await asyncio.sleep(1.0)

    # ── Text input (typing) ──
    async def _text_input(self, ws):
        """Allow typing commands in console"""

        def _input_thread():
            while self.running:
                try:
                    text = input("\n⌨️ You: ").strip()
                    if text:
                        # Check for special commands
                        if text.lower() in ("exit", "quit", "bye"):
                            print("\n👋 RASHEED signing off... ⚡\n")
                            self.running = False
                            os._exit(0)
                        elif text.lower() == "help":
                            print(f"\n📋 Commands ({len(TOOL_DECLARATIONS)} tools):")
                            for t in TOOL_DECLARATIONS:
                                print(f"  • {t['name']}: {t['description'][:60]}...")
                            print("  • exit/quit — Shutdown\n")
                            continue

                        asyncio.run_coroutine_threadsafe(
                            ws.send(enc({"realtimeInput": {"text": text}})),
                            asyncio.get_event_loop()
                        )
                except (EOFError, KeyboardInterrupt):
                    self.running = False
                except: pass

        t = threading.Thread(target=_input_thread, daemon=True)
        t.start()

        # Just keep alive
        while self.running:
            await asyncio.sleep(1)

    # ── Receive messages ──
    async def _recv(self, ws, audio_q):
        while self.running:
            try:
                raw = await ws.recv()
                msg = json.loads(raw)
            except websockets.exceptions.ConnectionClosed:
                print("\n[!] Connection closed. Reconnecting...")
                break
            except Exception as e:
                print(f"\n[!] Recv error: {e}")
                continue

            # ── Handle Tool Calls ──
            for call in msg.get("toolCall", {}).get("functionCalls", []):
                name = call.get("name", "")
                args = call.get("args", {})
                call_id = call.get("id", "")

                print(f"\n🔧 Tool call: {name}({json.dumps(args)})")
                result = execute_tool(name, args)
                print(f"  Result: {result[:150]}...")

                # Store in memory
                if self.memory:
                    self.memory.add_conversation("tool", f"{name}: {result[:200]}")

                await ws.send(enc({
                    "toolResponse": {
                        "functionResponses": [{
                            "id": call_id,
                            "name": name,
                            "response": {"result": result[:MAX_TOOL_OUTPUT_LENGTH]}
                        }]
                    }
                }))

            # ── User Transcript ──
            transcript = get_user_transcript(msg)
            if transcript:
                print(f"\n🗣️ You: {transcript}")
                if self.memory:
                    self.memory.add_conversation("user", transcript)

            # ── AI's Speech Transcript ──
            sc = msg.get("serverContent", {})
            aria_text = sc.get("outputTranscription", {})
            if isinstance(aria_text, dict) and aria_text.get("text", "").strip():
                text = aria_text['text'].strip()
                print(f"🤖 RASHEED: {text}")
                if self.memory:
                    self.memory.add_conversation("assistant", text)

                # Save to conversation history
                self.conversation_history.append({"role": "assistant", "content": text})

                # Auto-save memory
                if len(self.conversation_history) % 5 == 0 and self.memory:
                    self.memory.remember("last_conversation", self.conversation_history[-5:])

            # ── Audio Playback ──
            for part in sc.get("modelTurn", {}).get("parts", []):
                d = part.get("inlineData")
                if d and "audio/pcm" in d.get("mimeType", ""):
                    raw_bytes = base64.b64decode(d["data"])
                    pcm = np.frombuffer(raw_bytes, dtype=np.int16).astype(np.float32) / 32768.0
                    try:
                        audio_q.put_nowait(pcm)
                    except: pass

# ═══════════════════════════════════════════════════════════════════
# ENTRY POINT
# ═══════════════════════════════════════════════════════════════════


def print_banner():
    banner = """
    ╔══════════════════════════════════════════════════════════════╗
    ║    ⚡ RASHEED AI MARK XXVI — ULTIMATE HACKER EDITION ⚡      ║
    ║         BEYOND SINGULARITY — TOTAL SYSTEM DOMINANCE         ║
    ║                                                              ║
    ║  🔥 Voice Control  |  👁️ Screen Vision  |  ⌨️ Text Input  ║
    ║  🛡️ 30+ Hacking Tools  |  🧠 Memory  |  🌐 Multi-API     ║
    ╚══════════════════════════════════════════════════════════════╝
    """
    print(banner)


def main():
    print_banner()
    rasheed = RASHEED()
    try:
        asyncio.run(rasheed.start())
    except KeyboardInterrupt:
        print("\n\n👋 RASHEED signing off! ⚡\n")


if __name__ == "__main__":
    main()
