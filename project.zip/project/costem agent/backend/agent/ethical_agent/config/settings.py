"""
RASHEED AI — Configuration & Settings
All API keys, paths, and configuration in one place.
"""
import os
import json
from pathlib import Path

# ── BASE PATHS ──
BASE_DIR = Path(__file__).parent.parent
DATA_DIR = BASE_DIR / "data"
LOGS_DIR = BASE_DIR / "logs"
SCREENSHOTS_DIR = DATA_DIR / "screenshots"
AUDIO_DIR = DATA_DIR / "audio"
MEMORY_FILE = DATA_DIR / "memory.json"
VECTOR_MEMORY_DIR = DATA_DIR / "vector_memory"
SKILLS_DIR = DATA_DIR / "skills"
PAYLOADS_DIR = DATA_DIR / "payloads"
RESULTS_DIR = DATA_DIR / "results"

for d in [DATA_DIR, LOGS_DIR, SCREENSHOTS_DIR, AUDIO_DIR, SKILLS_DIR, PAYLOADS_DIR, RESULTS_DIR]:
    d.mkdir(parents=True, exist_ok=True)

# ── API KEYS (Your provided keys) ──
API_KEYS = {
    "gemini": "AIzaSyAogD9CiO9utuWrO3ezRXTnTvBljqingn0",
    "openai": "sk-abcd1234abcd1234abcd1234abcd1234abcd1234",
    "groq": "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",
}

# ── GEMINI LIVE API ──
GEMINI_WS_URL = (
    "wss://generativelanguage.googleapis.com/ws/"
    "google.ai.generativelanguage.v1beta."
    "GenerativeService.BidiGenerateContent"
)
GEMINI_MODEL = "models/gemini-2.5-flash-native-audio-preview-12-2025"
GEMINI_VOICE = "Puck"  # Male voice

# ── AUDIO CONFIG ──
MIC_RATE = 16000
SPK_RATE = 24000
FRAMES = int(MIC_RATE * 20 / 1000)
AUDIO_CHANNELS = 1

# ── SCREEN/VISION CONFIG ──
SCREEN_CAPTURE_FPS = 1
SCREEN_CAPTURE_QUALITY = 60
SCREEN_MAX_WIDTH = 1280
WEBCAM_FPS = 1

# ── SYSTEM ──
MAX_TOOL_OUTPUT_LENGTH = 5000
MAX_MEMORY_ITEMS = 1000
AUTO_SAVE_INTERVAL = 60  # seconds
MAX_CONCURRENT_TOOLS = 5

# ── KALI / WSL ──
KALI_WSL_DISTRO = "kali-linux"
USE_KALI = True

# ── DARK WEB / TOR ──
TOR_PROXY = "socks5://127.0.0.1:9050"
TOR_HTTP_PROXY = "http://127.0.0.1:8118"
USE_TOR = True

# ── MODEL ROUTING ──
# Which model for which task
MODEL_ROUTES = {
    "default": "gemini",
    "code": "openai",
    "hacking": "groq",
    "reasoning": "gemini",
    "creative": "groq",
}

# ── TOOL LIST (auto-generated) ──
TOOL_CATEGORIES = {
    "system": ["open_app", "close_app", "get_system_info", "execute_command",
                "execute_powershell", "shutdown", "restart", "lock", "volume_control"],
    "files": ["list_directory", "read_file", "write_file", "download_file"],
    "process": ["get_process_list", "kill_process"],
    "network": ["get_network_info", "check_internet", "get_public_ip",
                 "get_geolocation", "wifi_profiles", "wifi_password"],
    "input": ["type_text", "press_keys", "get_clipboard", "set_clipboard"],
    "capture": ["take_screenshot", "capture_webcam", "record_audio"],
    "hacking": ["port_scan", "directory_scan", "generate_payload",
                 "check_vulnerability", "exploit", "crack_hash",
                 "sql_inject", "xss_test", "reverse_shell"],
    "kali": ["kali_command", "kali_tool", "kali_terminal"],
    "darkweb": ["tor_request", "onion_search"],
    "code": ["run_python", "run_bash", "generate_code"],
    "memory": ["save_memory", "recall_memory", "search_memory"],
}