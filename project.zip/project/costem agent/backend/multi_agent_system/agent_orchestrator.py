# ╔══════════════════════════════════════════════════════════╗
# ║     Agent Orchestrator - Multi-Agent Coordination        ║
# ║     Manages all AI systems in unified interface          ║
# ╚══════════════════════════════════════════════════════════╝

import asyncio
import logging
from typing import Dict, List, Any, Optional, Callable
from dataclasses import dataclass
from enum import Enum
import sys
import os

logger = logging.getLogger("RASHEED.Orchestrator")


class AgentType(Enum):
    """Agent types in the system"""
    CORE_RASHEED = "core_rasheed"           # Main RASHEED system
    PENTEST = "pentest"                     # PentestGPT
    WORM = "worm"                           # WormGPT
    PAPERCLIP = "paperclip"                 # Paperclip framework
    BUSINESS = "business"                   # Business skills
    SECURITY = "security"                   # Security tools
    ORCHESTRATION = "orchestration"         # Agent factory
    AUTONOMOUS = "autonomous"               # Self-evolving agents


@dataclass
class AgentStatus:
    """Status of an agent"""
    agent_id: str
    agent_type: AgentType
    is_active: bool
    is_healthy: bool
    last_error: Optional[str] = None
    active_tasks: int = 0
    total_tasks: int = 0


class AgentOrchestrator:
    """Central coordinator for all AI agents"""
    
    def __init__(self):
        self.agents: Dict[str, Any] = {}
        self.agent_status: Dict[str, AgentStatus] = {}
        self.task_queue: List[Dict[str, Any]] = []
        self.agent_callbacks: Dict[str, List[Callable]] = {}
        self.running = False
        
    def register_agent(self, agent_id: str, agent_type: AgentType, agent_instance: Any) -> bool:
        """Register a new agent"""
        try:
            if agent_id in self.agents:
                logger.warning(f"Agent {agent_id} already registered, updating...")
            
            self.agents[agent_id] = agent_instance
            self.agent_status[agent_id] = AgentStatus(
                agent_id=agent_id,
                agent_type=agent_type,
                is_active=False,
                is_healthy=True
            )
            
            logger.info(f"✓ Agent registered: {agent_id} ({agent_type.value})")
            self._notify_callbacks(agent_id, "registered", agent_instance)
            return True
        except Exception as e:
            logger.error(f"✗ Failed to register agent {agent_id}: {e}")
            return False
    
    def unregister_agent(self, agent_id: str) -> bool:
        """Unregister an agent"""
        try:
            if agent_id not in self.agents:
                logger.warning(f"Agent {agent_id} not found")
                return False
            
            del self.agents[agent_id]
            del self.agent_status[agent_id]
            logger.info(f"✓ Agent unregistered: {agent_id}")
            return True
        except Exception as e:
            logger.error(f"✗ Failed to unregister agent {agent_id}: {e}")
            return False
    
    def get_agent(self, agent_id: str) -> Optional[Any]:
        """Get agent by ID"""
        return self.agents.get(agent_id)
    
    def get_agents_by_type(self, agent_type: AgentType) -> List[str]:
        """Get all agents of a specific type"""
        return [
            agent_id for agent_id, status in self.agent_status.items()
            if status.agent_type == agent_type
        ]
    
    def activate_agent(self, agent_id: str) -> bool:
        """Activate an agent"""
        if agent_id not in self.agent_status:
            return False
        
        self.agent_status[agent_id].is_active = True
        logger.info(f"✓ Agent activated: {agent_id}")
        self._notify_callbacks(agent_id, "activated", None)
        return True
    
    def deactivate_agent(self, agent_id: str) -> bool:
        """Deactivate an agent"""
        if agent_id not in self.agent_status:
            return False
        
        self.agent_status[agent_id].is_active = False
        logger.info(f"✓ Agent deactivated: {agent_id}")
        self._notify_callbacks(agent_id, "deactivated", None)
        return True
    
    async def execute_task(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a task using the appropriate agent"""
        agent_id = task.get("agent_id", "core_rasheed")
        task_id = task.get("task_id", "unknown")
        
        if agent_id not in self.agents:
            return {"success": False, "error": f"Agent {agent_id} not found"}
        
        try:
            agent = self.agents[agent_id]
            status = self.agent_status[agent_id]
            
            status.active_tasks += 1
            status.total_tasks += 1
            
            # Try to execute
            if hasattr(agent, 'execute'):
                result = await agent.execute(task) if asyncio.iscoroutinefunction(agent.execute) else agent.execute(task)
            elif hasattr(agent, 'run'):
                result = await agent.run(task) if asyncio.iscoroutinefunction(agent.run) else agent.run(task)
            else:
                result = {"success": False, "error": "Agent has no execute method"}
            
            status.active_tasks -= 1
            status.is_healthy = result.get("success", False)
            
            return result
        
        except Exception as e:
            status.active_tasks -= 1
            status.is_healthy = False
            status.last_error = str(e)
            logger.error(f"✗ Task {task_id} failed on agent {agent_id}: {e}")
            return {"success": False, "error": str(e), "agent": agent_id}
    
    async def broadcast_task(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """Send a task to all active agents and collect results"""
        results = {}
        
        for agent_id, agent in self.agents.items():
            status = self.agent_status[agent_id]
            if status.is_active:
                task_with_agent = {**task, "agent_id": agent_id}
                result = await self.execute_task(task_with_agent)
                results[agent_id] = result
        
        return results
    
    def add_task_to_queue(self, task: Dict[str, Any]) -> str:
        """Add task to processing queue"""
        task_id = f"task_{len(self.task_queue)}"
        task["task_id"] = task_id
        self.task_queue.append(task)
        logger.info(f"✓ Task queued: {task_id}")
        return task_id
    
    def get_system_status(self) -> Dict[str, Any]:
        """Get overall system status"""
        active_count = sum(1 for s in self.agent_status.values() if s.is_active)
        healthy_count = sum(1 for s in self.agent_status.values() if s.is_healthy)
        
        return {
            "running": self.running,
            "total_agents": len(self.agents),
            "active_agents": active_count,
            "healthy_agents": healthy_count,
            "queue_size": len(self.task_queue),
            "agents": {
                agent_id: {
                    "type": status.agent_type.value,
                    "active": status.is_active,
                    "healthy": status.is_healthy,
                    "active_tasks": status.active_tasks,
                    "total_tasks": status.total_tasks,
                    "last_error": status.last_error
                }
                for agent_id, status in self.agent_status.items()
            }
        }
    
    def subscribe(self, agent_id: str, callback: Callable):
        """Subscribe to agent events"""
        if agent_id not in self.agent_callbacks:
            self.agent_callbacks[agent_id] = []
        self.agent_callbacks[agent_id].append(callback)
    
    def _notify_callbacks(self, agent_id: str, event: str, data: Any):
        """Notify subscribed callbacks"""
        callbacks = self.agent_callbacks.get(agent_id, [])
        for callback in callbacks:
            try:
                callback(event, data)
            except Exception as e:
                logger.error(f"Callback error: {e}")


# Global orchestrator instance
_orchestrator: Optional[AgentOrchestrator] = None


def get_orchestrator() -> AgentOrchestrator:
    """Get the global orchestrator instance"""
    global _orchestrator
    if _orchestrator is None:
        _orchestrator = AgentOrchestrator()
    return _orchestrator


def init_orchestrator() -> AgentOrchestrator:
    """Initialize the orchestrator"""
    global _orchestrator
    _orchestrator = AgentOrchestrator()
    return _orchestrator
