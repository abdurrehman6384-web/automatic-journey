# ╔══════════════════════════════════════════════════════════╗
# ║     Multi-Agent Tools - New Tool Declarations            ║
# ║     Add these to tools.py for full integration           ║
# ╚══════════════════════════════════════════════════════════╝

MULTI_AGENT_TOOLS = [
    # ════════════════════════════════════════════════════════
    # ── Agent Orchestration ────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "start_all_agents",
        "description": "Sab AI agents ko start karo — PentestGPT, WormGPT, Paperclip, Business Skills",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "stop_all_agents",
        "description": "Sab AI agents ko stop karo gracefully",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "get_orchestrator_status",
        "description": "Multi-agent orchestrator ka complete status dekho",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "activate_agent",
        "description": "Specific agent ko activate karo",
        "parameters": {
            "type": "object",
            "properties": {
                "agent_id": {"type": "string", "description": "Agent ID to activate"}
            },
            "required": ["agent_id"]
        }
    },
    {
        "name": "deactivate_agent",
        "description": "Specific agent ko deactivate karo",
        "parameters": {
            "type": "object",
            "properties": {
                "agent_id": {"type": "string", "description": "Agent ID to deactivate"}
            },
            "required": ["agent_id"]
        }
    },

    # ════════════════════════════════════════════════════════
    # ── PentestGPT Integration ─────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "pentest_target",
        "description": "PentestGPT se target ko pentest karo — vulnerability scanning, exploitation",
        "parameters": {
            "type": "object",
            "properties": {
                "target": {"type": "string", "description": "Target URL or IP"},
                "instruction": {"type": "string", "description": "Custom pentest instructions (optional)"}
            },
            "required": ["target"]
        }
    },
    {
        "name": "pentest_resume_session",
        "description": "Previous pentesting session resume karo",
        "parameters": {
            "type": "object",
            "properties": {
                "session_id": {"type": "string", "description": "Previous session ID"}
            },
            "required": ["session_id"]
        }
    },
    {
        "name": "pentest_list_sessions",
        "description": "Sab pentesting sessions dekho",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── WormGPT Integration ────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "worm_execute_command",
        "description": "WormGPT mein command execute karo — automation, scripting",
        "parameters": {
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "Command to execute"},
                "target": {"type": "string", "description": "Target (optional)"}
            },
            "required": ["command"]
        }
    },
    {
        "name": "worm_install_modules",
        "description": "WormGPT mein required modules install karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Paperclip Agent Framework ──────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "paperclip_orchestrate",
        "description": "Paperclip se multiple agents ko coordinate karo",
        "parameters": {
            "type": "object",
            "properties": {
                "action": {"type": "string", "description": "Action to coordinate"},
                "agents": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Agent names to use"
                }
            },
            "required": ["action"]
        }
    },
    {
        "name": "paperclip_spawn_agent",
        "description": "Paperclip se naya agent spawn karo",
        "parameters": {
            "type": "object",
            "properties": {
                "agent_name": {"type": "string", "description": "Name for new agent"},
                "capabilities": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Agent capabilities"
                }
            },
            "required": ["agent_name"]
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Business Skills Integration ────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "business_skill_execute",
        "description": "Business skill use karo — analytics, reporting, management",
        "parameters": {
            "type": "object",
            "properties": {
                "skill": {"type": "string", "description": "Skill name"},
                "params": {"type": "object", "description": "Skill parameters"}
            },
            "required": ["skill"]
        }
    },
    {
        "name": "business_list_skills",
        "description": "Sab available business skills dekho",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Agent Factory Integration ──────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "factory_create_agent",
        "description": "Agent Factory se naya specialized agent banao",
        "parameters": {
            "type": "object",
            "properties": {
                "agent_type": {"type": "string", "description": "Type of agent (coder, analyst, explorer, etc.)"},
                "spec": {"type": "object", "description": "Agent specifications"}
            },
            "required": ["agent_type"]
        }
    },
    {
        "name": "factory_list_templates",
        "description": "Available agent templates dekho",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Multi-Agent Task Management ────────────────────────
    # ══════════���═════════════════════════════════════════════
    {
        "name": "queue_multi_agent_task",
        "description": "Multiple agents ke liye task queue mein add karo",
        "parameters": {
            "type": "object",
            "properties": {
                "task": {"type": "string", "description": "Task description"},
                "agents": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Agent IDs to execute task"
                },
                "priority": {"type": "integer", "description": "Task priority (1-10)"}
            },
            "required": ["task"]
        }
    },
    {
        "name": "process_agent_queue",
        "description": "Sab queued multi-agent tasks process karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "get_agent_task_status",
        "description": "Agent tasks ka status dekho",
        "parameters": {
            "type": "object",
            "properties": {
                "task_id": {"type": "string", "description": "Task ID (optional)"}
            }
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Cross-Agent Communication ──────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "broadcast_to_agents",
        "description": "Sab active agents ko message broadcast karo",
        "parameters": {
            "type": "object",
            "properties": {
                "message": {"type": "string", "description": "Message to broadcast"},
                "agent_type": {"type": "string", "description": "Specific agent type (optional)"}
            },
            "required": ["message"]
        }
    },
    {
        "name": "agent_to_agent_message",
        "description": "Ek agent se dusre agent ko message bhejo",
        "parameters": {
            "type": "object",
            "properties": {
                "from_agent": {"type": "string", "description": "Sender agent ID"},
                "to_agent": {"type": "string", "description": "Receiver agent ID"},
                "message": {"type": "string", "description": "Message content"}
            },
            "required": ["from_agent", "to_agent", "message"]
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Cyber Tools Coordination ───────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "cyber_team_scan",
        "description": "Cyber tools team se complete security scan karo",
        "parameters": {
            "type": "object",
            "properties": {
                "target": {"type": "string", "description": "Target to scan"},
                "depth": {"type": "string", "description": "Scan depth: quick, normal, or deep"}
            },
            "required": ["target"]
        }
    },
    {
        "name": "cyber_team_report",
        "description": "Cyber team se detailed security report generate karo",
        "parameters": {
            "type": "object",
            "properties": {
                "format": {"type": "string", "description": "Report format: pdf, json, html"}
            }
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Skills Team Coordination ───────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "skills_team_execute",
        "description": "Skills team se kisi complex skill ko execute karo",
        "parameters": {
            "type": "object",
            "properties": {
                "skill_category": {"type": "string", "description": "Skill category"},
                "skill_name": {"type": "string", "description": "Specific skill"},
                "params": {"type": "object", "description": "Skill parameters"}
            },
            "required": ["skill_category", "skill_name"]
        }
    },

    # ════════════════════════════════════════════════════════
    # ── System Health & Monitoring ─────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "monitor_all_agents",
        "description": "Sab agents ki real-time monitoring start karo",
        "parameters": {
            "type": "object",
            "properties": {
                "interval_seconds": {"type": "integer", "description": "Monitoring interval"}
            }
        }
    },
    {
        "name": "restart_failed_agent",
        "description": "Failed agent ko restart karo",
        "parameters": {
            "type": "object",
            "properties": {
                "agent_id": {"type": "string", "description": "Agent ID to restart"}
            },
            "required": ["agent_id"]
        }
    },
    {
        "name": "export_agent_logs",
        "description": "Sab agents ke logs export karo",
        "parameters": {
            "type": "object",
            "properties": {
                "format": {"type": "string", "description": "Export format: txt, json, csv"},
                "include_errors_only": {"type": "boolean", "description": "Only error logs?"}
            }
        }
    }
]
