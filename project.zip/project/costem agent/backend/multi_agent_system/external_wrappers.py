# ╔══════════════════════════════════════════════════════════╗
# ║     External System Wrappers - Integration Layer         ║
# ║     Wraps external AI systems for unified interface      ║
# ╚══════════════════════════════════════════════════════════╝

import logging
import subprocess
import sys
import os
from typing import Dict, Any, Optional, List
from pathlib import Path

logger = logging.getLogger("RASHEED.Wrappers")


class BaseWrapper:
    """Base wrapper for external systems"""
    
    def __init__(self, system_name: str, system_path: Optional[str] = None):
        self.system_name = system_name
        self.system_path = system_path
        self.is_running = False
        self.last_error: Optional[str] = None
    
    async def execute(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """Execute task on external system"""
        raise NotImplementedError
    
    def start(self) -> bool:
        """Start the external system"""
        try:
            self.is_running = True
            logger.info(f"✓ {self.system_name} started")
            return True
        except Exception as e:
            self.last_error = str(e)
            logger.error(f"✗ Failed to start {self.system_name}: {e}")
            return False
    
    def stop(self) -> bool:
        """Stop the external system"""
        try:
            self.is_running = False
            logger.info(f"✓ {self.system_name} stopped")
            return True
        except Exception as e:
            self.last_error = str(e)
            logger.error(f"✗ Failed to stop {self.system_name}: {e}")
            return False
    
    def get_status(self) -> Dict[str, Any]:
        """Get system status"""
        return {
            "name": self.system_name,
            "running": self.is_running,
            "last_error": self.last_error
        }


class PentestGPTWrapper(BaseWrapper):
    """Wrapper for PentestGPT system"""
    
    def __init__(self, system_path: str = "PentestGPT-main"):
        super().__init__("PentestGPT", system_path)
        self.pentestgpt_path = Path(system_path)
    
    async def execute(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """Execute pentesting task"""
        try:
            if not self.is_running:
                return {"success": False, "error": "PentestGPT not running"}
            
            target = task.get("target", "")
            instruction = task.get("instruction", "")
            
            if not target:
                return {"success": False, "error": "No target specified"}
            
            logger.info(f"🎯 PentestGPT executing: {target}")
            
            # Would call PentestGPT interface here
            return {
                "success": True,
                "system": "PentestGPT",
                "target": target,
                "status": "Task submitted to PentestGPT",
                "message": f"Pentesting {target} with context: {instruction[:100]}"
            }
        except Exception as e:
            self.last_error = str(e)
            logger.error(f"✗ PentestGPT error: {e}")
            return {"success": False, "error": str(e)}


class WormGPTWrapper(BaseWrapper):
    """Wrapper for WormGPT system"""
    
    def __init__(self, system_path: str = "wormGPT-wormGPT"):
        super().__init__("WormGPT", system_path)
        self.worm_path = Path(system_path)
    
    async def execute(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """Execute worm/automation task"""
        try:
            if not self.is_running:
                return {"success": False, "error": "WormGPT not running"}
            
            command = task.get("command", "")
            target = task.get("target", "")
            
            if not command and not target:
                return {"success": False, "error": "No command or target specified"}
            
            logger.info(f"🔧 WormGPT executing: {command or target}")
            
            return {
                "success": True,
                "system": "WormGPT",
                "command": command,
                "target": target,
                "status": "Task submitted to WormGPT",
                "message": f"Executing: {command or target}"
            }
        except Exception as e:
            self.last_error = str(e)
            logger.error(f"✗ WormGPT error: {e}")
            return {"success": False, "error": str(e)}


class PaperclipWrapper(BaseWrapper):
    """Wrapper for Paperclip framework"""
    
    def __init__(self, system_path: str = "paperclip-master"):
        super().__init__("Paperclip", system_path)
        self.paperclip_path = Path(system_path)
    
    async def execute(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """Execute agent orchestration task"""
        try:
            if not self.is_running:
                return {"success": False, "error": "Paperclip not running"}
            
            action = task.get("action", "")
            agents = task.get("agents", [])
            
            logger.info(f"📋 Paperclip orchestrating: {action}")
            
            return {
                "success": True,
                "system": "Paperclip",
                "action": action,
                "agents": agents,
                "status": "Paperclip orchestration started",
                "message": f"Coordinating {len(agents)} agents for: {action}"
            }
        except Exception as e:
            self.last_error = str(e)
            logger.error(f"✗ Paperclip error: {e}")
            return {"success": False, "error": str(e)}


class BusinessSkillsWrapper(BaseWrapper):
    """Wrapper for Business Skills system"""
    
    def __init__(self, system_path: str = "ai-business-skills-master"):
        super().__init__("BusinessSkills", system_path)
        self.skills_path = Path(system_path)
    
    async def execute(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """Execute business skill task"""
        try:
            if not self.is_running:
                return {"success": False, "error": "Business Skills not running"}
            
            skill = task.get("skill", "")
            params = task.get("params", {})
            
            logger.info(f"💼 Business Skill executing: {skill}")
            
            return {
                "success": True,
                "system": "BusinessSkills",
                "skill": skill,
                "params": params,
                "status": "Business skill task started"
            }
        except Exception as e:
            self.last_error = str(e)
            logger.error(f"✗ Business Skills error: {e}")
            return {"success": False, "error": str(e)}


class AgentFactoryWrapper(BaseWrapper):
    """Wrapper for Agent Factory system"""
    
    def __init__(self, system_path: str = "agent-factory-main"):
        super().__init__("AgentFactory", system_path)
        self.factory_path = Path(system_path)
    
    async def execute(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """Execute agent creation/management task"""
        try:
            if not self.is_running:
                return {"success": False, "error": "Agent Factory not running"}
            
            action = task.get("action", "")  # create, spawn, manage, etc.
            agent_spec = task.get("agent_spec", {})
            
            logger.info(f"🤖 Agent Factory: {action}")
            
            return {
                "success": True,
                "system": "AgentFactory",
                "action": action,
                "agent_spec": agent_spec,
                "status": "Agent factory task submitted"
            }
        except Exception as e:
            self.last_error = str(e)
            logger.error(f"✗ Agent Factory error: {e}")
            return {"success": False, "error": str(e)}


class ExternalSystemsManager:
    """Manages all external system wrappers"""
    
    def __init__(self, base_path: str = "."):
        self.base_path = Path(base_path)
        self.wrappers: Dict[str, BaseWrapper] = {}
        self._initialize_wrappers()
    
    def _initialize_wrappers(self):
        """Initialize all external system wrappers"""
        try:
            # PentestGPT
            if (self.base_path / "PentestGPT-main").exists():
                self.wrappers["pentest"] = PentestGPTWrapper(str(self.base_path / "PentestGPT-main"))
                logger.info("✓ PentestGPT wrapper initialized")
            
            # WormGPT
            if (self.base_path / "wormGPT-wormGPT").exists():
                self.wrappers["worm"] = WormGPTWrapper(str(self.base_path / "wormGPT-wormGPT"))
                logger.info("✓ WormGPT wrapper initialized")
            
            # Paperclip
            if (self.base_path / "paperclip-master").exists():
                self.wrappers["paperclip"] = PaperclipWrapper(str(self.base_path / "paperclip-master"))
                logger.info("✓ Paperclip wrapper initialized")
            
            # Business Skills
            if (self.base_path / "ai-business-skills-master").exists():
                self.wrappers["business"] = BusinessSkillsWrapper(str(self.base_path / "ai-business-skills-master"))
                logger.info("✓ Business Skills wrapper initialized")
            
            # Agent Factory
            if (self.base_path / "agent-factory-main").exists():
                self.wrappers["factory"] = AgentFactoryWrapper(str(self.base_path / "agent-factory-main"))
                logger.info("✓ Agent Factory wrapper initialized")
        
        except Exception as e:
            logger.error(f"Error initializing wrappers: {e}")
    
    async def start_all(self) -> Dict[str, bool]:
        """Start all external systems"""
        results = {}
        for name, wrapper in self.wrappers.items():
            results[name] = wrapper.start()
        return results
    
    async def stop_all(self) -> Dict[str, bool]:
        """Stop all external systems"""
        results = {}
        for name, wrapper in self.wrappers.items():
            results[name] = wrapper.stop()
        return results
    
    def get_status_all(self) -> Dict[str, Any]:
        """Get status of all external systems"""
        return {
            name: wrapper.get_status()
            for name, wrapper in self.wrappers.items()
        }
    
    async def execute_on_system(self, system: str, task: Dict[str, Any]) -> Dict[str, Any]:
        """Execute task on specific external system"""
        if system not in self.wrappers:
            return {"success": False, "error": f"System {system} not found"}
        
        return await self.wrappers[system].execute(task)
