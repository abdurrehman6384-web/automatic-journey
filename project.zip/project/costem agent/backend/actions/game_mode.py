# game_mode.py — RASHEED Game Playing AI v6.0
import pyautogui
import keyboard
import time
import cv2
import numpy as np
import threading
from vision import vision
from error_handler import logger

pyautogui.FAILSAFE = True
pyautogui.PAUSE = 0.005


class GameAI:
    def __init__(self):
        self.running = False
        self.game_thread = None
        self.mode = None
        self.reaction_time = 0.05
        self.keys_held = set()

    def press(self, key: str, duration: float = 0):
        if duration > 0:
            keyboard.press(key)
            time.sleep(duration)
            keyboard.release(key)
        else:
            pyautogui.press(key)

    def hold_key(self, key: str):
        if key not in self.keys_held:
            keyboard.press(key)
            self.keys_held.add(key)

    def release_key(self, key: str):
        if key in self.keys_held:
            keyboard.release(key)
            self.keys_held.discard(key)

    def release_all(self):
        for key in list(self.keys_held):
            keyboard.release(key)
        self.keys_held.clear()

    def click(self, x=None, y=None, button='left'):
        if x and y:
            pyautogui.click(x, y, button=button)
        else:
            pyautogui.click(button=button)

    def move_to(self, x, y, speed=0.1):
        pyautogui.moveTo(x, y, duration=speed)

    def get_game_frame(self) -> np.ndarray | None:
        return vision.get_screen_frame()

    def find_color(self, color_bgr: tuple, tolerance: int = 20) -> list:
        return vision.detect_color_region(color_bgr, tolerance)

    def start_game_mode(self, mode: str) -> str:
        mode = mode.lower()
        if mode == "fps":
            return self.start_fps_mode()
        elif mode == "runner":
            return self.start_runner_mode()
        elif mode == "clicker":
            return self.start_clicker_mode()
        elif mode == "dino":
            return self.start_dino_mode()
        return f"❌ Unknown game mode: {mode}"

    def start_fps_mode(self):
        self.mode = "fps"
        self.running = True
        self.game_thread = threading.Thread(
            target=self._fps_loop, daemon=True
        )
        self.game_thread.start()
        return "🎮 FPS Mode active boss!"

    def _fps_loop(self):
        RED_ENEMY = (0, 0, 200)
        screen_w, screen_h = vision.get_screen_size()
        center_x = screen_w // 2
        center_y = screen_h // 2

        while self.running and self.mode == "fps":
            try:
                enemies = self.find_color(RED_ENEMY, tolerance=40)
                if enemies:
                    nearest = min(
                        enemies,
                        key=lambda p: abs(p[0]-center_x) + abs(p[1]-center_y)
                    )
                    curr_x, curr_y = pyautogui.position()
                    dx = (nearest[0] - curr_x) * 0.3
                    dy = (nearest[1] - curr_y) * 0.3
                    pyautogui.moveRel(dx, dy, duration=0.05)
                time.sleep(self.reaction_time)
            except Exception:
                time.sleep(0.1)

    def start_runner_mode(self):
        self.mode = "runner"
        self.running = True
        self.game_thread = threading.Thread(
            target=self._runner_loop, daemon=True
        )
        self.game_thread.start()
        return "🎮 Runner Mode active boss!"

    def _runner_loop(self):
        screen_w, screen_h = vision.get_screen_size()
        while self.running and self.mode == "runner":
            try:
                frame = self.get_game_frame()
                if frame is None:
                    time.sleep(0.05)
                    continue
                danger_zone = frame[
                    screen_h//2:screen_h*3//4,
                    screen_w//3:screen_w*2//3
                ]
                gray = cv2.cvtColor(danger_zone, cv2.COLOR_BGR2GRAY)
                _, thresh = cv2.threshold(
                    gray, 50, 255, cv2.THRESH_BINARY_INV
                )
                obstacle_pixels = np.sum(thresh > 0)
                if obstacle_pixels > 500:
                    pyautogui.press('space')
                    time.sleep(0.3)
                time.sleep(self.reaction_time)
            except Exception:
                time.sleep(0.1)

    def start_clicker_mode(self):
        self.mode = "clicker"
        self.running = True
        self._target_color = (0, 200, 0)
        self.game_thread = threading.Thread(
            target=self._clicker_loop, daemon=True
        )
        self.game_thread.start()
        return "🎮 Clicker Mode active boss!"

    def _clicker_loop(self):
        while self.running and self.mode == "clicker":
            try:
                targets = self.find_color(self._target_color)
                if targets:
                    x, y = targets[0]
                    self.click(x, y)
                    time.sleep(0.1)
                time.sleep(self.reaction_time)
            except Exception:
                time.sleep(0.1)

    def start_dino_mode(self):
        self.mode = "dino"
        self.running = True
        self.game_thread = threading.Thread(
            target=self._dino_loop, daemon=True
        )
        self.game_thread.start()
        return "🦕 Dino Mode active boss!"

    def _dino_loop(self):
        screen_w, screen_h = vision.get_screen_size()
        danger_x = screen_w // 2
        danger_y = screen_h // 2 - 30
        danger_w = 200
        danger_h = 60

        while self.running and self.mode == "dino":
            try:
                frame = self.get_game_frame()
                if frame is None:
                    time.sleep(0.05)
                    continue
                region = frame[
                    danger_y:danger_y + danger_h,
                    danger_x:danger_x + danger_w
                ]
                gray = cv2.cvtColor(region, cv2.COLOR_BGR2GRAY)
                dark_pixels = np.sum(gray < 100)
                if dark_pixels > 100:
                    pyautogui.press('space')
                    time.sleep(0.4)
                time.sleep(0.03)
            except Exception:
                time.sleep(0.1)

    def stop_game(self):
        self.running = False
        self.mode = None
        self.release_all()
        return "🛑 Game mode band kar diya boss!"


game_ai = GameAI()