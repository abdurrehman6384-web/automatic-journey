# meeting_transcriber.py — Meeting Auto-Transcriber
import threading
import os
# ── Standard Library Imports (Cython requires these at top) ──
import os
import sys
import time
import json
import re
import threading
import subprocess
import base64
import hashlib
import shutil
import glob
import socket
import signal
import traceback
import datetime
from pathlib import Path
from typing import Optional, List, Dict, Any
import queue
import numpy as np
import sounddevice as sd
from config import logger
from error_handler import safe_execute

class MeetingTranscriber:
    def __init__(self):
        self.recording = False
        self.transcript = []
        self._audio_q = queue.Queue()

    def start_transcription(self) -> str:
        if self.recording:
            return "Already recording!"
        self.recording = True
        self.transcript = []
        
        t = threading.Thread(target=self._record_loop, daemon=True)
        t.start()
        return "🎙️ Meeting transcription started!"

    def stop_transcription(self) -> str:
        self.recording = False
        return f"🛑 Stopped. {len(self.transcript)} segments captured."

    def _record_loop(self):
        RATE = 16000
        CHUNK = 4800  # 0.3 seconds
        
        with sd.InputStream(samplerate=RATE, channels=1, dtype='int16', blocksize=CHUNK) as mic:
            buffer = []
            silence_count = 0
            
            while self.recording:
                pcm, _ = mic.read(CHUNK)
                volume = np.sqrt(np.mean(pcm.astype(float)**2))
                
                if volume > 0.02:  # Speech detected
                    buffer.append(pcm.copy())
                    silence_count = 0
                else:
                    silence_count += 1
                    
                    # After 1.5s silence, process buffer
                    if silence_count > 5 and buffer:
                        audio_data = np.concatenate(buffer)
                        text = self._transcribe_chunk(audio_data)
                        if text:
                            self.transcript.append({
                                "time": str(datetime.now().strftime("%H:%M")),
                                "text": text
                            })
                        buffer = []
                
                time.sleep(0.01)

    def _transcribe_chunk(self, audio: np.ndarray) -> str:
        """Transcribe audio chunk using Groq Whisper API"""
        import base64
        from config import GROQ_API_KEY
        
        if not GROQ_API_KEY:
            return ""
        
        try:
            import requests
            # Save as temp wav
            import wave
            import tempfile
            
            with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
                with wave.open(f.name, 'wb') as wf:
                    wf.setnchannels(1)
                    wf.setsampwidth(2)
                    wf.setframerate(16000)
                    wf.writeframes(audio.tobytes())
                
                with open(f.name, 'rb') as audio_file:
                    r = requests.post(
                        "https://api.groq.com/openai/v1/audio/transcriptions",
                        headers={"Authorization": f"Bearer {GROQ_API_KEY}"},
                        files={"file": audio_file},
                        data={"model": "whisper-large-v3", "language": "en"},
                        timeout=10
                    )
                
                os.unlink(f.name)
                
                if r.status_code == 200:
                    return r.json().get("text", "")
        except Exception:
            pass
        return ""

    @safe_execute(max_retries=1)
    def get_summary(self) -> str:
        if not self.transcript:
            return "No transcript yet."
        
        full_text = "\n".join(f"[{t['time']}] {t['text']}" for t in self.transcript)
        
        from ai_brain import llm_router
        prompt = f"Summarize this meeting transcript in 5 bullet points:\n\n{full_text[:5000]}"
        return llm_router.smart_ask(prompt)

    @safe_execute(max_retries=1)
    def get_action_items(self) -> str:
        if not self.transcript:
            return "No transcript yet."
        
        full_text = "\n".join(t["text"] for t in self.transcript)
        from ai_brain import llm_router
        prompt = f"Extract action items and decisions from this meeting:\n\n{full_text[:5000]}"
        return llm_router.smart_ask(prompt)


# Global instance
meeting = MeetingTranscriber()
