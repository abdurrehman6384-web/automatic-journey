# ╔══════════════════════════════════════════════════════════╗
# ║       self_coder.py — RASHEED Self-Coding Engine         ║
# ║       Generates, Tests & Loads New Tools Autonomously    ║
# ╚══════════════════════════════════════════════════════════╝

import os
import sys
import json
import time
import importlib
import subprocess
import traceback
from datetime import datetime


class SelfCoder:
    """RASHEED khud naya code likhe, test kare aur load kare"""

    def __init__(self):
        self.plugins_dir = "auto_plugins"
        self.registry_file = "auto_plugins_registry.json"
        self.registry = self._load_registry()
        os.makedirs(self.plugins_dir, exist_ok=True)

    # ── Registry Management ───────────────────────────
    def _load_registry(self):
        try:
            if os.path.exists(self.registry_file):
                with open(self.registry_file, 'r') as f:
                    return json.load(f)
        except:
            pass
        return {"plugins": {}}

    def _save_registry(self):
        try:
            with open(self.registry_file, 'w') as f:
                json.dump(self.registry, f, indent=2)
        except:
            pass

    # ════════════════════════════════════════════════════════
    # MAIN: Generate New Tool from Description
    # ════════════════════════════════════════════════════════

    def generate_tool(self, description, tool_name=None):
        """AI se naya tool ka code generate karo"""

        if not tool_name:
            # Auto-generate name from description
            words = description.lower().split()[:3]
            tool_name = "_".join(words).replace(" ", "_")
            # Clean name
            tool_name = "".join(c for c in tool_name if c.isalnum() or c == "_")

        print(f"\n🧬 SELF-CODER: Generating tool '{tool_name}'...")
        print(f"   📝 Description: {description}")

        # ── Step 1: Generate Code ─────────────────────
        code = self._generate_code(description, tool_name)

        if not code:
            return "❌ Code generation failed!"

        # ── Step 2: Save to File ──────────────────────
        filepath = os.path.join(self.plugins_dir, f"{tool_name}.py")
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(code)

        print(f"   ✅ Code saved: {filepath}")

        # ── Step 3: Test Code ─────────────────────────
        test_result = self._test_code(filepath, tool_name)

        if test_result["success"]:
            print(f"   ✅ Test PASSED!")

            # ── Step 4: Register & Load ───────────────
            self._register_plugin(tool_name, filepath, description)
            self._load_plugin(tool_name, filepath)

            return f"✅ Tool '{tool_name}' generated, tested & loaded successfully!\n   📄 File: {filepath}"
        else:
            print(f"   ❌ Test FAILED: {test_result['error']}")
            print(f"   🔧 Attempting auto-fix...")

            # ── Step 5: Auto-Fix ──────────────────────
            fixed = self._auto_fix(filepath, tool_name, test_result["error"])

            if fixed:
                print(f"   ✅ Auto-fix successful!")
                self._register_plugin(tool_name, filepath, description)
                self._load_plugin(tool_name, filepath)
                return f"✅ Tool '{tool_name}' auto-fixed & loaded!\n   📄 File: {filepath}"
            else:
                return f"❌ Tool generation failed. Auto-fix couldn't resolve errors.\n   Error: {test_result['error']}"

    # ── Code Generation ───────────────────────────────
    def _generate_code(self, description, tool_name):
        """Generate Python code for the tool"""

        # Template-based code generation (works offline)
        templates = {
            "web_scraper": self._template_scraper,
            "file_manager": self._template_file_manager,
            "api_caller": self._template_api_caller,
            "calculator": self._template_calculator,
            "converter": self._template_converter,
            "monitor": self._template_monitor,
            "notification": self._template_notification,
            "downloader": self._template_downloader,
        }

        # Detect template type from description
        desc_lower = description.lower()

        if any(w in desc_lower for w in ["scrape", "website", "web page", "html"]):
            return templates["web_scraper"](tool_name, description)
        elif any(w in desc_lower for w in ["file", "folder", "organize", "rename"]):
            return templates["file_manager"](tool_name, description)
        elif any(w in desc_lower for w in ["api", "fetch", "request", "http"]):
            return templates["api_caller"](tool_name, description)
        elif any(w in desc_lower for w in ["calculate", "math", "convert", "compute"]):
            return templates["calculator"](tool_name, description)
        elif any(w in desc_lower for w in ["convert", "transform", "change format"]):
            return templates["converter"](tool_name, description)
        elif any(w in desc_lower for w in ["monitor", "watch", "track", "observe"]):
            return templates["monitor"](tool_name, description)
        elif any(w in desc_lower for w in ["notify", "alert", "reminder", "warn"]):
            return templates["notification"](tool_name, description)
        elif any(w in desc_lower for w in ["download", "save", "fetch file"]):
            return templates["downloader"](tool_name, description)

        # Default: Custom tool template
        return self._template_custom(tool_name, description)

    # ── Templates ─────────────────────────────────────

    def _template_custom(self, name, desc):
        return f'''# Auto-generated by RASHEED Self-Coder
# Tool: {name}
# Description: {desc}
# Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

import os
import sys
import json

def run(**kwargs):
    """
    Main function for {name}
    {desc}
    """
    try:
        # TODO: Implement the main logic here
        result = "Tool '{name}' executed successfully!"

        # Process kwargs (input parameters)
        for key, value in kwargs.items():
            result += f"\\n  {{key}}: {{value}}"

        return result
    except Exception as e:
        return f"Error in {name}: {{e}}"

def info():
    """Return tool information"""
    return {{
        "name": "{name}",
        "description": "{desc}",
        "parameters": {{}},
        "returns": "string"
    }}

if __name__ == "__main__":
    # Test the tool
    print(run())
'''

    def _template_scraper(self, name, desc):
        return f'''# Auto-generated by RASHEED Self-Coder
# Tool: {name} (Web Scraper)
# Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

import requests
from urllib.parse import quote_plus

def run(url="", query=""):
    """
    Scrape text from a website
    URL ya query do, text return karunga
    """
    try:
        if query and not url:
            url = f"https://www.google.com/search?q={{quote_plus(query)}}"

        headers = {{
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }}

        response = requests.get(url, headers=headers, timeout=10)

        if response.status_code == 200:
            # Simple text extraction
            text = response.text

            # Remove HTML tags (basic)
            import re
            clean = re.sub(r'<script[^>]*>.*?</script>', '', text, flags=re.DOTALL)
            clean = re.sub(r'<style[^>]*>.*?</style>', '', clean, flags=re.DOTALL)
            clean = re.sub(r'<[^>]+>', ' ', clean)
            clean = re.sub(r'\\s+', ' ', clean).strip()

            # Limit output
            return clean[:3000] if len(clean) > 3000 else clean
        else:
            return f"HTTP Error: {{response.status_code}}"

    except Exception as e:
        return f"Scraping Error: {{e}}"

def info():
    return {{
        "name": "{name}",
        "description": "{desc}",
        "parameters": {{"url": "string", "query": "string"}},
        "returns": "scraped text"
    }}

if __name__ == "__main__":
    print(run(query="python tutorial"))
'''

    def _template_file_manager(self, name, desc):
        return f'''# Auto-generated by RASHEED Self-Coder
# Tool: {name} (File Manager)
# Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

import os
import shutil
from datetime import datetime

def run(action="list", path=".", pattern=""):
    """
    Manage files and folders
    Actions: list, search, organize, size
    """
    try:
        if action == "list":
            files = os.listdir(path)
            return "\\n".join(files[:100])

        elif action == "search":
            results = []
            for root, dirs, files in os.walk(path):
                for f in files:
                    if pattern.lower() in f.lower():
                        results.append(os.path.join(root, f))
            return "\\n".join(results[:50]) if results else "No files found"

        elif action == "size":
            total = 0
            for root, dirs, files in os.walk(path):
                for f in files:
                    fp = os.path.join(root, f)
                    try: total += os.path.getsize(fp)
                    except: pass
            mb = total / (1024*1024)
            return f"Total size: {{mb:.1f}} MB"

        elif action == "organize":
            # Organize files by extension
            moved = 0
            for f in os.listdir(path):
                if os.path.isfile(os.path.join(path, f)):
                    ext = f.split('.')[-1].lower() if '.' in f else 'other'
                    ext_dir = os.path.join(path, ext + "_files")
                    os.makedirs(ext_dir, exist_ok=True)
                    shutil.move(os.path.join(path, f), os.path.join(ext_dir, f))
                    moved += 1
            return f"Organized {{moved}} files by extension!"

        return f"Unknown action: {{action}}"

    except Exception as e:
        return f"File Manager Error: {{e}}"

def info():
    return {{
        "name": "{name}",
        "description": "{desc}",
        "parameters": {{"action": "string", "path": "string", "pattern": "string"}},
        "returns": "operation result"
    }}

if __name__ == "__main__":
    print(run(action="list"))
'''

    def _template_calculator(self, name, desc):
        return f'''# Auto-generated by RASHEED Self-Coder
# Tool: {name} (Calculator)
# Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

import math

def run(expression="", operation="eval"):
    """
    Perform calculations
    Operations: eval, sqrt, power, percentage, trig
    """
    try:
        if operation == "eval" and expression:
            # Safe eval
            allowed = {{'abs': abs, 'round': round, 'min': min, 'max': max,
                       'pow': pow, 'sum': sum, 'int': int, 'float': float}}
            result = eval(expression, {{"__builtins__": {{}}}}, allowed)
            return f"Result: {{result}}"

        elif operation == "sqrt" and expression:
            return f"√{{expression}} = {{math.sqrt(float(expression))}}"

        elif operation == "power":
            base = float(kwargs.get('base', expression))
            exp = float(kwargs.get('exp', 2))
            return f"{{base}}^{{exp}} = {{math.pow(base, exp)}}"

        elif operation == "percentage":
            value = float(expression)
            total = float(kwargs.get('total', 100))
            return f"{{value}} is {{(value/total)*100}}% of {{total}}"

        return "Please provide an expression"

    except Exception as e:
        return f"Calculation Error: {{e}}"

def info():
    return {{
        "name": "{name}",
        "description": "{desc}",
        "parameters": {{"expression": "string", "operation": "string"}},
        "returns": "calculation result"
    }}

if __name__ == "__main__":
    print(run(expression="2**10"))
'''

    def _template_api_caller(self, name, desc):
        return f'''# Auto-generated by RASHEED Self-Coder
# Tool: {name} (API Caller)
# Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

import requests
import json

def run(url="", method="GET", headers=None, data=None):
    """
    Make HTTP API requests
    """
    try:
        headers = headers or {{'Content-Type': 'application/json'}}

        if method.upper() == "GET":
            response = requests.get(url, headers=headers, timeout=10)
        elif method.upper() == "POST":
            response = requests.post(url, headers=headers, json=data, timeout=10)
        elif method.upper() == "PUT":
            response = requests.put(url, headers=headers, json=data, timeout=10)
        elif method.upper() == "DELETE":
            response = requests.delete(url, headers=headers, timeout=10)
        else:
            return f"Unknown method: {{method}}"

        try:
            return json.dumps(response.json(), indent=2)
        except:
            return response.text[:3000]

    except Exception as e:
        return f"API Error: {{e}}"

def info():
    return {{
        "name": "{name}",
        "description": "{desc}",
        "parameters": {{"url": "string", "method": "string", "data": "object"}},
        "returns": "API response"
    }}

if __name__ == "__main__":
    print(run(url="https://api.github.com"))
'''

    def _template_monitor(self, name, desc):
        return f'''# Auto-generated by RASHEED Self-Coder
# Tool: {name} (Monitor)
# Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

import psutil
import time

def run(target="system", duration=5):
    """
    Monitor system resources or process
    Targets: system, network, disk, process
    """
    try:
        if target == "system":
            cpu = psutil.cpu_percent(interval=1)
            ram = psutil.virtual_memory()
            disk = psutil.disk_usage('/')
            return f"""System Monitor:
  CPU: {{cpu}}%
  RAM: {{ram.percent}}% ({{ram.used//1073741824}}GB / {{ram.total//1073741824}}GB)
  Disk: {{disk.percent}}% ({{disk.used//1073741824}}GB / {{disk.total//1073741824}}GB)
  Processes: {{len(psutil.pids())}}"""

        elif target == "network":
            net = psutil.net_io_counters()
            return f"""Network Monitor:
  Bytes Sent: {{net.bytes_sent / 1024:.1f}} KB
  Bytes Recv: {{net.bytes_recv / 1024:.1f}} KB
  Packets Sent: {{net.packets_sent}}
  Packets Recv: {{net.packets_recv}}"""

        elif target == "top_processes":
            procs = []
            for p in psutil.process_iter(['pid', 'name', 'cpu_percent', 'memory_percent']):
                try:
                    procs.append(p.info)
                except:
                    pass
            procs.sort(key=lambda x: x.get('cpu_percent', 0) or 0, reverse=True)
            result = "Top Processes:\\n"
            for p in procs[:10]:
                result += f"  {{p.get('name', 'N/A')}}: CPU {{p.get('cpu_percent', 0):.1f}}%, RAM {{p.get('memory_percent', 0):.1f}}%\\n"
            return result

        return f"Unknown target: {{target}}"

    except Exception as e:
        return f"Monitor Error: {{e}}"

def info():
    return {{
        "name": "{name}",
        "description": "{desc}",
        "parameters": {{"target": "string", "duration": "integer"}},
        "returns": "monitoring data"
    }}

if __name__ == "__main__":
    print(run())
'''

    def _template_notification(self, name, desc):
        return f'''# Auto-generated by RASHEED Self-Coder
# Tool: {name} (Notification)
# Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

import time
import threading
from datetime import datetime, timedelta

def run(title="RASHEED", message="", delay_minutes=0):
    """
    Send notification / Set reminder
    """
    try:
        if delay_minutes > 0:
            # Schedule for later
            notify_time = datetime.now() + timedelta(minutes=delay_minutes)
            
            def delayed_notify():
                time.sleep(delay_minutes * 60)
                _show_notification(title, message)
            
            t = threading.Thread(target=delayed_notify, daemon=True)
            t.start()
            return f"⏰ Reminder set for {{notify_time.strftime('%I:%M %p')}}!\\n📝 {{message}}"
        
        else:
            # Show now
            _show_notification(title, message)
            return f"✅ Notification sent: {{title}} - {{message}}"

    except Exception as e:
        return f"Notification Error: {{e}}"

def _show_notification(title, message):
    """Show Windows notification"""
    try:
        from plyer import notification
        notification.notify(title=title, message=message, timeout=10)
    except:
        # Fallback: Windows toast
        try:
            from win10toast import ToastNotifier
            ToastNotifier().show_toast(title, message, duration=10)
        except:
            print(f"🔔 {{title}}: {{message}}")

def info():
    return {{
        "name": "{name}",
        "description": "{desc}",
        "parameters": {{"title": "string", "message": "string", "delay_minutes": "integer"}},
        "returns": "notification status"
    }}

if __name__ == "__main__":
    print(run(title="Test", message="Hello from RASHEED!"))
'''

    def _template_converter(self, name, desc):
        return f'''# Auto-generated by RASHEED Self-Coder
# Tool: {name} (Converter)
# Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

def run(conversion="", value=""):
    """
    Convert between units
    Supports: temperature, length, weight, data, time
    """
    try:
        val = float(value) if value else 0
        conv = conversion.lower().strip()

        # Temperature
        if "celsius to fahrenheit" in conv or "c to f" in conv:
            return f"{{val}}°C = {{(val * 9/5) + 32}}°F"
        if "fahrenheit to celsius" in conv or "f to c" in conv:
            return f"{{val}}°F = {{(val - 32) * 5/9}}°C"

        # Length
        if "km to miles" in conv:
            return f"{{val}} km = {{val * 0.621371}} miles"
        if "miles to km" in conv:
            return f"{{val}} miles = {{val * 1.60934}} km"
        if "meters to feet" in conv or "m to ft" in conv:
            return f"{{val}} m = {{val * 3.28084}} ft"
        if "feet to meters" in conv or "ft to m" in conv:
            return f"{{val}} ft = {{val * 0.3048}} m"

        # Weight
        if "kg to pounds" in conv or "kg to lbs" in conv:
            return f"{{val}} kg = {{val * 2.20462}} lbs"
        if "pounds to kg" in conv or "lbs to kg" in conv:
            return f"{{val}} lbs = {{val * 0.453592}} kg"

        # Data
        if "gb to mb" in conv:
            return f"{{val}} GB = {{val * 1024}} MB"
        if "mb to gb" in conv:
            return f"{{val}} MB = {{val / 1024:.2f}} GB"

        return f"Conversion '{{conv}}' not supported yet. Try: c to f, km to miles, kg to lbs"

    except Exception as e:
        return f"Converter Error: {{e}}"

def info():
    return {{
        "name": "{name}",
        "description": "{desc}",
        "parameters": {{"conversion": "string", "value": "string"}},
        "returns": "converted value"
    }}

if __name__ == "__main__":
    print(run(conversion="c to f", value="100"))
'''

    def _template_downloader(self, name, desc):
        return f'''# Auto-generated by RASHEED Self-Coder
# Tool: {name} (Downloader)
# Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

import os
import requests

def run(url="", save_path="RASHEED_Downloads", filename=""):
    """
    Download files from URL
    """
    try:
        os.makedirs(save_path, exist_ok=True)

        if not url:
            return "Please provide a URL"

        if not filename:
            filename = url.split('/')[-1] or "downloaded_file"

        filepath = os.path.join(save_path, filename)

        print(f"📥 Downloading: {{url}}")
        response = requests.get(url, stream=True, timeout=30)

        if response.status_code == 200:
            total = int(response.headers.get('content-length', 0))
            downloaded = 0

            with open(filepath, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
                    downloaded += len(chunk)
                    if total > 0:
                        pct = (downloaded / total) * 100
                        print(f"\\r  Progress: {{pct:.1f}}%", end='', flush=True)

            size_mb = os.path.getsize(filepath) / (1024*1024)
            return f"✅ Downloaded: {{filepath}} ({{size_mb:.1f}} MB)"
        else:
            return f"HTTP Error: {{response.status_code}}"

    except Exception as e:
        return f"Download Error: {{e}}"

def info():
    return {{
        "name": "{name}",
        "description": "{desc}",
        "parameters": {{"url": "string", "save_path": "string", "filename": "string"}},
        "returns": "download status"
    }}

if __name__ == "__main__":
    print(run(url="https://example.com"))
'''

    # ── Test Code ─────────────────────────────────────
    def _test_code(self, filepath, tool_name):
        """Test generated code by importing it"""
        try:
            # Add plugin dir to path
            if self.plugins_dir not in sys.path:
                sys.path.insert(0, self.plugins_dir)

            # Try importing
            spec = importlib.util.spec_from_file_location(tool_name, filepath)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)

            # Check if 'run' function exists
            if not hasattr(module, 'run'):
                return {"success": False, "error": "No 'run' function found in generated code"}

            # Try running (with empty kwargs as test)
            try:
                result = module.run()
                return {"success": True, "result": str(result)}
            except TypeError:
                # Function might need arguments, that's OK
                return {"success": True, "result": "Function exists (needs arguments)"}

        except SyntaxError as e:
            return {"success": False, "error": f"Syntax Error: Line {e.lineno}: {e.msg}"}
        except Exception as e:
            return {"success": False, "error": str(e)}

    # ── Auto-Fix Code ─────────────────────────────────
    def _auto_fix(self, filepath, tool_name, error_msg):
        """Attempt to fix common code errors"""
        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                code = f.read()

            fixed = False

            # Fix 1: Missing imports
            if "NameError" in error_msg or "name" in error_msg and "is not defined" in error_msg:
                import re
                missing = re.search(r"name '(\w+)' is not defined", error_msg)
                if missing:
                    name = missing.group(1)
                    common_imports = {
                        "os": "import os",
                        "sys": "import sys",
                        "json": "import json",
                        "time": "import time",
                        "math": "import math",
                        "re": "import re",
                        "requests": "import requests",
                        "datetime": "from datetime import datetime",
                        "psutil": "import psutil",
                        "threading": "import threading",
                        "shutil": "import shutil",
                        "subprocess": "import subprocess",
                        "base64": "import base64",
                    }
                    if name in common_imports:
                        code = common_imports[name] + "\n" + code
                        fixed = True

            # Fix 2: Indentation errors
            if "IndentationError" in error_msg:
                lines = code.split('\n')
                fixed_code = []
                for line in lines:
                    fixed_code.append(line.replace('\t', '    '))
                code = '\n'.join(fixed_code)
                fixed = True

            # Fix 3: f-string issues
            if "f-string" in error_msg:
                # Replace f-strings with format()
                code = code.replace("f'", "'").replace('f"', '"')
                fixed = True

            if fixed:
                with open(filepath, 'w', encoding='utf-8') as f:
                    f.write(code)

                # Re-test
                result = self._test_code(filepath, tool_name)
                return result["success"]

            return False

        except:
            return False

    # ── Register Plugin ───────────────────────────────
    def _register_plugin(self, name, filepath, description):
        """Register plugin in registry"""
        self.registry["plugins"][name] = {
            "filepath": filepath,
            "description": description,
            "created": datetime.now().isoformat(),
            "active": True
        }
        self._save_registry()

    # ── Load Plugin Live ──────────────────────────────
    def _load_plugin(self, name, filepath):
        """Load plugin into RASHEED runtime"""
        try:
            if self.plugins_dir not in sys.path:
                sys.path.insert(0, self.plugins_dir)

            spec = importlib.util.spec_from_file_location(name, filepath)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)

            sys.modules[f"auto_plugin_{name}"] = module
            print(f"   🔌 Plugin '{name}' loaded into runtime!")
            return True
        except Exception as e:
            print(f"   ❌ Load error: {e}")
            return False

    # ── List All Plugins ──────────────────────────────
    def list_plugins(self):
        """List all auto-generated plugins"""
        if not self.registry["plugins"]:
            return "ℹ️ No auto-generated plugins yet. Say: 'Generate a tool for...'"
        
        result = "\n🧬 Auto-Generated Plugins:\n\n"
        for name, info in self.registry["plugins"].items():
            status = "🟢 Active" if info.get("active") else "🔴 Inactive"
            result += f"  {status} {name}\n"
            result += f"     📝 {info['description']}\n"
            result += f"     📄 {info['filepath']}\n\n"
        return result

    # ── Execute Plugin ────────────────────────────────
    def execute_plugin(self, name, **kwargs):
        """Execute an auto-generated plugin"""
        try:
            module_name = f"auto_plugin_{name}"
            if module_name in sys.modules:
                module = sys.modules[module_name]
                return module.run(**kwargs)
            else:
                # Try loading from file
                if name in self.registry["plugins"]:
                    filepath = self.registry["plugins"][name]["filepath"]
                    self._load_plugin(name, filepath)
                    module = sys.modules.get(module_name)
                    if module:
                        return module.run(**kwargs)
            
            return f"❌ Plugin '{name}' not found!"
        except Exception as e:
            return f"❌ Plugin execution error: {e}"

# ════════════════════════════════════════════════════════
# GLOBAL INSTANCE
# ════════════════════════════════════════════════════════


self_coder = SelfCoder()
