# agent.py — Autonomous Agent System (Chain of Thought + Self-Reflection)
import json
# ── Standard Library Imports (Cython requires these at top) ──
import os
import sys
import time
import json
import re
import threading
import subprocess
import base64
import hashlib
import shutil
import glob
import socket
import signal
import traceback
import datetime
from pathlib import Path
from typing import Optional, List, Dict, Any
import threading
import queue
import error_handler
import config
from config import AGENT_MAX_ITERATIONS, logger
from error_handler import safe_execute
from ai_brain import llm_router

# NOTE: DO NOT import execute_tool at top level — causes circular import!
# It is imported inside the function instead (lazy import).


class AutonomousAgent:
    def __init__(self):
        self.task_queue = []  # List of {"task": str, "priority": int}

    def add_task(self, task: str, priority: int = 1) -> str:
        self.task_queue.append({"task": task, "priority": priority})
        self.task_queue.sort(key=lambda x: x["priority"], reverse=True)
        return f"✅ Task added to queue: {task}"

    def process_queue(self) -> str:
        if not self.task_queue:
            return "No tasks in queue."
        results = []
        while self.task_queue:
            task_obj = self.task_queue.pop(0)
            result = self.execute_chain(task_obj["task"])
            results.append(f"Task: {task_obj['task']} -> {result}")
        return "\n".join(results)

    @safe_execute(max_retries=1)
    def execute_chain(self, goal: str) -> str:
        """Chain of Thought: Plan -> Execute -> Verify loop"""
        # ── LAZY IMPORT (Fixes circular import) ──────
        from executor import execute_tool
        # ─────────────────────────────────────────────

        logger.info(f"🤖 Agent starting goal: {goal}")

        context = f"Goal: {goal}\n"

        for i in range(AGENT_MAX_ITERATIONS):
            # Step 1: Think & Plan
            prompt = (
                f"You are an AI Agent. Your goal: {goal}\n"
                f"Current context: {context}\n"
                f"What is the NEXT single action to take? "
                f"Respond ONLY in JSON format: "
                f'{{"thought": "why", "tool": "tool_name", "args": {{"key": "value"}}}}'
            )

            ai_response = llm_router.smart_ask(prompt)
            if not ai_response or "❌" in str(ai_response):
                return f"❌ Agent thinking failed at step {i+1}"

            # Step 2: Parse Action
            try:
                clean = ai_response.replace("```json", "").replace("```", "").strip()
                action = json.loads(clean)
                tool_name = action.get("tool")
                tool_args = action.get("args", {})

                if tool_name.lower() in ["done", "finish", "complete"]:
                    return f"✅ Goal achieved in {i+1} steps!"

            except json.JSONDecodeError:
                context += f"AI thought: {ai_response}\n"
                continue

            # Step 3: Execute Tool
            result = execute_tool(tool_name, tool_args)
            context += f"Step {i+1}: Used {tool_name} with {tool_args}. Result: {result}\n"
            logger.info(f"Agent Step {i+1}: {tool_name} -> {result}")

            # Step 4: Self-Reflection (Did it work?)
            if "❌" in result or "error" in result.lower():
                reflect_prompt = (
                    f"You tried to use {tool_name} but got error: {result}.\n"
                    f"Goal: {goal}\n"
                    f"Suggest a fix or alternative tool."
                )
                fix = llm_router.smart_ask(reflect_prompt)
                context += f"Reflection: {fix}\n"

        return f"⚠️ Max iterations reached. Status: {context[-500:]}"


# Global instance
agent = AutonomousAgent()
