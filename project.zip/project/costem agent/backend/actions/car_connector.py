# ╔══════════════════════════════════════════════════════════╗
# ║       car_connector.py — RASHEED Car Integration        ║
# ║       Connect to OBD2 Bluetooth Scanner                  ║
# ╚══════════════════════════════════════════════════════════╝

import obd


class CarConnector:

    def __init__(self):
        self.connection = None
        
    def connect(self, port=None):
        """Connect to OBD2 Scanner via Bluetooth"""
        try:
            self.connection = obd.OBD(port)  # auto-connects
            if self.connection.is_connected():
                return f"✅ Car Connected! Protocol: {self.connection.protocol_name}"
            return "❌ Could not connect to car"
        except Exception as e:
            return f"❌ OBD2 Error: {e}"

    def get_rpm(self):
        if self.connection:
            resp = self.connection.query(obd.commands.RPM)
            return f"🏎️ RPM: {resp.value}"
        return "Not connected"

    def get_speed(self):
        if self.connection:
            resp = self.connection.query(obd.commands.SPEED)
            return f"🚗 Speed: {resp.value}"
        return "Not connected"

    def get_engine_temp(self):
        if self.connection:
            resp = self.connection.query(obd.commands.COOLANT_TEMP)
            return f"🌡️ Engine Temp: {resp.value}"
        return "Not connected"

    def get_fuel_level(self):
        if self.connection:
            resp = self.connection.query(obd.commands.FUEL_LEVEL)
            return f"⛽ Fuel: {resp.value}"
        return "Not connected"

    def full_diagnosis(self):
        return f"""
╔════════════════════════════════════════════╗
║         🚗 RASHEED CAR DIAGNOSTICS         ║
╠════════════════════════════════════════════╣
║  {self.get_rpm()}
║  {self.get_speed()}
║  {self.get_engine_temp()}
║  {self.get_fuel_level()}
╚════════════════════════════════════════════╝
        """


car = CarConnector()
