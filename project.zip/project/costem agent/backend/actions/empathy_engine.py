# ╔══════════════════════════════════════════════════════════╗
# ║       empathy_engine.py — RASHEED Emotion Detection      ║
# ║       Detects user's mood via webcam & voice tone        ║
# ╚══════════════════════════════════════════════════════════╝

import cv2
import numpy as np
from datetime import datetime

class EmpathyEngine:
    """RASHEED ke liye Emotion Detection System"""

    def __init__(self):
        self.current_mood = "neutral"
        self.mood_history = []
        try:
            from fer import FER
            self.detector = FER(mtcnn=True)
            self.available = True
            print("🧠 Empathy Engine: Active (FER)")
        except ImportError:
            self.available = False
            print("⚠️ Empathy Engine: FER not installed. Run: pip install fer")

    def detect_mood_from_frame(self, frame):
        """Webcam frame se emotion detect karo"""
        if not self.available:
            return "neutral"
        try:
            result = self.detector.detect_emotions(frame)
            if result:
                emotions = result[0]["emotions"]
                # Get dominant emotion
                dominant = max(emotions, key=emotions.get)
                self.current_mood = dominant
                self.mood_history.append({
                    "mood": dominant,
                    "time": datetime.now().isoformat()
                })
                return dominant
        except:
            pass
        return "neutral"

    def get_response_style(self):
        """Mood ke hisaab se AI ka tone set karo"""
        styles = {
            "happy": "Match their energy! Be enthusiastic and cheerful! 😄",
            "sad": "Be very gentle, caring and supportive. Speak softly. 🤗",
            "angry": "Stay calm, professional and solution-focused. Don't argue. 🧘",
            "surprise": "Be informative and help them understand. 🤓",
            "fear": "Be reassuring, confident and protective. 🛡️",
            "disgust": "Be neutral and offer alternatives. 🔄",
            "neutral": "Be your normal smart self. 🤖"
        }
        return styles.get(self.current_mood, styles["neutral"])

    def should_suggest_break(self):
        """Agar user 3 baar sad/angry detect hua toh break suggest karo"""
        if len(self.mood_history) >= 3:
            last_3 = [m["mood"] for m in self.mood_history[-3:]]
            if last_3.count("sad") >= 3:
                return "break" # Suggest a walk
            if last_3.count("angry") >= 3:
                return "calm" # Suggest deep breath
        return None

empathy = EmpathyEngine()