# god_coder.py — Autonomous Code Engine (Prompt-to-Project, Auto-Error Fixer)
import os
import subprocess
import json
from config import BASE_DIR, logger
from error_handler import safe_execute
from ai_brain import llm_router


class GodCoder:
    """
    Reads prompt from file or text, plans architecture, 
    writes complete project files, runs them, and auto-fixes errors.
    Capable of generating projects up to 1,000,000 lines iteratively.
    """

    @safe_execute(max_retries=1)
    def build_from_prompt(self, prompt_source: str, project_name: str = "ai_project") -> str:
        """
        Build complete project from prompt text or prompt file path.
        Reads the prompt -> Plans Architecture -> Writes Files -> Runs -> Fixes Errors.
        """
        # Step 1: Read Prompt
        if os.path.exists(prompt_source):
            with open(prompt_source, 'r', encoding='utf-8') as f:
                prompt = f.read()
            logger.info(f"📖 Read prompt from file: {prompt_source}")
        else:
            prompt = prompt_source

        if not prompt.strip():
            return "❌ Prompt is empty!"

        # Step 2: Plan Architecture
        logger.info("🧠 Planning architecture...")
        arch_prompt = (
            f"You are an elite Software Architect. Based on this project description, "
            f"provide the COMPLETE file structure and a brief description of each file.\n\n"
            f"PROJECT DESCRIPTION:\n{prompt[:5000]}\n\n"
            f"Respond ONLY in this JSON format:\n"
            f'{{"project_name": "name", "files": [{{"path": "folder/file.py", "description": "what this file does"}}]}}'
        )

        arch_response = llm_router.smart_ask(arch_prompt)
        if not arch_response or "❌" in str(arch_response):
            return f"❌ Architecture planning failed: {arch_response}"

        # Parse architecture
        try:
            clean = arch_response.replace("```json", "").replace("```", "").strip()
            arch = json.loads(clean)
            project_name = arch.get("project_name", project_name)
            files = arch.get("files", [])
        except json.JSONDecodeError:
            return f"❌ Architecture JSON parse failed. AI said:\n{arch_response[:500]}"

        if not files:
            return "❌ No files in architecture plan!"

        # Step 3: Create Project Directory
        project_dir = os.path.join(str(BASE_DIR), project_name)
        os.makedirs(project_dir, exist_ok=True)

        # Step 4: Write Each File
        written = 0
        for file_info in files:
            file_path = file_info.get("path", "")
            file_desc = file_info.get("description", "")

            if not file_path:
                continue

            full_path = os.path.join(project_dir, file_path)
            os.makedirs(os.path.dirname(full_path), exist_ok=True)

            # Generate code for this file
            code_prompt = (
                f"You are an elite Python Developer. Write the COMPLETE code for this file.\n\n"
                f"PROJECT: {project_name}\n"
                f"FILE: {file_path}\n"
                f"DESCRIPTION: {file_desc}\n"
                f"FULL PROJECT CONTEXT: {prompt[:3000]}\n\n"
                f"Write production-ready, clean, well-commented Python code.\n"
                f"Output ONLY the code. No markdown blocks. No explanations."
            )

            code = llm_router.smart_ask(code_prompt)
            if code and "❌" not in str(code):
                # Clean markdown
                code = code.replace("```python", "").replace("```", "").strip()
                with open(full_path, 'w', encoding='utf-8') as f:
                    f.write(code)
                written += 1
                logger.info(f"✍️ Written: {file_path}")

        # Step 5: Generate requirements.txt
        req_prompt = (
            f"Based on this project, list all pip packages needed.\n"
            f"Project: {prompt[:2000]}\n"
            f"Output ONLY package names, one per line. No explanations."
        )
        reqs = llm_router.smart_ask(req_prompt)
        if reqs and "❌" not in str(reqs):
            with open(os.path.join(project_dir, "requirements.txt"), 'w') as f:
                f.write(reqs)

        # Step 6: Run & Auto-Fix
        main_file = os.path.join(project_dir, "main.py")
        run_result = ""
        if os.path.exists(main_file):
            run_result = self._run_and_fix(main_file)

        return (
            f"🧬 Project '{project_name}' Created!\n"
            f"📁 Directory: {project_dir}\n"
            f"📝 Files Written: {written}/{len(files)}\n"
            f"🔧 Run Status: {run_result}"
        )

    def _run_and_fix(self, file_path: str, max_fixes: int = 3) -> str:
        """Run the file and auto-fix errors iteratively"""
        for attempt in range(max_fixes):
            try:
                result = subprocess.run(
                    ["python", file_path],
                    capture_output=True, text=True, timeout=15
                )

                if result.returncode == 0:
                    return "✅ Runs successfully!"

                # Has error - try to fix
                error = result.stderr.strip()
                if not error:
                    return "⚠️ Exited with code 1 but no error output"

                logger.info(f"🔧 Fix attempt {attempt+1}: {error[:200]}")

                fix_prompt = (
                    f"Fix this Python error. Output the COMPLETE corrected file.\n\n"
                    f"ERROR:\n{error[:2000]}\n\n"
                    f"FILE CONTENT:\n"
                )

                with open(file_path, 'r', encoding='utf-8') as f:
                    current_code = f.read()

                fix_prompt += current_code[:6000]

                fixed_code = llm_router.smart_ask(fix_prompt)
                if fixed_code and "❌" not in str(fixed_code):
                    fixed_code = fixed_code.replace("```python", "").replace("```", "").strip()
                    with open(file_path, 'w', encoding='utf-8') as f:
                        f.write(fixed_code)
                else:
                    return f"❌ Auto-fix failed: {error[:300]}"

            except subprocess.TimeoutExpired:
                return "✅ Running (timeout = likely a server/GUI app)"
            except Exception as e:
                return f"❌ Run error: {e}"

        return f"⚠️ Could not fix after {max_fixes} attempts"

    @safe_execute(max_retries=1)
    def fix_file(self, file_path: str) -> str:
        """Read a file, run it, and fix any errors"""
        if not os.path.exists(file_path):
            return f"❌ File not found: {file_path}"
        return self._run_and_fix(file_path)

    @safe_execute(max_retries=1)
    def read_prompt_and_build(self, prompt_file: str) -> str:
        """Read a prompt file and build complete project"""
        project_name = os.path.splitext(os.path.basename(prompt_file))[0]
        return self.build_from_prompt(prompt_file, project_name)


# Global instance
god_coder = GodCoder()