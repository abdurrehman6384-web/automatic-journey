# content_creator.py — Auto Content Creator
from ai_brain import llm_router
from error_handler import safe_execute

class ContentCreator:

    @safe_execute(max_retries=1)
    def write_script(self, topic: str, duration: str = "5 minutes") -> str:
        prompt = (
            f"Write a YouTube script for: {topic} ({duration}). "
            f"Include hook, main content, CTA. Use engaging Hinglish tone."
        )
        return llm_router.smart_ask(prompt)

    @safe_execute(max_retries=1)
    def thumbnail_prompt(self, topic: str) -> str:
        prompt = (
            f"Generate a detailed image prompt for YouTube thumbnail about: {topic}. "
            f"Describe colors, text overlay, style. Make it click-worthy."
        )
        return llm_router.smart_ask(prompt)

    @safe_execute(max_retries=1)
    def seo_optimize(self, title: str) -> str:
        prompt = (
            f"Generate SEO-optimized YouTube metadata for: {title}\n"
            f"Output:\n1. 5 Title options\n2. Description (200 words)\n3. 15 tags"
        )
        return llm_router.smart_ask(prompt)

    @safe_execute(max_retries=1)
    def analyze_trends(self, niche: str = "tech") -> str:
        prompt = f"What are the top 5 trending video ideas in {niche} niche right now? Be specific."
        return llm_router.smart_ask(prompt)


# Global instance
creator = ContentCreator()