# deep_search.py — Deep Local File Content Search Engine
import os
import json
import threading
import time
from pathlib import Path
from datetime import datetime
from config import (
    SEARCH_INDEX_DIR, SEARCH_MAX_FILE_SIZE,
    BASE_DIR, logger
)
from error_handler import safe_execute

os.makedirs(SEARCH_INDEX_DIR, exist_ok=True)

INDEX_FILE = os.path.join(SEARCH_INDEX_DIR, "content_index.json")


class DeepSearchEngine:
    """
    Local Google-like search engine for PC files.
    Indexes content of PDF, Word, Text, CSV, Python, JSON files.
    Searches by keywords inside file content.
    """

    # File extensions to index
    INDEXABLE_EXTENSIONS = {
        ".txt", ".md", ".py", ".js", ".html", ".css", ".json",
        ".csv", ".xml", ".yaml", ".yml", ".toml", ".cfg", ".ini",
        ".log", ".sql", ".sh", ".bat", ".ps1", ".env",
    }

    # Extensions requiring special parsers
    PDF_EXTENSIONS = {".pdf"}
    WORD_EXTENSIONS = {".docx", ".doc"}
    EXCEL_EXTENSIONS = {".xlsx", ".xls"}

    def __init__(self):
        self.index = {}
        self._load_index()

    def _load_index(self):
        """Load existing index from disk"""
        if os.path.exists(INDEX_FILE):
            try:
                with open(INDEX_FILE, 'r', encoding='utf-8') as f:
                    self.index = json.load(f)
                logger.info(f"📂 Search index loaded: {len(self.index)} files")
            except Exception:
                self.index = {}
        else:
            self.index = {}

    def _save_index(self):
        """Save index to disk"""
        try:
            with open(INDEX_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.index, f, ensure_ascii=False, indent=1)
        except Exception as e:
            logger.error(f"Index save error: {e}")

    # ── Text Extraction ──────────────────────────────
    def _extract_text(self, file_path: str) -> str:
        """Extract text from any supported file type"""
        ext = Path(file_path).suffix.lower()

        try:
            if ext in self.PDF_EXTENSIONS:
                return self._extract_pdf(file_path)
            elif ext in self.WORD_EXTENSIONS:
                return self._extract_word(file_path)
            elif ext in self.INDEXABLE_EXTENSIONS:
                return self._extract_plain(file_path)
            elif ext in self.EXCEL_EXTENSIONS:
                return self._extract_csv_like(file_path)
            else:
                return ""
        except Exception as e:
            logger.debug(f"Extract error {file_path}: {e}")
            return ""

    def _extract_plain(self, file_path: str) -> str:
        """Extract text from plain text files"""
        try:
            # Try utf-8 first, fallback to latin-1
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    return f.read()[:50000]
            except UnicodeDecodeError:
                with open(file_path, 'r', encoding='latin-1') as f:
                    return f.read()[:50000]
        except Exception:
            return ""

    def _extract_pdf(self, file_path: str) -> str:
        """Extract text from PDF files"""
        try:
            import PyPDF2
            text = ""
            with open(file_path, 'rb') as f:
                reader = PyPDF2.PdfReader(f)
                for page in reader.pages[:50]:
                    page_text = page.extract_text()
                    if page_text:
                        text += page_text + "\n"
            return text[:50000]
        except ImportError:
            return "[PDF - Install PyPDF2 to read]"
        except Exception:
            return ""

    def _extract_word(self, file_path: str) -> str:
        """Extract text from Word files"""
        try:
            from docx import Document
            doc = Document(file_path)
            text = "\n".join([p.text for p in doc.paragraphs])
            return text[:50000]
        except ImportError:
            return "[DOCX - Install python-docx to read]"
        except Exception:
            return ""

    def _extract_csv_like(self, file_path: str) -> str:
        """Extract text from CSV/Excel-like files"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read()[:50000]
        except Exception:
            return ""

    # ── Indexing ─────────────────────────────────────
    def index_file(self, file_path: str) -> str:
        """Index a single file's content"""
        if not os.path.exists(file_path):
            return f"❌ File not found: {file_path}"

        size = os.path.getsize(file_path)
        if size > SEARCH_MAX_FILE_SIZE:
            return f"⚠️ File too large: {size / (1024*1024):.1f}MB"

        text = self._extract_text(file_path)
        if not text.strip():
            return f"⚠️ No text content in: {file_path}"

        # Create index entry
        rel_path = file_path
        ext = Path(file_path).suffix.lower()

        self.index[rel_path] = {
            "path": file_path,
            "name": os.path.basename(file_path),
            "ext": ext,
            "size_mb": round(size / (1024 * 1024), 2),
            "indexed_at": str(datetime.now()),
            "content_preview": text[:500],
            "content_full": text.lower(),  # Lowercase for search
            "word_count": len(text.split()),
        }

        self._save_index()
        return f"✅ Indexed: {os.path.basename(file_path)} ({len(text.split())} words)"

    def index_directory(self, directory: str = None, max_files: int = 500) -> str:
        """Index all supported files in a directory recursively"""
        directory = directory or str(Path.home() / "Desktop")
        
        if not os.path.exists(directory):
            return f"❌ Directory not found: {directory}"

        indexed = 0
        errors = 0
        all_exts = (
            self.INDEXABLE_EXTENSIONS |
            self.PDF_EXTENSIONS |
            self.WORD_EXTENSIONS |
            self.EXCEL_EXTENSIONS
        )

        for root, dirs, files in os.walk(directory):
            # Skip hidden and system folders
            dirs[:] = [
                d for d in dirs
                if not d.startswith('.') and d not in [
                    'node_modules', '__pycache__', '.git', '.venv',
                    'AppData', 'Windows', '$Recycle.Bin', 'System Volume Information'
                ]
            ]

            for f in files:
                if indexed >= max_files:
                    break

                ext = Path(f).suffix.lower()
                if ext in all_exts:
                    fp = os.path.join(root, f)
                    try:
                        size = os.path.getsize(fp)
                        if size <= SEARCH_MAX_FILE_SIZE:
                            text = self._extract_text(fp)
                            if text.strip():
                                self.index[fp] = {
                                    "path": fp,
                                    "name": f,
                                    "ext": ext,
                                    "size_mb": round(size / (1024 * 1024), 2),
                                    "indexed_at": str(datetime.now()),
                                    "content_preview": text[:500],
                                    "content_full": text.lower(),
                                    "word_count": len(text.split()),
                                }
                                indexed += 1
                    except Exception:
                        errors += 1

        self._save_index()
        return f"📂 Indexed {indexed} files! Errors: {errors}. Directory: {directory}"

    # ── Searching ────────────────────────────────────
    def search(self, query: str, max_results: int = 10) -> str:
        """Search for keywords inside indexed files"""
        if not self.index:
            return "❌ No files indexed yet! Say 'Rasheed, index desktop' first."

        keywords = [kw.lower().strip() for kw in query.split() if len(kw) > 2]
        if not keywords:
            return "❌ Query too short. Use at least 3 character words."

        results = []
        for fp, data in self.index.items():
            content = data.get("content_full", "")
            name = data.get("name", "").lower()
            preview = data.get("content_preview", "")

            score = 0
            matches = []

            for kw in keywords:
                # Count occurrences in content
                content_count = content.count(kw)
                name_count = name.count(kw)

                if content_count > 0:
                    score += content_count
                    matches.append(f"'{kw}' x{content_count}")
                if name_count > 0:
                    score += name_count * 5  # Name match is weighted higher

            if score > 0:
                # Find relevant snippet
                snippet = self._get_snippet(content, keywords)
                
                results.append({
                    "score": score,
                    "path": data.get("path", fp),
                    "name": data.get("name", ""),
                    "ext": data.get("ext", ""),
                    "size_mb": data.get("size_mb", 0),
                    "matches": ", ".join(matches),
                    "snippet": snippet,
                })

        if not results:
            return f"🔍 No files found containing: '{query}'"

        # Sort by relevance score
        results.sort(key=lambda x: x["score"], reverse=True)

        output = f"🔍 Found {len(results)} files for '{query}':\n\n"
        for i, r in enumerate(results[:max_results], 1):
            output += (
                f"{i}. 📄 {r['name']}\n"
                f"   Path: {r['path']}\n"
                f"   Matches: {r['matches']}\n"
                f"   Size: {r['size_mb']}MB\n"
                f"   Snippet: {r['snippet']}\n\n"
            )

        return output

    def _get_snippet(self, content: str, keywords: list, context: int = 80) -> str:
        """Get a relevant snippet around the first keyword match"""
        for kw in keywords:
            idx = content.find(kw)
            if idx >= 0:
                start = max(0, idx - context)
                end = min(len(content), idx + len(kw) + context)
                snippet = content[start:end].replace('\n', ' ').strip()
                return f"...{snippet}..."
        return content[:150].replace('\n', ' ').strip() + "..."

    # ── Index Management ─────────────────────────────
    def clear_index(self) -> str:
        """Clear the search index"""
        self.index = {}
        self._save_index()
        return "🗑️ Search index cleared!"

    def get_index_stats(self) -> str:
        """Get index statistics"""
        if not self.index:
            return "📂 Index is empty. Say 'index desktop' to start."

        total = len(self.index)
        total_words = sum(d.get("word_count", 0) for d in self.index.values())
        
        # Count by extension
        ext_count = {}
        for data in self.index.values():
            ext = data.get("ext", "other")
            ext_count[ext] = ext_count.get(ext, 0) + 1

        ext_str = ", ".join(f"{ext}: {cnt}" for ext, cnt in sorted(ext_count.items()))

        return (
            f"📊 Index Stats:\n"
            f"   Total Files: {total}\n"
            f"   Total Words: {total_words:,}\n"
            f"   Types: {ext_str}"
        )


# Global instance
deep_search = DeepSearchEngine()