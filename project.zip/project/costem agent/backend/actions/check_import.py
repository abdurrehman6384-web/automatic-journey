"""Quick script to find missing top-level imports"""
import os
import re

STDLIB = {
    'time', 'os', 'sys', 'json', 're', 'threading', 'subprocess',
    'base64', 'hashlib', 'shutil', 'glob', 'socket', 'signal',
    'traceback', 'datetime', 'math', 'random', 'collections',
    'pathlib', 'typing', 'io', 'struct', 'ctypes', 'queue',
    'logging', 'tempfile', 'webbrowser', 'urllib', 'http',
    'email', 'html', 'xml', 'csv', 'sqlite3', 'functools',
    'itertools', 'operator', 'copy', 'pprint', 'textwrap',
    'unicodedata', 'string', 'enum', 'dataclasses', 'abc',
    'importlib', 'inspect', 'dis', 'ast', 'tokenize',
}


def check_file(filepath):
    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()
    
    # Find top-level imports
    imports = set()
    for match in re.finditer(r'^import\s+(\w+)', content, re.MULTILINE):
        imports.add(match.group(1))
    for match in re.finditer(r'^from\s+(\w+)', content, re.MULTILINE):
        imports.add(match.group(1))
    
    # Find all name usage (simple check)
    issues = []
    for match in re.finditer(r'\b(\w+)\.', content):
        name = match.group(1)
        if name in STDLIB and name not in imports:
            # Check if it's imported inside a function
            if not re.search(rf'^import\s+{name}', content, re.MULTILINE) and \
               not re.search(rf'^from\s+{name}', content, re.MULTILINE):
                issues.append(name)
    
    return list(set(issues))


print("🔍 Scanning Python files for missing top-level imports...\n")

for f in os.listdir('.'):
    if f.endswith('.py') and f not in ['check_imports.py', 'build_cython.py']:
        issues = check_file(f)
        if issues:
            print(f"⚠️ {f}: Missing top-level imports → {', '.join(issues)}")
            print(f"   Add this to top of {f}:")
            for imp in sorted(issues):
                print(f"   import {imp}")
            print()
        else:
            print(f"✅ {f}: OK")

print("\nDone!")
