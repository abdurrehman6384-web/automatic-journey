# ╔══════════════════════════════════════════════════════════╗
# ║       RASHEED AI v10.0 GOD MODE — main.py              ║
# ║       Created by Abdurrehman                            ║
# ║       All Errors Fixed • Production Ready                ║
# ╚══════════════════════════════════════════════════════════╝

import asyncio
import base64
import json
import numpy as np
import sounddevice as sd
import threading
import queue as _queue
import time
import re
import sys
import signal
import traceback

# ── Optional Imports (Graceful Fallback) ────────────────
try:
    import websockets
    HAS_WEBSOCKETS = True
except ImportError:
    HAS_WEBSOCKETS = False
    print("❌ websockets not installed! Run: pip install websockets")

try:
    import cv2
    HAS_CV2 = True
except ImportError:
    HAS_CV2 = False

try:
    import mss
    HAS_MSS = True
except ImportError:
    HAS_MSS = False

try:
    from PIL import Image
    HAS_PIL = True
except ImportError:
    HAS_PIL = False


# ════════════════════════════════════════════════════════
# CONFIG — Default Values (Override from config.py)
# ════════════════════════════════════════════════════════
try:
    from config import (
        GEMINI_API_KEY,
        GEMINI_WS_URL,
        GEMINI_MODEL,
        MIC_RATE,
        SPK_RATE,
        MIC_FRAMES,
        VISION_INTERVAL,
        SCREEN_WIDTH,
        SCREEN_QUALITY,
        VOICE_NAME,
        FACE_LOCK_ENABLED
    )
except ImportError:
    print("⚠️ config.py not found — using default values")
    GEMINI_API_KEY = "AIzaSyDTxchsOjccEWlMZIG347gTAT9lBOPEhWA"
    GEMINI_WS_URL = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent"
    GEMINI_MODEL = "models/gemini-2.0-flash-exp"
    MIC_RATE = 16000
    SPK_RATE = 24000
    MIC_FRAMES = 512
    VISION_INTERVAL = 3.0
    SCREEN_WIDTH = 800
    SCREEN_QUALITY = 60
    VOICE_NAME = "Orus"
    FACE_LOCK_ENABLED = False

if not GEMINI_API_KEY:
    print("❌ GEMINI_API_KEY is empty! Set it in config.py")
    print("💡 Create config.py with: GEMINI_API_KEY = 'your-key-here'")


# ════════════════════════════════════════════════════════
# CORE IMPORTS — Graceful Fallbacks
# ════════════════════════════════════════════════════════

# ── Prompt ────────────────────────────────────────────
try:
    from prompt import RASHEED_PROMPT
except ImportError:
    RASHEED_PROMPT = """You are RASHEED, an advanced AI assistant created by Abdurrehman. You help users with any task. You can control the computer, browse the web, write code, and much more. Always respond in the same language the user speaks. Be helpful, smart, and efficient."""
    print("⚠️ prompt.py not found — using default prompt")

# ── Tools ─────────────────────────────────────────────
try:
    from tools import TOOLS
except ImportError:
    TOOLS = []
    print("⚠️ tools.py not found — no tools available")

# ── Executor ──────────────────────────────────────────
try:
    from executor import execute_tool, handle_voice_command
except ImportError:
    try:
        from executor import execute_tool
        handle_voice_command = None
    except ImportError:
        execute_tool = None
        handle_voice_command = None
        print("⚠️ executor.py not found — tool execution disabled")

# ── Vision ────────────────────────────────────────────
try:
    from vision import vision
except ImportError:
    vision = None
    print("⚠️ vision.py not found — vision disabled")

# ── Memory ────────────────────────────────────────────
try:
    from memory import memory
except ImportError:
    memory = None
    print("⚠️ memory.py not found — memory disabled")

# ── App Helper ────────────────────────────────────────
try:
    from app import extract_app_name, open_website
except ImportError:
    try:
        from app import extract_app_name
        open_website = None
    except ImportError:
        extract_app_name = None
        open_website = None
        print("⚠️ app.py not found — app opening disabled")

# ── Face Lock ─────────────────────────────────────────
try:
    from face_lock import face_lock
except ImportError:
    face_lock = None
    print("⚠️ face_lock.py not found — face lock disabled")

# ── Self Upgrader ─────────────────────────────────────
try:
    from self_upgrader import upgrader
except ImportError:
    upgrader = None
    print("⚠️ self_upgrader.py not found — auto-update disabled")

# ── Error Handler ─────────────────────────────────────
try:
    from error_handler import logger
except ImportError:
    # Create a simple logger fallback
    import logging
    logger = logging.getLogger("RASHEED")
    logger.setLevel(logging.INFO)
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter('%(levelname)s: %(message)s'))
    logger.addHandler(handler)
    print("⚠️ error_handler.py not found — using basic logger")

# ── Plugin Engine ─────────────────────────────────────
try:
    from plugin_engine import plugin_engine
except ImportError:
    plugin_engine = None
    print("⚠️ plugin_engine.py not found — plugins disabled")


# ════════════════════════════════════════════════════════
# SETUP PAYLOAD — Gemini Live API Format
# ════════════════════════════════════════════════════════

def _build_setup():
    """Build the setup payload for Gemini Live API"""

    # Collect all tool declarations
    all_tools = list(TOOLS) if TOOLS else []

    if plugin_engine:
        try:
            plugin_tools = plugin_engine.get_tool_declarations()
            if plugin_tools:
                all_tools.extend(plugin_tools)
        except Exception as e:
            print(f"⚠️ Plugin tools error: {e}")

    setup_payload = {
        "setup": {
            "model": GEMINI_MODEL,
            "generation_config": {
                "temperature": 0.8,
                "response_modalities": ["AUDIO"],
                "speech_config": {
                    "voice_config": {
                        "prebuilt_voice_config": {
                            "voice_name": VOICE_NAME
                        }
                    }
                }
            },
            "input_audio_transcription": {},
            "output_audio_transcription": {},
            "system_instruction": {
                "parts": [
                    {
                        "text": RASHEED_PROMPT
                    }
                ]
            }
        }
    }

    # Only add tools if we have any
    if all_tools:
        setup_payload["setup"]["tools"] = [
            {
                "function_declarations": all_tools
            }
        ]

    return setup_payload


# ════════════════════════════════════════════════════════
# HELPER FUNCTIONS
# ════════════════════════════════════════════════════════

def enc(x):
    """Encode dict to JSON bytes for WebSocket"""
    try:
        return json.dumps(x).encode("utf-8")
    except (TypeError, ValueError) as e:
        logger.error(f"JSON encode error: {e}")
        return b"{}"


def get_user_transcript(msg: dict) -> str:
    """Extract user's spoken text from Gemini response"""
    sc = msg.get("serverContent", {})

    # Check multiple possible keys
    for key in ["inputTranscription", "inputTranscript"]:
        t = sc.get(key, {})
        if isinstance(t, dict) and t.get("text", "").strip():
            return t["text"].strip()
        if isinstance(t, str) and t.strip():
            return t.strip()

    return ""


# ════════════════════════════════════════════════════════
# RASHEED MAIN CLASS
# ════════════════════════════════════════════════════════

class RASHEED:

    def __init__(self):
        self.running = True
        self._ws = None
        self._loop = None
        self.cam_ok = False
        self._frame_q = _queue.Queue(maxsize=2)
        self._last_screen_b64 = ""
        self._vision_lock = threading.Lock()
        self._audio_q = None
        self._play_stop = None

        # ── Start Screen Capture Thread ───────────────
        if vision and HAS_MSS:
            self._screen_thread = threading.Thread(
                target=self._screen_capture_loop,
                daemon=True
            )
            self._screen_thread.start()
            print("🖥️ Screen capture thread started")
        else:
            self._screen_thread = None
            print("⚠️ Screen capture disabled (no vision module or mss)")

        # ── Start API Server (Optional) ──────────────
        try:
            from api_server import start_api_server
            api_thread = threading.Thread(
                target=start_api_server,
                daemon=True
            )
            api_thread.start()
            print("🌐 RASHEED API Server running on port 8000")
        except ImportError:
            print("ℹ️ API Server not available (api_server.py missing)")
        except Exception as e:
            print(f"⚠️ API Server failed: {e}")

    # ── Cleanup ───────────────────────────────────────
    def cleanup(self):
        """Properly shutdown all resources"""
        print("\n🛑 RASHEED shutting down...")
        self.running = False

        if self._play_stop:
            self._play_stop.set()

        if self._audio_q:
            try:
                self._audio_q.put(None, timeout=1)
            except:
                pass

        if vision:
            try:
                vision.stop_webcam()
            except:
                pass

        if upgrader:
            try:
                upgrader.stop_auto_checker()
            except:
                pass

        print("✅ Cleanup complete. Goodbye!")

    # ── Screen Capture Loop ───────────────────────────
    def _screen_capture_loop(self):
        """Continuously capture screen for vision"""
        while self.running:
            try:
                if vision:
                    b64 = vision.get_screen_b64(
                        width=SCREEN_WIDTH,
                        quality=SCREEN_QUALITY
                    )
                    if b64:
                        with self._vision_lock:
                            self._last_screen_b64 = b64
                time.sleep(VISION_INTERVAL)
            except Exception as e:
                logger.debug(f"Screen capture error: {e}")
                time.sleep(1.0)

    def _get_latest_screen(self) -> str:
        """Get the most recent screen capture"""
        with self._vision_lock:
            return self._last_screen_b64

    # ── Face Lock ─────────────────────────────────────
    def verify_face_lock(self) -> bool:
        """Check face lock at startup"""
        if not FACE_LOCK_ENABLED:
            logger.info("Face lock disabled — skipping verification")
            return True

        if not face_lock:
            logger.warning("Face lock module not available — skipping")
            return True

        try:
            logger.info("🔒 Face lock active — verifying identity...")
            result = face_lock.verify_at_startup()
            return result
        except AttributeError:
            logger.warning("Face lock verify method not found — skipping")
            return True
        except Exception as e:
            logger.error(f"Face lock error: {e}")
            return True  # Don't block on error

    # ── Main Start ────────────────────────────────────
    async def start(self):
        """Main entry point"""
        # Face lock check
        if not self.verify_face_lock():
            print("🚫 Access denied — RASHEED shutting down")
            logger.warning("Face lock verification failed!")
            return

        # Start auto updater
        if upgrader:
            try:
                upgrader.start_auto_checker()
                logger.info("Auto-updater started")
            except Exception as e:
                logger.warning(f"Auto-updater failed: {e}")

        # Check API key
        if not GEMINI_API_KEY:
            print("❌ Cannot start — GEMINI_API_KEY is empty!")
            print("💡 Set it in config.py")
            return

        # Check websockets
        if not HAS_WEBSOCKETS:
            print("❌ Cannot start — websockets not installed!")
            print("💡 Run: pip install websockets")
            return

        # Connection loop with retry
        retry_count = 0
        max_retries = 50

        while self.running and retry_count < max_retries:
            try:
                await self._session()
                retry_count = 0  # Reset on successful session

            except websockets.exceptions.ConnectionClosed as e:
                retry_count += 1
                wait = min(2 ** retry_count, 30)
                logger.warning(f"Connection closed: {e} — retry {retry_count} in {wait}s")
                print(f"🔄 Reconnecting in {wait} seconds...")
                await asyncio.sleep(wait)

            except websockets.exceptions.InvalidStatusCode as e:
                if "401" in str(e) or "403" in str(e):
                    print("❌ API Key invalid! Check your GEMINI_API_KEY")
                    return
                retry_count += 1
                wait = min(2 ** retry_count, 30)
                logger.error(f"HTTP error: {e} — retry in {wait}s")
                await asyncio.sleep(wait)

            except Exception as e:
                retry_count += 1
                wait = min(2 ** retry_count, 30)
                logger.error(f"Session error: {e} — retry {retry_count} in {wait}s")
                await asyncio.sleep(wait)

        if retry_count >= max_retries:
            print("❌ Max retries reached — RASHEED stopping")
        self.cleanup()

    # ── WebSocket Session ─────────────────────────────
    async def _session(self):
        """Single WebSocket session with Gemini"""
        ws_url = f"{GEMINI_WS_URL}?key={GEMINI_API_KEY}"

        async with websockets.connect(
            ws_url,
            max_size=None,
            ping_interval=20,
            ping_timeout=60,
            compression=None,
        ) as ws:

            self._ws = ws
            self._loop = asyncio.get_running_loop()

            # Send setup payload
            setup = _build_setup()
            await ws.send(enc(setup))

            # Wait for setup confirmation
            setup_resp = await ws.recv()
            resp_data = json.loads(setup_resp)

            # Check for setup errors
            if "error" in resp_data:
                error_msg = resp_data["error"].get("message", "Unknown error")
                print(f"❌ Setup error: {error_msg}")
                raise Exception(f"Gemini setup failed: {error_msg}")

            logger.info("✅ Gemini connected and configured!")
            print("✅ RASHEED v10.0 Ready! Bol boss...")
            print("─" * 60)

            # Audio queue and stop event
            self._audio_q = _queue.Queue()
            self._play_stop = asyncio.Event()

            # ── Start Speaker Thread ──────────────────
            play_t = threading.Thread(
                target=self._playback_thread,
                args=(self._audio_q, self._play_stop),
                daemon=True
            )
            play_t.start()

            # ── Start Webcam ─────────────────────────
            self.cam_ok = False
            if vision:
                try:
                    self.cam_ok = vision.start_webcam()
                    if self.cam_ok:
                        print("📷 Webcam started")
                    else:
                        print("ℹ️ Webcam not available — screen vision only")
                except Exception as e:
                    logger.warning(f"Webcam error: {e}")
                    self.cam_ok = False

            try:
                await asyncio.gather(
                    self._send_audio(ws),
                    self._send_vision(ws),
                    self._text_input(ws),
                    self._recv(ws, self._audio_q),
                )
            except asyncio.CancelledError:
                logger.info("Session cancelled")
            finally:
                self._play_stop.set()
                if self._audio_q:
                    try:
                        self._audio_q.put(None, timeout=1)
                    except:
                        pass
                play_t.join(timeout=3.0)

                if vision:
                    try:
                        vision.stop_webcam()
                    except:
                        pass

    # ── Audio Playback Thread ─────────────────────────
    def _playback_thread(self, audio_q, stop_event):
        """Separate thread for smooth audio playback"""
        BUF_SIZE = int(SPK_RATE * 0.20)  # 200ms buffer
        audio_buffer = np.array([], dtype=np.float32)

        try:
            stream = sd.OutputStream(
                samplerate=SPK_RATE,
                channels=1,
                dtype="float32",
                blocksize=BUF_SIZE,
                latency="high"
            )
            stream.start()
        except Exception as e:
            logger.error(f"Speaker init error: {e}")
            return

        while not stop_event.is_set():
            try:
                chunk = audio_q.get(timeout=0.15)
                if chunk is None:
                    continue

                audio_buffer = np.concatenate([audio_buffer, chunk])

                # Play buffered audio in chunks
                while len(audio_buffer) >= BUF_SIZE:
                    try:
                        stream.write(audio_buffer[:BUF_SIZE])
                        audio_buffer = audio_buffer[BUF_SIZE:]
                    except Exception as e:
                        logger.debug(f"Audio write error: {e}")
                        break

            except _queue.Empty:
                # Play remaining buffer even if no new data
                if len(audio_buffer) > 0:
                    try:
                        stream.write(audio_buffer)
                        audio_buffer = np.array([], dtype=np.float32)
                    except:
                        pass

            except Exception as e:
                logger.debug(f"Playback error: {e}")

        # Flush remaining audio
        if len(audio_buffer) > 0:
            try:
                stream.write(audio_buffer)
            except:
                pass

        try:
            stream.stop()
            stream.close()
        except:
            pass

    # ── Send Microphone Audio ─────────────────────────
    async def _send_audio(self, ws):
        """Capture and send microphone audio to Gemini"""
        try:
            with sd.InputStream(
                samplerate=MIC_RATE,
                channels=1,
                dtype="int16",
                blocksize=MIC_FRAMES,
                latency="low"
            ) as mic:
                while self.running:
                    try:
                        pcm, _ = mic.read(MIC_FRAMES)
                        if pcm is not None and len(pcm) > 0:
                            audio_b64 = base64.b64encode(
                                pcm.tobytes()
                            ).decode("utf-8")

                            await ws.send(enc({
                                "realtimeInput": {
                                    "audio": {
                                        "mimeType": "audio/pcm;rate=16000",
                                        "data": audio_b64
                                    }
                                }
                            }))
                    except Exception as e:
                        logger.debug(f"Mic read error: {e}")

                    await asyncio.sleep(0.01)

        except Exception as e:
            logger.error(f"Microphone init error: {e}")
            print("⚠️ Microphone not available — text mode only")

            # Keep the coroutine alive even without mic
            while self.running:
                await asyncio.sleep(1.0)

    # ── Send Vision Frames ────────────────────────────
    async def _send_vision(self, ws):
        """Send screen/webcam frames to Gemini"""
        frame_count = 0

        while self.running:
            try:
                frame_count += 1
                b64 = None

                # Every 3rd frame: try webcam
                if frame_count % 3 == 0 and self.cam_ok and vision:
                    try:
                        b64 = vision.get_webcam_b64()
                    except Exception as e:
                        logger.debug(f"Webcam frame error: {e}")
                        b64 = None

                # Fallback: screen capture
                if not b64:
                    b64 = self._get_latest_screen()

                if b64:
                    await ws.send(enc({
                        "realtimeInput": {
                            "video": {
                                "mimeType": "image/jpeg",
                                "data": b64
                            }
                        }
                    }))

            except websockets.exceptions.ConnectionClosed:
                break
            except Exception as e:
                logger.debug(f"Vision send error: {e}")

            await asyncio.sleep(VISION_INTERVAL)

    # ── Text Input ────────────────────────────────────
    async def _text_input(self, ws):
        """Handle typed text input from user"""
        def _input_loop():
            while self.running:
                try:
                    text = input().strip()
                    if not text:
                        continue

                    if text.lower() in ["exit", "quit", "bye"]:
                        print("👋 Shutting down RASHEED...")
                        self.running = False
                        return

                    if self._ws and self._loop and not self._loop.is_closed():
                        future = asyncio.run_coroutine_threadsafe(
                            ws.send(enc({
                                "realtimeInput": {
                                    "text": text
                                }
                            })),
                            self._loop
                        )
                        try:
                            future.result(timeout=5)
                        except Exception as e:
                            logger.error(f"Text send error: {e}")

                except EOFError:
                    # No more input (piped input ended)
                    self.running = False
                    return
                except Exception as e:
                    logger.debug(f"Input error: {e}")

        t = threading.Thread(target=_input_loop, daemon=True)
        t.start()

        # Keep coroutine alive
        while self.running:
            await asyncio.sleep(0.5)

    # ── Receiver ──────────────────────────────────────
    async def _recv(self, ws, audio_q):
        """Receive and process messages from Gemini"""
        while self.running:
            try:
                raw = await ws.recv()
                msg = json.loads(raw)

            except websockets.exceptions.ConnectionClosed:
                logger.warning("WebSocket connection closed")
                print("🔄 Connection lost — reconnecting...")
                break

            except json.JSONDecodeError as e:
                logger.error(f"JSON decode error: {e}")
                continue

            except Exception as e:
                logger.error(f"Receive error: {e}")
                await asyncio.sleep(0.1)
                continue

            # ── Handle Tool Calls ────────────────────
            tool_calls = (
                msg.get("toolCall", {})
                .get("functionCalls", [])
            )

            if tool_calls:
                responses = []

                for call in tool_calls:
                    tool_name = call.get("name", "unknown")
                    call_args = call.get("args", {})
                    call_id = call.get("id", "")

                    print(f"\n🔧 Tool Called: {tool_name}")

                    # Execute the tool
                    result = self._safe_execute_tool(tool_name, call_args)
                    print(f"   → Result: {str(result)[:200]}")

                    # Format response for Gemini
                    responses.append({
                        "id": call_id,
                        "name": tool_name,
                        "response": {
                            "result": str(result) if result is not None else "Tool executed successfully"
                        }
                    })

                # Send all tool responses back
                try:
                    await ws.send(enc({
                        "toolResponse": {
                            "functionResponses": responses
                        }
                    }))
                except Exception as e:
                    logger.error(f"Tool response send error: {e}")

            # ── User Transcript (What user said) ─────
            transcript = get_user_transcript(msg)

            if transcript:
                print(f"\n🗣️ Boss: {transcript}")

                # Save to memory
                if memory:
                    try:
                        memory.add_conversation(transcript, "processing...")
                    except AttributeError:
                        pass
                    except Exception as e:
                        logger.debug(f"Memory save error: {e}")

                # ── Voice Command Fallback ────────────
                if not tool_calls:
                    # Try handle_voice_command
                    if handle_voice_command:
                        try:
                            handled = handle_voice_command(transcript)
                            if handled:
                                continue
                        except Exception as e:
                            logger.debug(f"Voice command error: {e}")

                    # Try fallback app open
                    if extract_app_name and not tool_calls:
                        try:
                            app = extract_app_name(transcript)
                            if app:
                                result = self._safe_execute_tool(
                                    "open_app", {"app_name": app}
                                )
                                if result:
                                    print(f"   → Fallback app: {result}")
                        except Exception as e:
                            logger.debug(f"App extraction error: {e}")

                # ── URL Detection ────────────────────
                if not tool_calls:
                    try:
                        url_match = re.search(
                            r'(https?://[\w\.-]+\.\w{2,})',
                            transcript.lower()
                        )
                        if not url_match:
                            url_match = re.search(
                                r'([\w]+\.(com|pk|org|net|io|edu|gov|co)(\/\S*)?)',
                                transcript.lower()
                            )

                        if url_match:
                            url = url_match.group(0)
                            # Filter out common false positives
                            skip = ["ok.com", "ho.com", "hi.com", "ya.com", "no.com"]
                            if url not in skip and open_website:
                                print(f"🌐 Opening: {url}")
                                open_website(url)
                    except Exception as e:
                        logger.debug(f"URL detection error: {e}")

            # ── AI Response Text ─────────────────────
            sc = msg.get("serverContent", {})

            # Output transcription (what RASHEED said)
            out_trans = sc.get("outputTranscription", {})
            if isinstance(out_trans, dict):
                text = out_trans.get("text", "").strip()
                if text:
                    print(f"🤖 RASHEED: {text}")

                    # Save AI response to memory
                    if memory and transcript:
                        try:
                            memory.add_conversation(transcript, text)
                        except:
                            pass

            # ── Audio Output (PCM data) ──────────────
            for part in sc.get("modelTurn", {}).get("parts", []):
                inline_data = part.get("inlineData")
                if inline_data and "audio/pcm" in inline_data.get("mimeType", ""):
                    try:
                        raw_bytes = base64.b64decode(inline_data["data"])
                        pcm_audio = (
                            np.frombuffer(raw_bytes, dtype=np.int16)
                            .astype(np.float32) / 32768.0
                        )

                        # Put audio in queue for playback
                        if audio_q:
                            try:
                                audio_q.put_nowait(pcm_audio)
                            except _queue.Full:
                                # Drop oldest chunk if queue is full
                                try:
                                    audio_q.get_nowait()
                                except:
                                    pass
                                try:
                                    audio_q.put_nowait(pcm_audio)
                                except:
                                    pass
                    except Exception as e:
                        logger.debug(f"Audio decode error: {e}")

            # ── Turn Complete ────────────────────────
            if sc.get("turnComplete", False):
                # Signal that RASHEED finished speaking
                pass

    # ── Safe Tool Execution ───────────────────────────
    def _safe_execute_tool(self, tool_name, args):
        """Execute tool with full error handling"""
        if not execute_tool:
            return f"Error: Tool executor not available"

        try:
            result = execute_tool(tool_name, args)
            return result
        except Exception as e:
            error_msg = f"Tool '{tool_name}' error: {str(e)}"
            logger.error(error_msg)
            return error_msg


# ════════════════════════════════════════════════════════
# BANNER
# ════════════════════════════════════════════════════════

def _print_banner() -> None:
    banner = """
╔════════════════════════════════════════════════════════╗
║       🤖 RASHEED AI v10.0 GOD MODE                   ║
║       JARVIS Level ASI Assistant                      ║
║       Created by: Abdurrehman                         ║
║                                                        ║
║  ✅ Live Voice Chat (Gemini 2.0)                     ║
║  ✅ Text Input                                       ║
║  ✅ Screen Vision (Real-time)                        ║
║  ✅ Webcam Vision                                    ║
║  ✅ Face Lock Security                               ║
║  ✅ Self Healing & Upgrading                         ║
║  ✅ Plugin Engine                                    ║
║  ✅ 130+ Tools                                       ║
║  ✅ Cyber Shield                                     ║
║  ✅ Remote API                                       ║
║  ✅ Digital Twin                                     ║
║  ✅ Knowledge Graph                                  ║
║  ✅ Quant Finance Pro                                ║
║  ✅ Universe Mode (NASA/SpaceX)                      ║
║  ✅ God Coder                                        ║
╚════════════════════════════════════════════════════════╝
💬 Speak or type — 'exit' to quit
"""
    print(banner)


# ════════════════════════════════════════════════════════
# DEPENDENCY CHECK
# ════════════════════════════════════════════════════════

def check_dependencies():
    """Check and report missing dependencies"""
    missing = []

    try:
        import websockets
    except ImportError:
        missing.append("websockets")

    try:
        import sounddevice
    except ImportError:
        missing.append("sounddevice")

    try:
        import numpy
    except ImportError:
        missing.append("numpy")

    try:
        import cv2
    except ImportError:
        missing.append("opencv-python")

    try:
        import mss
    except ImportError:
        missing.append("mss")

    try:
        from PIL import Image
    except ImportError:
        missing.append("Pillow")

    if missing:
        print("\n❌ Missing Required Dependencies:")
        for m in missing:
            print(f"   - {m}")
        print(f"\n💡 Install all: pip install {' '.join(missing)}")
        print()

    return len(missing) == 0


# ════════════════════════════════════════════════════════
# ENTRY POINT
# ════════════════════════════════════════════════════════

def main():
    global GEMINI_API_KEY
    _print_banner()

    # Check dependencies
    if not check_dependencies():
        print("⚠️ Some features may not work without missing packages")
        print("Continuing anyway...\n")

    # Check API key
    if not GEMINI_API_KEY:
        print("❌ GEMINI_API_KEY is not set!")
        print("Create config.py with:")
        print("  GEMINI_API_KEY = 'your-api-key-here'")
        print()
        try:
            key = input("Or enter API key now: ").strip()
            if key:
                GEMINI_API_KEY = key
            else:
                print("No key provided. Exiting.")
                return
        except (EOFError, KeyboardInterrupt):
            return

    # Handle Ctrl+C gracefully
    def signal_handler(sig, frame):
        print("\n🛑 Ctrl+C pressed — shutting down...")
        sys.exit(0)

    signal.signal(signal.SIGINT, signal_handler)

    # Start RASHEED
    try:
        rasheed = RASHEED()
        asyncio.run(rasheed.start())
    except KeyboardInterrupt:
        print("\n👋 RASHEED stopped by user")
    except Exception as e:
        print(f"\n❌ Critical Error: {e}")
        traceback.print_exc()
    finally:
        try:
            rasheed.cleanup()
        except:
            pass


if __name__ == "__main__":
    main()