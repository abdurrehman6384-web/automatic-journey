# voice_changer.py — Real-Time Voice Changer
import numpy as np
import sounddevice as sd
import threading
from config import logger
from error_handler import safe_execute

class VoiceChanger:
    def __init__(self):
        self.active = False
        self.mode = "normal"  # normal, deep, robotic, chipmunk

    def set_mode(self, mode: str) -> str:
        modes = ["normal", "deep", "robotic", "chipmunk", "echo"]
        if mode.lower() not in modes:
            return f"❌ Modes: {', '.join(modes)}"
        self.mode = mode.lower()
        return f"🎙️ Voice mode: {self.mode}"

    def start(self) -> str:
        if self.active:
            return "Already active!"
        self.active = True
        t = threading.Thread(target=self._voice_loop, daemon=True)
        t.start()
        return f"🎙️ Voice changer active! Mode: {self.mode}"

    def stop(self) -> str:
        self.active = False
        return "🔇 Voice changer stopped."

    def _modify_audio(self, audio: np.ndarray) -> np.ndarray:
        if self.mode == "deep":
            # Pitch down by downsampling
            indices = np.arange(0, len(audio), 1.3).astype(int)
            shifted = audio[indices[:len(audio)]]
            return shifted[:len(audio)]
        
        elif self.mode == "chipmunk":
            # Pitch up
            indices = np.arange(0, len(audio), 0.7).astype(int)
            shifted = audio[indices % len(audio)]
            return shifted
        
        elif self.mode == "robotic":
            # Quantize + ring mod
            mod = np.sin(2 * np.pi * 50 * np.arange(len(audio)) / 16000)
            return (audio * mod * 1.5).astype(np.float32)
        
        elif self.mode == "echo":
            delay = int(16000 * 0.1)
            echoed = np.zeros(len(audio) + delay)
            echoed[:len(audio)] = audio
            echoed[delay:] += audio * 0.5
            return echoed[:len(audio)].astype(np.float32)
        
        return audio

    def _voice_loop(self):
        RATE = 16000
        BLOCK = 1024
        
        with sd.InputStream(samplerate=RATE, channels=1, dtype='float32', blocksize=BLOCK) as mic, \
             sd.OutputStream(samplerate=RATE, channels=1, dtype='float32', blocksize=BLOCK) as speaker:
            while self.active:
                audio, _ = mic.read(BLOCK)
                modified = self._modify_audio(audio.flatten())
                speaker.write(modified.reshape(-1, 1))


# Global instance
voice_changer = VoiceChanger()