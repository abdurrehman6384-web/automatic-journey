# ╔══════════════════════════════════════════════════════════╗
# ║       vector_memory.py — RASHEED Permanent Memory       ║
# ║       Stores everything with semantic search             ║
# ╚══════════════════════════════════════════════════════════╝

import os
import json
import hashlib
import time
from datetime import datetime


class VectorMemory:
    """RASHEED ki permanent memory — Har cheez yaad rakhta hai"""

    def __init__(self):
        self.memory_dir = "rasheed_memory"
        self.index_file = os.path.join(self.memory_dir, "memory_index.json")
        self.index = self._load_index()
        os.makedirs(self.memory_dir, exist_ok=True)

    # ── Index Management ──────────────────────────────
    def _load_index(self):
        try:
            if os.path.exists(self.index_file):
                with open(self.index_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
        except:
            pass
        return {
            "conversations": [],
            "facts": {},
            "files": [],
            "screenshots": [],
            "commands": [],
            "preferences": {},
            "stats": {
                "total_memories": 0,
                "total_conversations": 0,
                "total_commands": 0
            }
        }

    def _save_index(self):
        try:
            with open(self.index_file, 'w', encoding='utf-8') as f:
                json.dump(self.index, f, indent=2, ensure_ascii=False)
        except:
            pass

    # ════════════════════════════════════════════════════════
    # STORE: Different types of memories
    # ════════════════════════════════════════════════════════

    def store_conversation(self, user_text, ai_text, context=""):
        """Har conversation permanently yaad rakho"""
        entry = {
            "id": self._generate_id(user_text + ai_text),
            "timestamp": datetime.now().isoformat(),
            "user": user_text,
            "ai": ai_text,
            "context": context,
            "tags": self._extract_tags(user_text + " " + ai_text)
        }

        self.index["conversations"].append(entry)
        self.index["stats"]["total_conversations"] += 1
        self.index["stats"]["total_memories"] += 1
        self._save_index()

        # Also save to individual file for large data
        self._save_memory_file(f"conv_{entry['id']}", entry)

        return entry["id"]

    def store_fact(self, key, value, category="general"):
        """Koi bhi fact yaad rakho"""
        self.index["facts"][key.lower()] = {
            "value": value,
            "category": category,
            "stored_at": datetime.now().isoformat(),
            "accessed_count": 0
        }
        self.index["stats"]["total_memories"] += 1
        self._save_index()
        return f"✅ Fact stored: {key}"

    def store_file_memory(self, filepath, description="", content_preview=""):
        """File ke baare mein yaad rakho"""
        entry = {
            "filepath": filepath,
            "description": description,
            "preview": content_preview[:500] if content_preview else "",
            "stored_at": datetime.now().isoformat(),
            "tags": self._extract_tags(description)
        }
        self.index["files"].append(entry)
        self._save_index()
        return True

    def store_command(self, command, result, success=True):
        """Har executed command yaad rakho"""
        entry = {
            "command": command,
            "result": str(result)[:200],
            "success": success,
            "timestamp": datetime.now().isoformat()
        }
        self.index["commands"].append(entry)
        self.index["stats"]["total_commands"] += 1
        
        # Keep only last 1000 commands
        if len(self.index["commands"]) > 1000:
            self.index["commands"] = self.index["commands"][-1000:]
        
        self._save_index()

    def store_preference(self, key, value):
        """User ki preferences yaad rakho"""
        self.index["preferences"][key] = {
            "value": value,
            "updated_at": datetime.now().isoformat()
        }
        self._save_index()

    # ════════════════════════════════════════════════════════
    # SEARCH: Semantic keyword search across all memories
    # ════════════════════════════════════════════════════════

    def search(self, query, limit=10):
        """Memory mein search karo — keyword based semantic search"""
        query_lower = query.lower().strip()
        query_words = set(query_lower.split())
        results = []

        # Search in conversations
        for conv in self.index["conversations"][-500:]:  # Last 500
            score = self._calculate_score(query_words, conv)
            if score > 0:
                results.append({
                    "type": "conversation",
                    "score": score,
                    "data": conv
                })

        # Search in facts
        for key, fact in self.index["facts"].items():
            score = self._calculate_score(query_words, {
                "user": key, "ai": fact["value"], "tags": fact.get("tags", [])
            })
            if score > 0:
                results.append({
                    "type": "fact",
                    "score": score,
                    "data": {"key": key, **fact}
                })

        # Search in files
        for file_entry in self.index["files"]:
            score = self._calculate_score(query_words, {
                "user": file_entry.get("description", ""),
                "tags": file_entry.get("tags", [])
            })
            if score > 0:
                results.append({
                    "type": "file",
                    "score": score,
                    "data": file_entry
                })

        # Sort by score
        results.sort(key=lambda x: x["score"], reverse=True)

        # Format results
        if not results:
            return f"ℹ️ Memory mein '{query}' ke baare mein kuch nahi mila."

        output = f"\n🔍 Memory Search Results for '{query}':\n\n"
        for i, r in enumerate(results[:limit], 1):
            if r["type"] == "conversation":
                d = r["data"]
                output += f"  {i}. 💬 [{d['timestamp'][:10]}]\n"
                output += f"     Boss: {d['user'][:100]}\n"
                output += f"     RASHEED: {d['ai'][:100]}\n\n"
            elif r["type"] == "fact":
                d = r["data"]
                output += f"  {i}. 📌 Fact: {d['key']} = {d['value'][:100]}\n\n"
            elif r["type"] == "file":
                d = r["data"]
                output += f"  {i}. 📄 File: {d['filepath']}\n"
                output += f"     {d.get('description', 'No description')}\n\n"

        return output

    def _calculate_score(self, query_words, entry):
        """Calculate relevance score"""
        score = 0

        # Check user text
        user_text = entry.get("user", "").lower()
        for word in query_words:
            if word in user_text:
                score += 3  # Direct match in user text

        # Check AI text
        ai_text = entry.get("ai", "").lower()
        for word in query_words:
            if word in ai_text:
                score += 2  # Match in AI response

        # Check tags
        tags = entry.get("tags", [])
        for word in query_words:
            if word in tags:
                score += 5  # Tag match (highest relevance)

        # Check description
        desc = entry.get("description", "").lower() if isinstance(entry.get("description"), str) else ""
        for word in query_words:
            if word in desc:
                score += 2

        return score

    # ── Helpers ───────────────────────────────────────
    def _extract_tags(self, text):
        """Extract important keywords as tags"""
        # Common stop words to ignore
        stop_words = {"the", "a", "an", "is", "are", "was", "were", "be",
                      "do", "does", "did", "will", "would", "can", "could",
                      "me", "my", "you", "your", "it", "in", "on", "at",
                      "to", "for", "of", "with", "and", "or", "but", "not",
                      "ka", "ki", "ke", "ko", "mein", "se", "par", "hai",
                      "hain", "kya", "kab", "kaise", "kyun"}

        words = text.lower().split()
        tags = [w for w in words if len(w) > 2 and w not in stop_words]
        return list(set(tags))[:10]  # Max 10 tags

    def _generate_id(self, text):
        """Generate unique ID"""
        return hashlib.md5(f"{text}{time.time()}".encode()).hexdigest()[:8]

    def _save_memory_file(self, name, data):
        """Save individual memory file"""
        try:
            filepath = os.path.join(self.memory_dir, f"{name}.json")
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except:
            pass

    # ── Memory Stats ──────────────────────────────────
    def get_stats(self):
        """Memory statistics"""
        stats = self.index["stats"]
        num_facts = len(self.index["facts"])
        num_prefs = len(self.index["preferences"])
        num_files = len(self.index["files"])

        return f"""
╔════════════════════════════════════════════╗
║       🧠 RASHEED MEMORY STATS              ║
╠════════════════════════════════════════════╣
║  💬 Conversations: {stats.get('total_conversations', 0)}
║  📌 Facts Stored:  {num_facts}
║  ⚙️ Preferences:   {num_prefs}
║  📄 Files Known:   {num_files}
║  🔧 Commands Run:  {stats.get('total_commands', 0)}
║  📊 Total Memories: {stats.get('total_memories', 0)}
╚════════════════════════════════════════════╝
"""

    def remember_context(self, current_input):
        """Get relevant past memories for current input"""
        results = self.search(current_input, limit=3)
        if "ℹ️" in results:
            return ""
        return f"\n[MEMORY CONTEXT - Past relevant conversations]:\n{results}"

# ════════════════════════════════════════════════════════
# GLOBAL INSTANCE
# ════════════════════════════════════════════════════════


vector_memory = VectorMemory()
