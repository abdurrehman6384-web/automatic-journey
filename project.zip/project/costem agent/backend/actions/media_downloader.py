# media_downloader.py — YouTube, MP3, Instagram Downloader
import os
import subprocess
from pathlib import Path
from config import DATA_DIR, logger
from error_handler import safe_execute


class MediaDownloader:
    def __init__(self):
        self.download_dir = str(DATA_DIR / "downloads")
        os.makedirs(self.download_dir, exist_ok=True)

    @safe_execute(max_retries=1)
    def download_youtube(self, url: str, quality: str = "best") -> str:
        """Download YouTube video in best quality"""
        try:
            import yt_dlp
        except ImportError:
            return "❌ yt-dlp not installed. Run: pip install yt-dlp"

        output_template = os.path.join(self.download_dir, "%(title)s.%(ext)s")

        ydl_opts = {
            "format": "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best" if quality == "best" else f"best[height<={quality.replace('p','')}]",
            "outtmpl": output_template,
            "quiet": True,
            "no_warnings": True,
        }

        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=True)
                title = info.get("title", "Video")
                filename = ydl.prepare_filename(info)
                return f"✅ Downloaded: {title}\n💾 Saved: {filename}"
        except Exception as e:
            return f"❌ Download error: {e}"

    @safe_execute(max_retries=1)
    def download_mp3(self, url: str) -> str:
        """Extract audio/MP3 from YouTube video"""
        try:
            import yt_dlp
        except ImportError:
            return "❌ yt-dlp not installed. Run: pip install yt-dlp"

        output_template = os.path.join(self.download_dir, "%(title)s.%(ext)s")

        ydl_opts = {
            "format": "bestaudio/best",
            "outtmpl": output_template,
            "postprocessors": [{
                "key": "FFmpegExtractAudio",
                "preferredcodec": "mp3",
                "preferredquality": "320",
            }],
            "quiet": True,
            "no_warnings": True,
        }

        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=True)
                title = info.get("title", "Audio")
                return f"🎵 MP3 Downloaded: {title}\n💾 Saved in: {self.download_dir}"
        except Exception as e:
            return f"❌ MP3 error: {e}"

    @safe_execute(max_retries=1)
    def download_instagram(self, url: str) -> str:
        """Download Instagram Reel/Post/Story"""
        try:
            import yt_dlp
        except ImportError:
            return "❌ yt-dlp not installed. Run: pip install yt-dlp"

        output_template = os.path.join(self.download_dir, "insta_%(id)s.%(ext)s")

        ydl_opts = {
            "format": "best",
            "outtmpl": output_template,
            "quiet": True,
            "no_warnings": True,
        }

        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=True)
                title = info.get("title", "Instagram Media")
                return f"📸 Instagram Downloaded: {title}\n💾 Saved in: {self.download_dir}"
        except Exception as e:
            return f"❌ Instagram download error: {e}"


# Global instance
media_downloader = MediaDownloader()