# ambient_listener.py — Ambient Sound Intelligence
import threading
import time
# ── Standard Library Imports (Cython requires these at top) ──
import os
import sys
import time
import json
import re
import threading
import subprocess
import base64
import hashlib
import shutil
import glob
import socket
import signal
import traceback
import datetime
from pathlib import Path
from typing import Optional, List, Dict, Any
import numpy as np
import sounddevice as sd
from config import logger
from error_handler import safe_execute

class AmbientListener:
    """
    Listens to room sounds.
    Detects: Doorbell, Alarm, Glass break, Baby cry (via volume/frequency patterns).
    """

    def __init__(self):
        self.listening = False
        self.sensitivity = 0.05  # Volume threshold

    def start_listening(self) -> str:
        if self.listening:
            return "Already listening!"
        self.listening = True
        t = threading.Thread(target=self._listen_loop, daemon=True)
        t.start()
        return "👂 Ambient listener started! I'll alert you on loud sounds."

    def stop_listening(self) -> str:
        self.listening = False
        return "🔇 Ambient listener stopped."

    def _listen_loop(self):
        RATE = 16000
        BLOCK = 1600
        
        with sd.InputStream(samplerate=RATE, channels=1, dtype='float32', blocksize=BLOCK) as stream:
            while self.listening:
                try:
                    audio, _ = stream.read(BLOCK)
                    volume = np.sqrt(np.mean(audio**2))
                    
                    if volume > self.sensitivity:
                        # Loud sound detected
                        self._handle_sound(volume, audio)
                    
                    time.sleep(0.05)
                except Exception:
                    time.sleep(0.1)

    def _handle_sound(self, volume: float, audio: np.ndarray):
        """Analyze the sound type"""
        # Basic frequency analysis
        fft = np.abs(np.fft.fft(audio.flatten()))
        freqs = np.fft.fftfreq(len(fft), 1/16000)
        
        # Peak frequency
        peak_freq = abs(freqs[np.argmax(fft[1:])+1])
        
        # Categorize
        alert = ""
        if volume > 0.3:
            alert = "🚨 VERY LOUD SOUND"
        elif volume > 0.1:
            if 2000 < peak_freq < 4000:
                alert = "🔔 Possible doorbell/alarm!"
            elif 300 < peak_freq < 800:
                alert = "🗣️ Loud voice detected"
            else:
                alert = "🔊 Loud sound detected"
        
        if alert:
            logger.info(f"Ambient: {alert} (Vol: {volume:.2f}, Freq: {peak_freq:.0f}Hz)")
            try:
                from app import show_notification
                show_notification("Ambient Alert", alert)
            except Exception:
                pass


# Global instance
ambient = AmbientListener()
