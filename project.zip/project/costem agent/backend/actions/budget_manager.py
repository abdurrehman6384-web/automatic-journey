# budget_manager.py — Budget & Expense Manager
import sqlite3
import os
import json
from datetime import datetime
from config import DATA_DIR, logger
from error_handler import safe_execute

DB_FILE = str(DATA_DIR / "budget.db")

class BudgetManager:
    def __init__(self):
        self._setup_db()

    def _setup_db(self):
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS expenses 
                     (id INTEGER PRIMARY KEY, amount REAL, category TEXT, 
                      description TEXT, date TEXT)''')
        c.execute('''CREATE TABLE IF NOT EXISTS budget_alerts 
                     (id INTEGER PRIMARY KEY, category TEXT, limit_amount REAL)''')
        conn.commit()
        conn.close()

    # ── Expense Log ──────────────────────────────────
    AUTO_CATEGORIES = {
        "lunch": "Food", "dinner": "Food", "breakfast": "Food", "chai": "Food",
        "uber": "Transport", "careem": "Transport", "rickshaw": "Transport", "petrol": "Transport",
        "electricity": "Bills", "gas": "Bills", "internet": "Bills", "water": "Bills",
        "medicine": "Health", "doctor": "Health", "pharmacy": "Health",
        "movie": "Entertainment", "netflix": "Entertainment", "game": "Entertainment",
        "salary": "Income", "freelance": "Income",
    }

    @safe_execute(max_retries=1)
    def log_expense(self, amount: float, description: str) -> str:
        # Auto-categorize
        category = "Other"
        desc_lower = description.lower()
        for keyword, cat in self.AUTO_CATEGORIES.items():
            if keyword in desc_lower:
                category = cat
                break

        date = datetime.now().strftime("%Y-%m-%d %H:%M")
        
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute("INSERT INTO expenses (amount, category, description, date) VALUES (?, ?, ?, ?)",
                  (amount, category, description, date))
        conn.commit()
        conn.close()

        # Check budget alert
        alert = self._check_alert(category, amount)

        result = f"💸 Logged: Rs {amount:.0f} for '{description}' [{category}]"
        if alert:
            result += f"\n⚠️ {alert}"
        return result

    def _check_alert(self, category: str, new_amount: float) -> str:
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        
        # Get current month total for this category
        c.execute("""SELECT SUM(amount) FROM expenses 
                     WHERE category=? AND date LIKE ?""", 
                  (category, f"{datetime.now().strftime('%Y-%m')}%"))
        total = c.fetchone()[0] or 0
        total += new_amount
        
        # Check alert
        c.execute("SELECT limit_amount FROM budget_alerts WHERE category=?", (category,))
        row = c.fetchone()
        conn.close()
        
        if row and total > row[0]:
            return f"🚨 BUDGET ALERT: {category} mein Rs {total:.0f} kharch ho gaye! Limit: Rs {row[0]:.0f}"
        return ""

    @safe_execute(max_retries=1)
    def set_budget_alert(self, category: str, limit: float) -> str:
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute("INSERT OR REPLACE INTO budget_alerts (category, limit_amount) VALUES (?, ?)",
                  (category, limit))
        conn.commit()
        conn.close()
        return f"🔔 Alert set: {category} limit = Rs {limit:.0f}"

    @safe_execute(max_retries=1)
    def monthly_report(self) -> str:
        month = datetime.now().strftime("%Y-%m")
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        
        c.execute("""SELECT category, SUM(amount), COUNT(*) FROM expenses 
                     WHERE date LIKE ? GROUP BY category ORDER BY SUM(amount) DESC""",
                  (f"{month}%",))
        rows = c.fetchall()
        
        c.execute("SELECT SUM(amount) FROM expenses WHERE date LIKE ?", (f"{month}%",))
        total = c.fetchone()[0] or 0
        conn.close()

        if not rows:
            return f"📊 {month}: Koi expense nahi hai."

        report = f"📊 Monthly Report ({month}):\n\n"
        for cat, amount, count in rows:
            pct = (amount / total * 100) if total > 0 else 0
            bar = "█" * int(pct / 5) + "░" * (20 - int(pct / 5))
            report += f"  {cat:15s} Rs {amount:>8.0f} ({count}x) {bar} {pct:.0f}%\n"
        
        report += f"\n  {'TOTAL':15s} Rs {total:>8.0f}"
        return report

    @safe_execute(max_retries=1)
    def scan_bill(self, image_path: str) -> str:
        """OCR bill and auto-log expenses"""
        from vision import vision
        text = vision.read_screen_text()  # or process image
        if not text:
            return "❌ Bill scan fail"
        
        # AI extract amount and items
        from ai_brain import llm_router
        prompt = (
            f"Extract total amount and items from this bill text. "
            f"Output JSON: {{\"total\": 0, \"items\": [\"item1\", \"item2\"], \"store\": \"name\"}}\n\n"
            f"Bill Text:\n{text[:2000]}"
        )
        result = llm_router.smart_ask(prompt)
        return f"🧾 Bill Scanned: {result[:200]}"


# Global instance
budget = BudgetManager()