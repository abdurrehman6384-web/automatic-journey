# ai_brain.py — RAG, Multi-LLM, Emotion Detection, Voice Cloning
import os
import json
# ── Standard Library Imports (Cython requires these at top) ──
import os
import sys
import time
import json
import re
import threading
import subprocess
import base64
import hashlib
import shutil
import glob
import socket
import signal
import traceback
import datetime
from pathlib import Path
from typing import Optional, List, Dict, Any
import requests
import numpy as np
from config import (
    GROQ_API_KEY, OPENAI_API_KEY, ELEVENLABS_API_KEY,
    CHROMA_PERSIST_DIR, logger
)
from error_handler import safe_execute

# ══════════════════════════════════════════════════════════
# MULTI-LLM ROUTER
# ══════════════════════════════════════════════════════════
class MultiLLM:
    def __init__(self):
        self.groq_key = GROQ_API_KEY
        self.openai_key = OPENAI_API_KEY

    @safe_execute(max_retries=1)
    def ask_groq(self, prompt: str, model: str = "llama-3.1-70b-versatile") -> str:
        """Fast tasks via Groq"""
        url = "https://api.groq.com/openai/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.groq_key}",
            "Content-Type": "application/json"
        }
        data = {
            "model": model,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.7
        }
        r = requests.post(url, headers=headers, json=data, timeout=10)
        return r.json()["choices"][0]["message"]["content"]

    @safe_execute(max_retries=1)
    def ask_openai(self, prompt: str, model: str = "gpt-4o-mini") -> str:
        """Complex tasks via OpenAI"""
        url = "https://api.openai.com/v1/chat/completions"
        headers = {
            "Authorization": f"Bearer {self.openai_key}",
            "Content-Type": "application/json"
        }
        data = {
            "model": model,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0.7
        }
        r = requests.post(url, headers=headers, json=data, timeout=15)
        return r.json()["choices"][0]["message"]["content"]

    def smart_ask(self, prompt: str) -> str:
        """Auto router: Try Groq first (fast), fallback to OpenAI"""
        if self.groq_key:
            result = self.ask_groq(prompt)
            if result and "❌" not in str(result):
                return result
        if self.openai_key:
            result = self.ask_openai(prompt)
            if result and "❌" not in str(result):
                return result
        return "❌ All LLMs failed or no API keys configured."

# ══════════════════════════════════════════════════════════
# RAG SYSTEM (LOCAL KNOWLEDGE BASE)
# ══════════════════════════════════════════════════════════
class RAGSystem:
    def __init__(self):
        self.chroma_available = False
        try:
            import chromadb
            self.chroma_client = chromadb.PersistentClient(path=CHROMA_PERSIST_DIR)
            self.collection = self.chroma_client.get_or_create_collection("rasheed_knowledge")
            self.chroma_available = True
            logger.info("ChromaDB RAG initialized.")
        except ImportError:
            logger.warning("ChromaDB not installed. RAG disabled. pip install chromadb")

    def add_document(self, text: str, doc_id: str = "doc_1") -> str:
        if not self.chroma_available:
            return "❌ ChromaDB not installed"
        try:
            self.collection.upsert(documents=[text], ids=[doc_id])
            return f"✅ Document added to RAG: {doc_id}"
        except Exception as e:
            return f"❌ RAG add error: {e}"

    def add_pdf(self, pdf_path: str) -> str:
        try:
            import PyPDF2
            text = ""
            with open(pdf_path, 'rb') as f:
                reader = PyPDF2.PdfReader(f)
                for page in reader.pages[:50]:
                    text += page.extract_text() + "\n"
            doc_id = os.path.basename(pdf_path).replace(".pdf", "")
            return self.add_document(text, doc_id)
        except Exception as e:
            return f"❌ PDF read error: {e}"

    def query(self, question: str, n_results: int = 3) -> str:
        if not self.chroma_available:
            return "❌ ChromaDB not installed"
        try:
            results = self.collection.query(query_texts=[question], n_results=n_results)
            docs = results.get("documents", [[]])[0]
            if not docs:
                return "No relevant info found in knowledge base."
            context = "\n---\n".join(docs)
            # Use LLM to answer based on context
            llm = MultiLLM()
            prompt = f"Based on this context, answer the question:\nContext:\n{context}\n\nQuestion: {question}"
            return llm.smart_ask(prompt)
        except Exception as e:
            return f"❌ RAG query error: {e}"

# ══════════════════════════════════════════════════════════
# VOICE CLONING (ELEVENLABS)
# ══════════════════════════════════════════════════════════
class VoiceCloner:
    def __init__(self):
        self.api_key = ELEVENLABS_API_KEY

    def clone_and_speak(self, text: str, voice_id: str = "21m00Tcm4TlvDq8ikWAM") -> str:
        """Generate audio file with custom voice. Default is 'Rachel'."""
        if not self.api_key:
            return "❌ ElevenLabs API key not set"
        try:
            url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}"
            headers = {
                "xi-api-key": self.api_key,
                "Content-Type": "application/json"
            }
            data = {
                "text": text,
                "voice_settings": {"stability": 0.75, "similarity_boost": 0.75}
            }
            r = requests.post(url, headers=headers, json=data, timeout=15)
            if r.status_code == 200:
                out_path = "data/cloned_voice.mp3"
                with open(out_path, 'wb') as f:
                    f.write(r.content)
                # Play audio
                import subprocess
                subprocess.Popen(
                    [out_path], shell=True,
                    creationflags=subprocess.CREATE_NO_WINDOW
                )
                return "✅ Speaking with cloned voice!"
            return f"❌ ElevenLabs error: {r.status_code}"
        except Exception as e:
            return f"❌ Voice clone error: {e}"

# ══════════════════════════════════════════════════════════
# EMOTION DETECTION (AUDIO ANALYSIS)
# ══════════════════════════════════════════════════════════
class EmotionDetector:
    def detect_from_audio(self, audio_chunk: np.ndarray) -> str:
        """Analyze volume and speed to guess emotion (Basic)"""
        try:
            rms = np.sqrt(np.mean(audio_chunk**2))
            zero_crossings = np.sum(np.diff(np.sign(audio_chunk)) != 0)
            
            if rms < 0.01:
                return "calm"
            elif rms > 0.15 and zero_crossings > 5000:
                return "angry"
            elif rms > 0.08:
                return "excited"
            else:
                return "neutral"
        except Exception:
            return "neutral"

# Global instances
llm_router = MultiLLM()
rag_system = RAGSystem()
voice_cloner = VoiceCloner()
emotion_detector = EmotionDetector()
