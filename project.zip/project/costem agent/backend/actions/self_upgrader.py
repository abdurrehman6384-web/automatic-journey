# self_upgrader.py — RASHEED Self-Upgrading System
import os
import subprocess
import json
import time
import threading
import requests
from pathlib import Path
from config import (
    AUTO_UPDATE_ENABLED, GIT_REPO_URL, UPDATE_CHECK_INTERVAL,
    BASE_DIR, logger
)


class SelfUpgrader:
    """Auto-update system for RASHEED"""

    def __init__(self):
        self.enabled = AUTO_UPDATE_ENABLED
        self.repo_url = GIT_REPO_URL
        self.check_interval = UPDATE_CHECK_INTERVAL
        self.version_file = str(BASE_DIR / "data" / "version.json")
        self.current_version = self._load_version()
        self._update_thread = None
        self.running = False

    def _load_version(self) -> dict:
        """Load current version info"""
        default = {"version": "6.0.0", "build": "20250101", "channel": "stable"}
        try:
            if os.path.exists(self.version_file):
                with open(self.version_file, 'r') as f:
                    return json.load(f)
        except Exception:
            pass
        return default

    def _save_version(self):
        """Save version info"""
        try:
            os.makedirs(os.path.dirname(self.version_file), exist_ok=True)
            with open(self.version_file, 'w') as f:
                json.dump(self.current_version, f, indent=2)
        except Exception as e:
            logger.error(f"Version save error: {e}")

    def get_version(self) -> str:
        return f"v{self.current_version.get('version', '6.0.0')} ({self.current_version.get('build', 'unknown')})"

    def check_for_updates(self) -> dict:
        """Check if update available"""
        if not self.repo_url:
            return {"available": False, "message": "No repo URL configured"}

        try:
            result = subprocess.run(
                ["git", "fetch", "origin"],
                capture_output=True, text=True, timeout=30,
                cwd=str(BASE_DIR)
            )

            result = subprocess.run(
                ["git", "log", "HEAD..origin/main", "--oneline"],
                capture_output=True, text=True, timeout=10,
                cwd=str(BASE_DIR)
            )

            if result.stdout.strip():
                commits = result.stdout.strip().split('\n')
                return {
                    "available": True,
                    "commits": len(commits),
                    "details": result.stdout.strip()[:500]
                }

            return {"available": False, "message": "Already up to date!"}

        except FileNotFoundError:
            return {"available": False, "message": "Git not installed"}
        except Exception as e:
            return {"available": False, "message": f"Check error: {e}"}

    def perform_update(self) -> str:
        """Perform the update"""
        if not self.repo_url:
            return "❌ No git repo configured for updates."

        try:
            logger.info("Starting self-update...")

            # Stash local changes
            subprocess.run(
                ["git", "stash"],
                capture_output=True, timeout=10,
                cwd=str(BASE_DIR)
            )

            # Pull latest
            result = subprocess.run(
                ["git", "pull", "origin", "main"],
                capture_output=True, text=True, timeout=60,
                cwd=str(BASE_DIR)
            )

            if result.returncode != 0:
                # Restore stash on failure
                subprocess.run(
                    ["git", "stash", "pop"],
                    capture_output=True, timeout=10,
                    cwd=str(BASE_DIR)
                )
                return f"❌ Update failed: {result.stderr[:200]}"

            # Pop stash
            subprocess.run(
                ["git", "stash", "pop"],
                capture_output=True, timeout=10,
                cwd=str(BASE_DIR)
            )

            # Install new dependencies
            req_file = str(BASE_DIR / "requirements.txt")
            if os.path.exists(req_file):
                subprocess.run(
                    ["pip", "install", "-r", req_file, "--quiet"],
                    capture_output=True, timeout=120
                )

            # Update version
            from datetime import datetime
            self.current_version["build"] = datetime.now().strftime("%Y%m%d")
            self._save_version()

            logger.info("Self-update completed successfully!")
            return f"✅ Updated to {self.get_version()}! Restart required."

        except Exception as e:
            logger.error(f"Update error: {e}")
            return f"❌ Update error: {e}"

    def update_pip_packages(self) -> str:
        """Update all pip packages"""
        try:
            result = subprocess.run(
                ["pip", "list", "--outdated", "--format=json"],
                capture_output=True, text=True, timeout=30
            )

            if not result.stdout.strip():
                return "✅ All packages already up to date!"

            packages = json.loads(result.stdout)
            updated = 0
            failed = 0

            for pkg in packages[:10]:  # Max 10 at a time
                name = pkg["name"]
                r = subprocess.run(
                    ["pip", "install", "--upgrade", name],
                    capture_output=True, timeout=60
                )
                if r.returncode == 0:
                    updated += 1
                    logger.info(f"Updated: {name}")
                else:
                    failed += 1
                    logger.warning(f"Failed to update: {name}")

            return f"✅ Updated: {updated} packages | Failed: {failed}"

        except Exception as e:
            return f"❌ Package update error: {e}"

    def start_auto_checker(self):
        """Background thread for periodic update checks"""
        if not self.enabled:
            return

        self.running = True
        self._update_thread = threading.Thread(
            target=self._check_loop, daemon=True
        )
        self._update_thread.start()
        logger.info("Auto-update checker started.")

    def _check_loop(self):
        """Periodic check loop"""
        while self.running:
            try:
                time.sleep(self.check_interval)
                result = self.check_for_updates()
                if result.get("available"):
                    logger.info(
                        f"Update available! {result.get('commits', 0)} new commits."
                    )
            except Exception as e:
                logger.error(f"Auto-update check error: {e}")

    def stop_auto_checker(self):
        """Stop the auto checker"""
        self.running = False

    def get_system_health(self) -> dict:
        """Check system health"""
        health = {
            "python_version": "",
            "git_installed": False,
            "pip_working": False,
            "disk_space_gb": 0,
            "memory_percent": 0,
        }
        try:
            import sys
            health["python_version"] = sys.version

            r = subprocess.run(
                ["git", "--version"], capture_output=True, timeout=5
            )
            health["git_installed"] = r.returncode == 0

            r = subprocess.run(
                ["pip", "--version"], capture_output=True, timeout=5
            )
            health["pip_working"] = r.returncode == 0

            import shutil
            disk = shutil.disk_usage("/")
            health["disk_space_gb"] = round(disk.free / (1024**3), 1)

            import psutil
            health["memory_percent"] = psutil.virtual_memory().percent

        except Exception as e:
            health["error"] = str(e)

        return health


# Global upgrader
upgrader = SelfUpgrader()