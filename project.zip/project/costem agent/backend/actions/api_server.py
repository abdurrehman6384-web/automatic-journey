# api_server.py — FastAPI Backend & Webhook Receiver
from fastapi import FastAPI, Request
import uvicorn
import threading
from config import FASTAPI_PORT, logger
from executor import execute_tool

app = FastAPI(title="RASHEED API", version="8.0")

@app.post("/command")
async def run_command(request: Request):
    """Execute any RASHEED command via API"""
    data = await request.json()
    tool_name = data.get("tool")
    args = data.get("args", {})
    result = execute_tool(tool_name, args)
    return {"status": "success", "result": result}

@app.post("/webhook/github")
async def github_webhook(request: Request):
    """Receives GitHub webhooks and triggers actions"""
    payload = await request.json()
    action = payload.get("action")
    if action == "opened" and "issue" in payload:
        issue_title = payload["issue"]["title"]
        # Send WhatsApp/Telegram alert
        execute_tool("show_notification", {"title": "GitHub Issue", "message": issue_title})
        return {"status": "Alert sent"}
    return {"status": "Ignored"}

def start_api_server():
    """Run FastAPI in background thread"""
    uvicorn.run(app, host="0.0.0.0", port=FASTAPI_PORT, log_level="warning")