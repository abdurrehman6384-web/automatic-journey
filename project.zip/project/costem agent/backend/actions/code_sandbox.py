# code_sandbox.py — Interactive Code Sandbox
import subprocess
import os
import tempfile
from config import logger
from error_handler import safe_execute

class CodeSandbox:

    @safe_execute(max_retries=1)
    def execute_code(self, code: str, language: str = "python") -> str:
        if language.lower() != "python":
            return "❌ Only Python supported in sandbox."

        # Write to temp file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False, encoding='utf-8') as f:
            f.write(code)
            temp_path = f.name

        try:
            result = subprocess.run(
                ["python", temp_path],
                capture_output=True, text=True, timeout=10
            )
            
            output = ""
            if result.stdout:
                output += f"📤 Output:\n{result.stdout[:3000]}\n"
            if result.stderr:
                output += f"❌ Error:\n{result.stderr[:1000]}\n"
            if not output:
                output = "✅ Code executed (no output)"
            return output
        except subprocess.TimeoutExpired:
            return "⏱️ Code timed out (10s limit)"
        finally:
            os.unlink(temp_path)

    @safe_execute(max_retries=1)
    def test_regex(self, pattern: str, test_string: str) -> str:
        import re
        try:
            matches = re.findall(pattern, test_string)
            if matches:
                return f"✅ Matches: {matches}"
            return "❌ No matches found"
        except Exception as e:
            return f"❌ Regex error: {e}"

    @safe_execute(max_retries=1)
    def test_api(self, url: str, method: str = "GET") -> str:
        import requests
        try:
            if method.upper() == "GET":
                r = requests.get(url, timeout=10)
            else:
                r = requests.post(url, timeout=10)
            
            return f"Status: {r.status_code}\nHeaders: {dict(list(r.headers.items())[:5])}\nBody: {r.text[:500]}"
        except Exception as e:
            return f"❌ API error: {e}"


# Global instance
sandbox = CodeSandbox()