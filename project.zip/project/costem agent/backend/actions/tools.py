# ╔══════════════════════════════════════════════════════════╗
# ║       tools.py — RASHEED v10.0 FINAL                    ║
# ║       All Tool Declarations for Gemini Function Calling  ║
# ║       Syntax Fixed • No Duplicates • Complete            ║
# ╚══════════════════════════════════════════════════════════╝

TOOLS = [

    # ════════════════════════════════════════════════════════
    # ── App Control ────────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "open_app",
        "description": "Koi bhi app/software kholo. Chrome, Notepad, WhatsApp, VS Code, etc.",
        "parameters": {
            "type": "object",
            "properties": {
                "app_name": {"type": "string", "description": "App ka naam jaise 'Chrome', 'Notepad'"}
            },
            "required": ["app_name"]
        }
    },
    {
        "name": "close_app",
        "description": "Koi bhi running app band karo",
        "parameters": {
            "type": "object",
            "properties": {
                "app_name": {"type": "string", "description": "Band karne wali app ka naam"}
            },
            "required": ["app_name"]
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Typing ─────────────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "type_text",
        "description": "Screen par text type karo — Unicode support (Urdu, Hindi, Arabic)",
        "parameters": {
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "Type karne wala text"},
                "use_clipboard": {"type": "boolean", "description": "Clipboard use karo for Unicode"}
            },
            "required": ["text"]
        }
    },
    {
        "name": "press_key",
        "description": "Keyboard key press karo (enter, tab, escape, space, etc.)",
        "parameters": {
            "type": "object",
            "properties": {
                "key": {"type": "string", "description": "Key name like 'enter', 'tab', 'escape'"}
            },
            "required": ["key"]
        }
    },
    {
        "name": "hotkey",
        "description": "Keyboard shortcut press karo — ctrl+c, alt+f4, win+d, etc.",
        "parameters": {
            "type": "object",
            "properties": {
                "keys": {"type": "string", "description": "Shortcut like 'ctrl+c' or 'alt+tab'"}
            },
            "required": ["keys"]
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Mouse ──────────────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "click_at",
        "description": "Screen par specific position par click karo",
        "parameters": {
            "type": "object",
            "properties": {
                "x": {"type": "integer", "description": "X coordinate"},
                "y": {"type": "integer", "description": "Y coordinate"}
            },
            "required": ["x", "y"]
        }
    },
    {
        "name": "right_click",
        "description": "Right click karo at specific position",
        "parameters": {
            "type": "object",
            "properties": {
                "x": {"type": "integer", "description": "X coordinate"},
                "y": {"type": "integer", "description": "Y coordinate"}
            },
            "required": ["x", "y"]
        }
    },
    {
        "name": "double_click",
        "description": "Double click karo at specific position",
        "parameters": {
            "type": "object",
            "properties": {
                "x": {"type": "integer", "description": "X coordinate"},
                "y": {"type": "integer", "description": "Y coordinate"}
            },
            "required": ["x", "y"]
        }
    },
    {
        "name": "move_mouse",
        "description": "Mouse move karo smoothly to specific position",
        "parameters": {
            "type": "object",
            "properties": {
                "x": {"type": "integer", "description": "Target X coordinate"},
                "y": {"type": "integer", "description": "Target Y coordinate"}
            },
            "required": ["x", "y"]
        }
    },
    {
        "name": "mouse_click",
        "description": "Click mouse with options — left/right/middle, single/double",
        "parameters": {
            "type": "object",
            "properties": {
                "x": {"type": "integer", "description": "X coordinate (optional)"},
                "y": {"type": "integer", "description": "Y coordinate (optional)"},
                "button": {"type": "string", "description": "left, right, or middle"},
                "clicks": {"type": "integer", "description": "Number of clicks"}
            }
        }
    },
    {
        "name": "get_mouse_position",
        "description": "Current mouse position dikhao",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "scroll",
        "description": "Page scroll karo up ya down",
        "parameters": {
            "type": "object",
            "properties": {
                "direction": {"type": "string", "description": "up or down"},
                "amount": {"type": "integer", "description": "Scroll amount"}
            },
            "required": ["direction"]
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Browser ────────────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "open_website",
        "description": "Browser mein website kholo",
        "parameters": {
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "Website URL"}
            },
            "required": ["url"]
        }
    },
    {
        "name": "search_google",
        "description": "Google par search karo",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query"}
            },
            "required": ["query"]
        }
    },
    {
        "name": "search_youtube",
        "description": "YouTube par search karo",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "YouTube search query"}
            },
            "required": ["query"]
        }
    },
    {
        "name": "play_youtube",
        "description": "YouTube video ya song play karo",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Song ya video ka naam"}
            },
            "required": ["query"]
        }
    },
    {
        "name": "search_wikipedia",
        "description": "Wikipedia par search karo aur summary do",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Wikipedia search topic"}
            },
            "required": ["query"]
        }
    },

    # ════════════════════════════════════════════════════════
    # ── YouTube Upload ─────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "upload_youtube",
        "description": "YouTube par video upload karo",
        "parameters": {
            "type": "object",
            "properties": {
                "video_path": {"type": "string", "description": "Video file path"},
                "title": {"type": "string", "description": "Video title"},
                "description": {"type": "string", "description": "Video description"},
                "privacy": {"type": "string", "description": "public, unlisted, or private"}
            },
            "required": ["video_path", "title"]
        }
    },
    {
        "name": "get_youtube_videos",
        "description": "Apni YouTube channel ki videos dekho",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Instagram ──────────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "upload_instagram_photo",
        "description": "Instagram par photo upload karo",
        "parameters": {
            "type": "object",
            "properties": {
                "image_path": {"type": "string", "description": "Photo file path"},
                "caption": {"type": "string", "description": "Photo caption"}
            },
            "required": ["image_path"]
        }
    },
    {
        "name": "upload_instagram_video",
        "description": "Instagram par video/reel upload karo",
        "parameters": {
            "type": "object",
            "properties": {
                "video_path": {"type": "string", "description": "Video file path"},
                "caption": {"type": "string", "description": "Video caption"}
            },
            "required": ["video_path"]
        }
    },
    {
        "name": "instagram_login",
        "description": "Instagram login karo",
        "parameters": {
            "type": "object",
            "properties": {
                "username": {"type": "string", "description": "Instagram username"},
                "password": {"type": "string", "description": "Instagram password"}
            },
            "required": ["username", "password"]
        }
    },
    {
        "name": "instagram_profile",
        "description": "Instagram profile info dekho",
        "parameters": {
            "type": "object",
            "properties": {
                "username": {"type": "string", "description": "Instagram username"}
            },
            "required": ["username"]
        }
    },

    # ════════════════════════════════════════════════════════
    # ── File Management ────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "create_folder",
        "description": "Naya folder banao",
        "parameters": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Folder ka naam"},
                "path": {"type": "string", "description": "Kahan banana hai (optional)"}
            },
            "required": ["name"]
        }
    },
    {
        "name": "create_file",
        "description": "Nai file banao with content",
        "parameters": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "File ka naam"},
                "content": {"type": "string", "description": "File ka content"},
                "path": {"type": "string", "description": "Kahan banana hai (optional)"}
            },
            "required": ["name"]
        }
    },
    {
        "name": "delete_file",
        "description": "File delete karo",
        "parameters": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "File ka naam"},
                "path": {"type": "string", "description": "File ka path (optional)"}
            },
            "required": ["name"]
        }
    },
    {
        "name": "read_file",
        "description": "File ka content padho",
        "parameters": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "File ka naam"},
                "path": {"type": "string", "description": "File ka path (optional)"}
            },
            "required": ["name"]
        }
    },
    {
        "name": "list_files",
        "description": "Folder ki files list karo",
        "parameters": {
            "type": "object",
            "properties": {
                "path": {"type": "string", "description": "Folder path (optional)"}
            }
        }
    },
    {
        "name": "search_file",
        "description": "File search karo system mein",
        "parameters": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Search keyword"}
            },
            "required": ["name"]
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Screen ─────────────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "take_screenshot",
        "description": "Full screen screenshot lo",
        "parameters": {
            "type": "object",
            "properties": {
                "filename": {"type": "string", "description": "Save filename (optional)"}
            }
        }
    },
    {
        "name": "take_screenshot_region",
        "description": "Specific screen region ka screenshot lo",
        "parameters": {
            "type": "object",
            "properties": {
                "x": {"type": "integer", "description": "Start X"},
                "y": {"type": "integer", "description": "Start Y"},
                "width": {"type": "integer", "description": "Region width"},
                "height": {"type": "integer", "description": "Region height"},
                "save_path": {"type": "string", "description": "Save path (optional)"}
            },
            "required": ["x", "y", "width", "height"]
        }
    },
    {
        "name": "read_screen_text",
        "description": "OCR se screen ka text padho",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── System Info ────────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "get_system_info",
        "description": "Battery, CPU, RAM, Disk basic info",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "detailed_system_info",
        "description": "Detailed system report — OS, CPU, RAM, Disk, Network, Uptime, Battery",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "get_system_temperature",
        "description": "CPU/GPU temperature, fan speed, system health check",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "get_weather",
        "description": "Current weather info kisi city ka",
        "parameters": {
            "type": "object",
            "properties": {
                "city": {"type": "string", "description": "City name"}
            }
        }
    },
    {
        "name": "calculate",
        "description": "Math calculation karo",
        "parameters": {
            "type": "object",
            "properties": {
                "expression": {"type": "string", "description": "Math expression like '25*4+10'"}
            },
            "required": ["expression"]
        }
    },
    {
        "name": "internet_speed_test",
        "description": "Internet speed test — download, upload, ping",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "get_my_location",
        "description": "Current IP-based location — city, country, ISP, coordinates",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── System Control ─────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "shutdown_pc",
        "description": "PC shutdown karo",
        "parameters": {
            "type": "object",
            "properties": {
                "timer": {"type": "integer", "description": "Delay in minutes (0 = immediate)"}
            }
        }
    },
    {
        "name": "restart_pc",
        "description": "PC restart karo",
        "parameters": {
            "type": "object",
            "properties": {
                "timer": {"type": "integer", "description": "Delay in minutes"}
            }
        }
    },
    {
        "name": "sleep_pc",
        "description": "PC sleep/hibernate mode mein daalo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "lock_pc",
        "description": "PC screen lock karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "cancel_shutdown",
        "description": "Pending shutdown/restart cancel karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Volume Control ─────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "set_volume",
        "description": "Volume exact level par set karo (0-100)",
        "parameters": {
            "type": "object",
            "properties": {
                "level": {"type": "integer", "description": "Volume level 0-100"}
            },
            "required": ["level"]
        }
    },
    {
        "name": "volume_up",
        "description": "Volume increase karo",
        "parameters": {
            "type": "object",
            "properties": {
                "steps": {"type": "integer", "description": "Kitna badhana hai (default 10)"}
            }
        }
    },
    {
        "name": "volume_down",
        "description": "Volume decrease karo",
        "parameters": {
            "type": "object",
            "properties": {
                "steps": {"type": "integer", "description": "Kitna kam karna hai (default 10)"}
            }
        }
    },
    {
        "name": "volume_mute",
        "description": "Volume mute karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "unmute_volume",
        "description": "Volume unmute karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Brightness Control ─────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "set_brightness",
        "description": "Screen brightness set karo (0-100)",
        "parameters": {
            "type": "object",
            "properties": {
                "level": {"type": "integer", "description": "Brightness level 0-100"}
            },
            "required": ["level"]
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Clipboard ──────────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "get_clipboard",
        "description": "Clipboard ka current text padho",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "copy_to_clipboard",
        "description": "Clipboard mein text copy karo",
        "parameters": {
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "Copy karne wala text"}
            },
            "required": ["text"]
        }
    },
    {
        "name": "clipboard_history",
        "description": "Clipboard history dikhao",
        "parameters": {
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "description": "Kitni entries dikhani hain"}
            }
        }
    },
    {
        "name": "pin_clipboard",
        "description": "Clipboard item pin karo (delete nahi hoga)",
        "parameters": {
            "type": "object",
            "properties": {
                "item_id": {"type": "integer", "description": "Item ID to pin"}
            },
            "required": ["item_id"]
        }
    },
    {
        "name": "copy_from_history",
        "description": "Clipboard history se item copy karo",
        "parameters": {
            "type": "object",
            "properties": {
                "item_id": {"type": "integer", "description": "Item ID to copy"}
            },
            "required": ["item_id"]
        }
    },
    {
        "name": "clear_clipboard",
        "description": "Clipboard history clear karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "start_clipboard_monitor",
        "description": "Clipboard monitor start karo — auto track copies",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Time & Date ────────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "get_time",
        "description": "Current time batao",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "get_date",
        "description": "Current date batao",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Alarm System ───────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "set_alarm",
        "description": "Alarm set karo with loud sound — format HH:MM or HH:MM AM/PM",
        "parameters": {
            "type": "object",
            "properties": {
                "alarm_time_str": {"type": "string", "description": "Time like '07:30 AM' or '14:30'"},
                "message": {"type": "string", "description": "Alarm message/label"}
            },
            "required": ["alarm_time_str"]
        }
    },
    {
        "name": "list_alarms",
        "description": "Sab active alarms dikhao",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "stop_all_alarms",
        "description": "Sab alarms stop karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── CMD ────────────────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "run_cmd",
        "description": "Windows CMD command chalao",
        "parameters": {
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "CMD command string"}
            },
            "required": ["command"]
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Communication ──────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "send_whatsapp",
        "description": "WhatsApp message bhejo",
        "parameters": {
            "type": "object",
            "properties": {
                "number": {"type": "string", "description": "Phone number with country code"},
                "message": {"type": "string", "description": "Message text"}
            },
            "required": ["number", "message"]
        }
    },
    {
        "name": "show_notification",
        "description": "Windows notification show karo",
        "parameters": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Notification title"},
                "message": {"type": "string", "description": "Notification message"}
            },
            "required": ["title", "message"]
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Process ────────────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "kill_process",
        "description": "Running process band karo by name",
        "parameters": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Process name like 'chrome.exe'"}
            },
            "required": ["name"]
        }
    },
    {
        "name": "get_active_window",
        "description": "Currently active window ka naam lo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Webcam & Photo ─────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "capture_photo",
        "description": "Webcam se photo capture karo",
        "parameters": {
            "type": "object",
            "properties": {
                "save_path": {"type": "string", "description": "Optional save path"}
            }
        }
    },
    {
        "name": "capture_burst_photos",
        "description": "Burst mode — multiple photos ek saath capture karo",
        "parameters": {
            "type": "object",
            "properties": {
                "count": {"type": "integer", "description": "Number of photos (default 5)"},
                "interval": {"type": "integer", "description": "Seconds between photos (default 1)"}
            }
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Screen Recording ───────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "start_screen_recording",
        "description": "Screen recording start karo",
        "parameters": {
            "type": "object",
            "properties": {
                "duration_seconds": {"type": "integer", "description": "Recording duration (optional)"},
                "fps": {"type": "integer", "description": "Frames per second (default 20)"}
            }
        }
    },
    {
        "name": "stop_screen_recording",
        "description": "Current screen recording stop karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Website Blocker / Focus Mode Pro ───────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "block_websites",
        "description": "Distracting websites block karo (social media, etc.) — requires admin",
        "parameters": {
            "type": "object",
            "properties": {
                "custom_sites": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Custom websites to block (optional)"
                }
            }
        }
    },
    {
        "name": "unblock_websites",
        "description": "Block kiye hue websites unblock karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "focus_mode_pro",
        "description": "Enhanced focus mode — websites block + Pomodoro + DND",
        "parameters": {
            "type": "object",
            "properties": {
                "duration_minutes": {"type": "integer", "description": "Total focus time in minutes"},
                "custom_blocked": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Custom websites to block"
                }
            }
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Game Mode ──────────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "start_game_mode",
        "description": "Game mode start karo — background apps kill, RAM boost",
        "parameters": {
            "type": "object",
            "properties": {
                "mode": {"type": "string", "description": "casual, competitive, or streaming"}
            },
            "required": ["mode"]
        }
    },
    {
        "name": "stop_game_mode",
        "description": "Game mode stop karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Face Lock ──────────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "face_enroll",
        "description": "Authorized face enroll karo for face lock",
        "parameters": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Person ka naam"}
            },
            "required": ["name"]
        }
    },
    {
        "name": "face_lock_status",
        "description": "Face lock system ka status dekho",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Self Upgrade ───────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "check_updates",
        "description": "RASHEED updates check karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "perform_update",
        "description": "RASHEED update install karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "update_packages",
        "description": "Sab pip packages update karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "get_version",
        "description": "Current RASHEED version dekho",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Memory ─────────────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "save_memory",
        "description": "Memory save karo — facts, preferences, reminders",
        "parameters": {
            "type": "object",
            "properties": {
                "category": {"type": "string", "description": "Memory category"},
                "key": {"type": "string", "description": "Memory key"},
                "value": {"type": "string", "description": "Memory value"}
            },
            "required": ["category", "key", "value"]
        }
    },
    {
        "name": "search_memory",
        "description": "Memory search karo — keyword se dhundho",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query"}
            },
            "required": ["query"]
        }
    },
    {
        "name": "memory_stats",
        "description": "Memory store ka statistics dekho",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "vector_memory_search",
        "description": "Semantic AI search — meaning se dhundho, keyword nahi",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Semantic search query"}
            },
            "required": ["query"]
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Error Report ───────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "error_summary",
        "description": "Sab recent errors ka summary dekho",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── AI Brain ───────────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "ask_ai",
        "description": "Complex AI question ka jawab do — Multi-LLM fallback",
        "parameters": {
            "type": "object",
            "properties": {
                "prompt": {"type": "string", "description": "Question ya prompt"}
            },
            "required": ["prompt"]
        }
    },
    {
        "name": "rag_add_document",
        "description": "RAG knowledge base mein text document add karo",
        "parameters": {
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "Document text"},
                "doc_id": {"type": "string", "description": "Document ID (optional)"}
            },
            "required": ["text"]
        }
    },
    {
        "name": "rag_add_pdf",
        "description": "PDF file ko RAG knowledge base mein add karo",
        "parameters": {
            "type": "object",
            "properties": {
                "pdf_path": {"type": "string", "description": "PDF file path"}
            },
            "required": ["pdf_path"]
        }
    },
    {
        "name": "rag_query",
        "description": "RAG knowledge base se sawal pucho",
        "parameters": {
            "type": "object",
            "properties": {
                "question": {"type": "string", "description": "Question to ask RAG"}
            },
            "required": ["question"]
        }
    },
    {
        "name": "clone_voice",
        "description": "Custom cloned voice mein bolo (ElevenLabs)",
        "parameters": {
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "Text to speak"},
                "voice_id": {"type": "string", "description": "Voice clone ID"}
            },
            "required": ["text"]
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Developer Mode ─────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "git_commit_push",
        "description": "Git add, commit aur push karo ek command mein",
        "parameters": {
            "type": "object",
            "properties": {
                "message": {"type": "string", "description": "Commit message"}
            },
            "required": ["message"]
        }
    },
    {
        "name": "generate_code",
        "description": "AI se code generate karo aur VS Code mein kholo",
        "parameters": {
            "type": "object",
            "properties": {
                "description": {"type": "string", "description": "Code description"},
                "filename": {"type": "string", "description": "File name (optional)"}
            },
            "required": ["description"]
        }
    },
    {
        "name": "auto_debug",
        "description": "Screen ya clipboard se error padh ke fix suggest karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "explain_code",
        "description": "Screen pe jo code hai usko AI se explain karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "auto_refactor",
        "description": "AI se kisi bhi Python file ka code optimize karo",
        "parameters": {
            "type": "object",
            "properties": {
                "file_path": {"type": "string", "description": "Python file path"}
            },
            "required": ["file_path"]
        }
    },
    {
        "name": "start_self_healer",
        "description": "Background self-healing crash monitor start karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "generate_plugin",
        "description": "Dynamic plugin generate karo aur live load karo",
        "parameters": {
            "type": "object",
            "properties": {
                "description": {"type": "string", "description": "Plugin description"},
                "plugin_name": {"type": "string", "description": "Plugin name"}
            },
            "required": ["description", "plugin_name"]
        }
    },

    # ════════════════════════════════════════════════════════
    # ── IoT & Automation ───────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "lights_on",
        "description": "Smart lights on karo",
        "parameters": {
            "type": "object",
            "properties": {
                "room": {"type": "string", "description": "Room name"}
            }
        }
    },
    {
        "name": "lights_off",
        "description": "Smart lights off karo",
        "parameters": {
            "type": "object",
            "properties": {
                "room": {"type": "string", "description": "Room name"}
            }
        }
    },
    {
        "name": "check_emails",
        "description": "Unread Gmail emails padho",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "fill_form",
        "description": "Web form auto-fill karo",
        "parameters": {
            "type": "object",
            "properties": {
                "data": {"type": "object", "description": "Form field-value pairs"}
            },
            "required": ["data"]
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Security & Ghost ───────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "scan_network",
        "description": "Network scan karo aur connected devices dikhao",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "vpn_connect",
        "description": "VPN connect karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "vpn_disconnect",
        "description": "VPN disconnect karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "encrypt_memory",
        "description": "Memory file encrypt karo for security",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "decrypt_memory",
        "description": "Memory file decrypt karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "anti_spyware_scan",
        "description": "Spyware aur suspicious processes scan karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "deploy_honeypot",
        "description": "Hacker trap honeypot deploy karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "monitor_ddos",
        "description": "DDoS attack monitor karo aur block karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "check_dark_web",
        "description": "Email dark web pe leak hai ya nahi check karo",
        "parameters": {
            "type": "object",
            "properties": {
                "email": {"type": "string", "description": "Email to check"}
            },
            "required": ["email"]
        }
    },
    {
        "name": "harden_firewall",
        "description": "Windows firewall harden karo aur ports band karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "start_usb_monitor",
        "description": "USB device monitoring start karo — unauthorized USB detect",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "patch_system",
        "description": "Security patches check aur install karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Lifestyle ──────────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "spotify_next",
        "description": "Spotify next track chalao",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "spotify_previous",
        "description": "Spotify previous track chalao",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "spotify_play_pause",
        "description": "Spotify play/pause toggle karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "prayer_times",
        "description": "Namaz ki timing batao — Fajr, Dhuhr, Asr, Maghrib, Isha",
        "parameters": {
            "type": "object",
            "properties": {
                "city": {"type": "string", "description": "City name"}
            }
        }
    },
    {
        "name": "crypto_price",
        "description": "Crypto ya stock ka current price batao",
        "parameters": {
            "type": "object",
            "properties": {
                "symbol": {"type": "string", "description": "Symbol like 'BTC', 'ETH', 'AAPL'"}
            },
            "required": ["symbol"]
        }
    },
    {
        "name": "start_focus_mode",
        "description": "Pomodoro focus mode start karo",
        "parameters": {
            "type": "object",
            "properties": {
                "minutes": {"type": "integer", "description": "Focus duration in minutes"}
            }
        }
    },
    {
        "name": "stop_focus_mode",
        "description": "Focus mode band karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "party_mode",
        "description": "Party mode start ya stop karo — lights + music",
        "parameters": {
            "type": "object",
            "properties": {
                "action": {"type": "string", "description": "start or stop"}
            }
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Autonomous Agent ───────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "agent_execute",
        "description": "Execute a complex multi-step task autonomously",
        "parameters": {
            "type": "object",
            "properties": {
                "goal": {"type": "string", "description": "Goal description"}
            },
            "required": ["goal"]
        }
    },
    {
        "name": "add_task_to_queue",
        "description": "Background task queue mein task add karo",
        "parameters": {
            "type": "object",
            "properties": {
                "task": {"type": "string", "description": "Task description"},
                "priority": {"type": "integer", "description": "Priority level (1-10)"}
            },
            "required": ["task"]
        }
    },
    {
        "name": "process_task_queue",
        "description": "Sab pending tasks process karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Browser Automation ─────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "web_scrape",
        "description": "Website se text scrape karo using Playwright",
        "parameters": {
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "Website URL"},
                "selector": {"type": "string", "description": "CSS selector (optional)"}
            },
            "required": ["url"]
        }
    },
    {
        "name": "web_fill_form",
        "description": "Web form automatically fill karo",
        "parameters": {
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "Form page URL"},
                "fields": {"type": "object", "description": "Field-value pairs"},
                "submit_selector": {"type": "string", "description": "Submit button selector"}
            },
            "required": ["url", "fields"]
        }
    },
    {
        "name": "track_price",
        "description": "Product price track karo aur alert do",
        "parameters": {
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "Product page URL"},
                "selector": {"type": "string", "description": "Price element CSS selector"},
                "target_price": {"type": "number", "description": "Target price for alert"}
            },
            "required": ["url", "selector", "target_price"]
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Deep OS Control ────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "disable_telemetry",
        "description": "Windows tracking aur telemetry disable karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "manage_startup",
        "description": "Startup apps list ya remove karo",
        "parameters": {
            "type": "object",
            "properties": {
                "action": {"type": "string", "description": "list or remove"},
                "app_name": {"type": "string", "description": "App to remove (for remove action)"}
            }
        }
    },
    {
        "name": "create_cron",
        "description": "Daily scheduled task banao",
        "parameters": {
            "type": "object",
            "properties": {
                "task_name": {"type": "string", "description": "Task name"},
                "command": {"type": "string", "description": "Command to run"},
                "time": {"type": "string", "description": "Time HH:MM format"}
            },
            "required": ["task_name", "command", "time"]
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Quant Finance Pro ──────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "find_arbitrage",
        "description": "Exchanges ke beech price difference dhundho for arbitrage",
        "parameters": {
            "type": "object",
            "properties": {
                "symbol": {"type": "string", "description": "Trading pair like 'BTC/USDT'"}
            }
        }
    },
    {
        "name": "market_sentiment",
        "description": "Crypto Fear & Greed index aur market strategy batao",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "monitor_whales",
        "description": "Whale transactions monitor karo — large crypto moves",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "calculate_grid",
        "description": "Grid trading levels calculate karo",
        "parameters": {
            "type": "object",
            "properties": {
                "symbol": {"type": "string", "description": "Trading pair"},
                "lower": {"type": "number", "description": "Lower price bound"},
                "upper": {"type": "number", "description": "Upper price bound"},
                "grids": {"type": "integer", "description": "Number of grid levels"}
            },
            "required": ["symbol", "lower", "upper"]
        }
    },
    {
        "name": "find_best_yield",
        "description": "Best staking aur DeFi yields dhundho",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "options_screener",
        "description": "High volatility stocks for options trading dhundho",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "forex_arb_simulator",
        "description": "Forex triangular arbitrage simulate karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "nft_sniper",
        "description": "NFT floor price drops track karo",
        "parameters": {
            "type": "object",
            "properties": {
                "collection": {"type": "string", "description": "NFT collection name"}
            }
        }
    },
    {
        "name": "scan_micro_caps",
        "description": "High volume micro-cap crypto tokens scan karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Universe Mode (Space & Satellite) ──────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "satellite_view",
        "description": "NASA se kisi city ka satellite image download karo",
        "parameters": {
            "type": "object",
            "properties": {
                "city": {"type": "string", "description": "City name"}
            },
            "required": ["city"]
        }
    },
    {
        "name": "satellite_coords",
        "description": "Specific coordinates ka satellite image lo",
        "parameters": {
            "type": "object",
            "properties": {
                "lat": {"type": "number", "description": "Latitude"},
                "lon": {"type": "number", "description": "Longitude"}
            },
            "required": ["lat", "lon"]
        }
    },
    {
        "name": "track_iss",
        "description": "International Space Station ka live location batao",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "people_in_space",
        "description": "Abhi space mein kitne log hain unke naam batao",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "nasa_apod",
        "description": "NASA ka aaj ka best astronomy image dekho",
        "parameters": {
            "type": "object",
            "properties": {
                "set_wallpaper": {"type": "boolean", "description": "Wallpaper set karo?"}
            }
        }
    },
    {
        "name": "check_asteroids",
        "description": "Aaj koi asteroid Earth ke paas se ja raha hai check karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "mars_weather",
        "description": "Mars ka latest mausam batao",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "mars_rover_photo",
        "description": "Mars rover ki latest photo download karo",
        "parameters": {
            "type": "object",
            "properties": {
                "rover": {"type": "string", "description": "Rover name: curiosity, perseverance"}
            }
        }
    },
    {
        "name": "meteor_showers",
        "description": "Upcoming meteor showers aur astronomical events batao",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "spacex_launches",
        "description": "Upcoming SpaceX rocket launches dekho",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "epic_earth",
        "description": "DSCOVR satellite se poori Earth ki photo download karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── PC Optimizer ───────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "clean_pc",
        "description": "PC ka junk clean karo — temp files, cache, recycle bin",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "boost_ram",
        "description": "RAM free karo — heavy background processes kill karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "analyze_disk",
        "description": "Disk space analyze karo — badi files dhundho",
        "parameters": {
            "type": "object",
            "properties": {
                "min_size_mb": {"type": "integer", "description": "Minimum file size in MB"}
            }
        }
    },
    {
        "name": "schedule_shutdown",
        "description": "PC ko X minutes baad shutdown karo",
        "parameters": {
            "type": "object",
            "properties": {
                "minutes": {"type": "integer", "description": "Delay in minutes"}
            },
            "required": ["minutes"]
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Media Downloader ───────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "download_youtube",
        "description": "YouTube video download karo (1080p/4K)",
        "parameters": {
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "YouTube video URL"},
                "quality": {"type": "string", "description": "best, medium, or low"}
            },
            "required": ["url"]
        }
    },
    {
        "name": "download_mp3",
        "description": "YouTube video se MP3 audio nikalo",
        "parameters": {
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "YouTube video URL"}
            },
            "required": ["url"]
        }
    },
    {
        "name": "download_instagram",
        "description": "Instagram reel/post/story download karo",
        "parameters": {
            "type": "object",
            "properties": {
                "url": {"type": "string", "description": "Instagram post/reel URL"}
            },
            "required": ["url"]
        }
    },

    # ════════════════════════════════════════════════════════
    # ── PDF Assistant ──────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "read_pdf",
        "description": "PDF file ka full text extract karo aur dikhao",
        "parameters": {
            "type": "object",
            "properties": {
                "file_path": {"type": "string", "description": "PDF file path"}
            },
            "required": ["file_path"]
        }
    },
    {
        "name": "summarize_pdf",
        "description": "PDF file ka AI summary do",
        "parameters": {
            "type": "object",
            "properties": {
                "pdf_path": {"type": "string", "description": "PDF file path"}
            },
            "required": ["pdf_path"]
        }
    },
    {
        "name": "pdf_to_word",
        "description": "PDF ko Word document mein convert karo",
        "parameters": {
            "type": "object",
            "properties": {
                "pdf_path": {"type": "string", "description": "PDF file path"}
            },
            "required": ["pdf_path"]
        }
    },
    {
        "name": "pdf_to_audio",
        "description": "PDF file ko aloud padho (Text-to-Speech)",
        "parameters": {
            "type": "object",
            "properties": {
                "file_path": {"type": "string", "description": "PDF file path"}
            },
            "required": ["file_path"]
        }
    },
    {
        "name": "read_document_aloud",
        "description": "Koi bhi text file ko aloud padho (TTS)",
        "parameters": {
            "type": "object",
            "properties": {
                "file_path": {"type": "string", "description": "Text file path"}
            },
            "required": ["file_path"]
        }
    },
    {
        "name": "images_to_pdf",
        "description": "Multiple photos ko ek PDF mein convert karo",
        "parameters": {
            "type": "object",
            "properties": {
                "image_paths": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of image file paths"
                },
                "output_name": {"type": "string", "description": "Output PDF name"}
            },
            "required": ["image_paths"]
        }
    },

    # ════════════════════════════════════════════════════════
    # ── God Coder ──────────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "build_project",
        "description": "Prompt se poora project banao — architecture, code, auto-fix",
        "parameters": {
            "type": "object",
            "properties": {
                "prompt": {"type": "string", "description": "Project description"},
                "project_name": {"type": "string", "description": "Project folder name"}
            },
            "required": ["prompt"]
        }
    },
    {
        "name": "build_from_file",
        "description": "Prompt file padh ke poora project banao",
        "parameters": {
            "type": "object",
            "properties": {
                "prompt_file": {"type": "string", "description": "Prompt file path"}
            },
            "required": ["prompt_file"]
        }
    },
    {
        "name": "fix_code_file",
        "description": "Kisi bhi Python file ki errors auto-fix karo",
        "parameters": {
            "type": "object",
            "properties": {
                "file_path": {"type": "string", "description": "Python file path"}
            },
            "required": ["file_path"]
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Deep Search Engine ─────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "deep_search",
        "description": "File content mein deep search karo — keyword se dhundho",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search keyword"}
            },
            "required": ["query"]
        }
    },
    {
        "name": "index_directory",
        "description": "Directory ke andar sab files ka content index karo",
        "parameters": {
            "type": "object",
            "properties": {
                "directory": {"type": "string", "description": "Directory path"},
                "max_files": {"type": "integer", "description": "Max files to index"}
            }
        }
    },
    {
        "name": "index_file",
        "description": "Ek specific file ka content index karo",
        "parameters": {
            "type": "object",
            "properties": {
                "file_path": {"type": "string", "description": "File path"}
            },
            "required": ["file_path"]
        }
    },
    {
        "name": "search_stats",
        "description": "Search index ka statistics dekho",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "clear_search_index",
        "description": "Search index clear karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Offline AI ─────────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "offline_chat",
        "description": "HuggingFace AI se offline baat karo (Gemini down ho toh)",
        "parameters": {
            "type": "object",
            "properties": {
                "message": {"type": "string", "description": "Message for offline AI"}
            },
            "required": ["message"]
        }
    },
    {
        "name": "download_vosk",
        "description": "Vosk voice model download karo for offline voice recognition",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "start_wake_word",
        "description": "Wake word detection start karo ('Hey Rasheed')",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "stop_wake_word",
        "description": "Wake word detection stop karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "offline_tts",
        "description": "Offline TTS se text ko audio mein convert karo",
        "parameters": {
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "Text to speak"}
            },
            "required": ["text"]
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Knowledge Graph ────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "add_entity",
        "description": "Knowledge graph mein entity add karo (person, place, thing)",
        "parameters": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Entity name"},
                "entity_type": {"type": "string", "description": "Type: person, place, thing"},
                "attributes": {"type": "object", "description": "Entity attributes"}
            },
            "required": ["name"]
        }
    },
    {
        "name": "add_relation",
        "description": "Do entities ke beech relation add karo",
        "parameters": {
            "type": "object",
            "properties": {
                "from_entity": {"type": "string", "description": "Source entity"},
                "relation": {"type": "string", "description": "Relation type"},
                "to_entity": {"type": "string", "description": "Target entity"}
            },
            "required": ["from_entity", "relation", "to_entity"]
        }
    },
    {
        "name": "add_fact",
        "description": "Kisi entity ke baare mein fact add karo",
        "parameters": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Entity name"},
                "key": {"type": "string", "description": "Fact key"},
                "value": {"type": "string", "description": "Fact value"}
            },
            "required": ["name", "key", "value"]
        }
    },
    {
        "name": "query_entity",
        "description": "Kisi entity ke baare mein sab kuch pucho",
        "parameters": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Entity name to query"}
            },
            "required": ["name"]
        }
    },
    {
        "name": "suggest_gift",
        "description": "Kisi ke liye gift suggest karo (knowledge graph preferences se)",
        "parameters": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Person name"}
            },
            "required": ["name"]
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Digital Twin ───────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "learn_my_style",
        "description": "User ke messages se communication style seekho",
        "parameters": {
            "type": "object",
            "properties": {
                "messages": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Sample messages for learning"
                }
            },
            "required": ["messages"]
        }
    },
    {
        "name": "reply_my_style",
        "description": "User ke style mein reply generate karo",
        "parameters": {
            "type": "object",
            "properties": {
                "context": {"type": "string", "description": "Reply context"},
                "recipient": {"type": "string", "description": "Reply recipient"}
            },
            "required": ["context"]
        }
    },
    {
        "name": "twin_stats",
        "description": "Digital twin ka learning stats dekho",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── RPA / Macro Recorder ───────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "start_recording",
        "description": "Screen actions record karo (macro recording)",
        "parameters": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Macro name"}
            }
        }
    },
    {
        "name": "stop_recording",
        "description": "Macro recording stop karo aur save karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "play_macro",
        "description": "Recorded macro replay karo",
        "parameters": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Macro name"},
                "speed": {"type": "number", "description": "Playback speed multiplier"}
            },
            "required": ["name"]
        }
    },
    {
        "name": "list_macros",
        "description": "Sab saved macros dikhao",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Screen Translator ──────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "translate_screen",
        "description": "Screen ka text OCR se translate karo",
        "parameters": {
            "type": "object",
            "properties": {
                "target_lang": {"type": "string", "description": "Target language code (ur, hi, ar, en)"}
            }
        }
    },
    {
        "name": "translation_overlay",
        "description": "Real-time translation overlay kholo on screen",
        "parameters": {
            "type": "object",
            "properties": {
                "target_lang": {"type": "string", "description": "Target language code"}
            }
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Ambient Listener ───────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "start_ambient",
        "description": "Room ki awaazein sunna shuru karo — background listening",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "stop_ambient",
        "description": "Ambient listener band karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Proactive Engine ───────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "start_proactive",
        "description": "Zero-prompt proactive engine start karo — auto suggestions",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "stop_proactive",
        "description": "Proactive engine band karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Window Manager ─────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "snap_left",
        "description": "Active window ko left half par snap karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "snap_right",
        "description": "Active window ko right half par snap karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "minimize_all",
        "description": "Sab windows minimize karo (Show Desktop)",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "maximize_window",
        "description": "Active window full screen karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "minimize_window",
        "description": "Specific window minimize karo by title",
        "parameters": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Window title (partial match)"}
            }
        }
    },
    {
        "name": "close_window",
        "description": "Specific window close karo by title",
        "parameters": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Window title (partial match)"}
            }
        }
    },
    {
        "name": "get_active_windows",
        "description": "Sab active windows ki list dikhao with titles",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "always_on_top",
        "description": "Active window ko always on top karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── QR Code Generator ──────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "generate_qr_code",
        "description": "QR code generate karo from text ya URL",
        "parameters": {
            "type": "object",
            "properties": {
                "data": {"type": "string", "description": "Text or URL for QR code"}
            },
            "required": ["data"]
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Plugin Engine ──────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "list_plugins",
        "description": "Sab loaded plugins dikhao",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "reload_plugins",
        "description": "Plugins folder rescan karo — new plugins load karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Budget Manager ─────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "log_expense",
        "description": "Expense log karo — amount aur description ke saath",
        "parameters": {
            "type": "object",
            "properties": {
                "amount": {"type": "number", "description": "Expense amount"},
                "description": {"type": "string", "description": "Kis cheez par kharch hua"}
            },
            "required": ["amount", "description"]
        }
    },
    {
        "name": "budget_alert",
        "description": "Budget alert set karo — category wise limit",
        "parameters": {
            "type": "object",
            "properties": {
                "category": {"type": "string", "description": "Expense category"},
                "limit": {"type": "number", "description": "Budget limit amount"}
            },
            "required": ["category", "limit"]
        }
    },
    {
        "name": "monthly_report",
        "description": "Monthly expense report generate karo",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "scan_bill",
        "description": "Bill scan karo OCR se aur auto-log karo",
        "parameters": {
            "type": "object",
            "properties": {
                "image_path": {"type": "string", "description": "Bill image path"}
            }
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Practice Partner ───────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "debate",
        "description": "AI se debate karo — kisi bhi topic par",
        "parameters": {
            "type": "object",
            "properties": {
                "topic": {"type": "string", "description": "Debate topic"},
                "stance": {"type": "string", "description": "Your stance: for or against"}
            },
            "required": ["topic"]
        }
    },
    {
        "name": "mock_interview",
        "description": "Interview practice karo — AI interviewer",
        "parameters": {
            "type": "object",
            "properties": {
                "role": {"type": "string", "description": "Job role for interview"}
            }
        }
    },
    {
        "name": "language_practice",
        "description": "Language practice karo — conversation mode",
        "parameters": {
            "type": "object",
            "properties": {
                "language": {"type": "string", "description": "Language to practice"}
            }
        }
    },
    {
        "name": "generate_flashcards",
        "description": "Flashcards generate karo kisi topic par",
        "parameters": {
            "type": "object",
            "properties": {
                "topic": {"type": "string", "description": "Flashcard topic"},
                "count": {"type": "integer", "description": "Number of flashcards"}
            },
            "required": ["topic"]
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Idea Capture & Mood ────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "log_dream",
        "description": "Dream log karo — details ke saath save karo",
        "parameters": {
            "type": "object",
            "properties": {
                "content": {"type": "string", "description": "Dream description"}
            },
            "required": ["content"]
        }
    },
    {
        "name": "capture_idea",
        "description": "Idea capture karo — quick note save",
        "parameters": {
            "type": "object",
            "properties": {
                "content": {"type": "string", "description": "Idea description"}
            },
            "required": ["content"]
        }
    },
    {
        "name": "random_idea",
        "description": "Random creative idea generate karo",
        "parameters": {
            "type": "object",
            "properties": {
                "domain": {"type": "string", "description": "Domain like 'tech', 'business'"}
            }
        }
    },
    {
        "name": "log_mood",
        "description": "Mood log karo — daily mood tracking",
        "parameters": {
            "type": "object",
            "properties": {
                "mood": {"type": "string", "description": "Mood: happy, sad, neutral, etc."},
                "note": {"type": "string", "description": "Optional note"}
            },
            "required": ["mood"]
        }
    },

    # ════════════════════════════════════════════════════════
    # ── Password Vault ─────────────────────────────────────
    # ════════════════════════════════════════════════════════
    {
        "name": "save_password",
        "description": "Password securely save karo — encrypted vault",
        "parameters": {
            "type": "object",
            "properties": {
                "site": {"type": "string", "description": "Website or app name"},
                "username": {"type": "string", "description": "Username or email"},
                "password": {"type": "string", "description": "Password to save"}
            },
            "required": ["site", "username", "password"]
        }
    },
    {
        "name": "get_password",
        "description": "Saved password retrieve karo — master password required",
        "parameters": {
            "type": "object",
            "properties": {
                "site": {"type": "string", "description": "Website or app name"}
            },
            "required": ["site"]
        }
    },
    {
        "name": "list_saved_sites",
        "description": "Sab saved password sites dikhao (passwords nahi)",
        "parameters": {
            "type": "object",
            "properties": {}
        }
    },
    {
        "name": "generate_password",
        "description": "Strong random password generate karo",
        "parameters": {
            "type": "object",
            "properties": {
                "length": {"type": "integer", "description": "Password length (default 16)"},
                "include_symbols": {"type": "boolean", "description": "Include symbols (default true)"}
            }
        }
    },
    {
        "name": "delete_password",
        "description": "Saved password delete karo",
        "parameters": {
            "type": "object",
            "properties": {
                "site": {"type": "string", "description": "Website to delete"}
            },
            "required": ["site"]
        }
    },

]


# ╔══════════════════════════════════════════════════════════╗
# ║                  TOOL COUNT & VALIDATION                ║
# ╚══════════════════════════════════════════════════════════╝

def get_tool_count():
    """Total tools count return karo"""
    return len(TOOLS)

def get_tool_names():
    """Sab tool names ki list return karo"""
    return [tool["name"] for tool in TOOLS]

def validate_tools():
    """Sab tools ka syntax validate karo"""
    errors = []
    names_seen = set()

    for i, tool in enumerate(TOOLS):
        # Check required fields
        if "name" not in tool:
            errors.append(f"Tool #{i+1}: Missing 'name' field")
        if "description" not in tool:
            errors.append(f"Tool #{i+1}: Missing 'description' field")
        if "parameters" not in tool:
            errors.append(f"Tool #{i+1}: Missing 'parameters' field")

        # Check duplicate names
        name = tool.get("name", "")
        if name in names_seen:
            errors.append(f"Tool #{i+1}: Duplicate name '{name}'")
        names_seen.add(name)

        # Validate parameters structure
        params = tool.get("parameters", {})
        if params:
            if "type" not in params:
                errors.append(f"Tool '{name}': parameters missing 'type'")
            if "properties" not in params:
                errors.append(f"Tool '{name}': parameters missing 'properties'")

    return errors

def print_tool_report():
    """Tool report print karo"""
    errors = validate_tools()
    print(f"\n╔════════════════════════════════════════════╗")
    print(f"║         RASHEED TOOLS REPORT               ║")
    print(f"╠════════════════════════════════════════════╣")
    print(f"║  Total Tools: {len(TOOLS)}")
    print(f"║  Validation: {'✅ PASSED' if not errors else '❌ ERRORS FOUND'}")
    if errors:
        for err in errors:
            print(f"║  ❌ {err}")
    print(f"╚════════════════════════════════════════════╝\n")


# Auto-validate on import
if __name__ == "__main__":
    print_tool_report()
    print("Tool Names:")
    for i, name in enumerate(get_tool_names(), 1):
        print(f"  {i:3d}. {name}")