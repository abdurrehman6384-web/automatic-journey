# app.py — RASHEED Complete App & System Control (v6.0 Upgraded)
import subprocess
import os
import time
import psutil
import pyautogui
import keyboard
import webbrowser
import pyperclip
import wikipedia
import datetime
import ctypes
from pathlib import Path
import threading
import logging

from config import DESKTOP
from error_handler import safe_execute, logger

# Safety
pyautogui.FAILSAFE = True
pyautogui.PAUSE = 0.01

# ── App Aliases ──────────────────────────────────────────
APP_ALIASES = {
    # Browsers
    "chrome": "chrome", "google chrome": "chrome",
    "firefox": "firefox", "edge": "msedge",
    "microsoft edge": "msedge", "brave": "brave",
    "opera": "opera",
    # System
    "notepad": "notepad", "notepad++": "notepad++",
    "calculator": "calc", "calc": "calc",
    "cmd": "cmd", "command prompt": "cmd",
    "terminal": "wt", "windows terminal": "wt",
    "task manager": "taskmgr", "file explorer": "explorer",
    "explorer": "explorer", "paint": "mspaint",
    "ms paint": "mspaint", "wordpad": "wordpad",
    "snipping tool": "snippingtool",
    "control panel": "control",
    "settings": "ms-settings:",
    "registry": "regedit",
    "disk management": "diskmgmt.msc",
    "device manager": "devmgmt.msc",
    "services": "services.msc",
    # Dev Tools
    "vscode": "code", "vs code": "code",
    "visual studio code": "code",
    "pycharm": "pycharm64",
    "android studio": "studio64",
    "git bash": "git bash", "postman": "postman",
    "docker": "docker desktop",
    "sublime": "sublime_text",
    # Communication
    "whatsapp": "shell:AppsFolder\\5319275A.WhatsAppDesktop_cv1g1gvanyjgm!App",
    "telegram": "telegram", "discord": "discord",
    "zoom": "zoom", "teams": "teams",
    "microsoft teams": "teams", "slack": "slack",
    "skype": "skype",
    # Media
    "spotify": "shell:AppsFolder\\SpotifyAB.SpotifyMusic_zpdnekdrzrea0!Spotify",
    "vlc": "vlc", "vlc media player": "vlc",
    "youtube": "chrome https://youtube.com",
    "netflix": "chrome https://netflix.com",
    # Office
    "word": "winword", "microsoft word": "winword",
    "excel": "excel", "microsoft excel": "excel",
    "powerpoint": "powerpnt",
    "microsoft powerpoint": "powerpnt",
    "outlook": "outlook", "onenote": "onenote",
    # Gaming
    "obs": "obs64", "obs studio": "obs64",
    "steam": "steam",
    "epic games": "epicgameslauncher",
    "canva": "chrome https://canva.com",
    "figma": "chrome https://figma.com",
    "photoshop": "photoshop",
}

UWP_PREFIXES = ["shell:AppsFolder", "ms-settings:", "shell:"]
PS = r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"

def is_uwp(path: str) -> bool:
    return any(path.startswith(p) for p in UWP_PREFIXES)

# ══════════════════════════════════════════════════════════
# APP CONTROL
# ══════════════════════════════════════════════════════════
@safe_execute(max_retries=2)
def open_app(app_name: str) -> str:
    name = app_name.lower().strip()
    search = APP_ALIASES.get(name)
    if not search:
        for key, value in APP_ALIASES.items():
            if name in key or key in name:
                search = value
                break
    if not search:
        search = name

    if is_uwp(search):
        subprocess.Popen(
            [PS, "-NoProfile", "-WindowStyle", "Hidden",
             "-Command", f"Start-Process '{search}'"],
            creationflags=subprocess.CREATE_NO_WINDOW
        )
    else:
        subprocess.Popen(
            ["cmd", "/c", "start", "", search],
            creationflags=subprocess.CREATE_NO_WINDOW
        )
    return f"✅ {app_name} khol diya boss!"

@safe_execute(max_retries=1)
def close_app(app_name: str) -> str:
    PROC_MAP = {
        "chrome": "chrome.exe", "firefox": "firefox.exe",
        "discord": "Discord.exe", "spotify": "Spotify.exe",
        "vlc": "vlc.exe", "code": "Code.exe",
        "notepad": "notepad.exe", "whatsapp": "WhatsApp.exe",
        "teams": "Teams.exe", "zoom": "Zoom.exe",
        "telegram": "Telegram.exe", "edge": "msedge.exe",
        "word": "WINWORD.EXE", "excel": "EXCEL.EXE",
        "powerpoint": "POWERPNT.EXE", "obs": "obs64.exe",
    }
    proc = PROC_MAP.get(app_name.lower(), app_name + ".exe")
    subprocess.run(
        ["taskkill", "/f", "/im", proc],
        capture_output=True,
        creationflags=subprocess.CREATE_NO_WINDOW
    )
    return f"🛑 {app_name} band kar diya boss!"

# ══════════════════════════════════════════════════════════
# SCREEN CONTROL
# ══════════════════════════════════════════════════════════
@safe_execute(max_retries=2)
def type_text(text: str, delay: float = 0.05) -> str:
    time.sleep(0.5)
    pyautogui.write(text, interval=delay)
    return f"✅ Typed: {text}"

@safe_execute(max_retries=2)
def type_text_keyboard(text: str) -> str:
    time.sleep(0.5)
    keyboard.write(text, delay=0.05)
    return f"✅ Typed: {text}"

@safe_execute()
def press_key(key: str) -> str:
    pyautogui.press(key)
    return f"✅ '{key}' pressed"

@safe_execute()
def hotkey(*keys) -> str:
    pyautogui.hotkey(*keys)
    return f"✅ Hotkey {'+'.join(keys)}"

@safe_execute()
def click_at(x: int, y: int) -> str:
    pyautogui.click(x, y)
    return f"✅ Clicked ({x}, {y})"

@safe_execute()
def right_click_at(x: int, y: int) -> str:
    pyautogui.rightClick(x, y)
    return "✅ Right clicked"

def scroll_up(amount: int = 3) -> str:
    pyautogui.scroll(amount)
    return "✅ Scrolled up"

def scroll_down(amount: int = 3) -> str:
    pyautogui.scroll(-amount)
    return "✅ Scrolled down"

@safe_execute()
def move_mouse(x: int, y: int) -> str:
    pyautogui.moveTo(x, y, duration=0.3)
    return f"✅ Mouse moved to ({x}, {y})"

@safe_execute()
def double_click(x: int = None, y: int = None) -> str:
    if x and y:
        pyautogui.doubleClick(x, y)
    else:
        pyautogui.doubleClick()
    return "✅ Double clicked"

# ══════════════════════════════════════════════════════════
# BROWSER CONTROL
# ══════════════════════════════════════════════════════════
def open_website(url: str) -> str:
    if not url.startswith("http"):
        url = "https://" + url
    webbrowser.open(url)
    return f"✅ {url} khola boss!"

def search_google(query: str) -> str:
    url = f"https://www.google.com/search?q={query.replace(' ', '+')}"
    webbrowser.open(url)
    return f"✅ Google: '{query}'"

def search_youtube(query: str) -> str:
    url = f"https://www.youtube.com/results?search_query={query.replace(' ', '+')}"
    webbrowser.open(url)
    return f"✅ YouTube: '{query}'"

def play_youtube(query: str) -> str:
    try:
        import pywhatkit
        pywhatkit.playonyt(query)
        return f"✅ Playing: '{query}'"
    except Exception:
        search_youtube(query)
        return f"✅ YouTube search: '{query}'"

def search_wikipedia(query: str) -> str:
    try:
        result = wikipedia.summary(query, sentences=3)
        return f"Wikipedia: {result}"
    except Exception as e:
        return f"❌ Wikipedia error: {e}"

# ══════════════════════════════════════════════════════════
# FILE & FOLDER
# ══════════════════════════════════════════════════════════
def create_folder(name: str, path: str = None) -> str:
    full = os.path.join(path or DESKTOP, name)
    os.makedirs(full, exist_ok=True)
    return f"✅ Folder '{name}' ban gaya!"

def delete_folder(name: str, path: str = None) -> str:
    import shutil
    full = os.path.join(path or DESKTOP, name)
    try:
        shutil.rmtree(full)
        return f"✅ Folder '{name}' deleted!"
    except Exception as e:
        return f"❌ Error: {e}"

def create_file(name: str, content: str = "", path: str = None) -> str:
    if "." not in name:
        name += ".txt"
    full = os.path.join(path or DESKTOP, name)
    with open(full, 'w', encoding='utf-8') as f:
        f.write(content)
    return f"✅ File '{name}' bana di!"

def delete_file(name: str, path: str = None) -> str:
    full = os.path.join(path or DESKTOP, name)
    try:
        os.remove(full)
        return f"✅ File '{name}' deleted!"
    except Exception as e:
        return f"❌ Error: {e}"

def read_file(name: str, path: str = None) -> str:
    full = os.path.join(path or DESKTOP, name)
    try:
        with open(full, 'r', encoding='utf-8') as f:
            return f"Content:\n{f.read()[:500]}"
    except Exception as e:
        return f"❌ Error: {e}"

def list_files(path: str = None) -> str:
    try:
        files = os.listdir(path or DESKTOP)
        return "Files:\n" + "\n".join(files[:20])
    except Exception as e:
        return f"❌ Error: {e}"

def search_file(name: str) -> str:
    results = []
    for root, dirs, files in os.walk(str(Path.home())):
        for f in files:
            if name.lower() in f.lower():
                results.append(os.path.join(root, f))
                if len(results) >= 5:
                    return "Found:\n" + "\n".join(results)
    return "Found:\n" + "\n".join(results) if results else f"❌ '{name}' nahi mila"

def rename_file(old: str, new: str, path: str = None) -> str:
    base = path or DESKTOP
    try:
        os.rename(os.path.join(base, old), os.path.join(base, new))
        return f"✅ '{old}' → '{new}'"
    except Exception as e:
        return f"❌ Error: {e}"

def open_file(filepath: str) -> str:
    try:
        os.startfile(filepath)
        return f"✅ '{filepath}' khola!"
    except Exception as e:
        return f"❌ Error: {e}"

# ══════════════════════════════════════════════════════════
# SYSTEM CONTROL
# ══════════════════════════════════════════════════════════
def shutdown_pc(timer: int = 10) -> str:
    os.system(f"shutdown /s /t {timer}")
    return f"⚠️ PC {timer}s mein band hoga!"

def restart_pc() -> str:
    os.system("shutdown /r /t 5")
    return "🔄 Restarting..."

def sleep_pc() -> str:
    os.system("rundll32.exe powrprof.dll,SetSuspendState 0,1,0")
    return "😴 Sleeping..."

def lock_pc() -> str:
    os.system("rundll32.exe user32.dll,LockWorkStation")
    return "🔒 Locked!"

def logoff_pc() -> str:
    os.system("shutdown /l")
    return "👋 Logging off..."

def cancel_shutdown() -> str:
    os.system("shutdown /a")
    return "✅ Shutdown cancelled!"

def hibernate_pc() -> str:
    os.system("shutdown /h")
    return "💤 Hibernating..."

# ══════════════════════════════════════════════════════════
# VOLUME CONTROL
# ══════════════════════════════════════════════════════════
def volume_up(steps: int = 5) -> str:
    for _ in range(steps):
        pyautogui.press("volumeup")
    return "🔊 Volume up!"

def volume_down(steps: int = 5) -> str:
    for _ in range(steps):
        pyautogui.press("volumedown")
    return "🔉 Volume down!"

def volume_mute() -> str:
    pyautogui.press("volumemute")
    return "🔇 Muted!"

def set_volume(level: int) -> str:
    try:
        from ctypes import cast, POINTER
        from comtypes import CLSCTX_ALL
        from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
        devices = AudioUtilities.GetSpeakers()
        interface = devices.Activate(
            IAudioEndpointVolume.iid, CLSCTX_ALL, None
        )
        volume = cast(interface, POINTER(IAudioEndpointVolume))
        volume.SetMasterVolumeLevelScalar(level / 100, None)
        return f"✅ Volume {level}%!"
    except Exception:
        for _ in range(50):
            pyautogui.press("volumedown")
        for _ in range(level // 2):
            pyautogui.press("volumeup")
        return f"✅ Volume ~{level}%"

# ══════════════════════════════════════════════════════════
# SYSTEM INFO
# ══════════════════════════════════════════════════════════
def get_battery() -> str:
    b = psutil.sensors_battery()
    if b:
        s = "Charging ⚡" if b.power_plugged else "Battery 🔋"
        return f"Battery: {b.percent:.0f}% | {s}"
    return "Battery info N/A"

def get_cpu() -> str:
    return f"CPU: {psutil.cpu_percent(interval=1)}% | Cores: {psutil.cpu_count()}"

def get_ram() -> str:
    r = psutil.virtual_memory()
    return f"RAM: {r.percent}% ({round(r.used/1024**3,1)}GB / {round(r.total/1024**3,1)}GB)"

def get_disk() -> str:
    d = psutil.disk_usage('/')
    return f"Disk: {d.percent}% ({round(d.used/1024**3,1)}GB / {round(d.total/1024**3,1)}GB)"

def get_system_info() -> str:
    return "\n".join([
        get_battery(), get_cpu(), get_ram(), get_disk(),
        f"Time: {datetime.datetime.now().strftime('%I:%M %p')}",
        f"Date: {datetime.datetime.now().strftime('%d %B %Y')}"
    ])

def get_running_processes() -> str:
    procs = []
    for p in psutil.process_iter(['name', 'cpu_percent']):
        try:
            if p.info['cpu_percent'] > 1:
                procs.append(f"{p.info['name']}: {p.info['cpu_percent']}%")
        except Exception:
            pass
    return "\n".join(procs[:10]) if procs else "No heavy processes"

def kill_process(name: str) -> str:
    killed = 0
    for p in psutil.process_iter(['name']):
        try:
            if name.lower() in p.info['name'].lower():
                p.kill()
                killed += 1
        except Exception:
            pass
    return f"✅ {killed} process(es) killed" if killed else f"❌ '{name}' not found"

# ══════════════════════════════════════════════════════════
# SCREENSHOT
# ══════════════════════════════════════════════════════════
def take_screenshot(filename: str = None) -> str:
    import mss
    import mss.tools
    ts = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = filename or f"screenshot_{ts}.png"
    path = os.path.join(DESKTOP, filename)
    try:
        with mss.mss() as sct:
            sct.shot(output=path)
        return f"✅ Screenshot: {path}"
    except Exception:
        pyautogui.screenshot(path)
        return f"✅ Screenshot: {path}"

def get_screen_as_base64() -> str:
    import base64, io, mss
    try:
        with mss.mss() as sct:
            monitor = sct.monitors[1]
            img = sct.grab(monitor)
            from PIL import Image
            pil_img = Image.frombytes("RGB", img.size, img.bgra, "raw", "BGRX")
            pil_img = pil_img.resize((1280, 720))
            buffer = io.BytesIO()
            pil_img.save(buffer, format="JPEG", quality=70)
            return base64.b64encode(buffer.getvalue()).decode()
    except Exception:
        return ""

def get_active_window_title() -> str:
    try:
        import pygetwindow as gw
        w = gw.getActiveWindow()
        return w.title if w else "Unknown"
    except Exception:
        return "Unknown"

# ══════════════════════════════════════════════════════════
# CLIPBOARD
# ══════════════════════════════════════════════════════════
def copy_to_clipboard(text: str) -> str:
    pyperclip.copy(text)
    return f"✅ Copied: {text[:50]}"

def get_clipboard() -> str:
    try:
        return f"Clipboard: {pyperclip.paste()[:200]}"
    except Exception:
        return "Clipboard empty"

def paste_clipboard() -> str:
    pyautogui.hotkey('ctrl', 'v')
    return "✅ Pasted"

def select_all_and_copy() -> str:
    pyautogui.hotkey('ctrl', 'a')
    time.sleep(0.2)
    pyautogui.hotkey('ctrl', 'c')
    time.sleep(0.2)
    return get_clipboard()

# ══════════════════════════════════════════════════════════
# TIME & DATE
# ══════════════════════════════════════════════════════════
def get_time() -> str:
    return datetime.datetime.now().strftime("%I:%M:%S %p")

def get_date() -> str:
    return datetime.datetime.now().strftime("%A, %d %B %Y")

def get_datetime() -> str:
    return f"{get_time()} | {get_date()}"

# ══════════════════════════════════════════════════════════
# CMD / POWERSHELL
# ══════════════════════════════════════════════════════════
def run_cmd(command: str) -> str:
    try:
        r = subprocess.run(
            command, shell=True,
            capture_output=True, text=True, timeout=15
        )
        output = r.stdout.strip() or r.stderr.strip()
        return output[:500] if output else "✅ Done"
    except Exception as e:
        return f"❌ CMD error: {e}"

def run_powershell(command: str) -> str:
    try:
        r = subprocess.run(
            [PS, "-NoProfile", "-Command", command],
            capture_output=True, text=True, timeout=15
        )
        return (r.stdout.strip() or r.stderr.strip())[:500]
    except Exception as e:
        return f"❌ PS error: {e}"

# ══════════════════════════════════════════════════════════
# NOTIFICATIONS
# ══════════════════════════════════════════════════════════
def show_notification(title: str, message: str) -> str:
    try:
        from win10toast import ToastNotifier
        ToastNotifier().show_toast(title, message, duration=5, threaded=True)
        return f"✅ Notification: {title}"
    except Exception:
        run_powershell(
            f'Add-Type -AssemblyName System.Windows.Forms; '
            f'[System.Windows.Forms.MessageBox]::Show("{message}", "{title}")'
        )
        return f"✅ Popup: {title}"

# ══════════════════════════════════════════════════════════
# WHATSAPP
# ══════════════════════════════════════════════════════════
def send_whatsapp(number: str, message: str) -> str:
    try:
        import pywhatkit
        now = datetime.datetime.now()
        pywhatkit.sendwhatmsg(number, message, now.hour, now.minute + 2)
        return "✅ WhatsApp message sent!"
    except Exception as e:
        return f"❌ WhatsApp error: {e}"

# ══════════════════════════════════════════════════════════
# WEATHER & MATH
# ══════════════════════════════════════════════════════════
def get_weather(city: str = None) -> str:
    from config import DEFAULT_CITY
    city = city or DEFAULT_CITY
    try:
        import requests
        r = requests.get(f"https://wttr.in/{city}?format=3", timeout=5)
        return f"🌤️ {r.text.strip()}"
    except Exception as e:
        return f"❌ Weather error: {e}"

def calculate(expression: str) -> str:
    try:
        result = eval(
            expression.replace("^", "**"),
            {"__builtins__": {}}, {}
        )
        return f"= {result}"
    except Exception as e:
        return f"❌ Math error: {e}"

# ══════════════════════════════════════════════════════════
# HELPER
# ══════════════════════════════════════════════════════════
def extract_app_name(transcript: str) -> str | None:
    text = transcript.lower().strip()
    TRIGGERS = [
        "open", "launch", "start", "run", "kholo", "khol",
        "chalao", "chala", "band karo"
    ]
    KNOWN = sorted(list(APP_ALIASES.keys()), key=len, reverse=True)

    triggered = None
    for trigger in TRIGGERS:
        if trigger in text:
            after = text.split(trigger, 1)[-1].strip()
            for filler in [
                "please", "kar", "karo", "kro", "do",
                "na", "bhai", "sir", "boss", "ji"
            ]:
                after = after.replace(filler, "").strip()
            triggered = after
            break

    if not triggered:
        return None

    for app in KNOWN:
        if app in triggered:
            return app

    words = triggered.split()
    return words[0] if words else None