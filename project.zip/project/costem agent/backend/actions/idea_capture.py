# idea_capture.py — Dream Journal & Idea Vault
import sqlite3
from datetime import datetime
from config import DATA_DIR, logger
from error_handler import safe_execute

DB_FILE = str(DATA_DIR / "ideas.db")

class IdeaCapture:
    def __init__(self):
        self._setup_db()

    def _setup_db(self):
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS ideas 
                     (id INTEGER PRIMARY KEY, type TEXT, content TEXT, 
                      mood TEXT, timestamp TEXT)''')
        conn.commit()
        conn.close()

    @safe_execute(max_retries=1)
    def log_dream(self, content: str) -> str:
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute("INSERT INTO ideas (type, content, mood, timestamp) VALUES (?, ?, ?, ?)",
                  ("dream", content, "unknown", str(datetime.now())))
        conn.commit()
        conn.close()
        return f"🌙 Dream logged!"

    @safe_execute(max_retries=1)
    def capture_idea(self, content: str) -> str:
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute("INSERT INTO ideas (type, content, mood, timestamp) VALUES (?, ?, ?, ?)",
                  ("idea", content, "excited", str(datetime.now())))
        conn.commit()
        conn.close()
        return f"💡 Idea captured!"

    @safe_execute(max_retries=1)
    def random_idea(self, domain: str = "startup") -> str:
        from ai_brain import llm_router
        prompt = f"Give me ONE creative {domain} idea that could make money. Be specific and unique."
        return llm_router.smart_ask(prompt)

    @safe_execute(max_retries=1)
    def organize_thoughts(self, raw_text: str) -> str:
        from ai_brain import llm_router
        prompt = f"Organize these scattered thoughts into structured bullet points:\n\n{raw_text[:3000]}"
        return llm_router.smart_ask(prompt)

    @safe_execute(max_retries=1)
    def log_mood(self, mood: str, note: str = "") -> str:
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute("INSERT INTO ideas (type, content, mood, timestamp) VALUES (?, ?, ?, ?)",
                  ("mood", note, mood, str(datetime.now())))
        conn.commit()
        conn.close()
        return f"😊 Mood logged: {mood}"


# Global instance
ideas = IdeaCapture()