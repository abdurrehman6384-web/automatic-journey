# memory.py — RASHEED Advanced Memory System v8.0 (SQLite + Vector)
import sqlite3
import os
import json
import datetime
from config import DATA_DIR, CHROMA_PERSIST_DIR, logger

DB_FILE = str(DATA_DIR / "rasheed_memory.db")

class RasheedMemory:
    def __init__(self):
        self.conn = sqlite3.connect(DB_FILE, check_same_thread=False)
        self._create_tables()
        self.vector_available = False
        self._init_vector()

    def _create_tables(self):
        cursor = self.conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT, user_msg TEXT, ai_msg TEXT
            )
        ''')
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS user_data (
                category TEXT, key TEXT, value TEXT,
                UNIQUE(category, key)
            )
        ''')
        self.conn.commit()

    def _init_vector(self):
        try:
            import chromadb
            self.chroma_client = chromadb.PersistentClient(path=CHROMA_PERSIST_DIR)
            self.collection = self.chroma_client.get_or_create_collection("rasheed_memory")
            self.vector_available = True
        except Exception:
            logger.warning("ChromaDB not available. Vector memory disabled.")

    def add_conversation(self, user_msg: str, ai_msg: str):
        cursor = self.conn.cursor()
        cursor.execute(
            "INSERT INTO conversations (timestamp, user_msg, ai_msg) VALUES (?, ?, ?)",
            (str(datetime.datetime.now()), user_msg, ai_msg)
        )
        self.conn.commit()
        # Add to vector DB for semantic search
        if self.vector_available:
            try:
                doc_id = f"conv_{cursor.lastrowid}"
                self.collection.upsert(
                    documents=[f"User: {user_msg}\nRASHEED: {ai_msg}"],
                    ids=[doc_id]
                )
            except Exception:
                pass

    def search_vector_memory(self, query: str, n: int = 3) -> str:
        if not self.vector_available:
            return "❌ Vector memory not available"
        try:
            results = self.collection.query(query_texts=[query], n_results=n)
            docs = results.get("documents", [[]])[0]
            return "\n---\n".join(docs) if docs else "No vector memories found."
        except Exception as e:
            return f"❌ Vector search error: {e}"

    def save_data(self, category: str, key: str, value: str):
        cursor = self.conn.cursor()
        cursor.execute(
            "INSERT OR REPLACE INTO user_data (category, key, value) VALUES (?, ?, ?)",
            (category, key, value)
        )
        self.conn.commit()

    def get_data(self, category: str, key: str) -> str:
        cursor = self.conn.cursor()
        cursor.execute("SELECT value FROM user_data WHERE category=? AND key=?", (category, key))
        row = cursor.fetchone()
        return row[0] if row else ""

    def get_stats(self) -> str:
        cursor = self.conn.cursor()
        conv_count = cursor.execute("SELECT COUNT(*) FROM conversations").fetchone()[0]
        data_count = cursor.execute("SELECT COUNT(*) FROM user_data").fetchone()[0]
        return f"🧠 Memory Stats:\nConversations: {conv_count}\nKnowledge Keys: {data_count}"

# Global instance
memory = RasheedMemory()