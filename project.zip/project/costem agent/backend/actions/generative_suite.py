# generative_suite.py — AI Image, Music, Video Analysis
import requests
import os
import ctypes
import time
import cv2
import base64
from config import STABILITY_API_KEY, DATA_DIR, logger
from error_handler import safe_execute
from ai_brain import llm_router

class GenerativeSuite:
    @safe_execute(max_retries=1)
    def generate_image(self, prompt: str, set_wallpaper: bool = True) -> str:
        """Generate AI Image via Stability AI and set as wallpaper"""
        if not STABILITY_API_KEY:
            return "❌ Stability API Key not set in .env"
        
        url = "https://api.stability.ai/v1/generation/stable-diffusion-xl-1024-v1-0/text-to-image"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {STABILITY_API_KEY}"
        }
        data = {
            "text_prompts": [{"text": prompt}],
            "cfg_scale": 7, "width": 1024, "height": 1024, "samples": 1, "steps": 30
        }
        
        r = requests.post(url, json=data, headers=headers, timeout=60)
        if r.status_code != 200:
            return f"❌ Image generation failed: {r.text[:200]}"
        
        img_data = base64.b64decode(r.json()["artifacts"][0]["base64"])
        img_path = str(DATA_DIR / "generated_wallpaper.png")
        with open(img_path, 'wb') as f:
            f.write(img_data)
        
        if set_wallpaper:
            ctypes.windll.user32.SystemParametersInfoW(20, 0, img_path, 3)
            return f"🎨 Image generated & Wallpaper set! Prompt: {prompt}"
        return f"🎨 Image saved at: {img_path}"

    @safe_execute(max_retries=1)
    def generate_music(self, prompt: str, duration: int = 120) -> str:
        """Generate AI Music (Requires Suno API / Local model bridge)"""
        # Placeholder for Suno/Udio API (As APIs are constantly changing, we use a standard wrapper)
        logger.info(f"Requesting music generation for: {prompt}")
        return "🎵 Music generation initiated! (Note: Configure Suno API wrapper in code for actual download)"

    def analyze_video_stream(self, duration_secs: int = 5) -> str:
        """Capture screen for X seconds, extract frames, and analyze via AI"""
        from vision import vision
        import numpy as np
        
        frames_data = []
        start_time = time.time()
        
        while time.time() - start_time < duration_secs:
            frame = vision.get_screen_frame()
            if frame is not None:
                _, buffer = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 60])
                frames_data.append(buffer.tobytes())
            time.sleep(1)  # 1 frame per second
            
        if not frames_data:
            return "❌ Could not capture video frames"
            
        # Pick 3 keyframes
        keyframes = frames_data[::max(1, len(frames_data)//3)][:3]
        descriptions = []
        
        for i, kf in enumerate(keyframes):
            b64 = base64.b64encode(kf).decode()
            # Using LLM to describe (If multimodal LLM is connected)
            prompt = f"Describe what is happening in this screenshot (Frame {i+1}). Be concise."
            # For now, we save and use context
            descriptions.append(f"Frame {i+1} captured.")
            
        return f"🎥 Analyzed {len(keyframes)} keyframes from {duration_secs}s stream. Context: {' | '.join(descriptions)}"

# Global instance
gen_suite = GenerativeSuite()