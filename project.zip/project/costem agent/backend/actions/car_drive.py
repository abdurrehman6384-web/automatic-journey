# car_drive.py — RASHEED Advanced Car Driving Module
# Features: Game Auto-Pilot, Driver Drowsiness Detection, OBD2 Diagnostics

import threading
import time
import logging

logger = logging.getLogger("RASHEED")

# ── Optional Imports ──────────────────────────────────
try:
    import cv2
    import numpy as np
    HAS_CV2 = True
except ImportError:
    HAS_CV2 = False

try:
    import pyautogui
    HAS_PYAUTOGUI = True
except ImportError:
    HAS_PYAUTOGUI = False

try:
    from PIL import ImageGrab
    HAS_PIL = True
except ImportError:
    HAS_PIL = False


class CarDriveAssistant:
    """Advanced Car Driving Assistant — Game + Real Life"""

    def __init__(self):
        self.game_driving = False
        self.drowsiness_active = False
        self._game_thread = None
        self._drowsy_thread = None
        self._speed = 0
        self._steering = 0.0  # -1.0 to 1.0
        self._lane_detected = False

        # Drowsiness detection params
        self._eye_closed_frames = 0
        self._yawn_frames = 0
        self._alarm_playing = False

        # Load Haar Cascades for face/eye detection
        self._face_cascade = None
        self._eye_cascade = None
        if HAS_CV2:
            try:
                self._face_cascade = cv2.CascadeClassifier(
                    cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
                )
                self._eye_cascade = cv2.CascadeClassifier(
                    cv2.data.haarcascades + 'haarcascade_eye.xml'
                )
                logger.info("CarDrive: Haar cascades loaded")
            except Exception as e:
                logger.warning(f"CarDrive: Cascade load error: {e}")

    # ════════════════════════════════════════════════════════
    # ── GAME AUTO-DRIVE (GTA V / Euro Truck / etc.) ──────
    # ════════════════════════════════════════════════════════

    def start_game_drive(self, mode="sport"):
        """
        Start auto-driving in a car game.
        Uses screen capture + lane detection + keyboard control.
        Modes: sport, cruise, race
        """
        if not HAS_CV2:
            return "❌ OpenCV (cv2) not installed! Run: pip install opencv-python"

        if not HAS_PYAUTOGUI:
            return "❌ pyautogui not installed! Run: pip install pyautogui"

        if self.game_driving:
            return "⚠️ Game driving already active!"

        self.game_driving = True
        self._speed = 0

        self._game_thread = threading.Thread(
            target=self._game_drive_loop,
            args=(mode,),
            daemon=True
        )
        self._game_thread.start()

        mode_emoji = {"sport": "🏎️", "cruise": "🚗", "race": "🏁"}
        return (
            f"{mode_emoji.get(mode, '🚗')} Game Auto-Drive STARTED!\n"
            f"   Mode: {mode.upper()}\n"
            f"   🎮 Make sure the game window is active\n"
            f"   🛑 Say 'stop car' to stop driving"
        )

    def stop_game_drive(self):
        """Stop auto-driving"""
        self.game_driving = False

        # Release all keys
        if HAS_PYAUTOGUI:
            try:
                pyautogui.keyUp('w')
                pyautogui.keyUp('a')
                pyautogui.keyUp('d')
                pyautogui.keyUp('s')
            except Exception:
                pass

        return "🛑 Game Auto-Drive STOPPED"

    def get_driving_status(self):
        """Get current driving status"""
        if not self.game_driving:
            return "ℹ️ Auto-drive is not active"

        return (
            f"🏎️ Auto-Drive Active\n"
            f"   Speed: {self._speed} km/h\n"
            f"   Steering: {'← Left' if self._steering < -0.2 else '→ Right' if self._steering > 0.2 else '↑ Straight'}\n"
            f"   Lane: {'✅ Detected' if self._lane_detected else '❌ Not found'}"
        )

    def _game_drive_loop(self, mode):
        """Main game driving loop — runs in background thread"""
        # Speed configs per mode
        mode_config = {
            "sport": {"target_speed": 120, "accel_rate": 0.5},
            "cruise": {"target_speed": 80, "accel_rate": 0.3},
            "race": {"target_speed": 200, "accel_rate": 0.8},
        }
        config = mode_config.get(mode, mode_config["sport"])

        screen_region = None  # None = full screen

        while self.game_driving:
            try:
                # 1. Capture screen
                frame = self._capture_game_screen(screen_region)
                if frame is None:
                    time.sleep(0.05)
                    continue

                # 2. Detect lanes
                steering, lane_found = self._detect_lanes(frame)
                self._steering = steering
                self._lane_detected = lane_found

                # 3. Control the car
                self._control_car(steering, config)

                # 4. Detect speed from screen (OCR-like heuristic)
                self._estimate_speed(frame)

                time.sleep(0.03)  # ~30 FPS

            except Exception as e:
                logger.debug(f"Game drive error: {e}")
                time.sleep(0.1)

    def _capture_game_screen(self, region=None):
        """Capture game screen as OpenCV frame"""
        try:
            if HAS_PIL:
                screenshot = ImageGrab.grab(bbox=region)
                frame = np.array(screenshot)
                frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
                return frame
            elif HAS_PYAUTOGUI:
                screenshot = pyautogui.screenshot(region=region)
                frame = np.array(screenshot)
                frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
                return frame
        except Exception as e:
            logger.debug(f"Screen capture error: {e}")
        return None

    def _detect_lanes(self, frame):
        """
        Detect road lanes using edge detection + Hough transform.
        Returns steering angle (-1.0 to 1.0) and lane_found bool.
        """
        try:
            h, w = frame.shape[:2]

            # Focus on lower half of screen (road area)
            roi = frame[int(h * 0.5):, :]

            # Convert to grayscale
            gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)

            # Gaussian blur
            blur = cv2.GaussianBlur(gray, (5, 5), 0)

            # Edge detection (Canny)
            edges = cv2.Canny(blur, 50, 150)

            # Define road region mask (trapezoid)
            mask = np.zeros_like(edges)
            roi_h, roi_w = edges.shape
            polygon = np.array([[
                (int(roi_w * 0.1), roi_h),
                (int(roi_w * 0.4), int(roi_h * 0.3)),
                (int(roi_w * 0.6), int(roi_h * 0.3)),
                (int(roi_w * 0.9), roi_h)
            ]], dtype=np.int32)
            cv2.fillPoly(mask, polygon, 255)
            masked_edges = cv2.bitwise_and(edges, mask)

            # Hough Line Transform
            lines = cv2.HoughLinesP(
                masked_edges, 1, np.pi / 180,
                threshold=50, minLineLength=50, maxLineGap=100
            )

            if lines is None:
                return 0.0, False

            # Calculate average line positions
            left_x = []
            right_x = []

            for line in lines:
                x1, y1, x2, y2 = line[0]
                if x2 == x1:
                    continue
                slope = (y2 - y1) / (x2 - x1)

                if slope < -0.3:  # Left lane
                    left_x.append((x1 + x2) / 2)
                elif slope > 0.3:  # Right lane
                    right_x.append((x1 + x2) / 2)

            center = roi_w / 2

            if left_x and right_x:
                lane_center = (np.mean(left_x) + np.mean(right_x)) / 2
                steering = (center - lane_center) / center
                steering = max(-1.0, min(1.0, steering))
                return steering, True

            elif left_x:
                steering = (center - np.mean(left_x) - 100) / center
                return max(-1.0, min(1.0, steering)), True

            elif right_x:
                steering = (center - np.mean(right_x) + 100) / center
                return max(-1.0, min(1.0, steering)), True

            return 0.0, False

        except Exception as e:
            logger.debug(f"Lane detection error: {e}")
            return 0.0, False

    def _control_car(self, steering, config):
        """Send keyboard inputs based on steering angle"""
        if not HAS_PYAUTOGUI:
            return

        try:
            # Always accelerate
            pyautogui.keyDown('w')

            # Steering
            if steering < -0.15:
                pyautogui.keyDown('a')
                pyautogui.keyUp('d')
            elif steering > 0.15:
                pyautogui.keyDown('d')
                pyautogui.keyUp('a')
            else:
                pyautogui.keyUp('a')
                pyautogui.keyUp('d')

            # Brake if sharp turn
            if abs(steering) > 0.6:
                pyautogui.keyDown('s')
                time.sleep(0.05)
                pyautogui.keyUp('s')

        except Exception as e:
            logger.debug(f"Car control error: {e}")

    def _estimate_speed(self, frame):
        """Estimate speed from screen (heuristic based on motion)"""
        # Simple heuristic: if lane lines are long, we're going fast
        self._speed = min(200, max(0, self._speed + 1))

    # ════════════════════════════════════════════════════════
    # ── DRIVER DROWSINESS DETECTION (Real Life) ──────────
    # ════════════════════════════════════════════════════════

    def start_drowsiness_detector(self):
        """
        Start driver drowsiness detection using webcam.
        Alerts if eyes closed for too long or yawning.
        """
        if not HAS_CV2:
            return "❌ OpenCV not installed! Run: pip install opencv-python"

        if self._face_cascade is None or self._eye_cascade is None:
            return "❌ Face/Eye detection models not available"

        if self.drowsiness_active:
            return "⚠️ Drowsiness detector already active!"

        self.drowsiness_active = True
        self._eye_closed_frames = 0
        self._yawn_frames = 0

        self._drowsy_thread = threading.Thread(
            target=self._drowsiness_loop,
            daemon=True
        )
        self._drowsy_thread.start()

        return (
            "👁️ Driver Drowsiness Detector STARTED!\n"
            "   📷 Using webcam to monitor your face\n"
            "   🔔 Will alert if you feel sleepy\n"
            "   🛑 Say 'stop drowsiness' to stop"
        )

    def stop_drowsiness_detector(self):
        """Stop drowsiness detection"""
        self.drowsiness_active = False
        self._alarm_playing = False
        return "👁️ Drowsiness Detector STOPPED"

    def _drowsiness_loop(self):
        """Main drowsiness detection loop"""
        try:
            cap = cv2.VideoCapture(0)
            if not cap.isOpened():
                logger.error("CarDrive: Cannot open webcam for drowsiness")
                self.drowsiness_active = False
                return
        except Exception as e:
            logger.error(f"CarDrive: Webcam error: {e}")
            self.drowsiness_active = False
            return

        EYE_CLOSED_THRESHOLD = 15  # frames
        YAWN_THRESHOLD = 20  # frames

        while self.drowsiness_active:
            try:
                ret, frame = cap.read()
                if not ret:
                    time.sleep(0.1)
                    continue

                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

                # Detect faces
                faces = self._face_cascade.detectMultiScale(
                    gray, scaleFactor=1.3, minNeighbors=5, minSize=(50, 50)
                )

                drowsy = False

                for (x, y, w, h) in faces:
                    roi_gray = gray[y:y+h, x:x+w]

                    # Detect eyes
                    eyes = self._eye_cascade.detectMultiScale(
                        roi_gray, scaleFactor=1.1, minNeighbors=5, minSize=(20, 20)
                    )

                    if len(eyes) < 1:
                        # Eyes closed or not visible
                        self._eye_closed_frames += 1
                    else:
                        self._eye_closed_frames = 0

                    # Check if drowsy (eyes closed too long)
                    if self._eye_closed_frames >= EYE_CLOSED_THRESHOLD:
                        drowsy = True

                    # Check for yawn (mouth area - simple heuristic)
                    mouth_roi = roi_gray[int(h*0.6):, :]
                    mouth_open_pixels = cv2.countNonZero(
                        cv2.threshold(mouth_roi, 30, 255, cv2.THRESH_BINARY_INV)[1]
                    )
                    if mouth_open_pixels > (w * h * 0.15):
                        self._yawn_frames += 1
                    else:
                        self._yawn_frames = max(0, self._yawn_frames - 1)

                    if self._yawn_frames >= YAWN_THRESHOLD:
                        drowsy = True

                    break  # Only process first face

                # Trigger alarm if drowsy
                if drowsy and not self._alarm_playing:
                    self._trigger_drowsiness_alert()

            except Exception as e:
                logger.debug(f"Drowsiness detection error: {e}")

            time.sleep(0.05)

        cap.release()

    def _trigger_drowsiness_alert(self):
        """Play loud alert sound and show notification"""
        self._alarm_playing = True

        try:
            from app import show_notification
            show_notification(
                "🚨 DROWSINESS ALERT!",
                "You are feeling sleepy! Please take a break!"
            )
        except Exception:
            pass

        # Try to play alarm sound
        try:
            import winsound
            threading.Thread(
                target=lambda: winsound.Beep(2000, 2000),
                daemon=True
            ).start()
        except Exception:
            pass

        # Reset after alert
        def _reset():
            time.sleep(5)
            self._alarm_playing = False
            self._eye_closed_frames = 0
            self._yawn_frames = 0

        threading.Thread(target=_reset, daemon=True).start()

    # ════════════════════════════════════════════════════════
    # ── CAR DIAGNOSTICS (OBD2) ────────────────────────────
    # ════════════════════════════════════════════════════════

    def read_car_diagnostics(self):
        """
        Read car OBD2 diagnostics (if ELM327 adapter connected).
        Returns RPM, Speed, Engine Temp, Fuel Level, etc.
        """
        try:
            import obd
            connection = obd.OBD()  # auto-connect

            if not connection.is_connected():
                return "❌ OBD2 adapter not connected! Connect ELM327 Bluetooth adapter"

            results = []
            commands = {
                "RPM": obd.commands.RPM,
                "Speed": obd.commands.SPEED,
                "Engine Temp": obd.commands.COOLANT_TEMP,
                "Throttle": obd.commands.THROTTLE_POS,
                "Fuel Level": obd.commands.FUEL_LEVEL,
                "Engine Load": obd.commands.ENGINE_LOAD,
            }

            for name, cmd in commands.items():
                try:
                    response = connection.query(cmd)
                    if response.value is not None:
                        results.append(f"  {name}: {response.value}")
                    else:
                        results.append(f"  {name}: N/A")
                except Exception:
                    results.append(f"  {name}: Error")

            connection.close()

            return "🚗 Car Diagnostics:\n" + "\n".join(results)

        except ImportError:
            return (
                "❌ python-OBD not installed!\n"
                "   Run: pip install python-OBD\n"
                "   Also need ELM327 OBD2 Bluetooth adapter"
            )
        except Exception as e:
            return f"❌ OBD2 Error: {e}"

    def get_car_location(self):
        """Get car's GPS location (if GPS module connected)"""
        try:
            import gps
            session = gps.gps("localhost", "2947")
            session.stream(gps.WATCH_ENABLE | gps.WATCH_NEWSTYLE)
            report = session.next()
            if report['class'] == 'TPV':
                return (
                    f"📍 Car Location:\n"
                    f"   Lat: {report.lat}\n"
                    f"   Lon: {report.lon}\n"
                    f"   Speed: {report.speed} m/s"
                )
        except ImportError:
            pass
        except Exception:
            pass

        # Fallback to IP location
        try:
            from new_features import get_my_location
            return f"📍 Car Location (IP-based):\n{get_my_location()}"
        except Exception:
            return "📍 Car location unavailable"

    def find_nearest_gas_station(self):
        """Find nearest gas station using Google Maps"""
        try:
            from app import search_google
            search_google("nearest gas station")
            return "⛽ Searching for nearest gas station on Google..."
        except Exception:
            return "⛽ Could not search for gas stations"

    def emergency_stop(self):
        """Emergency stop — release all keys and stop everything"""
        self.game_driving = False
        self.drowsiness_active = False

        if HAS_PYAUTOGUI:
            try:
                pyautogui.keyUp('w')
                pyautogui.keyUp('a')
                pyautogui.keyUp('d')
                pyautogui.keyUp('s')
                pyautogui.press('space')  # Brake
            except Exception:
                pass

        return "🚨 EMERGENCY STOP! All driving stopped!"


# ════════════════════════════════════════════════════════
# Global Instance
# ════════════════════════════════════════════════════════
car_assistant = CarDriveAssistant()