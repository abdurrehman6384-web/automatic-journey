# remote_bridge.py — Telegram Bot Control
import threading
from config import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, logger
from executor import execute_tool

class TelegramBridge:
    def __init__(self):
        self.token = TELEGRAM_BOT_TOKEN
        self.chat_id = TELEGRAM_CHAT_ID

    def start(self):
        if not self.token:
            logger.warning("Telegram token not set. Bot disabled.")
            return
        try:
            from telegram.ext import ApplicationBuilder, CommandHandler
            app = ApplicationBuilder().token(self.token).build()
            
            app.add_handler(CommandHandler("pc", self._handle_command))
            app.add_handler(CommandHandler("screenshot", self._screenshot))
            
            logger.info("Telegram Bot started!")
            app.run_polling()
        except ImportError:
            logger.error("python-telegram-bot not installed. pip install python-telegram-bot")
        except Exception as e:
            logger.error(f"Telegram error: {e}")

    async def _handle_command(self, update, context):
        text = update.message.text.replace("/pc ", "").strip()
        result = execute_tool("run_cmd", {"command": text})
        await update.message.reply_text(str(result)[:4000])

    async def _screenshot(self, update, context):
        result = execute_tool("take_screenshot", {})
        await update.message.reply_text(result)

def start_telegram_bot():
    """Run Telegram bot in background thread"""
    bot = TelegramBridge()
    bot.start()

# Global
telegram_thread = threading.Thread(target=start_telegram_bot, daemon=True)