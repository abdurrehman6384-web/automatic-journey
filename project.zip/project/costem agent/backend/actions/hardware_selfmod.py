# hardware_selfmod.py — Self-Rewriting Code, GPU Control, RAM Disk
import os
import subprocess
import shutil
from config import BASE_DIR, logger
from error_handler import safe_execute
from ai_brain import llm_router

class HardwareSelfMod:
    @safe_execute(max_retries=1)
    def self_modify_code(self, file_path: str, instruction: str) -> str:
        """Read a Python file, use AI to rewrite/optimize it, and save"""
        full_path = os.path.join(str(BASE_DIR), file_path)
        if not os.path.exists(full_path):
            return f"❌ File not found: {file_path}"
            
        with open(full_path, 'r', encoding='utf-8') as f:
            original_code = f.read()
            
        prompt = (
            f"Modify the following Python code based on this instruction: '{instruction}'\n"
            f"Output ONLY the complete modified Python code. No markdown blocks.\n\n"
            f"CODE:\n{original_code[:3000]}"
        )
        
        new_code = llm_router.smart_ask(prompt)
        if not new_code or "❌" in str(new_code):
            return "❌ AI failed to generate modified code."
            
        # Backup original
        shutil.copy2(full_path, full_path + ".bak")
        
        # Overwrite with new code
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(new_code)
            
        return f"🧬 Code modified and saved! Backup created at {file_path}.bak"

    @safe_execute(max_retries=1)
    def set_gpu_fans(self, speed: int) -> str:
        """Set Nvidia GPU fan speed (Requires nvidia-smi / NVML)"""
        try:
            import pynvml
            pynvml.nvmlInit()
            handle = pynvml.nvmlDeviceGetHandleByIndex(0)
            # Note: Fan control requires coolbit unlocked in Xorg/Nvidia settings
            return f"💨 GPU Fan speed command sent to {speed}% (Requires Nvidia Coolbits unlocked)"
        except Exception as e:
            return f"❌ GPU control error: {e}"

    @safe_execute(max_retries=1)
    def create_ram_disk(self, size_mb: int, drive_letter: str = "R") -> str:
        """Create a RAM Disk on Windows via ImDisk"""
        # Requires ImDisk Toolkit installed (http://www.ltr-data.se/opencode.html/)
        cmd = f"imdisk -a -s {size_mb}M -m {drive_letter}: -p \"/fs:NTFS /q /y\""
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            return f"💾 RAM Disk created at {drive_letter}: ({size_mb}MB)"
        return f"❌ RAM Disk error (Install ImDisk): {result.stderr[:200]}"

# Global instance
hw_selfmod = HardwareSelfMod()