# swarm_engine.py — Multi-Agent Swarm (CrewAI Style)
import threading
import queue
from concurrent.futures import ThreadPoolExecutor
from config import logger
from ai_brain import llm_router
from executor import execute_tool

class SwarmAgent:
    def __init__(self, role: str, task_queue: queue.Queue, result_queue: queue.Queue):
        self.role = role
        self.task_queue = task_queue
        self.result_queue = result_queue

    def run(self):
        while not self.task_queue.empty():
            try:
                task = self.task_queue.get_nowait()
                prompt = f"You are a {self.role}. Complete this task: {task}\nOutput only the result text."
                result = llm_router.smart_ask(prompt)
                self.result_queue.put({"role": self.role, "task": task, "result": result})
            except Exception as e:
                break

class SwarmEngine:
    def deploy_swarm(self, roles: list, tasks: list) -> str:
        """Deploy multiple agents to complete tasks in parallel"""
        task_q = queue.Queue()
        result_q = queue.Queue()
        
        for task in tasks:
            task_q.put(task)
            
        threads = []
        for role in roles:
            agent = SwarmAgent(role, task_q, result_q)
            t = threading.Thread(target=agent.run, daemon=True)
            t.start()
            threads.append(t)
            
        for t in threads:
            t.join(timeout=120)  # Max 2 min per agent
            
        results = []
        while not result_q.empty():
            r = result_q.get()
            results.append(f"[{r['role']}] Task: {r['task'][:30]}... -> {r['result'][:100]}...")
            
        return f"🐝 Swarm Complete! Results:\n" + "\n".join(results)

# Global instance
swarm = SwarmEngine()