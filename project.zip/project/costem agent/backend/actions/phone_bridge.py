# ╔══════════════════════════════════════════════════════════╗
# ║       phone_bridge.py — RASHEED Mobile Bridge            ║
# ║       Control RASHEED from WhatsApp / Telegram           ║
# ╚══════════════════════════════════════════════════════════╝

import requests
import time
import threading


class PhoneBridge:

    def __init__(self, telegram_token=None):
        self.token = telegram_token
        self.base_url = f"https://api.telegram.org/bot{self.token}"
        self.running = False

    def send_message(self, chat_id, text):
        """Phone par message bhejo"""
        url = f"{self.base_url}/sendMessage"
        data = {"chat_id": chat_id, "text": text}
        requests.post(url, json=data)

    def send_photo(self, chat_id, photo_path):
        """Phone par photo bhejo (Screenshot)"""
        url = f"{self.base_url}/sendPhoto"
        with open(photo_path, "rb") as f:
            files = {"photo": f}
            data = {"chat_id": chat_id}
            requests.post(url, files=files, data=data)

    def alert_phone(self, message):
        """PC se phone par emergency alert bhejo"""
        # Get latest chat updates
        url = f"{self.base_url}/getUpdates"
        resp = requests.get(url).json()
        if resp["result"]:
            chat_id = resp["result"][-1]["message"]["chat"]["id"]
            self.send_message(chat_id, f"🚨 RASHEED ALERT:\n{message}")

    def listen_commands(self):
        """Phone se commands suno (Background thread)"""
        self.running = True
        last_update = 0
        
        while self.running:
            try:
                url = f"{self.base_url}/getUpdates?offset={last_update+1}"
                resp = requests.get(url, timeout=5).json()
                
                for update in resp.get("result", []):
                    last_update = update["update_id"]
                    if "message" in update:
                        text = update["message"].get("text", "")
                        chat_id = update["message"]["chat"]["id"]
                        
                        # Execute command
                        from executor import execute_tool
                        result = execute_tool("run_cmd", {"command": text})
                        self.send_message(chat_id, f"✅ Done:\n{result}")
            except:
                pass
            time.sleep(2)

    def start_listening(self):
        t = threading.Thread(target=self.listen_commands, daemon=True)
        t.start()
        print("📱 Phone Bridge: Listening...")


bridge = PhoneBridge(telegram_token="YOUR_TELEGRAM_BOT_TOKEN")
