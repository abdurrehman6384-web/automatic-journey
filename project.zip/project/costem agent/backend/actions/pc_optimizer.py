# pc_optimizer.py — PC Cleaner, RAM Booster, Disk Analyzer, Shutdown Timer
import os
import shutil
import subprocess
import ctypes
import threading
import time
from pathlib import Path
from config import logger
from error_handler import safe_execute


class PCOptimizer:

    # ── 1. Junk Cleaner ──────────────────────────────
    @safe_execute(max_retries=1)
    def clean_junk(self) -> str:
        """Clean temp files, cache, and recycle bin"""
        cleaned = 0
        errors = 0
        total_size = 0

        # Paths to clean
        paths_to_clean = [
            os.environ.get("TEMP", ""),
            os.path.join(os.environ.get("WINDIR", "C:\\Windows"), "Temp"),
            os.path.join(str(Path.home()), "AppData", "Local", "Temp"),
            os.path.join(str(Path.home()), "AppData", "Local", "Microsoft", "Windows", "INetCache"),
            os.path.join(str(Path.home()), "AppData", "Local", "Google", "Chrome", "User Data", "Default", "Cache"),
        ]

        for path in paths_to_clean:
            if not path or not os.path.exists(path):
                continue
            for item in os.listdir(path):
                item_path = os.path.join(path, item)
                try:
                    if os.path.isfile(item_path):
                        size = os.path.getsize(item_path)
                        os.remove(item_path)
                        total_size += size
                        cleaned += 1
                    elif os.path.isdir(item_path):
                        size = sum(
                            os.path.getsize(os.path.join(dp, f))
                            for dp, dn, fns in os.walk(item_path)
                            for f in fns
                            if os.path.isfile(os.path.join(dp, f))
                        )
                        shutil.rmtree(item_path, ignore_errors=True)
                        total_size += size
                        cleaned += 1
                except Exception:
                    errors += 1

        # Empty Recycle Bin
        try:
            ctypes.windll.shell32.SHEmptyRecycleBinW(None, None, 7)
        except Exception:
            pass

        size_mb = total_size / (1024 * 1024)
        return f"🧹 Cleaned {cleaned} items! Freed {size_mb:.1f} MB. Errors: {errors}"

    # ── 2. RAM Booster ───────────────────────────────
    @safe_execute(max_retries=1)
    def boost_ram(self) -> str:
        """Kill heavy background processes to free RAM"""
        import psutil
        
        freed = 0
        killed = []
        
        # Processes that are safe to kill (non-critical)
        safe_to_kill = [
            "OneDrive.exe", "SkypeApp.exe", "Teams.exe", "Discord.exe",
            "Spotify.exe", "Notion.exe", "Figma.exe", "WeChat.exe",
            "Zoom.exe", "Telegram.exe", "WhatsApp.exe",
        ]
        
        for proc in psutil.process_iter(['name', 'memory_info']):
            try:
                name = proc.info['name']
                mem = proc.info['memory_info'].rss / (1024 * 1024)  # MB
                
                if name in safe_to_kill:
                    proc.kill()
                    freed += mem
                    killed.append(f"{name} ({mem:.0f}MB)")
            except Exception:
                pass

        if killed:
            return f"⚡ RAM Boosted! Freed {freed:.0f}MB\nKilled: {', '.join(killed[:5])}"
        return "✅ RAM already optimized! No heavy apps running."

    # ── 3. Disk Space Analyzer ───────────────────────
    @safe_execute(max_retries=1)
    def analyze_disk(self, min_size_mb: int = 100) -> str:
        """Find large files and folders eating disk space"""
        large_items = []
        home = str(Path.home())
        
        # Scan common large folders
        scan_dirs = [
            os.path.join(home, "Desktop"),
            os.path.join(home, "Downloads"),
            os.path.join(home, "Documents"),
            os.path.join(home, "Videos"),
            os.path.join(home, "AppData", "Local"),
        ]
        
        for scan_dir in scan_dirs:
            if not os.path.exists(scan_dir):
                continue
            for root, dirs, files in os.walk(scan_dir):
                # Skip hidden folders
                dirs[:] = [d for d in dirs if not d.startswith('.')]
                
                for f in files:
                    try:
                        fp = os.path.join(root, f)
                        size = os.path.getsize(fp) / (1024 * 1024)
                        if size >= min_size_mb:
                            large_items.append((fp, size))
                    except Exception:
                        pass
                if len(large_items) >= 20:
                    break
        
        large_items.sort(key=lambda x: x[1], reverse=True)
        
        if not large_items:
            return f"✅ No files larger than {min_size_mb}MB found!"
        
        result = f"📊 Large Files (>{min_size_mb}MB):\n\n"
        for path, size in large_items[:15]:
            # Shorten path for display
            short = path.replace(home, "~")
            result += f"📦 {size:.0f}MB — {short}\n"
        
        return result

    # ── 4. Auto Shutdown Timer ───────────────────────
    @safe_execute(max_retries=1)
    def schedule_shutdown(self, minutes: int = 60) -> str:
        """Schedule PC shutdown after X minutes"""
        seconds = minutes * 60
        subprocess.run(
            ["shutdown", "/s", "/t", str(seconds)],
            capture_output=True,
            creationflags=subprocess.CREATE_NO_WINDOW
        )
        return f"⏰ PC will shut down in {minutes} minutes! Say 'cancel shutdown' to stop."

    def cancel_shutdown(self) -> str:
        """Cancel scheduled shutdown"""
        subprocess.run(
            ["shutdown", "/a"],
            capture_output=True,
            creationflags=subprocess.CREATE_NO_WINDOW
        )
        return "✅ Shutdown cancelled!"


# Global instance
pc_optimizer = PCOptimizer()