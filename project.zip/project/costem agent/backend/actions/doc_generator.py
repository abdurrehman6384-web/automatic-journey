# doc_generator.py — Legal & Business Document Generator
from ai_brain import llm_router
from error_handler import safe_execute

class DocGenerator:

    @safe_execute(max_retries=1)
    def generate_contract(self, party_a: str, party_b: str, contract_type: str = "freelance") -> str:
        prompt = (
            f"Generate a professional {contract_type} contract between {party_a} and {party_b}. "
            f"Include: scope, payment terms, timeline, termination clause, confidentiality. "
            f"Format properly with numbered sections."
        )
        return llm_router.smart_ask(prompt)

    @safe_execute(max_retries=1)
    def generate_nda(self, parties: str) -> str:
        prompt = f"Generate a Non-Disclosure Agreement between {parties}. Include standard NDA clauses."
        return llm_router.smart_ask(prompt)

    @safe_execute(max_retries=1)
    def generate_invoice(self, client: str, items: str, total: float) -> str:
        prompt = (
            f"Generate a professional invoice for:\n"
            f"Client: {client}\nItems: {items}\nTotal: Rs {total}\n"
            f"Include invoice number, date, payment terms."
        )
        return llm_router.smart_ask(prompt)

    @safe_execute(max_retries=1)
    def build_resume(self, name: str, skills: str, experience: str) -> str:
        prompt = (
            f"Build a professional resume for {name}.\n"
            f"Skills: {skills}\nExperience: {experience}\n"
            f"Format it cleanly with sections. Make it ATS-friendly."
        )
        return llm_router.smart_ask(prompt)

    @safe_execute(max_retries=1)
    def generate_cover_letter(self, name: str, role: str, company: str) -> str:
        prompt = f"Write a compelling cover letter for {name} applying for {role} at {company}."
        return llm_router.smart_ask(prompt)


# Global instance
doc_gen = DocGenerator()