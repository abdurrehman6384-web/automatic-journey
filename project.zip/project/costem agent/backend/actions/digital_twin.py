# digital_twin.py — Behavioural Cloning / Digital Twin
import os
import json
from config import DATA_DIR, logger
from error_handler import safe_execute

TWIN_FILE = str(DATA_DIR / "digital_twin.json")

class DigitalTwin:
    """
    Learns your chat style: short/long, emoji usage, Hinglish frequency.
    Generates replies in YOUR style.
    """

    def __init__(self):
        self.style = {
            "avg_length": "medium",       # short, medium, long
            "emoji_frequency": "medium",  # low, medium, high
            "language_mix": "hinglish",   # english, hinglish, urdu
            "formality": "casual",        # formal, casual, slang
            "common_phrases": [],
            "sample_messages": [],
        }
        self._load()

    def _load(self):
        if os.path.exists(TWIN_FILE):
            try:
                with open(TWIN_FILE, 'r', encoding='utf-8') as f:
                    self.style.update(json.load(f))
            except Exception:
                pass

    def _save(self):
        try:
            with open(TWIN_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.style, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def learn_from_messages(self, messages: list) -> str:
        """Learn style from user's past messages"""
        # Analyze patterns
        total_len = sum(len(m) for m in messages)
        avg_len = total_len / len(messages) if messages else 0
        
        emoji_count = sum(1 for m in messages for c in m if ord(c) > 127000)
        
        # Store samples
        self.style["sample_messages"] = messages[-50:]  # Keep last 50
        self.style["avg_length"] = "short" if avg_len < 30 else "medium" if avg_len < 100 else "long"
        self.style["emoji_frequency"] = "low" if emoji_count < 5 else "medium" if emoji_count < 20 else "high"
        
        self._save()
        return f"🧬 Learned your style! Avg length: {self.style['avg_length']}, Emoji: {self.style['emoji_frequency']}"

    def generate_reply(self, context: str, recipient: str = "friend") -> str:
        """Generate a reply in the user's style"""
        from ai_brain import llm_router
        
        samples = self.style.get("sample_messages", [])[-10:]
        sample_text = "\n".join(f"- {s}" for s in samples)
        
        prompt = (
            f"You are writing a message in the EXACT style of the user. "
            f"Style: {self.style['avg_length']} length, {self.style['emoji_frequency']} emoji, "
            f"{self.style['language_mix']} language.\n\n"
            f"User's past messages (copy this style exactly):\n{sample_text}\n\n"
            f"Context: Reply to {recipient} about: {context}\n"
            f"Write ONLY the message, nothing else."
        )
        
        return llm_router.smart_ask(prompt)

    def get_stats(self) -> str:
        return (
            f"🧬 Your Digital Twin:\n"
            f"  Length: {self.style['avg_length']}\n"
            f"  Emoji: {self.style['emoji_frequency']}\n"
            f"  Language: {self.style['language_mix']}\n"
            f"  Samples learned: {len(self.style.get('sample_messages', []))}"
        )


# Global instance
digital_twin = DigitalTwin()