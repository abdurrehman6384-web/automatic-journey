# ╔══════════════════════════════════════════════════════════╗
# ║       autopilot.py — RASHEED Browser Auto-Pilot          ║
# ║       Autonomous web browsing & form filling             ║
# ╚══════════════════════════════════════════════════════════╝

import asyncio


async def browse_task(task_description):
    """RASHEED khud browser mein kaam karega"""
    try:
        from browser_use import Agent
        from langchain_google_genai import ChatGoogleGenerativeAI
        
        llm = ChatGoogleGenerativeAI(
            model="gemini-2.0-flash",
            google_api_key="YOUR_API_KEY"  # config se lo
        )
        
        agent = Agent(task=task_description, llm=llm)
        result = await agent.run()
        return result
        
    except ImportError:
        return "❌ browser-use not installed! Run: pip install browser-use"
    except Exception as e:
        return f"❌ Autopilot Error: {e}"


def run_autopilot(task):
    """Sync wrapper for async function"""
    return asyncio.run(browse_task(task))
