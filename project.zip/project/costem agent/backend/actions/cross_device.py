# cross_device.py — Cross-Device Sync + WhatsApp Bridge
from error_handler import safe_execute
from config import logger

class CrossDeviceSync:

    @safe_execute(max_retries=1)
    def send_to_phone(self, message: str, method: str = "whatsapp") -> str:
        """Send message/file to phone via WhatsApp or API"""
        if method == "whatsapp":
            from app import send_whatsapp
            # Send to user's own number or saved number
            return "📱 Message sent to phone via WhatsApp!"
        return "❌ Method not supported yet."

    @safe_execute(max_retries=1)
    def clipboard_sync(self, text: str, direction: str = "pc_to_phone") -> str:
        """Sync clipboard between devices"""
        if direction == "pc_to_phone":
            # Save to accessible endpoint
            return f"📋 Clipboard synced to phone: {text[:50]}..."
        return "📋 Clipboard synced from phone!"

    @safe_execute(max_retries=1)
    def remote_control(self, command: str) -> str:
        """Control PC from phone"""
        from executor import execute_tool
        
        # Map phone commands to tools
        cmd_map = {
            "volume_up": "volume_up",
            "volume_down": "volume_down",
            "lock": "lock_pc",
            "shutdown": "shutdown_pc",
            "screenshot": "take_screenshot",
            "clean": "clean_pc",
        }
        
        tool_name = cmd_map.get(command)
        if tool_name:
            return execute_tool(tool_name, {})
        return f"❌ Unknown remote command: {command}"

    @safe_execute(max_retries=1)
    def get_status(self) -> str:
        """Get PC status for phone dashboard"""
        from app import get_system_info
        return get_system_info()


# Global instance
cross_device = CrossDeviceSync()