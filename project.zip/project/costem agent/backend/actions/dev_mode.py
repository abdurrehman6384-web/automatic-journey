# dev_mode.py — Voice-to-Code, Auto-Debug, Git Control, Code Explainer
import subprocess
import os
from config import BASE_DIR, logger
from error_handler import safe_execute
from ai_brain import llm_router
from vision import vision
from typing_engine import typer


class DevMode:
    # ── Voice Git Control ─────────────────────────────
    @safe_execute(max_retries=1)
    def git_commit_push(self, message: str) -> str:
        """Git add, commit, and push"""
        cmds = [
            ["git", "add", "."],
            ["git", "commit", "-m", message],
            ["git", "push"]
        ]
        for cmd in cmds:
            result = subprocess.run(
                cmd, capture_output=True, text=True,
                timeout=30, cwd=str(BASE_DIR)
            )
            if result.returncode != 0 and "nothing to commit" not in result.stdout:
                logger.warning(f"Git cmd failed: {cmd} -> {result.stderr}")
        return f"✅ Git pushed with message: '{message}'"

    # ── Voice-to-Code (AI Code Generator) ─────────────
    @safe_execute(max_retries=1)
    def generate_code(self, description: str, filename: str = None) -> str:
        """Generate code from description and save/open it"""
        prompt = (
            f"Write a complete Python program for this: {description}\n"
            f"Output ONLY the code, no explanation."
        )
        code = llm_router.smart_ask(prompt)
        if not code or "❌" in str(code):
            return f"❌ Code generation failed: {code}"
        
        # Clean markdown blocks
        code = code.replace("```python", "").replace("```", "").strip()
        
        if not filename:
            filename = "generated_code.py"
        
        filepath = os.path.join(str(BASE_DIR), filename)
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(code)
        
        # Open in VS Code
        subprocess.Popen(["code", filepath])
        return f"✅ Code generated and opened in VS Code: {filename}"

    # ── Auto-Debugger ─────────────────────────────────
    def auto_debug(self, error_text: str = None) -> str:
        """Read error from screen/clipboard and suggest fix"""
        if not error_text:
            error_text = vision.read_screen_text()
            if not error_text:
                import pyperclip
                error_text = pyperclip.paste()
        
        if not error_text or len(error_text) < 10:
            return "❌ No error text found on screen or clipboard."
        
        prompt = (
            f"Analyze this error and provide the exact fix. Give only the corrected code block:\n\n"
            f"{error_text[:2000]}"
        )
        fix = llm_router.smart_ask(prompt)
        return f"🔍 Suggested Fix:\n{fix}"

    # ── Live Code Explainer ───────────────────────────
    def explain_code(self) -> str:
        """Read code from screen and explain it"""
        code = vision.read_screen_text()
        if not code:
            return "❌ No code found on screen."
        
        prompt = (
            f"Explain this code in simple Roman Urdu/Hinglish:\n\n{code[:2000]}"
        )
        explanation = llm_router.smart_ask(prompt)
        return explanation

# Global instance
dev_mode = DevMode()