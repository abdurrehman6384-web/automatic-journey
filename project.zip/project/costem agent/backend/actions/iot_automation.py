# iot_automation.py — Smart Home, Email, Form Filler
import requests
import subprocess
import time
from config import HUE_BRIDGE_IP, HUE_API_KEY, logger
from error_handler import safe_execute
from vision import vision
from typing_engine import typer


class SmartHome:
    """Philips Hue / Tuya Smart Home Control"""
    @safe_execute(max_retries=1)
    def control_lights(self, room: str = "1", state: bool = True, brightness: int = 200) -> str:
        if not HUE_BRIDGE_IP or not HUE_API_KEY:
            return "❌ Hue Bridge IP/API Key not set in .env"
        url = f"http://{HUE_BRIDGE_IP}/api/{HUE_API_KEY}/lights/{room}/state"
        data = {"on": state, "bri": brightness}
        r = requests.put(url, json=data, timeout=5)
        return f"💡 Light {room} {'ON' if state else 'OFF'} Brightness:{brightness}"

    def lights_on(self, room: str = "1") -> str:
        return self.control_lights(room, True, 254)

    def lights_off(self, room: str = "1") -> str:
        return self.control_lights(room, False, 0)

    def lights_dim(self, room: str = "1") -> str:
        return self.control_lights(room, True, 80)


class EmailManager:
    """Gmail read/reply via API"""
    @safe_execute(max_retries=1)
    def check_unread(self) -> str:
        try:
            from googleapiclient.discovery import build
            from google_auth_oauthlib.flow import InstalledAppFlow
            from google.auth.transport.requests import Request
            from google.oauth2.credentials import Credentials
            import pickle
            import os
            from config import GMAIL_CREDENTIALS_FILE

            SCOPES = ['https://www.googleapis.com/auth/gmail.readonly']
            creds = None
            token_file = 'data/gmail_token.json'

            if os.path.exists(token_file):
                creds = Credentials.from_authorized_user_file(token_file, SCOPES)
            if not creds or not creds.valid:
                if creds and creds.expired and creds.refresh_token:
                    creds.refresh(Request())
                else:
                    flow = InstalledAppFlow.from_client_secrets_file(GMAIL_CREDENTIALS_FILE, SCOPES)
                    creds = flow.run_local_server(port=0)
                with open(token_file, 'w') as f:
                    creds.to_json()

            service = build('gmail', 'v1', credentials=creds)
            results = service.users().messages().list(
                userId='me', labelIds=['INBOX'], q='is:unread', maxResults=5
            ).execute()
            messages = results.get('messages', [])
            
            if not messages:
                return "📭 No unread emails boss!"
            
            output = "📬 Unread Emails:\n"
            for msg in messages:
                msg_data = service.users().messages().get(userId='me', id=msg['id']).execute()
                headers = msg_data['payload']['headers']
                subject = next((h['value'] for h in headers if h['name'] == 'Subject'), 'No Subject')
                sender = next((h['value'] for h in headers if h['name'] == 'From'), 'Unknown')
                output += f"  • From: {sender}\n    Subject: {subject}\n"
            return output
        except Exception as e:
            return f"❌ Email error: {e}"


class AutoFormFiller:
    """Fill forms based on AI instructions"""
    def fill_current_form(self, data: dict) -> str:
        """Takes dict like {'name': 'Abdurrehman', 'email': 'boss@rash.eed'} and fills active form"""
        try:
            import pyautogui
            filled = 0
            for key, value in data.items():
                typer.type_smart(str(value))
                pyautogui.press('tab')
                time.sleep(0.3)
                filled += 1
            pyautogui.press('enter')
            return f"✅ Filled {filled} fields and submitted!"
        except Exception as e:
            return f"❌ Form fill error: {e}"

# Global instances
smart_home = SmartHome()
email_manager = EmailManager()
form_filler = AutoFormFiller()