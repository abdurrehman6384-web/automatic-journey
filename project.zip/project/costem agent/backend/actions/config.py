# config.py — RASHEED Centralized Configuration
import os
import logging  # ✅ اضافہ کیا گیا
from pathlib import Path
from dotenv import load_dotenv

# Load .env
load_dotenv()

# ── Project Paths ────────────────────────────────────────
BASE_DIR = Path(__file__).parent
LOGS_DIR = BASE_DIR / "logs"
DATA_DIR = BASE_DIR / "data"
ASSETS_DIR = BASE_DIR / "assets"
FACE_DATA_DIR = ASSETS_DIR / "face_data"

# Create dirs
for d in [LOGS_DIR, DATA_DIR, ASSETS_DIR, FACE_DATA_DIR]:
    d.mkdir(parents=True, exist_ok=True)

# ── API Keys ─────────────────────────────────────────────
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
FRAMEWORK_API_KEY = os.getenv("FRAMEWORK_API_KEY", "")

# ── Face Lock ────────────────────────────────────────────
FACE_LOCK_ENABLED = os.getenv("FACE_LOCK_ENABLED", "false").lower() == "true"
FACE_LOCK_PIN = os.getenv("FACE_LOCK_PIN", "1234")
FACE_LOCK_TOLERANCE = float(os.getenv("FACE_LOCK_TOLERANCE", "0.6"))
FACE_MODEL_PATH = str(FACE_DATA_DIR / "face_model.yml")
FACE_LABELS_PATH = str(FACE_DATA_DIR / "face_labels.json")
AUTHORIZED_FACE_DIR = str(FACE_DATA_DIR / "authorized")

# ── Voice ────────────────────────────────────────────────
VOICE_NAME = os.getenv("VOICE_NAME", "Puck")
MIC_RATE = int(os.getenv("MIC_RATE", "16000"))
SPK_RATE = int(os.getenv("SPK_RATE", "24000"))

# ── Vision ───────────────────────────────────────────────
VISION_FPS = int(os.getenv("VISION_FPS", "30"))
SCREEN_QUALITY = int(os.getenv("SCREEN_QUALITY", "70"))
SCREEN_WIDTH = int(os.getenv("SCREEN_WIDTH", "1280"))
VISION_INTERVAL = 1.0 / VISION_FPS

# ── Self Upgrade ─────────────────────────────────────────
AUTO_UPDATE_ENABLED = os.getenv("AUTO_UPDATE_ENABLED", "false").lower() == "true"
GIT_REPO_URL = os.getenv("GIT_REPO_URL", "")
UPDATE_CHECK_INTERVAL = int(os.getenv("UPDATE_CHECK_INTERVAL", "3600"))

# ── Memory ───────────────────────────────────────────────
MEMORY_MAX_CONVERSATIONS = int(os.getenv("MEMORY_MAX_CONVERSATIONS", "200"))
MEMORY_FILE = str(Path.home() / os.getenv("MEMORY_FILE", "rasheed_memory.json"))

# ── Logging ──────────────────────────────────────────────
LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
LOG_FILE = str(BASE_DIR / os.getenv("LOG_FILE", "logs/rasheed.log"))
LOG_MAX_SIZE_MB = int(os.getenv("LOG_MAX_SIZE_MB", "10"))
LOG_BACKUP_COUNT = int(os.getenv("LOG_BACKUP_COUNT", "5"))

# ── Security ─────────────────────────────────────────────
ENCRYPTION_KEY = os.getenv("ENCRYPTION_KEY", "rasheed_auto_gen_changeme")
RATE_LIMIT_PER_MINUTE = int(os.getenv("RATE_LIMIT_PER_MINUTE", "60"))

# ── Weather ──────────────────────────────────────────────
DEFAULT_CITY = os.getenv("DEFAULT_CITY", "Karachi")

# ── YouTube ──────────────────────────────────────────────
YOUTUBE_CREDENTIALS_FILE = os.getenv("YOUTUBE_CREDENTIALS_FILE", "youtube_credentials.json")

# ── Gemini WebSocket ─────────────────────────────────────
GEMINI_WS_URL = (
    "wss://generativelanguage.googleapis.com/ws/"
    "google.ai.generativelanguage.v1beta."
    "GenerativeService.BidiGenerateContent"
)

# ── Gemini Model ─────────────────────────────────────────
GEMINI_MODEL = "models/gemini-2.5-flash-native-audio-preview-12-2025"

# ── Audio ────────────────────────────────────────────────
MIC_FRAMES = int(MIC_RATE * 20 / 1000)

# ── Desktop ──────────────────────────────────────────────
DESKTOP = str(Path.home() / "Desktop")  # ✅ یہاں "and" اور main.py کا کمنٹ ہٹا کر ٹھیک کیا

# ═════════════════════════════════════════════════════════=
# ✅ CENTRALIZED LOGGER SETUP (اضافہ کیا گیا)
# ═════════════════════════════════════════════════════════=
logger = logging.getLogger("RASHEED")
logger.setLevel(getattr(logging, LOG_LEVEL.upper(), logging.INFO))

# کنسول ہینڈلر (ٹرمنل میں لاگ دکھائے گا)
ch = logging.StreamHandler()
ch.setLevel(getattr(logging, LOG_LEVEL.upper(), logging.INFO))

# فائل ہینڈلر (لاگز فائل میں محفوظ کرے گا)
fh = logging.FileHandler(LOG_FILE)
fh.setLevel(getattr(logging, LOG_LEVEL.upper(), logging.INFO))

# لاگ کا فارمیٹ
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
ch.setFormatter(formatter)
fh.setFormatter(formatter)

# ہینڈلرز کو logger میں شامل کریں
if not logger.handlers:  # ڈپلیکیٹ ہینڈلرز سے بچنے کے لیے
    logger.addHandler(ch)
    logger.addHandler(fh)
    # ── AI Brain ─────────────────────────────────────────────
GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
ELEVENLABS_API_KEY = os.getenv("ELEVENLABS_API_KEY", "")
CHROMA_PERSIST_DIR = str(BASE_DIR / os.getenv("CHROMA_PERSIST_DIR", "data/chroma_db"))

# ── Smart Home ───────────────────────────────────────────
HUE_BRIDGE_IP = os.getenv("HUE_BRIDGE_IP", "")
HUE_API_KEY = os.getenv("HUE_API_KEY", "")

# ── Email ────────────────────────────────────────────────
GMAIL_CREDENTIALS_FILE = os.getenv("GMAIL_CREDENTIALS_FILE", "gmail_credentials.json")

# ── VPN ──────────────────────────────────────────────────
VPN_CLI_PATH = os.getenv("VPN_CLI_PATH", "")

# ── Proactive AI ─────────────────────────────────────────
PROACTIVE_AI_ENABLED = os.getenv("PROACTIVE_AI_ENABLED", "false").lower() == "true"
PROACTIVE_INTERVAL = int(os.getenv("PROACTIVE_INTERVAL", "30"))
# ── Agent System ─────────────────────────────────────────
AGENT_MAX_ITERATIONS = int(os.getenv("AGENT_MAX_ITERATIONS", "5"))
AGENT_MODEL = os.getenv("AGENT_MODEL", "llama-3.1-70b-versatile")

# ── Remote Access ────────────────────────────────────────
FASTAPI_PORT = int(os.getenv("FASTAPI_PORT", "8000"))
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")

# ── GitHub Webhook ───────────────────────────────────────
GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", "")
GITHUB_REPO = os.getenv("GITHUB_REPO", "")

# ── Playwright ───────────────────────────────────────────
HEADLESS_BROWSER = os.getenv("HEADLESS_BROWSER", "true").lower() == "true"
# ── Trading ──────────────────────────────────────────────
BINANCE_API_KEY = os.getenv("BINANCE_API_KEY", "")
BINANCE_SECRET = os.getenv("BINANCE_SECRET", "")
DRY_RUN_TRADING = os.getenv("DRY_RUN_TRADING", "true").lower() == "true"

# ── Space ────────────────────────────────────────────────
NASA_API_KEY = os.getenv("NASA_API_KEY", "")
# ── Generative AI ────────────────────────────────────────
STABILITY_API_KEY = os.getenv("STABILITY_API_KEY", "")
SUNO_API_KEY = os.getenv("SUNO_API_KEY", "")
# ── Health ───────────────────────────────────────────────
HEALTH_API_URL = os.getenv("HEALTH_API_URL", "")
# ── HuggingFace AI ──────────────────────────────────────
HUGGINGFACE_API_KEY = os.getenv("HUGGINGFACE_API_KEY", "")
HUGGINGFACE_MODEL = os.getenv("HUGGINGFACE_MODEL", "mistralai/Mistral-7B-Instruct-v0.2")

# ── Offline Mode ────────────────────────────────────────
OFFLINE_ENABLED = os.getenv("OFFLINE_ENABLED", "true").lower() == "true"
WAKE_WORD = os.getenv("WAKE_WORD", "rasheed")
VOSK_MODEL_PATH = os.getenv("VOSK_MODEL_PATH", "models/vosk-model-small-en-us-0.15")

# ── Deep Search ─────────────────────────────────────────
SEARCH_INDEX_DIR = str(BASE_DIR / "data" / "search_index")
SEARCH_MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB max per file


GEMINI_API_KEY = 'AIzaSyDTxchsOjccEWlMZIG347gTAT9lBOPEhWA'