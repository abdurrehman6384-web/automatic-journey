# ╔══════════════════════════════════════════════════════════╗
# ║       voice_clone.py — RASHEED Voice Cloning (Local)     ║
# ║       Speak in YOUR voice using Coqui TTS                ║
# ╚══════════════════════════════════════════════════════════╝

import os


class VoiceCloner:

    def __init__(self):
        self.model = None
        self.available = False
        try:
            from TTS.api import TTS
            self.tts = TTS("tts_models/multilingual/multi-dataset/xtts_v2")
            self.available = True
            print("🎙️ Voice Cloning Engine: Ready")
        except:
            print("⚠️ Voice Cloning: TTS not installed")

    def clone_and_speak(self, text, reference_audio="my_voice_sample.wav"):
        """Apni awaaz mein bole"""
        if not self.available:
            return False
        try:
            output_path = "output_cloned.wav"
            self.tts.tts_to_file(
                text=text,
                speaker_wav=reference_audio,
                language="en",
                file_path=output_path
            )
            os.system(f'start {output_path}')  # Windows play
            return True
        except Exception as e:
            print(f"Voice clone error: {e}")
            return False


voice_cloner = VoiceCloner()
