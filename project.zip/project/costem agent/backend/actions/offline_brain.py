# offline_mode.py — Offline Voice, Wake Word, HuggingFace AI Fallback
import os
import json
import threading
import time
import requests
from config import (
    HUGGINGFACE_API_KEY, HUGGINGFACE_MODEL,
    WAKE_WORD, VOSK_MODEL_PATH, logger
)
from error_handler import safe_execute


class OfflineAI:
    """
    HuggingFace API for offline/fallback AI chat.
    When Gemini is down, this kicks in.
    """

    @safe_execute(max_retries=1)
    def chat(self, message: str, history: list = None) -> str:
        """Chat using HuggingFace Inference API"""
        if not HUGGINGFACE_API_KEY:
            return "❌ HuggingFace API key not set in .env"

        url = f"https://api-inference.huggingface.co/models/{HUGGINGFACE_MODEL}"
        headers = {
            "Authorization": f"Bearer {HUGGINGFACE_API_KEY}",
            "Content-Type": "application/json"
        }

        # Build prompt
        prompt = f"<s>[INST] You are RASHEED, a helpful AI assistant created by Abdurrehman. "
        prompt += f"Respond in the same language the user speaks. Be concise and helpful.\n"
        
        if history:
            for h in history[-5:]:
                prompt += f"User: {h['user']}\nRASHEED: {h['ai']}\n"
        
        prompt += f"User: {message}\nRASHEED: [/INST]"

        data = {
            "inputs": prompt,
            "parameters": {
                "max_new_tokens": 500,
                "temperature": 0.7,
                "top_p": 0.95,
                "do_sample": True,
                "return_full_text": False
            }
        }

        try:
            r = requests.post(url, headers=headers, json=data, timeout=30)

            if r.status_code == 200:
                result = r.json()
                if isinstance(result, list) and len(result) > 0:
                    text = result[0].get("generated_text", "")
                    # Clean up
                    text = text.replace("[/INST]", "").strip()
                    if text:
                        return text
                return "⚠️ HuggingFace returned empty response"
            
            elif r.status_code == 503:
                return "⏳ HuggingFace model is loading... try again in 20 seconds"
            
            else:
                return f"❌ HuggingFace error: {r.status_code}"

        except requests.exceptions.Timeout:
            return "❌ HuggingFace request timed out"
        except Exception as e:
            return f"❌ HuggingFace error: {e}"


class OfflineVoice:
    """
    Offline Voice Recognition using Vosk.
    Wake word detection + basic offline commands.
    """

    def __init__(self):
        self.listening = False
        self.vosk_available = False
        self._check_vosk()

    def _check_vosk(self):
        """Check if Vosk model is available"""
        model_path = VOSK_MODEL_PATH
        if os.path.exists(model_path):
            try:
                import vosk
                self.vosk_available = True
                logger.info(f"Vosk model found: {model_path}")
            except ImportError:
                logger.warning("Vosk not installed. Run: pip install vosk")
                self.vosk_available = False
        else:
            logger.warning(f"Vosk model not found at: {model_path}")
            logger.warning("Download from: https://alphacephei.com/vosk/models")
            self.vosk_available = False

    def download_vosk_model(self) -> str:
        """Download Vosk small English model"""
        import zipfile
        
        model_dir = os.path.dirname(VOSK_MODEL_PATH)
        os.makedirs(model_dir, exist_ok=True)
        
        url = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
        zip_path = os.path.join(model_dir, "vosk-model.zip")

        try:
            print("📥 Downloading Vosk model (40MB)...")
            r = requests.get(url, timeout=120, stream=True)
            with open(zip_path, 'wb') as f:
                for chunk in r.iter_content(chunk_size=8192):
                    f.write(chunk)

            print("📦 Extracting...")
            with zipfile.ZipFile(zip_path, 'r') as z:
                z.extractall(model_dir)

            os.remove(zip_path)
            self.vosk_available = True
            return "✅ Vosk model downloaded! Offline voice is ready."

        except Exception as e:
            return f"❌ Download error: {e}"

    # ── Offline Commands ─────────────────────────────
    OFFLINE_COMMANDS = {
        "volume up": {"tool": "volume_up", "args": {}},
        "volume down": {"tool": "volume_down", "args": {}},
        "mute": {"tool": "volume_mute", "args": {}},
        "lock": {"tool": "lock_pc", "args": {}},
        "time": {"tool": "get_time", "args": {}},
        "date": {"tool": "get_date", "args": {}},
        "weather": {"tool": "get_weather", "args": {}},
        "screenshot": {"tool": "take_screenshot", "args": {}},
        "clean": {"tool": "clean_pc", "args": {}},
        "boost": {"tool": "boost_ram", "args": {}},
        "shutdown": {"tool": "shutdown_pc", "args": {}},
        "restart": {"tool": "restart_pc", "args": {}},
    }

    APP_COMMANDS = {
        "chrome": "chrome",
        "notepad": "notepad",
        "code": "code",
        "calculator": "calc",
        "firefox": "firefox",
        "spotify": "spotify",
        "discord": "discord",
        "whatsapp": "whatsapp",
    }

    def process_offline_command(self, text: str) -> str:
        """Process basic commands offline without Gemini"""
        text_lower = text.lower().strip()

        # Remove wake word if present
        for wake in [WAKE_WORD, "hey rasheed", "ok rasheed"]:
            if text_lower.startswith(wake):
                text_lower = text_lower.replace(wake, "").strip()

        # Check direct commands
        for cmd, tool_info in self.OFFLINE_COMMANDS.items():
            if cmd in text_lower:
                try:
                    from executor import execute_tool
                    return execute_tool(tool_info["tool"], tool_info["args"])
                except Exception as e:
                    return f"❌ Offline command error: {e}"

        # Check app open commands
        for app_keyword, app_name in self.APP_COMMANDS.items():
            if f"open {app_keyword}" in text_lower or f"{app_keyword} kholo" in text_lower:
                try:
                    from executor import execute_tool
                    return execute_tool("open_app", {"app_name": app_name})
                except Exception as e:
                    return f"❌ App open error: {e}"

        # Check file operations
        if "create file" in text_lower or "file banao" in text_lower:
            try:
                from executor import execute_tool
                name = text_lower.split("file")[-1].strip().replace("banao", "").strip()
                name = name or "untitled.txt"
                return execute_tool("create_file", {"name": name})
            except Exception:
                pass

        if "delete file" in text_lower or "file delete" in text_lower:
            try:
                from executor import execute_tool
                name = text_lower.split("file")[-1].strip().replace("delete", "").strip()
                return execute_tool("delete_file", {"name": name})
            except Exception:
                pass

        # Check search
        if "search" in text_lower or "dhundho" in text_lower:
            query = text_lower.replace("search", "").replace("dhundho", "").strip()
            if query:
                try:
                    from executor import execute_tool
                    return execute_tool("deep_search", {"query": query})
                except Exception:
                    pass

        # If no offline command matched, use HuggingFace AI
        return self._ask_offline_ai(text)

    def _ask_offline_ai(self, text: str) -> str:
        """Fallback to HuggingFace AI for general chat"""
        ai = OfflineAI()
        response = ai.chat(text)
        if response and "❌" not in str(response):
            return response
        return "⚠️ I'm offline and couldn't process that. Try: volume up/down, time, date, open chrome, lock, screenshot, clean, boost."


class WakeWordDetector:
    """
    Background wake word detection using Vosk.
    Runs in separate thread, triggers on "Rasheed" or "Hey Rasheed".
    """

    def __init__(self):
        self.active = False
        self.callback = None  # Function to call when wake word detected

    def start(self, callback=None) -> str:
        """Start wake word detection"""
        self.callback = callback
        self.active = True

        voice = OfflineVoice()
        if not voice.vosk_available:
            return "❌ Vosk model not found. Download it first."

        t = threading.Thread(target=self._detect_loop, daemon=True)
        t.start()
        return f"👂 Wake word '{WAKE_WORD}' detection started!"

    def stop(self) -> str:
        """Stop wake word detection"""
        self.active = False
        return "🔇 Wake word detection stopped."

    def _detect_loop(self):
        """Continuous listening for wake word"""
        try:
            import vosk
            import sounddevice as sd
            import json

            model = vosk.Model(VOSK_MODEL_PATH)
            samplerate = 16000
            recognizer = vosk.KaldiRecognizer(model, samplerate)

            with sd.InputStream(
                samplerate=samplerate, channels=1,
                dtype="int16", blocksize=8000
            ) as stream:
                while self.active:
                    data, _ = stream.read(8000)
                    if recognizer.AcceptWaveform(data.tobytes()):
                        result = json.loads(recognizer.Result())
                        text = result.get("text", "").lower()

                        if WAKE_WORD in text:
                            logger.info(f"👂 Wake word detected: {text}")
                            if self.callback:
                                self.callback(text)
                    else:
                        # Partial result check
                        partial = json.loads(recognizer.PartialResult())
                        ptext = partial.get("partial", "").lower()
                        if WAKE_WORD in ptext:
                            logger.info(f"👂 Wake word (partial): {ptext}")
                            if self.callback:
                                self.callback(ptext)

                    time.sleep(0.01)

        except ImportError:
            logger.error("Vosk not installed for wake word detection")
        except Exception as e:
            logger.error(f"Wake word error: {e}")


# Global instances
offline_ai = OfflineAI()
offline_voice = OfflineVoice()
wake_word = WakeWordDetector()
