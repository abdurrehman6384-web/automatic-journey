# ╔══════════════════════════════════════════════════════════╗
# ║       autonomous_goals.py — RASHEED Goal Engine          ║
# ║       Zero-Prompt: Thinks & Acts Without Commands        ║
# ╚══════════════════════════════════════════════════════════╝

import os
import json
import time
import threading
import datetime
import psutil


class AutonomousGoalEngine:
    """RASHEED khud sochta hai aur bina command ke kaam karta hai"""

    def __init__(self):
        self.running = False
        self.goals_file = "autonomous_goals.json"
        self.goals = self._load_goals()
        self.last_actions = {}
        self.study_reminder_given_today = False
        self.morning_greeting_done = False
        self.breakfast_reminder = False

    def _load_goals(self):
        try:
            if os.path.exists(self.goals_file):
                with open(self.goals_file, 'r') as f:
                    return json.load(f)
        except:
            pass
        return {
            "active_goals": [],
            "completed_goals": [],
            "daily_routine": True,
            "health_monitor": True,
            "study_monitor": True,
            "system_monitor": True
        }

    def _save_goals(self):
        try:
            with open(self.goals_file, 'w') as f:
                json.dump(self.goals, f, indent=2)
        except:
            pass

    # ════════════════════════════════════════════════════════
    # MAIN: Start Autonomous Engine
    # ════════════════════════════════════════════════════════

    def start(self):
        """Start the autonomous goal engine"""
        if self.running:
            return
        
        self.running = True
        t = threading.Thread(target=self._main_loop, daemon=True)
        t.start()
        print("🔮 Autonomous Goals: Engine Started!")

    def stop(self):
        """Stop the autonomous engine"""
        self.running = False
        print("🔮 Autonomous Goals: Engine Stopped")

    def _main_loop(self):
        """Main autonomous loop — checks every 60 seconds"""
        while self.running:
            try:
                self._check_time_based_goals()
                self._check_system_health()
                self._check_battery()
                self._check_ram_usage()
                self._check_study_schedule()
                self._process_active_goals()
            except Exception as e:
                pass
            
            time.sleep(60)  # Check every minute

    # ════════════════════════════════════════════════════════
    # TIME-BASED AUTONOMOUS GOALS
    # ════════════════════════════════════════════════════════

    def _check_time_based_goals(self):
        """Time-based automatic actions"""
        now = datetime.datetime.now()
        hour = now.hour
        minute = now.minute
        weekday = now.weekday()  # 0=Monday

        # ── Subah 6-7 AM: Good Morning + Quran Reminder ──
        if hour == 6 and minute == 0 and not self.morning_greeting_done:
            self.morning_greeting_done = True
            self._speak_and_notify(
                "Assalam o Alaikum Boss! Good Morning! 🌅\n"
                "Subah MashaAllah! Quran revision ka time ho gaya hai. 📖",
                "🌅 Good Morning!"
            )

        # ── 8 AM: Study Time ─────────────────────────────
        if hour == 8 and minute == 0 and weekday < 5:  # Weekdays only
            if not self.study_reminder_given_today:
                self.study_reminder_given_today = True
                self._speak_and_notify(
                    "Boss! 8 baj gaye hain. Study time! 📚\n"
                    "Math se shuru karein — practice problems solve karein.",
                    "📚 Study Time!"
                )
                # Auto-open study apps
                self._try_execute("open_app", {"app_name": "chrome"})

        # ── 10 AM: Short Break ───────────────────────────
        if hour == 10 and minute == 0:
            self._speak_and_notify(
                "Boss! 10 minute ka break le lo. ☕\n"
                "Paani piyo aur thoda walk karo! 🚶",
                "☕ Break Time!"
            )

        # ── 2 PM: Afternoon Study ────────────────────────
        if hour == 14 and minute == 0 and weekday < 5:
            self._speak_and_notify(
                "Boss! Zuhr ke baad Computer Science ka time! 💻\n"
                "RASHEED se koi bhi topic pucho — mein samjha dunga!",
                "💻 CS Study Time!"
            )

        # ── 5 PM: Asr Reminder ───────────────────────────
        if hour == 17 and minute == 0:
            self._speak_and_notify(
                "Boss! Asr ki Namaz ka time ho gaya hai. 🤲",
                "🤲 Namaz Reminder"
            )

        # ── 9 PM: Revision Time ──────────────────────────
        if hour == 21 and minute == 0:
            self._speak_and_notify(
                "Boss! Raat 9 baj gaye. Aaj jo parha hai wo revision karo! 📝\n"
                "RASHEED se test le sakte ho — 'Math ka paper banao' bolo!",
                "📝 Revision Time!"
            )

        # ── 11 PM: Good Night ────────────────────────────
        if hour == 23 and minute == 0:
            self._speak_and_notify(
                "Boss! 11 baj gaye hain. Ab so jao! 😴\n"
                "Kal subah fresh mind se parhenge. Goodnight! 🌙",
                "🌙 Goodnight!"
            )
            # Reset daily flags
            self.morning_greeting_done = False
            self.study_reminder_given_today = False

    # ════════════════════════════════════════════════════════
    # SYSTEM HEALTH AUTONOMOUS GOALS
    # ════════════════════════════════════════════════════════

    def _check_system_health(self):
        """Monitor system health automatically"""
        if not self.goals.get("system_monitor", True):
            return

        cpu = psutil.cpu_percent(interval=1)
        
        # High CPU alert
        if cpu > 90:
            last_alert = self.last_actions.get("cpu_alert", 0)
            if time.time() - last_alert > 600:  # Max 1 alert per 10 min
                self.last_actions["cpu_alert"] = time.time()
                self._speak_and_notify(
                    f"⚠️ Boss! CPU usage {cpu}% par hai!\n"
                    "Koi heavy app band karein ya RASHEED RAM boost kare?",
                    "⚠️ High CPU Alert!"
                )

    def _check_battery(self):
        """Battery monitoring"""
        battery = psutil.sensors_battery()
        if not battery:
            return

        # Low battery alert (not plugged in)
        if not battery.power_plugged and battery.percent < 20:
            last_alert = self.last_actions.get("battery_alert", 0)
            if time.time() - last_alert > 300:  # Max 1 alert per 5 min
                self.last_actions["battery_alert"] = time.time()
                self._speak_and_notify(
                    f"🔋 Boss! Battery {battery.percent}% par hai!\n"
                    "Charger plug kar lo — warna PC shut down ho jayega!",
                    "🔋 Low Battery!"
                )

        # Fully charged alert
        if battery.power_plugged and battery.percent >= 95:
            last_alert = self.last_actions.get("charge_full", 0)
            if time.time() - last_alert > 1800:  # Max 1 alert per 30 min
                self.last_actions["charge_full"] = time.time()
                self._speak_and_notify(
                    f"✅ Boss! Battery {battery.percent}% charge ho gayi!\n"
                    "Charger nikal do — overcharging se battery kharab hoti hai.",
                    "✅ Battery Full!"
                )

    def _check_ram_usage(self):
        """RAM monitoring"""
        ram = psutil.virtual_memory()
        
        if ram.percent > 90:
            last_alert = self.last_actions.get("ram_alert", 0)
            if time.time() - last_alert > 600:
                self.last_actions["ram_alert"] = time.time()
                self._speak_and_notify(
                    f"⚠️ RAM {ram.percent}% use ho rahi hai!\n"
                    "Kya RASHEED RAM boost kare? Heavy processes kill kar deta hoon.",
                    "⚠️ High RAM Usage!"
                )
                # Auto-boost if critical
                if ram.percent > 95:
                    self._try_execute("boost_ram", {})

    def _check_study_schedule(self):
        """Study schedule monitoring"""
        if not self.goals.get("study_monitor", True):
            return

        # Check if it's a study day and time
        now = datetime.datetime.now()
        weekday = now.weekday()
        
        # Weekend reminder
        if weekday >= 5 and now.hour == 10 and now.minute == 0:
            if not self.last_actions.get("weekend_study", 0):
                self.last_actions["weekend_study"] = time.time()
                self._speak_and_notify(
                    "📚 Boss! Weekend hai lekin thoda revision zaroor karo!\n"
                    "RASHEED se koi paper solve karwao! 💪",
                    "📚 Weekend Study"
                )

    # ════════════════════════════════════════════════════════
    # ACTIVE GOALS PROCESSING
    # ════════════════════════════════════════════════════════

    def add_goal(self, description, priority=5, deadline=None):
        """Add a new autonomous goal"""
        goal = {
            "id": len(self.goals["active_goals"]) + 1,
            "description": description,
            "priority": priority,  # 1-10
            "deadline": deadline,
            "created": datetime.datetime.now().isoformat(),
            "status": "pending",
            "attempts": 0
        }
        self.goals["active_goals"].append(goal)
        self._save_goals()
        return f"✅ Goal added: {description}"

    def _process_active_goals(self):
        """Process pending goals"""
        for goal in self.goals["active_goals"]:
            if goal["status"] == "pending":
                # Check if deadline is approaching
                if goal.get("deadline"):
                    deadline = datetime.datetime.fromisoformat(goal["deadline"])
                    now = datetime.datetime.now()
                    
                    if deadline < now:
                        goal["status"] = "overdue"
                        self._speak_and_notify(
                            f"🚨 Goal Overdue: {goal['description']}\n"
                            "Kya aap abhi yeh complete karna chahte hain?",
                            "🚨 Goal Overdue!"
                        )
                
                # Check priority goals (remind every hour)
                if goal["priority"] >= 8:
                    last_remind = self.last_actions.get(f"goal_{goal['id']}", 0)
                    if time.time() - last_remind > 3600:  # Remind every hour
                        self.last_actions[f"goal_{goal['id']}"] = time.time()
                        self._speak_and_notify(
                            f"📌 Pending Goal: {goal['description']}\n"
                            f"Priority: {goal['priority']}/10",
                            "📌 Goal Reminder"
                        )

        self._save_goals()

    def complete_goal(self, goal_id):
        """Mark goal as completed"""
        for goal in self.goals["active_goals"]:
            if goal["id"] == goal_id:
                goal["status"] = "completed"
                self.goals["completed_goals"].append(goal)
                self.goals["active_goals"].remove(goal)
                self._save_goals()
                return f"✅ Goal completed: {goal['description']}"
        return "❌ Goal not found"

    def list_goals(self):
        """Show all active goals"""
        if not self.goals["active_goals"]:
            return "ℹ️ No active goals. Say: 'Add goal: [description]'"
        
        result = "\n🎯 Active Goals:\n\n"
        for goal in sorted(self.goals["active_goals"], key=lambda x: x["priority"], reverse=True):
            status_emoji = "🔴" if goal["status"] == "overdue" else "🟡" if goal["status"] == "pending" else "🟢"
            result += f"  {status_emoji} #{goal['id']} [{goal['priority']}/10] {goal['description']}\n"
            if goal.get("deadline"):
                result += f"     ⏰ Deadline: {goal['deadline'][:10]}\n"
        
        result += f"\n  ✅ Completed: {len(self.goals['completed_goals'])} goals"
        return result

    # ════════════════════════════════════════════════════════
    # HELPERS
    # ════════════════════════════════════════════════════════

    def _speak_and_notify(self, message, title="RASHEED"):
        """Speak and show notification"""
        print(f"\n🔮 RASHEED: {message}\n")
        
        # Try to speak
        try:
            from offline_brain import offline_voice
            # Speak only first 100 chars to not be annoying
            offline_voice.speak(message[:100])
        except:
            pass

        # Try notification
        try:
            from plyer import notification
            notification.notify(title=title, message=message[:200], timeout=10)
        except:
            pass

    def _try_execute(self, tool_name, args):
        """Try to execute a tool"""
        try:
            from executor import execute_tool
            execute_tool(tool_name, args)
        except:
            pass

# ════════════════════════════════════════════════════════
# GLOBAL INSTANCE
# ════════════════════════════════════════════════════════


autonomous = AutonomousGoalEngine()
