# ╔══════════════════════════════════════════════════════════╗
# ║       build_cython.py — FIXED VERSION                    ║
# ║       Handles "undeclared name" errors automatically     ║
# ╚══════════════════════════════════════════════════════════╝

import os
import sys
import shutil
import glob
from setuptools import setup, Extension
from Cython.Build import cythonize
from Cython.Compiler import Options

# ── Cython Options (Less Strict) ──────────────────────
Options.error_on_unknown_names = False  # Ignore undeclared name errors
Options.error_on_uninitialized = False  # Ignore uninitialized errors

# ── Files to EXCLUDE from compilation ──────────────────
EXCLUDE_FILES = [
    "main.py",
    "config.py",
    "build_cython.py",
    "setup.py",
]


def get_python_files():
    """Find all .py files in current directory to compile"""
    py_files = []
    for f in os.listdir('.'):
        if f.endswith('.py') and f not in EXCLUDE_FILES:
            py_files.append(f)
    return py_files


def compile_to_c():
    """Compile all .py files to .pyd (C extensions)"""
    py_files = get_python_files()
    
    if not py_files:
        print("❌ No .py files found to compile!")
        return False
    
    print(f"🔨 Compiling {len(py_files)} files to C...\n")
    for f in py_files:
        print(f"   📄 {f}")
    print()
    
    # Build extensions list
    extensions = []
    for py_file in py_files:
        module_name = py_file.replace('.py', '')
        ext = Extension(
            module_name,
            sources=[py_file],
        )
        extensions.append(ext)
    
    try:
        setup(
            ext_modules=cythonize(
                extensions,
                compiler_directives={
                    'language_level': "3",
                    'embedsignature': False,
                    'emit_code_comments': False,
                    'boundscheck': False,  # Faster C code
                    'wraparound': False,  # Faster C code
                    'initializedcheck': False,  # Faster C code
                },
                force=True,
            ),
        )
        return True
    except Exception as e:
        print(f"❌ Compilation Error: {e}")
        return False


def swap_files():
    """Move old .py files to backup, keep only .pyd files"""
    backup_dir = "source_backup"
    if not os.path.exists(backup_dir):
        os.makedirs(backup_dir)
    
    py_files = get_python_files()
    
    print("\n🔄 Swapping .py files with .pyd files...\n")
    
    for py_file in py_files:
        module_name = py_file.replace('.py', '')
        
        # Find the compiled .pyd file (pattern: module.cpxxx-win_amd64.pyd)
        pyd_files = glob.glob(f"{module_name}.cp*.pyd")
        
        if pyd_files:
            pyd_file = pyd_files[0]  # Take the first match
            
            # Move old .py to backup
            if os.path.exists(py_file):
                shutil.move(py_file, os.path.join(backup_dir, py_file))
            
            # Move .c file to backup (cleanup)
            c_file = py_file.replace('.py', '.c')
            if os.path.exists(c_file):
                shutil.move(c_file, os.path.join(backup_dir, c_file))
            
            print(f"   ✅ {py_file} → {pyd_file}")
        else:
            print(f"   ⚠️ {py_file} — .pyd not found, keeping original")
    
    # Clean up build artifacts
    for item in ['build', 'temp']:
        if os.path.exists(item):
            try:
                shutil.rmtree(item)
            except:
                pass
    
    print(f"\n📁 Original files backed up to: {backup_dir}/")


if __name__ == "__main__":
    print("""
╔══════════════════════════════════════════════════════════╗
║       🔒 RASHEED Cython Compiler — FIXED VERSION        ║
║       Handles undeclared name errors automatically       ║
╚══════════════════════════════════════════════════════════╝
    """)
    
    # Step 1: Compile
    if compile_to_c():
        print("\n✅ C compilation successful!")
        print("\n🔄 Swapping files...")
        swap_files()
        
        print("""
╔══════════════════════════════════════════════════════════╗
║  ✅ ALL FILES COMPILED TO .pyd (Unbreakable C DLLs)     ║
║                                                          ║
║  🔒 Your Python code is now 100% hidden!                ║
║  📁 Original .py files moved to source_backup/          ║
║                                                          ║
║  ➡️  Next Step: Run PyInstaller to create .exe           ║
╚══════════════════════════════════════════════════════════╝
        """)
    else:
        print("❌ Compilation failed! Check errors above.")
