# face_lock.py — RASHEED Face Lock System (Python 3.13 Compatible)
# Uses OpenCV Haar Cascade + LBPH Face Recognizer (built into OpenCV)
import cv2
import numpy as np
import os
import json
import time
from pathlib import Path
from config import (
    FACE_LOCK_ENABLED, FACE_LOCK_PIN, FACE_LOCK_TOLERANCE,
    FACE_MODEL_PATH, FACE_LABELS_PATH, AUTHORIZED_FACE_DIR,
    logger
)


class FaceLockSystem:
    """
    Face Lock: Option A — Startup verification with fallback PIN
    - OpenCV Haar Cascade for face detection (no external deps)
    - LBPH Face Recognizer (built into OpenCV)
    - Falls back to PIN if face not recognized
    - Python 3.13 fully compatible
    """

    def __init__(self):
        self.enabled = FACE_LOCK_ENABLED
        self.pin = FACE_LOCK_PIN
        self.tolerance = FACE_LOCK_TOLERANCE
        self.model_path = FACE_MODEL_PATH
        self.labels_path = FACE_LABELS_PATH
        self.auth_dir = AUTHORIZED_FACE_DIR

        # OpenCV built-in face detector
        cascade_path = cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
        self.face_cascade = cv2.CascadeClassifier(cascade_path)
        self.eye_cascade = cv2.CascadeClassifier(
            cv2.data.haarcascades + 'haarcascade_eye.xml'
        )

        # LBPH Face Recognizer (built into OpenCV)
        self.recognizer = cv2.face.LBPHFaceRecognizer_create(
            radius=1, neighbors=8, grid_x=8, grid_y=8, threshold=80
        )

        self.labels = {}  # {label_id: "name"}
        self.is_trained = False
        self.authorized = False
        self.locked = True

        # Create authorized face directory
        os.makedirs(self.auth_dir, exist_ok=True)

        # Load existing model
        self._load_model()

    def _load_model(self):
        """Load trained face model"""
        try:
            if os.path.exists(self.model_path) and os.path.exists(self.labels_path):
                self.recognizer.read(self.model_path)
                with open(self.labels_path, 'r') as f:
                    self.labels = json.load(f)
                self.is_trained = True
                logger.info("Face model loaded successfully.")
            else:
                logger.info("No trained face model found. Enrollment required.")
        except Exception as e:
            logger.warning(f"Face model load error: {e}")

    def detect_faces(self, frame: np.ndarray) -> list:
        """Detect faces in a frame — returns list of (x, y, w, h)"""
        try:
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            gray = cv2.equalizeHist(gray)
            faces = self.face_cascade.detectMultiScale(
                gray,
                scaleFactor=1.1,
                minNeighbors=5,
                minSize=(80, 80),
                flags=cv2.CASCADE_SCALE_IMAGE
            )
            return list(faces)
        except Exception as e:
            logger.error(f"Face detection error: {e}")
            return []

    def verify_liveness(self, frame: np.ndarray, face_rect: tuple) -> bool:
        """Basic liveness check: detect eyes within face region"""
        try:
            x, y, w, h = face_rect
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            face_roi = gray[y:y+h, x:x+w]
            eyes = self.eye_cascade.detectMultiScale(face_roi, 1.1, 3)
            return len(eyes) >= 1
        except Exception:
            return True  # Skip liveness if error

    def recognize_face(self, frame: np.ndarray) -> tuple:
        """
        Recognize face in frame.
        Returns: (name, confidence) or (None, None)
        """
        if not self.is_trained:
            return None, None

        try:
            faces = self.detect_faces(frame)
            for (x, y, w, h) in faces:
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                face_roi = gray[y:y+h, x:x+w]
                face_roi = cv2.resize(face_roi, (200, 200))

                label_id, confidence = self.recognizer.predict(face_roi)
                # LBPH confidence: lower = better match
                if confidence < 100:  # Adjust threshold
                    name = self.labels.get(str(label_id), "Unknown")
                    return name, confidence

            return None, None
        except Exception as e:
            logger.error(f"Face recognition error: {e}")
            return None, None

    def enroll_face(self, name: str, num_samples: int = 30) -> str:
        """
        Enroll a new authorized face.
        Captures multiple samples for better accuracy.
        """
        try:
            cap = cv2.VideoCapture(0)
            if not cap.isOpened():
                return "❌ Webcam nahi mili! Face enrollment fail."

            save_dir = os.path.join(self.auth_dir, name)
            os.makedirs(save_dir, exist_ok=True)

            # Get next label ID
            next_id = len(self.labels)
            for label_id_str in self.labels:
                next_id = max(next_id, int(label_id_str) + 1)

            samples = 0
            print(f"📸 Face enrollment shuru: {name}")
            print(f"   Camera dekho, {num_samples} samples lunge...")

            while samples < num_samples:
                ret, frame = cap.read()
                if not ret:
                    continue

                faces = self.detect_faces(frame)
                for (x, y, w, h) in faces:
                    # Check liveness
                    if not self.verify_liveness(frame, (x, y, w, h)):
                        continue

                    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                    face_roi = gray[y:y+h, x:x+w]
                    face_roi = cv2.resize(face_roi, (200, 200))

                    # Save sample
                    sample_path = os.path.join(save_dir, f"{name}_{samples}.jpg")
                    cv2.imwrite(sample_path, face_roi)
                    samples += 1

                    # Draw rectangle on display
                    cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
                    cv2.putText(
                        frame,
                        f"Sample {samples}/{num_samples}",
                        (10, 30),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2
                    )

                cv2.imshow("RASHEED Face Enrollment — Press Q to cancel", frame)
                if cv2.waitKey(100) & 0xFF == ord('q'):
                    break

            cap.release()
            cv2.destroyAllWindows()

            if samples < 5:
                return f"❌ Only {samples} samples. Need at least 5."

            # Train model with all enrolled faces
            self._train_model()
            self.labels[str(next_id)] = name

            # Save labels
            with open(self.labels_path, 'w') as f:
                json.dump(self.labels, f)

            return f"✅ Face enrolled: {name} ({samples} samples)!"

        except Exception as e:
            return f"❌ Enrollment error: {e}"

    def _train_model(self):
        """Train LBPH model with all enrolled faces"""
        try:
            faces = []
            labels = []

            for label_dir in os.listdir(self.auth_dir):
                label_path = os.path.join(self.auth_dir, label_dir)
                if not os.path.isdir(label_path):
                    continue

                # Find label ID
                label_id = None
                for lid, lname in self.labels.items():
                    if lname == label_dir:
                        label_id = int(lid)
                        break
                if label_id is None:
                    label_id = len(self.labels)
                    self.labels[str(label_id)] = label_dir

                for img_file in os.listdir(label_path):
                    if img_file.endswith(('.jpg', '.png', '.jpeg')):
                        img_path = os.path.join(label_path, img_file)
                        img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
                        if img is not None:
                            img = cv2.resize(img, (200, 200))
                            faces.append(img)
                            labels.append(label_id)

            if not faces:
                logger.warning("No face data to train!")
                return

            self.recognizer.train(faces, np.array(labels))
            self.recognizer.save(self.model_path)

            with open(self.labels_path, 'w') as f:
                json.dump(self.labels, f)

            self.is_trained = True
            logger.info(f"Face model trained with {len(faces)} samples.")

        except Exception as e:
            logger.error(f"Model training error: {e}")

    def verify_at_startup(self) -> bool:
        """
        Option A: Face verification at startup.
        Shows webcam, checks for authorized face.
        Falls back to PIN after 3 failed attempts.
        """
        if not self.enabled:
            logger.info("Face lock disabled. Skipping verification.")
            self.locked = False
            self.authorized = True
            return True

        if not self.is_trained:
            logger.warning("No face model trained! Falling back to PIN.")
            return self._pin_fallback()

        print("\n🔒 RASHEED Face Lock Active!")
        print("   Camera dekho ya PIN enter karo...")

        attempts = 0
        max_attempts = 3

        try:
            cap = cv2.VideoCapture(0)
            if not cap.isOpened():
                logger.warning("Webcam nahi mili! PIN fallback.")
                return self._pin_fallback()

            start_time = time.time()
            timeout = 30  # 30 seconds to verify

            while attempts < max_attempts and (time.time() - start_time) < timeout:
                ret, frame = cap.read()
                if not ret:
                    continue

                faces = self.detect_faces(frame)

                for (x, y, w, h) in faces:
                    # Liveness check
                    if not self.verify_liveness(frame, (x, y, w, h)):
                        cv2.putText(
                            frame, "Eyes not detected",
                            (10, 60), cv2.FONT_HERSHEY_SIMPLEX,
                            0.7, (0, 0, 255), 2
                        )
                        continue

                    # Recognize
                    name, confidence = self.recognize_face(frame)

                    if name and confidence < 80:
                        # SUCCESS
                        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 3)
                        cv2.putText(
                            frame, f"Welcome {name}!",
                            (10, 30), cv2.FONT_HERSHEY_SIMPLEX,
                            0.8, (0, 255, 0), 2
                        )
                        cv2.imshow("RASHEED Face Lock", frame)
                        cv2.waitKey(1500)

                        cap.release()
                        cv2.destroyAllWindows()

                        self.authorized = True
                        self.locked = False
                        logger.info(f"Face verified: {name} (confidence: {confidence:.1f})")
                        print(f"✅ Face verified! Welcome {name}!")
                        return True
                    else:
                        cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 0, 255), 3)
                        cv2.putText(
                            frame, f"Unknown (attempt {attempts+1}/{max_attempts})",
                            (10, 30), cv2.FONT_HERSHEY_SIMPLEX,
                            0.7, (0, 0, 255), 2
                        )
                        attempts += 1
                        time.sleep(1)

                # Display
                cv2.putText(
                    frame,
                    f"Face Lock | Attempts: {attempts}/{max_attempts} | Press P for PIN",
                    (10, frame.shape[0] - 20),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1
                )
                cv2.imshow("RASHEED Face Lock", frame)
                key = cv2.waitKey(100) & 0xFF
                if key == ord('p'):
                    cap.release()
                    cv2.destroyAllWindows()
                    return self._pin_fallback()
                if key == ord('q'):
                    break

            cap.release()
            cv2.destroyAllWindows()

        except Exception as e:
            logger.error(f"Face verification error: {e}")

        # Face failed, try PIN
        print(f"⚠️ Face not recognized ({attempts} attempts). PIN fallback...")
        return self._pin_fallback()

    def _pin_fallback(self) -> bool:
        """PIN-based fallback authentication"""
        print(f"\n🔑 Enter PIN to unlock RASHEED:")
        for attempt in range(3):
            try:
                entered = input(f"   PIN (attempt {attempt+1}/3): ").strip()
                if entered == self.pin:
                    self.authorized = True
                    self.locked = False
                    print("✅ PIN correct! Unlocked!")
                    return True
                else:
                    print("   ❌ Wrong PIN!")
            except (EOFError, KeyboardInterrupt):
                print("\n   Cancelled.")
                return False

        print("🚫 Access denied! Too many wrong attempts.")
        return False

    def get_status(self) -> str:
        status = "🔒 LOCKED" if self.locked else "🔓 UNLOCKED"
        trained = "Yes" if self.is_trained else "No"
        users = list(self.labels.values()) if self.labels else ["None"]
        return (
            f"Face Lock: {status}\n"
            f"Enabled: {self.enabled}\n"
            f"Trained: {trained}\n"
            f"Authorized Users: {', '.join(users)}"
        )


# Global face lock instance
face_lock = FaceLockSystem()