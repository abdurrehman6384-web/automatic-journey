# browser_agent.py — Playwright Headless Browser Agent
import asyncio
from config import HEADLESS_BROWSER, logger
from error_handler import safe_execute


class BrowserAgent:
    def __init__(self):
        self.browser = None
        self.page = None
        self.playwright = None

    async def _start_browser(self):
        try:
            from playwright.async_api import async_playwright
            self.playwright = await async_playwright().start()
            self.browser = await self.playwright.chromium.launch(headless=HEADLESS_BROWSER)
            self.page = await self.browser.new_page()
            logger.info("Playwright browser started.")
            return True
        except ImportError:
            logger.error("Playwright not installed. Run: pip install playwright && playwright install")
            return False
        except Exception as e:
            logger.error(f"Browser start error: {e}")
            return False

    @safe_execute(max_retries=1)
    def scrape_website(self, url: str, selector: str = "body") -> str:
        """Scrape text from a website"""
        async def _scrape():
            if not self.page:
                if not await self._start_browser():
                    return "❌ Browser failed to start"
            await self.page.goto(url, timeout=15000)
            element = await self.page.query_selector(selector)
            if element:
                return await element.inner_text()
            return "❌ Selector not found"
        
        loop = asyncio.new_event_loop()
        result = loop.run_until_complete(_scrape())
        loop.close()
        return str(result)[:2000] if result else "❌ No content"

    @safe_execute(max_retries=1)
    def fill_form(self, url: str, fields: dict, submit_selector: str = "button[type='submit']") -> str:
        """Fill a web form automatically"""
        async def _fill():
            if not self.page:
                if not await self._start_browser():
                    return "❌ Browser failed"
            await self.page.goto(url, timeout=15000)
            for selector, value in fields.items():
                await self.page.fill(selector, str(value))
            await self.page.click(submit_selector)
            return "✅ Form filled and submitted!"
        
        loop = asyncio.new_event_loop()
        result = loop.run_until_complete(_fill())
        loop.close()
        return str(result)

    def track_price(self, url: str, selector: str, target_price: float) -> str:
        """Background price tracker (Checks once, use cron for periodic)"""
        text = self.scrape_website(url, selector)
        try:
            # Clean price string to float
            price_str = ''.join(c for c in text if c.isdigit() or c == '.')
            current_price = float(price_str)
            if current_price <= target_price:
                return f"🎉 Price dropped! Current: {current_price}, Target: {target_price}"
            return f"💰 Price: {current_price} (Target: {target_price})"
        except ValueError:
            return f"❌ Could not parse price from: {text}"

# Global instance
browser_agent = BrowserAgent()