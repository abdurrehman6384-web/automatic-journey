# ╔══════════════════════════════════════════════════════════╗
# ║     Agent Registry - Multi-Agent System Discovery        ║
# ║     Registers and manages all AI agents                  ║
# ╚══════════════════════════════════════════════════════════╝

import asyncio
from typing import Dict, List, Optional, Any, Callable
from enum import Enum
from dataclasses import dataclass, field
import logging

logger = logging.getLogger("RASHEED.AgentRegistry")

class AgentCapability(Enum):
    """Agent capabilities/roles"""
    CORE = "core"               # Main system
    PENTESTING = "pentesting"   # PentestGPT
    AUTOMATION = "automation"   # wormGPT, RPA
    BUSINESS = "business"       # Business skills
    ORCHESTRATION = "orchestration"  # Paperclip
    SECURITY = "security"       # Security ghost
    DEVELOPMENT = "development" # God coder
    DATA_ANALYSIS = "data_analysis"  # Analytics
    COMMUNICATION = "communication"  # Speech, text

@dataclass
class Agent:
    """Agent definition"""
    id: str
    name: str
    description: str
    capabilities: List[AgentCapability]
    instance: Optional[Any] = None
    status: str = "inactive"
    priority: int = 5  # 1=highest, 10=lowest
    max_concurrent_tasks: int = 3
    active_tasks: int = 0
    error_count: int = 0
    last_error: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

class AgentRegistry:
    """Central registry for all agents in the system"""
    
    def __init__(self):
        self.agents: Dict[str, Agent] = {}
        self.capability_index: Dict[AgentCapability, List[str]] = {}
        self.agent_callbacks: Dict[str, List[Callable]] = {}
        
    def register(self, agent: Agent) -> bool:
        """Register a new agent"""
        try:
            if agent.id in self.agents:
                logger.warning(f"Agent {agent.id} already registered, updating...")
            
            self.agents[agent.id] = agent
            
            # Index by capabilities
            for cap in agent.capabilities:
                if cap not in self.capability_index:
                    self.capability_index[cap] = []
                if agent.id not in self.capability_index[cap]:
                    self.capability_index[cap].append(agent.id)
            
            logger.info(f"✓ Agent registered: {agent.name} ({agent.id})")
            self._notify_callbacks(agent.id, "registered", agent)
            return True
        except Exception as e:
            logger.error(f"✗ Failed to register agent {agent.id}: {e}")
            return False
    
    def unregister(self, agent_id: str) -> bool:
        """Unregister an agent"""
        try:
            if agent_id not in self.agents:
                logger.warning(f"Agent {agent_id} not found")
                return False
            
            agent = self.agents[agent_id]
            
            # Remove from capability index
            for cap in agent.capabilities:
                if cap in self.capability_index:
                    self.capability_index[cap] = [
                        aid for aid in self.capability_index[cap] if aid != agent_id
                    ]
            
            del self.agents[agent_id]
            logger.info(f"✓ Agent unregistered: {agent.name}")
            self._notify_callbacks(agent_id, "unregistered", agent)
            return True
        except Exception as e:
            logger.error(f"✗ Failed to unregister agent {agent_id}: {e}")
            return False
    
    def get_agent(self, agent_id: str) -> Optional[Agent]:
        """Get agent by ID"""
        return self.agents.get(agent_id)
    
    def get_agents_by_capability(self, capability: AgentCapability) -> List[Agent]:
        """Get all agents with specific capability"""
        agent_ids = self.capability_index.get(capability, [])
        return [self.agents[aid] for aid in agent_ids if aid in self.agents]
    
    def get_available_agents(self, capability: Optional[AgentCapability] = None) -> List[Agent]:
        """Get available agents (sorted by priority)"""
        if capability:
            candidates = self.get_agents_by_capability(capability)
        else:
            candidates = list(self.agents.values())
        
        # Filter to available agents
        available = [
            a for a in candidates 
            if a.status == "active" and a.active_tasks < a.max_concurrent_tasks
        ]
        
        # Sort by priority (lower number = higher priority)
        available.sort(key=lambda a: a.priority)
        return available
    
    def update_agent_status(self, agent_id: str, status: str) -> bool:
        """Update agent status"""
        if agent_id not in self.agents:
            return False
        
        agent = self.agents[agent_id]
        agent.status = status
        self._notify_callbacks(agent_id, f"status_changed_{status}", agent)
        return True
    
    def record_task(self, agent_id: str, task_id: str, active: bool) -> bool:
        """Record task activity"""
        if agent_id not in self.agents:
            return False
        
        agent = self.agents[agent_id]
        if active:
            agent.active_tasks += 1
        else:
            agent.active_tasks = max(0, agent.active_tasks - 1)
        
        return True
    
    def record_error(self, agent_id: str, error: str) -> bool:
        """Record agent error"""
        if agent_id not in self.agents:
            return False
        
        agent = self.agents[agent_id]
        agent.error_count += 1
        agent.last_error = error
        logger.error(f"Agent {agent_id} error (#{agent.error_count}): {error}")
        self._notify_callbacks(agent_id, "error", {"error": error, "count": agent.error_count})
        return True
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get registry statistics"""
        total = len(self.agents)
        active = sum(1 for a in self.agents.values() if a.status == "active")
        total_tasks = sum(a.active_tasks for a in self.agents.values())
        total_errors = sum(a.error_count for a in self.agents.values())
        
        return {
            "total_agents": total,
            "active_agents": active,
            "inactive_agents": total - active,
            "active_tasks": total_tasks,
            "total_errors": total_errors,
            "agents": {
                aid: {
                    "name": a.name,
                    "status": a.status,
                    "capabilities": [c.value for c in a.capabilities],
                    "tasks": a.active_tasks,
                    "errors": a.error_count,
                    "priority": a.priority
                }
                for aid, a in self.agents.items()
            }
        }
    
    def subscribe(self, agent_id: str, callback: Callable):
        """Subscribe to agent events"""
        if agent_id not in self.agent_callbacks:
            self.agent_callbacks[agent_id] = []
        self.agent_callbacks[agent_id].append(callback)
    
    def _notify_callbacks(self, agent_id: str, event: str, data: Any):
        """Notify subscribed callbacks"""
        callbacks = self.agent_callbacks.get(agent_id, [])
        for callback in callbacks:
            try:
                callback(event, data)
            except Exception as e:
                logger.error(f"Callback error: {e}")


# Global registry instance
global_registry = AgentRegistry()

def get_registry() -> AgentRegistry:
    """Get the global agent registry"""
    return global_registry
