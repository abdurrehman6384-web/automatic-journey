# executor.py — RASHEED Tool Executor v10.0 FINAL
# ALL features preserved, ALL syntax errors fixed

from universe_mode import universe
from knowledge_graph import knowledge
from digital_twin import digital_twin
from rpa_engine import rpa_engine
from screen_translator import screen_translator
from ambient_listener import ambient
from proactive_engine import proactive
from window_manager import window_mgr
from clipboard_manager import clipboard_mgr
from plugin_engine import plugin_engine
from deep_search import deep_search
from offline_mode import offline_ai, offline_voice, wake_word
from pc_optimizer import pc_optimizer
from media_downloader import media_downloader
from pdf_assistant import pdf_assistant
from god_coder import god_coder

from app import (
    open_app, close_app, type_text, type_text_keyboard,
    press_key, hotkey, click_at, right_click_at,
    scroll_up, scroll_down, move_mouse, double_click,
    open_website, search_google, search_youtube,
    play_youtube, search_wikipedia, create_folder, delete_folder,
    create_file, delete_file, read_file, list_files, search_file,
    rename_file, open_file, shutdown_pc, restart_pc, sleep_pc,
    lock_pc, logoff_pc, cancel_shutdown, hibernate_pc,
    volume_up, volume_down, volume_mute, set_volume,
    get_battery, get_cpu, get_ram, get_disk, get_system_info,
    get_running_processes, kill_process, take_screenshot,
    get_screen_as_base64, get_active_window_title,
    copy_to_clipboard, get_clipboard, paste_clipboard,
    select_all_and_copy, get_time, get_date, get_datetime,
    run_cmd, run_powershell, show_notification, send_whatsapp,
    get_weather, calculate, extract_app_name,
)

from vision import vision
from game_mode import game_ai

from uploader import (
    upload_youtube_video, upload_instagram_photo,
    upload_instagram_video, save_instagram_creds,
    get_my_youtube_videos, get_instagram_profile,
)

from typing_engine import typer
from memory import memory
from face_lock import face_lock
from self_upgrader import upgrader
from error_handler import error_reporter, logger

# ── v7.0 Imports ────────────────────────────────────
from ai_brain import (
    llm_router, rag_system, voice_cloner, emotion_detector
)
from dev_mode import dev_mode
from iot_automation import (
    smart_home, email_manager, form_filler
)
from security_ghost import (
    intrusion_detector, vpn_controller,
    memory_encryptor, anti_spyware
)
from lifestyle import (
    prayer_times, crypto_tracker,
    spotify, pomodoro, party_mode
)

# ── v8.0 Imports ────────────────────────────────────
from agent import agent
from browser_agent import browser_agent
from os_control import os_control
from security_pro import security_pro

# ── v10.0 Imports ───────────────────────────────────
from self_coding import self_coder
from quant_finance_pro import quant_pro
from cyber_shield import cyber_shield
from password_vault import vault as password_vault

# ── New Features Import ─────────────────────────────
from new_features import (
    internet_speed_test, get_my_location,
    get_system_temperature, capture_photo,
    capture_burst_photos, block_websites,
    unblock_websites, focus_mode_pro,
    set_alarm, stop_all_alarms, list_alarms,
    start_screen_recording, stop_screen_recording,
    set_brightness, get_brightness,
    download_youtube_video, get_prayer_times,
    copy_to_clipboard_new, paste_from_clipboard,
    show_clipboard_history,
    shutdown_system, restart_system,
    sleep_system, lock_screen,
    mouse_click, read_pdf, pdf_to_audio,
    get_active_windows, minimize_window,
    maximize_window, close_window,
    generate_qr_code, detailed_system_info,
)


def execute_tool(name: str, args: dict) -> str:
    logger.info(f"Tool called: {name} | args={args}")

    try:
        # ══════════════════════════════════════════════
        # ── App Control ──────────────────────────────
        # ══════════════════════════════════════════════
        if name == "open_app":
            return open_app(args.get("app_name", ""))

        elif name == "close_app":
            return close_app(args.get("app_name", ""))

        # ── Typing ───────────────────────────────────
        elif name == "type_text":
            text = args.get("text", "")
            use_cb = args.get("use_clipboard", False)
            if use_cb:
                return typer.type_unicode(text)
            return typer.type_smart(text)

        elif name == "press_key":
            return press_key(args.get("key", "enter"))

        elif name == "hotkey":
            keys = [k.strip() for k in args.get("keys", "").split(",")]
            return hotkey(*keys)

        # ── Mouse ────────────────────────────────────
        elif name == "click_at":
            return click_at(args.get("x", 0), args.get("y", 0))

        elif name == "right_click":
            return right_click_at(args.get("x", 0), args.get("y", 0))

        elif name == "double_click":
            return double_click(args.get("x"), args.get("y"))

        elif name == "move_mouse":
            return move_mouse(args.get("x", 0), args.get("y", 0))

        elif name == "scroll":
            d = args.get("direction", "down")
            a = args.get("amount", 3)
            return scroll_up(a) if d == "up" else scroll_down(a)

        # ── Browser ──────────────────────────────────
        elif name == "open_website":
            return open_website(args.get("url", ""))

        elif name == "search_google":
            return search_google(args.get("query", ""))

        elif name == "search_youtube":
            return search_youtube(args.get("query", ""))

        elif name == "play_youtube":
            return play_youtube(args.get("query", ""))

        elif name == "search_wikipedia":
            return search_wikipedia(args.get("query", ""))

        # ── YouTube Upload ───────────────────────────
        elif name == "upload_youtube":
            return upload_youtube_video(
                video_path=args.get("video_path", ""),
                title=args.get("title", "My Video"),
                description=args.get("description", "Uploaded by RASHEED AI"),
                privacy=args.get("privacy", "private")
            )

        elif name == "get_youtube_videos":
            return get_my_youtube_videos()

        # ── Instagram ────────────────────────────────
        elif name == "upload_instagram_photo":
            return upload_instagram_photo(
                image_path=args.get("image_path", ""),
                caption=args.get("caption", "Posted by RASHEED AI 🤖")
            )

        elif name == "upload_instagram_video":
            return upload_instagram_video(
                video_path=args.get("video_path", ""),
                caption=args.get("caption", "Posted by RASHEED AI 🤖")
            )

        elif name == "instagram_login":
            return save_instagram_creds(
                args.get("username", ""),
                args.get("password", "")
            )

        elif name == "instagram_profile":
            return get_instagram_profile(args.get("username"))

        # ── File Management ──────────────────────────
        elif name == "create_folder":
            return create_folder(args.get("name", ""), args.get("path"))

        elif name == "create_file":
            return create_file(
                args.get("name", ""),
                args.get("content", ""),
                args.get("path")
            )

        elif name == "delete_file":
            return delete_file(args.get("name", ""), args.get("path"))

        elif name == "read_file":
            return read_file(args.get("name", ""), args.get("path"))

        elif name == "list_files":
            return list_files(args.get("path"))

        elif name == "search_file":
            return search_file(args.get("name", ""))

        elif name == "take_screenshot":
            return take_screenshot(args.get("filename"))

        elif name == "read_screen_text":
            return vision.read_screen_text()

        # ── System Info ──────────────────────────────
        elif name == "get_system_info":
            return get_system_info()

        elif name == "get_weather":
            return get_weather(args.get("city"))

        elif name == "calculate":
            return calculate(args.get("expression", "0"))

        # ── System Control ───────────────────────────
        elif name == "shutdown_pc":
            return shutdown_pc(args.get("timer", 10))

        elif name == "restart_pc":
            return restart_pc()

        elif name == "sleep_pc":
            return sleep_pc()

        elif name == "lock_pc":
            return lock_pc()

        elif name == "cancel_shutdown":
            return cancel_shutdown()

        # ── Volume ───────────────────────────────────
        elif name == "volume_up":
            return volume_up(args.get("steps", 5))

        elif name == "volume_down":
            return volume_down(args.get("steps", 5))

        elif name == "volume_mute":
            return volume_mute()

        # ── Clipboard ────────────────────────────────
        elif name == "get_clipboard":
            return get_clipboard()

        elif name == "copy_to_clipboard":
            return copy_to_clipboard(args.get("text", ""))

        # ── Time & Date ──────────────────────────────
        elif name == "get_time":
            return get_time()

        elif name == "get_date":
            return get_date()

        # ── CMD ──────────────────────────────────────
        elif name == "run_cmd":
            return run_cmd(args.get("command", ""))

        # ── Communication ────────────────────────────
        elif name == "send_whatsapp":
            return send_whatsapp(
                args.get("number", ""),
                args.get("message", "")
            )

        elif name == "show_notification":
            return show_notification(
                args.get("title", "RASHEED"),
                args.get("message", "")
            )

        # ── Process ──────────────────────────────────
        elif name == "kill_process":
            return kill_process(args.get("name", ""))

        elif name == "get_active_window":
            return get_active_window_title()

        # ── Game Mode ────────────────────────────────
        elif name == "start_game_mode":
            mode = args.get("mode", "dino").lower()
            return game_ai.start_game_mode(mode)

        elif name == "stop_game_mode":
            return game_ai.stop_game()

        # ── Face Lock ────────────────────────────────
        elif name == "face_enroll":
            return face_lock.enroll_face(args.get("name", "Boss"))

        elif name == "face_lock_status":
            return face_lock.get_status()

        # ── Self Upgrade ─────────────────────────────
        elif name == "check_updates":
            result = upgrader.check_for_updates()
            if result.get("available"):
                return (
                    f"⬆️ Update available! "
                    f"{result.get('commits', 0)} new commits.\n"
                    f"{result.get('details', '')[:200]}"
                )
            return f"✅ {result.get('message', 'Already up to date!')}"

        elif name == "perform_update":
            return upgrader.perform_update()

        elif name == "update_packages":
            return upgrader.update_pip_packages()

        elif name == "get_version":
            return f"🤖 RASHEED {upgrader.get_version()}"

        # ── Memory ───────────────────────────────────
        elif name == "save_memory":
            cat = args.get("category", "notes")
            key = args.get("key", "")
            val = args.get("value", "")
            if cat == "identity":
                memory.save_identity(key, val)
            elif cat == "preferences":
                memory.save_preference(key, val)
            elif cat == "projects":
                memory.save_project(key, val)
            elif cat == "relationships":
                memory.save_relationship(key, val)
            elif cat == "wishes":
                memory.save_wish(key, val)
            elif cat == "notes":
                memory.save_note(key, val)
            else:
                memory.set_pref(key, val)
            return f"✅ Memory saved: [{cat}] {key}={val}"

        elif name == "search_memory":
            return memory.search_memory(args.get("query", ""))

        elif name == "memory_stats":
            return memory.get_stats()

        # ── Error Report ─────────────────────────────
        elif name == "error_summary":
            return error_reporter.get_summary()

        # ══════════════════════════════════════════════
        # ── AI Brain ─────────────────────────────────
        # ══════════════════════════════════════════════
        elif name == "ask_ai":
            return llm_router.smart_ask(args.get("prompt", ""))

        elif name == "rag_add_document":
            return rag_system.add_document(
                args.get("text", ""),
                args.get("doc_id", "doc_1")
            )

        elif name == "rag_add_pdf":
            return rag_system.add_pdf(args.get("pdf_path", ""))

        elif name == "rag_query":
            return rag_system.query(args.get("question", ""))

        elif name == "clone_voice":
            return voice_cloner.clone_and_speak(
                args.get("text", ""),
                args.get("voice_id")
            )

        # ── Developer Mode ───────────────────────────
        elif name == "git_commit_push":
            return dev_mode.git_commit_push(
                args.get("message", "Update by RASHEED")
            )

        elif name == "generate_code":
            return dev_mode.generate_code(
                args.get("description", ""),
                args.get("filename")
            )

        elif name == "auto_debug":
            return dev_mode.auto_debug()

        elif name == "explain_code":
            return dev_mode.explain_code()

        # ── IoT & Automation ─────────────────────────
        elif name == "lights_on":
            return smart_home.lights_on(args.get("room", "1"))

        elif name == "lights_off":
            return smart_home.lights_off(args.get("room", "1"))

        elif name == "check_emails":
            return email_manager.check_unread()

        elif name == "fill_form":
            return form_filler.fill_current_form(args.get("data", {}))

        # ── Security & Ghost ─────────────────────────
        elif name == "scan_network":
            return intrusion_detector.scan_network()

        elif name == "vpn_connect":
            return vpn_controller.connect()

        elif name == "vpn_disconnect":
            return vpn_controller.disconnect()

        elif name == "encrypt_memory":
            return memory_encryptor.encrypt_memory()

        elif name == "decrypt_memory":
            return memory_encryptor.decrypt_memory()

        elif name == "anti_spyware_scan":
            return anti_spyware.scan_and_kill()

        # ── Lifestyle ────────────────────────────────
        elif name == "spotify_next":
            return spotify.next_track()

        elif name == "spotify_previous":
            return spotify.previous_track()

        elif name == "spotify_play_pause":
            return spotify.play_pause()

        elif name == "prayer_times":
            return prayer_times.get_times(args.get("city"))

        elif name == "crypto_price":
            return crypto_tracker.get_price(
                args.get("symbol", "BTCUSDT")
            )

        elif name == "start_focus_mode":
            return pomodoro.start_focus(args.get("minutes", 25))

        elif name == "stop_focus_mode":
            return pomodoro.stop_focus()

        elif name == "party_mode":
            if args.get("action", "start") == "start":
                return party_mode.start_party()
            return party_mode.stop_party()

        # ══════════════════════════════════════════════
        # ── Autonomous Agent ─────────────────────────
        # ══════════════════════════════════════════════
        elif name == "agent_execute":
            return agent.execute_chain(args.get("goal", ""))

        elif name == "add_task_to_queue":
            return agent.add_task(
                args.get("task", ""),
                args.get("priority", 1)
            )

        elif name == "process_task_queue":
            return agent.process_queue()

        # ── Browser Automation ───────────────────────
        elif name == "web_scrape":
            return browser_agent.scrape_website(
                args.get("url", ""),
                args.get("selector", "body")
            )

        elif name == "web_fill_form":
            return browser_agent.fill_form(
                args.get("url", ""),
                args.get("fields", {}),
                args.get("submit_selector")
            )

        elif name == "track_price":
            return browser_agent.track_price(
                args.get("url", ""),
                args.get("selector", ".price"),
                args.get("target_price", 0.0)
            )

        # ── Deep OS Control ──────────────────────────
        elif name == "disable_telemetry":
            return os_control.disable_telemetry()

        elif name == "manage_startup":
            return os_control.manage_startup(
                args.get("action", "list"),
                args.get("app_name")
            )

        elif name == "create_cron":
            return os_control.create_cron_task(
                args.get("task_name", ""),
                args.get("command", ""),
                args.get("time", "08:00")
            )

        # ── Advanced Memory ──────────────────────────
        elif name == "vector_memory_search":
            return memory.search_vector_memory(
                args.get("query", "")
            )

        # ── Security Pro ─────────────────────────────
        elif name == "start_usb_monitor":
            return security_pro.start_usb_monitor()

        elif name == "patch_system":
            return security_pro.patch_system()

        # ══════════════════════════════════════════════
        # ── Self-Coding Engine ───────────────────────
        # ══════════════════════════════════════════════
        elif name == "auto_refactor":
            return self_coder.auto_refactor(
                args.get("file_path", "")
            )

        elif name == "start_self_healer":
            return self_coder.start_self_healer()

        elif name == "generate_plugin":
            return self_coder.generate_plugin(
                args.get("description", ""),
                args.get("plugin_name", "custom_plugin")
            )

        # ══════════════════════════════════════════════
        # ── Quant Finance Pro ────────────────────────
        # ══════════════════════════════════════════════
        elif name == "find_arbitrage":
            return quant_pro.find_arbitrage(
                args.get("symbol", "BTC")
            )

        elif name == "market_sentiment":
            return quant_pro.get_sentiment()

        elif name == "monitor_whales":
            return quant_pro.monitor_whales()

        elif name == "calculate_grid":
            return quant_pro.calculate_grid(
                args.get("symbol", "BTC"),
                args.get("lower", 60000),
                args.get("upper", 70000),
                args.get("grids", 5)
            )

        elif name == "find_best_yield":
            return quant_pro.find_best_yield()

        elif name == "options_screener":
            return quant_pro.options_screener()

        elif name == "forex_arb_simulator":
            return quant_pro.forex_arb_simulator()

        elif name == "nft_sniper":
            return quant_pro.nft_sniper(
                args.get("collection", "boredapeyachtclub")
            )

        elif name == "scan_micro_caps":
            return quant_pro.scan_micro_caps()

        # ══════════════════════════════════════════════
        # ── Cyber Shield ─────────────────────────────
        # ══════════════════════════════════════════════
        elif name == "deploy_honeypot":
            return cyber_shield.deploy_honeypot()

        elif name == "monitor_ddos":
            return cyber_shield.monitor_ddos()

        elif name == "check_dark_web":
            return cyber_shield.check_dark_web(
                args.get("email", "")
            )

        elif name == "harden_firewall":
            return cyber_shield.harden_firewall()

        # ── Password Vault ───────────────────────────
        elif name == "get_password":
            return password_vault.get_password(args.get("site", ""))

        elif name == "list_passwords":
            return password_vault.list_passwords(args.get("site"))

        elif name == "delete_password":
            return password_vault.delete_password(
                args.get("site", ""),
                args.get("username", "")
            )

        # ══════════════════════════════════════════════
        # ── Universe Mode ────────────────────────────
        # ══════════════════════════════════════════════
        elif name == "satellite_view":
            return universe.get_city_satellite(
                args.get("city", "karachi")
            )

        elif name == "satellite_coords":
            return universe.get_satellite_image(
                args.get("lat", 24.86),
                args.get("lon", 67.01)
            )

        elif name == "track_iss":
            return universe.track_iss()

        elif name == "people_in_space":
            return universe.people_in_space()

        elif name == "nasa_apod":
            return universe.get_apod(args.get("set_wallpaper", False))

        elif name == "check_asteroids":
            return universe.check_asteroids()

        elif name == "mars_weather":
            return universe.mars_weather()

        elif name == "mars_rover_photo":
            return universe.mars_rover_photo(
                args.get("rover", "curiosity")
            )

        elif name == "meteor_showers":
            return universe.check_meteor_showers()

        elif name == "spacex_launches":
            return universe.spacex_launches()

        elif name == "epic_earth":
            return universe.epic_earth_image()

        # ══════════════════════════════════════════════
        # ── PC Optimizer ─────────────────────────────
        # ══════════════════════════════════════════════
        elif name == "clean_pc":
            return pc_optimizer.clean_junk()

        elif name == "boost_ram":
            return pc_optimizer.boost_ram()

        elif name == "analyze_disk":
            return pc_optimizer.analyze_disk(
                args.get("min_size_mb", 100)
            )

        elif name == "schedule_shutdown":
            return pc_optimizer.schedule_shutdown(
                args.get("minutes", 60)
            )

        # ── Media Downloader ─────────────────────────
        elif name == "download_youtube":
            return media_downloader.download_youtube(
                args.get("url", ""),
                args.get("quality", "best")
            )

        elif name == "download_mp3":
            return media_downloader.download_mp3(
                args.get("url", "")
            )

        elif name == "download_instagram":
            return media_downloader.download_instagram(
                args.get("url", "")
            )

        # ── PDF Assistant ────────────────────────────
        elif name == "summarize_pdf":
            return pdf_assistant.summarize_pdf(
                args.get("pdf_path", "")
            )

        elif name == "pdf_to_word":
            return pdf_assistant.pdf_to_word(
                args.get("pdf_path", "")
            )

        elif name == "read_document_aloud":
            return pdf_assistant.read_document_aloud(
                args.get("file_path", "")
            )

        elif name == "images_to_pdf":
            return pdf_assistant.images_to_pdf(
                args.get("image_paths", []),
                args.get("output_name", "output.pdf")
            )

        # ── God Coder ────────────────────────────────
        elif name == "build_project":
            return god_coder.build_from_prompt(
                args.get("prompt", ""),
                args.get("project_name", "ai_project")
            )

        elif name == "build_from_file":
            return god_coder.read_prompt_and_build(
                args.get("prompt_file", "")
            )

        elif name == "fix_code_file":
            return god_coder.fix_file(
                args.get("file_path", "")
            )

        # ── Deep Search Engine ───────────────────────
        elif name == "deep_search":
            return deep_search.search(args.get("query", ""))

        elif name == "index_directory":
            return deep_search.index_directory(
                args.get("directory"),
                args.get("max_files", 500)
            )

        elif name == "index_file":
            return deep_search.index_file(args.get("file_path", ""))

        elif name == "search_stats":
            return deep_search.get_index_stats()

        elif name == "clear_search_index":
            return deep_search.clear_index()

        # ── Offline AI ───────────────────────────────
        elif name == "offline_chat":
            return offline_ai.chat(args.get("message", ""))

        elif name == "download_vosk":
            return offline_voice.download_vosk_model()

        elif name == "start_wake_word":
            return wake_word.start()

        elif name == "stop_wake_word":
            return wake_word.stop()

        # ══════════════════════════════════════════════
        # ── NEW FEATURES (v10.0+) ────────────────────
        # ══════════════════════════════════════════════
        elif name == "internet_speed_test":
            return internet_speed_test()

        elif name == "get_my_location":
            return get_my_location()

        elif name == "get_system_temperature":
            return get_system_temperature()

        elif name == "capture_photo":
            return capture_photo()

        elif name == "capture_burst_photos":
            return capture_burst_photos(args.get("count", 5))

        elif name == "block_websites":
            return block_websites(args.get("sites"))

        elif name == "unblock_websites":
            return unblock_websites()

        elif name == "focus_mode_pro":
            return focus_mode_pro()

        elif name == "set_alarm":
            return set_alarm(
                args.get("time", ""),
                args.get("label", "RASHEED Alarm")
            )

        elif name == "stop_all_alarms":
            return stop_all_alarms()

        elif name == "list_alarms":
            return list_alarms()

        elif name == "start_screen_recording":
            return start_screen_recording()

        elif name == "stop_screen_recording":
            return stop_screen_recording()

        elif name == "set_brightness":
            return set_brightness(args.get("level", 50))

        elif name == "get_brightness":
            return get_brightness()

        elif name == "download_youtube_video":
            return download_youtube_video(
                args.get("url", ""),
                args.get("audio_only", False)
            )

        elif name == "get_prayer_times":
            return get_prayer_times(args.get("city", "Karachi"))

        elif name == "copy_to_clipboard_new":
            return copy_to_clipboard_new(args.get("text", ""))

        elif name == "paste_from_clipboard":
            return paste_from_clipboard()

        elif name == "show_clipboard_history":
            return show_clipboard_history()

        elif name == "shutdown_system":
            return shutdown_system()

        elif name == "restart_system":
            return restart_system()

        elif name == "sleep_system":
            return sleep_system()

        elif name == "lock_screen":
            return lock_screen()

        elif name == "mouse_click":
            return mouse_click()

        elif name == "read_pdf":
            return read_pdf(args.get("pdf_path", ""))

        elif name == "pdf_to_audio":
            return pdf_to_audio(args.get("pdf_path", ""))

        elif name == "get_active_windows":
            return get_active_windows()

        elif name == "minimize_window":
            return minimize_window(args.get("title"))

        elif name == "maximize_window":
            return maximize_window(args.get("title"))

        elif name == "close_window":
            return close_window(args.get("title"))

        elif name == "generate_qr_code":
            return generate_qr_code(args.get("data", ""))

        elif name == "detailed_system_info":
            return detailed_system_info()

        # ══════════════════════════════════════════════
        # ── Unknown Tool (MUST BE LAST) ──────────────
        # ══════════════════════════════════════════════
        else:
            return f"❓ Unknown tool: {name}"

    except Exception as e:
        error_reporter.report(name, e)
        return f"❌ Tool error [{name}]: {e}"


# ════════════════════════════════════════════════════════
# ── Voice Command Handler (Natural Language) ───────────
# ════════════════════════════════════════════════════════
def handle_voice_command(command: str) -> bool:
    """
    Handle natural language voice commands.
    Returns True if command was handled, False otherwise.
    """
    cmd = command.lower().strip()

    # ── Internet Speed Test ──
    if any(x in cmd for x in [
        "speed test", "internet speed", "net speed",
        "download speed", "upload speed", "speed check"
    ]):
        print(internet_speed_test())
        return True

    # ── Location ──
    if any(x in cmd for x in [
        "where am i", "my location", "current location",
        "meri location", "kahan hu", "where i am",
        "ip location", "mera ip"
    ]):
        print(get_my_location())
        return True

    # ── Temperature ──
    if any(x in cmd for x in [
        "temperature", "cpu temp", "gpu temp",
        "system temp", "heating", "overheating",
        "garmi", "temperature check"
    ]):
        print(get_system_temperature())
        return True

    # ── Photo Capture ──
    if any(x in cmd for x in [
        "take photo", "capture photo", "take picture",
        "photo lo", "meri photo", "selfie",
        "webcam photo", "camera photo"
    ]):
        if "burst" in cmd or "multiple" in cmd:
            print(capture_burst_photos())
        else:
            print(capture_photo())
        return True

    # ── Focus Mode / Website Blocking ──
    if any(x in cmd for x in [
        "focus mode", "study mode", "block website",
        "block social media", "concentrate",
        "distraction", "padhai mode"
    ]):
        if "unblock" in cmd or "stop focus" in cmd:
            print(unblock_websites())
        elif "pro" in cmd:
            print(focus_mode_pro())
        else:
            print(block_websites())
        return True

    # ── Alarm ──
    if "alarm" in cmd:
        if "stop" in cmd or "cancel" in cmd:
            print(stop_all_alarms())
        elif "list" in cmd or "show" in cmd:
            print(list_alarms())
        else:
            import re
            time_match = re.search(
                r'(\d{1,2}:\d{2}\s*(?:am|pm)?)', cmd
            )
            if time_match:
                print(set_alarm(time_match.group(1), "RASHEED Alarm"))
            else:
                print("⏰ Alarm ke liye time batao! Format: HH:MM AM/PM")
        return True

    # ── Screen Recording ──
    if any(x in cmd for x in [
        "screen record", "record screen", "recording start",
        "record karo", "screen capture video"
    ]):
        if "stop" in cmd or "end" in cmd:
            print(stop_screen_recording())
        else:
            print(start_screen_recording())
        return True

    # ── Volume Control ──
    if any(x in cmd for x in [
        "volume up", "awaz badhao", "sound badhao"
    ]):
        volume_up()
        return True

    if any(x in cmd for x in [
        "volume down", "awaz kam", "sound kam"
    ]):
        volume_down()
        return True

    if any(x in cmd for x in [
        "mute", "khamosh", "silent"
    ]):
        volume_mute()
        return True

    if "volume set" in cmd or "set volume" in cmd:
        import re
        num = re.search(r'(\d+)', cmd)
        if num:
            set_volume(int(num.group(1)))
        return True

    # ── Brightness ──
    if any(x in cmd for x in [
        "brightness", "roshni", "screen bright"
    ]):
        import re
        num = re.search(r'(\d+)', cmd)
        if num:
            print(set_brightness(int(num.group(1))))
        elif "up" in cmd or "badhao" in cmd:
            print(set_brightness(100))
        elif "down" in cmd or "kam" in cmd:
            print(set_brightness(30))
        else:
            print(get_brightness())
        return True

    # ── YouTube Download ──
    if any(x in cmd for x in [
        "youtube download", "video download",
        "download video", "yt download"
    ]):
        import re
        url_match = re.search(r'(https?://[^\s]+)', cmd)
        if url_match:
            audio_only = (
                "audio" in cmd or "mp3" in cmd or "music" in cmd
            )
            print(download_youtube_video(
                url_match.group(1), audio_only=audio_only
            ))
        else:
            print("❌ YouTube URL dalo! Example: download youtube https://youtube.com/...")
        return True

    # ── Prayer Times ──
    if any(x in cmd for x in [
        "prayer time", "namaz time", "namaz ka waqt",
        "salah time", "azan time", "namaz"
    ]):
        print(get_prayer_times())
        return True

    # ── Clipboard ──
    if any(x in cmd for x in ["clipboard", "copy text", "paste"]):
        if "copy" in cmd:
            text = cmd.replace("copy", "").replace("clipboard", "").strip()
            print(copy_to_clipboard_new(text))
        elif "paste" in cmd or "read" in cmd:
            print(paste_from_clipboard())
        elif "history" in cmd:
            print(show_clipboard_history())
        return True

    # ── System Power ──
    if any(x in cmd for x in [
        "shutdown", "band karo", "pc band"
    ]):
        print(shutdown_system())
        return True

    if any(x in cmd for x in [
        "restart", "reboot", "pc restart"
    ]):
        print(restart_system())
        return True

    if any(x in cmd for x in [
        "sleep", "pc sleep", "hibernate"
    ]):
        print(sleep_system())
        return True

    if any(x in cmd for x in [
        "lock screen", "pc lock", "lock karo"
    ]):
        print(lock_screen())
        return True

    # ── Mouse/Keyboard ──
    if any(x in cmd for x in ["click here", "mouse click"]):
        mouse_click()
        return True

    if "type" in cmd and ("text" in cmd or "likho" in cmd):
        text = cmd.replace("type", "").replace("text", "").replace("likho", "").strip()
        typer.type_smart(text)
        return True

    # ── PDF ──
    if any(x in cmd for x in [
        "read pdf", "pdf padho", "pdf read"
    ]):
        import re
        path_match = re.search(r'[\w:\\/.]+\.pdf', cmd)
        if path_match:
            if "audio" in cmd or "suno" in cmd:
                print(pdf_to_audio(path_match.group(0)))
            else:
                print(read_pdf(path_match.group(0)))
        else:
            print("❌ PDF file ka path batao!")
        return True

    # ── Windows ──
    if any(x in cmd for x in [
        "show windows", "active windows", "window list"
    ]):
        print(get_active_windows())
        return True

    if "minimize" in cmd:
        title = cmd.replace("minimize", "").strip() or None
        print(minimize_window(title))
        return True

    if "maximize" in cmd:
        title = cmd.replace("maximize", "").strip() or None
        print(maximize_window(title))
        return True

    if "close window" in cmd:
        title = cmd.replace("close window", "").strip() or None
        print(close_window(title))
        return True

    # ── QR Code ──
    if any(x in cmd for x in [
        "qr code", "generate qr", "qr banao"
    ]):
        data = (
            cmd.replace("qr code", "")
            .replace("generate", "")
            .replace("banao", "")
            .strip()
        )
        if data:
            print(generate_qr_code(data))
        else:
            print("❌ QR Code ke liye text ya URL dalo!")
        return True

    # ── System Info ──
    if any(x in cmd for x in [
        "system info", "pc info", "computer info",
        "system details", "pc details"
    ]):
        print(detailed_system_info())
        return True

    return False