# pdf_assistant.py — PDF Summarizer, PDF2Word, TTS Reader, Image2PDF
import os
from pathlib import Path
from config import DATA_DIR, logger
from error_handler import safe_execute


class PDFAssistant:

    # ── 1. PDF Summarizer ────────────────────────────
    @safe_execute(max_retries=1)
    def summarize_pdf(self, pdf_path: str) -> str:
        """Read PDF and summarize it using AI"""
        if not os.path.exists(pdf_path):
            return f"❌ File not found: {pdf_path}"

        try:
            import PyPDF2
        except ImportError:
            return "❌ pip install PyPDF2"

        text = ""
        try:
            with open(pdf_path, 'rb') as f:
                reader = PyPDF2.PdfReader(f)
                # Read first 30 pages max
                for i, page in enumerate(reader.pages[:30]):
                    page_text = page.extract_text()
                    if page_text:
                        text += page_text + "\n"
        except Exception as e:
            return f"❌ PDF read error: {e}"

        if not text.strip():
            return "❌ PDF mein koi text nahi mila (scanned image ho sakti hai)"

        # AI Summary
        from ai_brain import llm_router
        prompt = (
            f"Summarize this document in concise bullet points (Roman Urdu/English mix):\n\n"
            f"{text[:8000]}"
        )
        summary = llm_router.smart_ask(prompt)
        return f"📄 PDF Summary:\n{summary}"

    # ── 2. PDF to Word Converter ─────────────────────
    @safe_execute(max_retries=1)
    def pdf_to_word(self, pdf_path: str) -> str:
        """Convert PDF to Word document"""
        if not os.path.exists(pdf_path):
            return f"❌ File not found: {pdf_path}"

        try:
            import PyPDF2
            from docx import Document
        except ImportError:
            return "❌ pip install PyPDF2 python-docx"

        try:
            with open(pdf_path, 'rb') as f:
                reader = PyPDF2.PdfReader(f)
                doc = Document()

                for i, page in enumerate(reader.pages):
                    text = page.extract_text()
                    if text:
                        doc.add_heading(f"Page {i+1}", level=2)
                        doc.add_paragraph(text)

                output_path = pdf_path.replace(".pdf", "_converted.docx")
                if not output_path.endswith(".docx"):
                    output_path = os.path.join(str(DATA_DIR), "converted.docx")

                doc.save(output_path)
                return f"✅ PDF converted to Word!\n💾 Saved: {output_path}"
        except Exception as e:
            return f"❌ Conversion error: {e}"

    # ── 3. Text to Speech (File Reader) ──────────────
    @safe_execute(max_retries=1)
    def read_document_aloud(self, file_path: str) -> str:
        """Read a text/PDF file aloud"""
        if not os.path.exists(file_path):
            return f"❌ File not found: {file_path}"

        text = ""
        if file_path.endswith(".pdf"):
            try:
                import PyPDF2
                with open(file_path, 'rb') as f:
                    reader = PyPDF2.PdfReader(f)
                    for page in reader.pages[:20]:
                        page_text = page.extract_text()
                        if page_text:
                            text += page_text
            except Exception as e:
                return f"❌ PDF read error: {e}"
        else:
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    text = f.read()
            except Exception as e:
                return f"❌ File read error: {e}"

        if not text.strip():
            return "❌ File mein koi text nahi hai"

        # TTS in separate thread
        def _speak():
            try:
                import pyttsx3
                engine = pyttsx3.init()
                engine.setProperty('rate', 170)
                engine.say(text[:5000])  # First 5000 chars
                engine.runAndWait()
            except Exception as e:
                logger.error(f"TTS error: {e}")

        import threading
        t = threading.Thread(target=_speak, daemon=True)
        t.start()

        return f"🔊 Reading document aloud... (First 5000 chars)"

    # ── 4. Image to PDF ──────────────────────────────
    @safe_execute(max_retries=1)
    def images_to_pdf(self, image_paths: list, output_name: str = "output.pdf") -> str:
        """Convert images to a single PDF"""
        try:
            from PIL import Image
        except ImportError:
            return "❌ pip install Pillow"

        if not image_paths:
            return "❌ No images provided"

        try:
            images = []
            for path in image_paths:
                if os.path.exists(path):
                    img = Image.open(path)
                    if img.mode != "RGB":
                        img = img.convert("RGB")
                    images.append(img)

            if not images:
                return "❌ No valid images found"

            output_path = os.path.join(str(DATA_DIR), output_name)
            first = images[0]
            first.save(output_path, save_all=True, append_images=images[1:])

            return f"✅ PDF created with {len(images)} images!\n💾 Saved: {output_path}"
        except Exception as e:
            return f"❌ Image2PDF error: {e}"


# Global instance
pdf_assistant = PDFAssistant()