# password_vault.py — Secure Password Vault
import json
import os
import pyperclip
import base64
from cryptography.fernet import Fernet
from config import ENCRYPTION_KEY, DATA_DIR, logger
from error_handler import safe_execute

VAULT_FILE = str(DATA_DIR / "password_vault.enc")


class PasswordVault:
    def __init__(self):
        # Generate consistent key from ENCRYPTION_KEY
        key = base64.urlsafe_b64encode(ENCRYPTION_KEY.encode()[:32].ljust(32, b"0"))
        self.fernet = Fernet(key)
        self.vault: dict[str, list[dict[str, str]]] = {}
        self._load()

    def _load(self):
        if os.path.exists(VAULT_FILE):
            try:
                with open(VAULT_FILE, "rb") as f:
                    decrypted = self.fernet.decrypt(f.read())
                    self.vault = json.loads(decrypted)
            except Exception:
                self.vault = {}

    def _save(self):
        try:
            encrypted = self.fernet.encrypt(json.dumps(self.vault).encode())
            with open(VAULT_FILE, "wb") as f:
                f.write(encrypted)
        except Exception as e:
            logger.error(f"Vault save error: {e}")

    @safe_execute(max_retries=1)
    def save_password(self, site: str, username: str, password: str) -> str:
        if site not in self.vault:
            self.vault[site] = []
        self.vault[site].append({"username": username, "password": password})
        self._save()
        return f"🔐 Password saved for {site}!"

    @safe_execute(max_retries=1)
    def get_password(self, site: str) -> str:
        if site not in self.vault:
            return f"❌ No password found for {site}"

        entries = self.vault[site]
        result = f"🔐 {site}:\n"
        for e in entries:
            result += f"  User: {e['username']}\n  Pass: {'*' * len(e['password'])}\n"

        # Auto-copy first password
        if entries:
            pyperclip.copy(entries[0]["password"])
            result += "📋 Password copied to clipboard!"
        return result

    @safe_execute(max_retries=1)
    def list_passwords(self, site: str | None = None) -> str:
        if site:
            if site not in self.vault:
                return f"❌ No password entries found for {site}"
            entries = self.vault[site]
            if not entries:
                return f"❌ No password entries found for {site}"
            lines = [f"🔐 {site}:"]
            for e in entries:
                lines.append(f"  - User: {e['username']}")
            return "\n".join(lines)

        # List all sites
        if not self.vault:
            return "❌ Vault is empty."
        lines: list[str] = ["🔐 All saved password entries:"]
        for s, entries in self.vault.items():
            lines.append(f"- {s} ({len(entries)} entr{'y' if len(entries) == 1 else 'ies'})")
        return "\n".join(lines)

    @safe_execute(max_retries=1)
    def delete_password(self, site: str, username: str) -> str:
        if site not in self.vault:
            return f"❌ No entries exist for {site}"

        entries = self.vault[site]
        before = len(entries)
        entries = [e for e in entries if e.get("username") != username]
        after = len(entries)

        if after == before:
            return f"❌ No password found for {site} / {username}"

        self.vault[site] = entries
        if not entries:
            # Remove empty site bucket
            del self.vault[site]

        self._save()
        return f"🗑️ Deleted password for {site} / {username}"

    @safe_execute(max_retries=1)
    def generate_password(self, length: int = 16) -> str:
        import secrets
        import string

        chars = string.ascii_letters + string.digits + "!@#$%^&*"
        password = "".join(secrets.choice(chars) for _ in range(length))
        pyperclip.copy(password)
        return f"🔑 Strong password generated ({length} chars)! Copied to clipboard."

    @safe_execute(max_retries=1)
    def check_breach(self, password: str) -> str:
        import hashlib
        import requests

        sha1 = hashlib.sha1(password.encode()).hexdigest().upper()
        prefix, suffix = sha1[:5], sha1[5:]
        try:
            r = requests.get(f"https://api.pwnedpasswords.com/range/{prefix}", timeout=5)
            if suffix in r.text:
                return "🚨 BREACHED! This password has been found in data leaks!"
            return "✅ Safe! Password not found in known breaches."
        except Exception:
            return "⚠️ Could not check breach database."

    @safe_execute(max_retries=1)
    def generate_2fa(self, secret: str) -> str:
        import hmac
        import struct
        import time
        import hashlib as _hashlib

        key = base64.b32decode(secret + "===="[: len(secret) % 4])
        counter = int(time.time() / 30)
        msg = struct.pack(">Q", counter)
        h = hmac.new(key, msg, _hashlib.sha1).digest()
        o = h[-1] & 0x0F
        code = struct.unpack(">I", h[o : o + 4])[0] & 0x7FFFFFFF
        return f"🔢 2FA Code: {str(code % 1000000).zfill(6)}"


# Global instance
vault = PasswordVault()
