# plugin_engine.py — Dynamic Plugin Engine (Infinite Scalability)
import os
import importlib
import inspect
from config import BASE_DIR, logger
from error_handler import safe_execute

PLUGIN_DIR = str(BASE_DIR / "plugins")
os.makedirs(PLUGIN_DIR, exist_ok=True)

# Create a sample plugin
SAMPLE_PLUGIN = '''
# plugins/sample_plugin.py — Sample RASHEED Plugin
"""Auto-generated sample plugin"""

def execute(**kwargs):
    """Every plugin must have an execute() function"""
    return "👋 Hello from Sample Plugin!"

# Tool declaration (auto-loaded)
TOOL = {
    "name": "sample_plugin",
    "description": "A sample plugin - customize this!",
    "parameters": {"type": "object", "properties": {}}
}
'''

# Write sample plugin if not exists
sample_path = os.path.join(PLUGIN_DIR, "sample_plugin.py")
if not os.path.exists(sample_path):
    with open(sample_path, 'w', encoding='utf-8') as f:
        f.write(SAMPLE_PLUGIN)


class PluginEngine:
    """
    Automatically discovers and loads plugins from the plugins/ folder.
    Each plugin.py file can define a TOOL dict and execute() function.
    This is how RASHEED gets 1000+ features - just drop files!
    """

    def __init__(self):
        self.plugins = {}  # {tool_name: {"module": module, "tool": TOOL_DICT, "execute": func}}

    def discover(self) -> str:
        """Scan plugins/ folder and load all valid plugins"""
        if not os.path.exists(PLUGIN_DIR):
            return "No plugins folder found."

        loaded = 0
        for filename in os.listdir(PLUGIN_DIR):
            if filename.endswith(".py") and not filename.startswith("_"):
                filepath = os.path.join(PLUGIN_DIR, filename)
                try:
                    spec = importlib.util.spec_from_file_location(filename[:-3], filepath)
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)
                    
                    if hasattr(module, 'TOOL') and hasattr(module, 'execute'):
                        tool_def = module.TOOL
                        tool_name = tool_def.get("name", filename[:-3])
                        self.plugins[tool_name] = {
                            "module": module,
                            "tool": tool_def,
                            "execute": module.execute
                        }
                        loaded += 1
                        logger.info(f"🔌 Plugin loaded: {tool_name}")
                except Exception as e:
                    logger.error(f"Plugin load error {filename}: {e}")

        return f"🔌 Loaded {loaded} plugins from {PLUGIN_DIR}"

    def get_tool_declarations(self) -> list:
        """Return all plugin tool declarations for Gemini"""
        return [p["tool"] for p in self.plugins.values()]

    def execute_plugin(self, name: str, args: dict) -> str:
        """Execute a plugin"""
        if name not in self.plugins:
            return f"❌ Plugin '{name}' not found"
        
        try:
            return self.plugins[name]["execute"](**args)
        except Exception as e:
            return f"❌ Plugin error [{name}]: {e}"

    def list_plugins(self) -> str:
        if not self.plugins:
            return "No plugins loaded."
        return "🔌 Loaded Plugins:\n" + "\n".join(f"  • {name}" for name in self.plugins)


# Global instance
plugin_engine = PluginEngine()

# Auto-discover on import
plugin_engine.discover()