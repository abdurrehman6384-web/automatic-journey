@echo off
title RASHEED - Installing New Features
color 0A

echo.
echo ╔════════════════════════════════════════════╗
echo ║   RASHEED - Installing New Features        ║
echo ╚════════════════════════════════════════════╝
echo.

echo [1/11] Installing speedtest-cli...
pip install speedtest-cli

echo [2/11] Installing mss (Screen Recording)...
pip install mss

echo [3/11] Installing pycaw (Volume Control)...
pip install pycaw

echo [4/11] Installing screen-brightness-control...
pip install screen-brightness-control

echo [5/11] Installing yt-dlp (YouTube Downloader)...
pip install yt-dlp

echo [6/11] Installing PyPDF2 (PDF Reader)...
pip install PyPDF2

echo [7/11] Installing qrcode (QR Generator)...
pip install qrcode[pil]

echo [8/11] Installing pygetwindows (Window Management)...
pip install PyGetWindows

echo [9/11] Installing pyautogui (Automation)...
pip install pyautogui

echo [10/11] Installing pyperclip (Clipboard)...
pip install pyperclip

echo [11/11] Installing wmi (System Temperature)...
pip install WMI

echo.
echo ╔════════════════════════════════════════════╗
echo ║   ✅ ALL NEW FEATURES INSTALLED!           ║
echo ╚════════════════════════════════════════════╝
echo.
pause