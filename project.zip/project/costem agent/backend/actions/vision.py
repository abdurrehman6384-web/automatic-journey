# vision.py — RASHEED Vision Engine v6.0 (Screen + OCR + Webcam)
import cv2
import numpy as np
import mss
import mss.tools
import base64
import io
from PIL import Image
import threading
from config import SCREEN_WIDTH, SCREEN_QUALITY, logger
from error_handler import safe_execute

# Tesseract path (Windows)
try:
    import pytesseract
    pytesseract.pytesseract.tesseract_cmd = (
        r'C:\Program Files\Tesseract-OCR\tesseract.exe'
    )
    OCR_AVAILABLE = True
except Exception:
    OCR_AVAILABLE = False
    logger.warning("Tesseract OCR not available. Install for OCR features.")


class VisionEngine:
    def __init__(self):
        self.screen_fps = 30
        self.cap = None

    def start_webcam(self) -> bool:
        try:
            self.cap = cv2.VideoCapture(0)
            if self.cap.isOpened():
                self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
                self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
                return True
            return False
        except Exception as e:
            logger.error(f"Webcam start error: {e}")
            return False

    def stop_webcam(self):
        if self.cap:
            self.cap.release()
            self.cap = None

    @safe_execute(max_retries=2)
    def get_screen_frame(self) -> np.ndarray | None:
        with mss.mss() as sct:
            monitor = sct.monitors[1]
            img = sct.grab(monitor)
            frame = np.array(img)
            frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
            return frame

    def get_screen_b64(
        self, width: int = None, quality: int = None
    ) -> str:
        width = width or SCREEN_WIDTH
        quality = quality or SCREEN_QUALITY
        try:
            with mss.mss() as sct:
                monitor = sct.monitors[1]
                img = sct.grab(monitor)
                pil_img = Image.frombytes(
                    "RGB", img.size, img.bgra, "raw", "BGRX"
                )
                h = int(pil_img.height * width / pil_img.width)
                pil_img = pil_img.resize((width, h), Image.LANCZOS)
                with io.BytesIO() as buffer:
                    pil_img.save(buffer, format="JPEG", quality=quality)
                    return base64.b64encode(buffer.getvalue()).decode()
        except Exception as e:
            logger.debug(f"get_screen_b64 failed: {e}")
            return ""

    def get_region_b64(self, x: int, y: int, w: int, h: int) -> str:
        try:
            with mss.mss() as sct:
                monitor = {"top": y, "left": x, "width": w, "height": h}
                img = sct.grab(monitor)
                pil_img = Image.frombytes(
                    "RGB", img.size, img.bgra, "raw", "BGRX"
                )
                with io.BytesIO() as buffer:
                    pil_img.save(buffer, format="JPEG", quality=80)
                    return base64.b64encode(buffer.getvalue()).decode()
        except Exception as e:
            logger.debug(f"get_region_b64 failed: {e}")
            return ""

    def get_webcam_b64(self) -> str:
        if not self.cap or not self.cap.isOpened():
            return ""
        try:
            ret, frame = self.cap.read()
            if not ret:
                return ""
            frame = cv2.resize(frame, (640, 480))
            _, jpeg = cv2.imencode(
                '.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 75]
            )
            return base64.b64encode(jpeg.tobytes()).decode()
        except Exception:
            return ""

    def read_screen_text(self) -> str:
        if not OCR_AVAILABLE:
            return "❌ Tesseract OCR not installed"
        try:
            frame = self.get_screen_frame()
            if frame is None:
                return ""
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            gray = cv2.threshold(
                gray, 0, 255,
                cv2.THRESH_BINARY + cv2.THRESH_OTSU
            )[1]
            text = pytesseract.image_to_string(gray, lang='eng')
            return text.strip()
        except Exception as e:
            return f"OCR error: {e}"

    def read_region_text(
        self, x: int, y: int, w: int, h: int
    ) -> str:
        if not OCR_AVAILABLE:
            return "❌ Tesseract OCR not installed"
        try:
            with mss.mss() as sct:
                monitor = {"top": y, "left": x, "width": w, "height": h}
                img = sct.grab(monitor)
                pil_img = Image.frombytes(
                    "RGB", img.size, img.bgra, "raw", "BGRX"
                )
                gray = cv2.cvtColor(
                    np.array(pil_img), cv2.COLOR_RGB2GRAY
                )
                gray = cv2.threshold(
                    gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU
                )[1]
                text = pytesseract.image_to_string(gray, lang="eng")
                return text.strip()
        except Exception as e:
            return f"Region OCR error: {e}"

    def detect_color_region(
        self, color_bgr: tuple, tolerance: int = 30
    ) -> list:
        try:
            frame = self.get_screen_frame()
            if frame is None:
                return []
            lower = np.array([max(0, c - tolerance) for c in color_bgr])
            upper = np.array([min(255, c + tolerance) for c in color_bgr])
            mask = cv2.inRange(frame, lower, upper)
            contours, _ = cv2.findContours(
                mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE
            )
            locations = []
            for cnt in contours[:10]:
                M = cv2.moments(cnt)
                if M["m00"] != 0:
                    cx = int(M["m10"] / M["m00"])
                    cy = int(M["m01"] / M["m00"])
                    locations.append((cx, cy))
            return locations
        except Exception:
            return []

    def find_template(self, template_path: str) -> tuple | None:
        try:
            frame = self.get_screen_frame()
            template = cv2.imread(template_path)
            if frame is None or template is None:
                return None
            result = cv2.matchTemplate(
                frame, template, cv2.TM_CCOEFF_NORMED
            )
            _, max_val, _, max_loc = cv2.minMaxLoc(result)
            if max_val > 0.8:
                h, w = template.shape[:2]
                center_x = max_loc[0] + w // 2
                center_y = max_loc[1] + h // 2
                return (center_x, center_y, max_val)
            return None
        except Exception:
            return None

    def get_pixel_color(self, x: int, y: int) -> tuple:
        try:
            with mss.mss() as sct:
                monitor = {"top": y, "left": x, "width": 1, "height": 1}
                img = sct.grab(monitor)
                pixel = img.pixel(0, 0)
                return pixel
        except Exception:
            return (0, 0, 0)

    def save_screenshot(
        self, path: str, region: dict = None
    ) -> bool:
        try:
            with mss.mss() as sct:
                monitor = region or sct.monitors[1]
                img = sct.grab(monitor)
                mss.tools.to_png(img.rgb, img.size, output=path)
            return True
        except Exception:
            return False

    def get_screen_size(self) -> tuple:
        try:
            with mss.mss() as sct:
                m = sct.monitors[1]
                return (m["width"], m["height"])
        except Exception:
            return (1920, 1080)


# Global vision engine
vision = VisionEngine()
