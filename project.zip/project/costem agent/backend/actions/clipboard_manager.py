# clipboard_manager.py — Clipboard History & Pin System
import sqlite3
import time
import threading
import pyperclip
from config import DATA_DIR, logger
from error_handler import safe_execute

DB_FILE = str(DATA_DIR / "clipboard.db")

class ClipboardManager:
    def __init__(self):
        self.pinned = []
        self._setup_db()
        self._monitor_active = False

    def _setup_db(self):
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS clipboard 
                     (id INTEGER PRIMARY KEY, text TEXT, timestamp REAL, pinned INTEGER DEFAULT 0)''')
        conn.commit()
        conn.close()

    def start_monitor(self) -> str:
        """Start monitoring clipboard changes"""
        if self._monitor_active:
            return "Already monitoring!"
        self._monitor_active = True
        t = threading.Thread(target=self._monitor_loop, daemon=True)
        t.start()
        return "📋 Clipboard monitor started!"

    def _monitor_loop(self):
        last = ""
        while self._monitor_active:
            try:
                current = pyperclip.paste()
                if current and current != last and len(current) > 2:
                    last = current
                    self._save_to_db(current)
            except Exception:
                pass
            time.sleep(0.5)

    def _save_to_db(self, text: str):
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute("INSERT INTO clipboard (text, timestamp) VALUES (?, ?)", (text, time.time()))
        # Keep only last 100
        c.execute("DELETE FROM clipboard WHERE pinned=0 AND id NOT IN (SELECT id FROM clipboard WHERE pinned=0 ORDER BY id DESC LIMIT 100)")
        conn.commit()
        conn.close()

    def get_history(self, limit: int = 10) -> str:
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute("SELECT id, text, pinned FROM clipboard ORDER BY id DESC LIMIT ?", (limit,))
        rows = c.fetchall()
        conn.close()
        
        if not rows:
            return "📋 Clipboard is empty."
        
        result = "📋 Clipboard History:\n\n"
        for id_, text, pinned in rows:
            pin = "📌 " if pinned else "   "
            result += f"{pin}[{id_}] {text[:80]}\n"
        return result

    def pin_item(self, item_id: int) -> str:
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute("UPDATE clipboard SET pinned=1 WHERE id=?", (item_id,))
        conn.commit()
        conn.close()
        return f"📌 Pinned item {item_id}!"

    def copy_item(self, item_id: int) -> str:
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute("SELECT text FROM clipboard WHERE id=?", (item_id,))
        row = c.fetchone()
        conn.close()
        if row:
            pyperclip.copy(row[0])
            return f"✅ Copied to clipboard!"
        return f"❌ Item {item_id} not found."

    def clear_history(self) -> str:
        conn = sqlite3.connect(DB_FILE)
        c = conn.cursor()
        c.execute("DELETE FROM clipboard WHERE pinned=0")
        conn.commit()
        conn.close()
        return "🗑️ Clipboard history cleared (pinned items kept)!"


# Global instance
clipboard_mgr = ClipboardManager()