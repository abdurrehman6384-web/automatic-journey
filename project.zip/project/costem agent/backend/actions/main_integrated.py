# ╔══════════════════════════════════════════════════════════╗
# ║     RASHEED v11.0 INTEGRATED - Multi-Agent Main          ║
# ║     Unified orchestration of ALL systems                 ║
# ║     Run: python main_integrated.py                       ║
# ╚══════════════════════════════════════════════════════════╝

import asyncio
import sys
import signal
import os
import logging
from pathlib import Path
from typing import Optional

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(name)s] %(levelname)s: %(message)s'
)
logger = logging.getLogger("RASHEED.Main")

# Add current directory to path for imports
sys.path.insert(0, str(Path(__file__).parent))

# Import RASHEED core
try:
    from main import RASHEED as CoreRASHEED
    from main import check_dependencies, _print_banner
    from config import GEMINI_API_KEY
    HAS_CORE = True
except ImportError as e:
    logger.warning(f"Core RASHEED import warning: {e}")
    HAS_CORE = False

# Import multi-agent system
try:
    from multi_agent_system import (
        AgentOrchestrator, 
        get_orchestrator,
        ExternalSystemsManager,
        PentestGPTWrapper,
        WormGPTWrapper,
        PaperclipWrapper,
        BusinessSkillsWrapper,
        AgentFactoryWrapper
    )
    from multi_agent_system.agent_orchestrator import AgentType
    HAS_MULTI_AGENT = True
except ImportError as e:
    logger.error(f"Multi-agent import error: {e}")
    HAS_MULTI_AGENT = False


class RASHEEDIntegrated:
    """Integrated RASHEED system with multi-agent orchestration"""
    
    def __init__(self):
        self.orchestrator: Optional[AgentOrchestrator] = None
        self.external_systems: Optional[ExternalSystemsManager] = None
        self.core_rasheed: Optional[CoreRASHEED] = None
        self.running = False
        self.setup_signal_handlers()
    
    def setup_signal_handlers(self):
        """Setup graceful shutdown handlers"""
        signal.signal(signal.SIGINT, self._handle_shutdown)
        if sys.platform != "win32":
            signal.signal(signal.SIGTERM, self._handle_shutdown)
    
    def _handle_shutdown(self, signum, frame):
        """Handle shutdown signal"""
        print("\n\n🛑 Shutdown signal received...")
        asyncio.create_task(self.shutdown())
    
    def initialize_orchestrator(self) -> bool:
        """Initialize the multi-agent orchestrator"""
        try:
            if not HAS_MULTI_AGENT:
                logger.error("Multi-agent system not available")
                return False
            
            self.orchestrator = get_orchestrator()
            logger.info("✓ Agent orchestrator initialized")
            
            # Register core RASHEED agent
            if HAS_CORE and self.core_rasheed:
                self.orchestrator.register_agent(
                    "core_rasheed",
                    AgentType.CORE_RASHEED,
                    self.core_rasheed
                )
            
            return True
        except Exception as e:
            logger.error(f"✗ Failed to initialize orchestrator: {e}")
            return False
    
    def initialize_external_systems(self) -> bool:
        """Initialize external system wrappers"""
        try:
            if not HAS_MULTI_AGENT:
                return False
            
            base_path = Path(__file__).parent
            self.external_systems = ExternalSystemsManager(str(base_path))
            
            # Register external systems as agents
            if self.orchestrator:
                for system_id, wrapper in self.external_systems.wrappers.items():
                    self.orchestrator.register_agent(
                        system_id,
                        self._get_agent_type(system_id),
                        wrapper
                    )
            
            logger.info(f"✓ {len(self.external_systems.wrappers)} external systems initialized")
            return True
        except Exception as e:
            logger.error(f"✗ Failed to initialize external systems: {e}")
            return False
    
    def _get_agent_type(self, system_id: str) -> AgentType:
        """Get agent type from system ID"""
        mapping = {
            "pentest": AgentType.PENTEST,
            "worm": AgentType.WORM,
            "paperclip": AgentType.ORCHESTRATION,
            "business": AgentType.AUTONOMOUS,
            "factory": AgentType.ORCHESTRATION
        }
        return mapping.get(system_id, AgentType.AUTONOMOUS)
    
    def initialize_core_rasheed(self) -> bool:
        """Initialize core RASHEED system"""
        try:
            if not HAS_CORE:
                logger.warning("Core RASHEED not available")
                return False
            
            self.core_rasheed = CoreRASHEED()
            logger.info("✓ Core RASHEED initialized")
            return True
        except Exception as e:
            logger.error(f"✗ Failed to initialize core RASHEED: {e}")
            return False
    
    async def start_all_systems(self) -> bool:
        """Start all systems"""
        try:
            logger.info("🚀 Starting all AI systems...")
            
            # Start external systems
            if self.external_systems:
                results = await self.external_systems.start_all()
                active = sum(1 for v in results.values() if v)
                logger.info(f"✓ Started {active}/{len(results)} external systems")
                
                # Activate agents
                if self.orchestrator:
                    for system_id in self.external_systems.wrappers.keys():
                        self.orchestrator.activate_agent(system_id)
            
            # Activate core RASHEED
            if self.orchestrator:
                self.orchestrator.activate_agent("core_rasheed")
            
            self.running = True
            logger.info("✅ All systems started successfully!")
            return True
        
        except Exception as e:
            logger.error(f"✗ Failed to start systems: {e}")
            return False
    
    async def shutdown(self):
        """Gracefully shutdown all systems"""
        try:
            logger.info("🛑 Shutting down all systems...")
            
            if self.external_systems:
                results = await self.external_systems.stop_all()
                stopped = sum(1 for v in results.values() if v)
                logger.info(f"✓ Stopped {stopped}/{len(results)} external systems")
            
            # Core RASHEED cleanup
            if self.core_rasheed:
                self.core_rasheed.cleanup()
            
            self.running = False
            logger.info("✅ Graceful shutdown complete")
        
        except Exception as e:
            logger.error(f"✗ Shutdown error: {e}")
        
        sys.exit(0)
    
    def print_status(self):
        """Print system status"""
        if not self.orchestrator:
            return
        
        status = self.orchestrator.get_system_status()
        
        print("\n" + "="*60)
        print("🤖 RASHEED v11.0 INTEGRATED - SYSTEM STATUS")
        print("="*60)
        print(f"Running: {'Yes ✓' if status['running'] else 'No ✗'}")
        print(f"Total Agents: {status['total_agents']}")
        print(f"Active Agents: {status['active_agents']}")
        print(f"Healthy Agents: {status['healthy_agents']}")
        print(f"Queue Size: {status['queue_size']}")
        print("-"*60)
        print("Agent Details:")
        for agent_id, info in status['agents'].items():
            status_icon = "✓" if info['healthy'] else "✗"
            active_icon = "▶" if info['active'] else "⏸"
            print(f"  {status_icon} {active_icon} {agent_id}: {info['type']}")
            if info['last_error']:
                print(f"      Last Error: {info['last_error'][:50]}")
        print("="*60 + "\n")
    
    async def run_interactive(self):
        """Run interactive mode with all systems"""
        print("\n" + "="*60)
        print("RASHEED v11.0 INTEGRATED - INTERACTIVE MODE")
        print("Commands: status, agents, help, quit")
        print("="*60 + "\n")
        
        while self.running:
            try:
                cmd = input("🤖 RASHEED > ").strip().lower()
                
                if not cmd:
                    continue
                
                if cmd == "quit" or cmd == "exit":
                    await self.shutdown()
                    break
                
                elif cmd == "status":
                    self.print_status()
                
                elif cmd == "agents":
                    if self.orchestrator:
                        agents = list(self.orchestrator.agents.keys())
                        print(f"Available agents: {', '.join(agents)}")
                
                elif cmd == "help":
                    print("""
Available Commands:
  status   - Show system status
  agents   - List all agents
  help     - Show this help
  quit     - Exit RASHEED
                    """)
                
                else:
                    # Try to execute as task on all agents
                    task = {
                        "description": cmd,
                        "type": "query"
                    }
                    if self.orchestrator:
                        results = await self.orchestrator.broadcast_task(task)
                        for agent_id, result in results.items():
                            if result.get("success"):
                                print(f"✓ {agent_id}: {result.get('message', 'OK')}")
                            else:
                                print(f"✗ {agent_id}: {result.get('error', 'Unknown error')}")
            
            except KeyboardInterrupt:
                await self.shutdown()
                break
            except Exception as e:
                logger.error(f"Command error: {e}")


async def main():
    """Main entry point"""
    # Print banner
    if HAS_CORE:
        _print_banner()
    
    # Check core dependencies
    if HAS_CORE:
        if not check_dependencies():
            print("⚠️  Some features may not work without missing packages")
    
    # Validate API key
    if not GEMINI_API_KEY:
        print("⚠️  GEMINI_API_KEY not set — some features will be limited")
    
    # Initialize integrated system
    integrated = RASHEEDIntegrated()
    
    # Initialize components
    print("\n🔧 Initializing integrated system...")
    if not integrated.initialize_core_rasheed():
        print("⚠️  Core RASHEED initialization failed, continuing with external systems...")
    
    if not integrated.initialize_orchestrator():
        print("❌ Failed to initialize orchestrator — exiting")
        sys.exit(1)
    
    if not integrated.initialize_external_systems():
        print("⚠️  External systems initialization failed")
    
    # Start all systems
    if not await integrated.start_all_systems():
        print("❌ Failed to start systems — exiting")
        sys.exit(1)
    
    # Print initial status
    integrated.print_status()
    
    # Run interactive mode
    try:
        await integrated.run_interactive()
    except KeyboardInterrupt:
        await integrated.shutdown()
    except Exception as e:
        logger.error(f"Fatal error: {e}")
        import traceback
        traceback.print_exc()
        await integrated.shutdown()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n👋 RASHEED stopped by user")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ Critical Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
