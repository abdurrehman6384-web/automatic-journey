# knowledge_graph.py — AI Knowledge Graph (Connected Memory)
import json
import os
from config import DATA_DIR, logger
from error_handler import safe_execute

GRAPH_FILE = str(DATA_DIR / "knowledge_graph.json")

class KnowledgeGraph:
    """
    Stores entities and relationships.
    Knows that Ahmed is your brother, lives in Dubai, likes Biryani.
    """

    def __init__(self):
        self.entities = {}  # {"Ahmed": {"type": "person", "attributes": {"birthday": "15 March", "likes": "Biryani", "city": "Dubai", "relation": "brother"}}}
        self.relations = [] # [{"from": "Abdurrehman", "relation": "brother", "to": "Ahmed"}]
        self._load()

    def _load(self):
        if os.path.exists(GRAPH_FILE):
            try:
                with open(GRAPH_FILE, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.entities = data.get("entities", {})
                    self.relations = data.get("relations", [])
            except Exception:
                pass

    def _save(self):
        try:
            with open(GRAPH_FILE, 'w', encoding='utf-8') as f:
                json.dump({"entities": self.entities, "relations": self.relations}, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"Graph save error: {e}")

    def add_entity(self, name: str, entity_type: str = "person", attributes: dict = None) -> str:
        name = name.strip().title()
        if name not in self.entities:
            self.entities[name] = {"type": entity_type, "attributes": {}}
        if attributes:
            self.entities[name]["attributes"].update(attributes)
        self._save()
        return f"🧠 Entity added: {name} ({entity_type})"

    def add_relation(self, from_entity: str, relation: str, to_entity: str) -> str:
        from_entity = from_entity.strip().title()
        to_entity = to_entity.strip().title()
        
        # Auto-create entities if they don't exist
        if from_entity not in self.entities:
            self.add_entity(from_entity)
        if to_entity not in self.entities:
            self.add_entity(to_entity)
            
        # Add relation
        rel = {"from": from_entity, "relation": relation, "to": to_entity}
        self.relations.append(rel)
        
        # Also store as attribute
        self.entities[from_entity]["attributes"][relation] = to_entity
        self._save()
        return f"🧠 Relation added: {from_entity} --{relation}--> {to_entity}"

    def add_fact(self, name: str, key: str, value: str) -> str:
        name = name.strip().title()
        if name not in self.entities:
            self.add_entity(name)
        self.entities[name]["attributes"][key] = value
        self._save()
        return f"🧠 Fact added: {name}'s {key} = {value}"

    def query_entity(self, name: str) -> str:
        name = name.strip().title()
        if name not in self.entities:
            # Try fuzzy search
            for ent_name in self.entities:
                if name.lower() in ent_name.lower():
                    name = ent_name
                    break
        
        if name not in self.entities:
            return f"❌ I don't know anyone named '{name}' yet."

        entity = self.entities[name]
        attrs = entity.get("attributes", {})
        
        # Find relations
        rels = []
        for r in self.relations:
            if r["from"] == name:
                rels.append(f"{r['relation']} → {r['to']}")
            elif r["to"] == name:
                rels.append(f"{r['relation']} ← {r['from']}")

        result = f"🧠 **{name}** ({entity.get('type', 'unknown')})\n"
        if attrs:
            result += "Facts:\n"
            for k, v in attrs.items():
                result += f"  • {k}: {v}\n"
        if rels:
            result += "Relations:\n"
            for r in rels[:10]:
                result += f"  • {r}\n"
        return result

    def suggest_gift(self, name: str) -> str:
        """Suggest gift based on entity's preferences"""
        name = name.strip().title()
        if name not in self.entities:
            return f"❌ I don't know {name}'s preferences yet."
        
        attrs = self.entities[name].get("attributes", {})
        likes = attrs.get("likes", attrs.get("hobbies", attrs.get("interests", "")))
        
        if likes:
            from ai_brain import llm_router
            prompt = f"Based on the fact that {name} likes {likes}, suggest 3 thoughtful gift ideas. Be creative. Keep it brief."
            return llm_router.smart_ask(prompt)
        return f"I know {name}, but not their preferences yet. Tell me what they like!"

    def auto_extract(self, text: str) -> str:
        """Auto-extract entities and relations from text using AI"""
        from ai_brain import llm_router
        prompt = (
            f"Extract entities (people, places, things) and their attributes/relations from this text. "
            f"Output ONLY valid JSON:\n"
            f'{{"entities": [{{"name": "Name", "type": "person", "attributes": {{"key": "value"}}}}], '
            f'"relations": [{{"from": "Name1", "relation": "brother", "to": "Name2"}}]}}\n\n'
            f"Text: {text[:2000]}"
        )
        response = llm_router.smart_ask(prompt)
        if not response or "❌" in str(response):
            return ""
        
        try:
            clean = response.replace("```json", "").replace("```", "").strip()
            data = json.loads(clean)
            
            count = 0
            for ent in data.get("entities", []):
                self.add_entity(ent["name"], ent.get("type", "person"), ent.get("attributes"))
                count += 1
            for rel in data.get("relations", []):
                self.add_relation(rel["from"], rel["relation"], rel["to"])
                count += 1
            
            self._save()
            return f"🧠 Auto-extracted {count} facts!"
        except Exception:
            return ""


# Global instance
knowledge = KnowledgeGraph()