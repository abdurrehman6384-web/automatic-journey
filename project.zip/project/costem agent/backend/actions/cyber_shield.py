# cyber_shield.py — Honeypot, DDoS Shield, Dark Web Monitor, Firewall Hardening
import socket
import threading
import time
import subprocess
import requests
from config import logger
from error_handler import safe_execute

class CyberShield:
    # ── 1. Honeypot Deployment ───────────────────────
    def deploy_honeypot(self, ports: list = [21, 22, 23, 3389]) -> str:
        """Open fake ports to trap hackers and block their IPs"""
        def _honeypot_server(port):
            try:
                s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                s.bind(('0.0.0.0', port))
                s.listen(5)
                while True:
                    conn, addr = s.accept()
                    hacker_ip = addr[0]
                    logger.warning(f"🚨 Honeypot triggered on port {port} by IP: {hacker_ip}")
                    conn.close()
                    # Auto-block IP
                    self._block_ip(hacker_ip)
            except Exception:
                pass

        for p in ports:
            t = threading.Thread(target=_honeypot_server, args=(p,), daemon=True)
            t.start()
        
        return f"🍯 Honeypot deployed on ports: {ports}. Intruders will be auto-blocked!"

    def _block_ip(self, ip: str):
        """Block IP via Windows Firewall"""
        try:
            cmd = f'netsh advfirewall firewall add rule name="RASHEED Block {ip}" dir=in action=block remoteip={ip}'
            subprocess.run(cmd, shell=True, capture_output=True, timeout=5)
            logger.info(f"🛑 Blocked IP: {ip}")
        except Exception as e:
            logger.error(f"Firewall block failed: {e}")

    # ── 2. DDoS Auto-Shield ──────────────────────────
    def monitor_ddos(self, threshold: int = 100) -> str:
        """Monitor active connections, block IPs exceeding threshold"""
        try:
            result = subprocess.run(['netstat', '-ano'], capture_output=True, text=True, timeout=5)
            ips = {}
            for line in result.stdout.split('\n'):
                if 'ESTABLISHED' in line or 'TIME_WAIT' in line:
                    parts = line.split()
                    if len(parts) > 1:
                        ip = parts[1].split(':')[0]
                        ips[ip] = ips.get(ip, 0) + 1
            
            attackers = [ip for ip, count in ips.items() if count > threshold and ip != '0.0.0.0' and ip != '127.0.0.1']
            for ip in attackers:
                self._block_ip(ip)
            
            return f"🛡️ DDoS Check: {len(ips)} unique IPs. Blocked {len(attackers)} suspicious IPs."
        except Exception as e:
            return f"❌ DDoS monitor error: {e}"

    # ── 3. Dark Web Monitor ──────────────────────────
    @safe_execute(max_retries=1)
    def check_dark_web(self, email: str) -> str:
        """Check if email was leaked using HaveIBeenPwned API"""
        url = f"https://haveibeenpwned.com/api/v3/breachedaccount/{email}"
        headers = {"hibp-api-key": "YOUR_HIBP_API_KEY", "user-agent": "RASHEED-AI"} # Get free key from haveibeenpwned
        r = requests.get(url, headers=headers, timeout=5)
        
        if r.status_code == 200:
            breaches = r.json()
            names = [b['Name'] for b in breaches]
            return f"🚨 ALERT! {email} found in breaches: {', '.join(names)}"
        elif r.status_code == 404:
            return f"✅ {email} is safe! No breaches found."
        return f"⚠️ Check failed: {r.status_code}"

    # ── 4. Auto Firewall Hardening ───────────────────
    @safe_execute(max_retries=1)
    def harden_firewall(self) -> str:
        """Block all inbound ports except essential ones (80, 443, 8000)"""
        # Enable default block
        subprocess.run('netsh advfirewall set allprofiles firewallpolicy blockinbound,allowoutbound', shell=True, capture_output=True)
        
        # Allow RASHEED API Port & Web
        essential_ports = [80, 443, 8000]
        for port in essential_ports:
            cmd = f'netsh advfirewall firewall add rule name="RASHEED Allow {port}" dir=in action=allow protocol=TCP localport={port}'
            subprocess.run(cmd, shell=True, capture_output=True)
            
        return "🏰 Firewall Hardened! Blocked all inbound except 80, 443, 8000."

# Global instance
cyber_shield = CyberShield()