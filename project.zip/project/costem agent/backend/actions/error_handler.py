# error_handler.py — RASHEED Advanced Error Handling & Recovery
import logging
import traceback
import functools
import time
import sys
from logging.handlers import RotatingFileHandler
from config import LOG_FILE, LOG_LEVEL, LOG_MAX_SIZE_MB, LOG_BACKUP_COUNT, LOGS_DIR


def setup_logging():
    """Structured logging system with rotation"""
    LOGS_DIR.mkdir(parents=True, exist_ok=True)

    logger = logging.getLogger("RASHEED")
    logger.setLevel(getattr(logging, LOG_LEVEL, logging.INFO))

    # File handler with rotation
    fh = RotatingFileHandler(
        LOG_FILE,
        maxBytes=LOG_MAX_SIZE_MB * 1024 * 1024,
        backupCount=LOG_BACKUP_COUNT,
        encoding="utf-8"
    )
    fh.setFormatter(logging.Formatter(
        '%(asctime)s | %(levelname)-8s | %(name)s | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    ))

    # Console handler
    ch = logging.StreamHandler()
    ch.setFormatter(logging.Formatter(
        '%(levelname)-8s | %(message)s'
    ))

    logger.addHandler(fh)
    logger.addHandler(ch)
    return logger


logger = setup_logging()


def safe_execute(max_retries: int = 3, delay: float = 1.0, backoff: float = 2.0):
    """Decorator: Auto-retry with exponential backoff"""
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            retries = 0
            current_delay = delay
            last_error = None

            while retries < max_retries:
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_error = e
                    retries += 1
                    logger.warning(
                        f"[RETRY {retries}/{max_retries}] "
                        f"{func.__name__} failed: {e} — "
                        f"retrying in {current_delay:.1f}s..."
                    )
                    time.sleep(current_delay)
                    current_delay *= backoff

            logger.error(
                f"[FAILED] {func.__name__} after {max_retries} retries: {last_error}"
            )
            return f"❌ Error after {max_retries} retries: {last_error}"

        return wrapper
    return decorator


def crash_recovery(func):
    """Decorator: Auto-restart on crash"""
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except KeyboardInterrupt:
            logger.info("User interrupted.")
            raise
        except Exception as e:
            logger.critical(
                f"[CRASH] {func.__name__}: {e}\n"
                f"{traceback.format_exc()}"
            )
            return f"❌ Critical error: {e}"
    return wrapper


class ErrorReporter:
    """Collect and report errors"""

    def __init__(self):
        self.errors = []
        self.max_errors = 100

    def report(self, context: str, error: Exception):
        entry = {
            "time": time.strftime("%Y-%m-%d %H:%M:%S"),
            "context": context,
            "error": str(error),
            "type": type(error).__name__,
            "traceback": traceback.format_exc()
        }
        self.errors.append(entry)
        if len(self.errors) > self.max_errors:
            self.errors = self.errors[-self.max_errors:]
        logger.error(f"[{context}] {type(error).__name__}: {error}")

    def get_recent(self, count: int = 5) -> list:
        return self.errors[-count:]

    def get_summary(self) -> str:
        if not self.errors:
            return "✅ No errors recorded!"
        from collections import Counter
        types = Counter(e["type"] for e in self.errors)
        lines = [f"📊 Error Summary ({len(self.errors)} total):"]
        for err_type, count in types.most_common():
            lines.append(f"  • {err_type}: {count}")
        return "\n".join(lines)


# Global error reporter
error_reporter = ErrorReporter()