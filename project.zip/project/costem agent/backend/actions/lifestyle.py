# lifestyle.py — Prayer, Crypto, Spotify, Pomodoro, Party Mode
import requests
import time
import threading
import subprocess
from config import DEFAULT_CITY, logger
from error_handler import safe_execute


class PrayerTimes:
    """Get Islamic prayer times via Aladhan API"""
    @safe_execute(max_retries=1)
    def get_times(self, city: str = None) -> str:
        city = city or DEFAULT_CITY
        url = f"http://api.aladhan.com/v1/timingsByCity?city={city}&country=Pakistan&method=1"
        r = requests.get(url, timeout=5)
        data = r.json()['data']['timings']
        return (
            f"🕌 Prayer Times ({city}):\n"
            f"Fajr: {data['Fajr']}\n"
            f"Dhuhr: {data['Dhuhr']}\n"
            f"Asr: {data['Asr']}\n"
            f"Maghrib: {data['Maghrib']}\n"
            f"Isha: {data['Isha']}"
        )


class CryptoTracker:
    """Live Crypto/Stock prices"""
    @safe_execute(max_retries=1)
    def get_price(self, symbol: str = "BTCUSDT") -> str:
        url = f"https://api.binance.com/api/v3/ticker/price?symbol={symbol.upper()}"
        r = requests.get(url, timeout=5)
        data = r.json()
        price = float(data['price'])
        return f"💰 {symbol.upper()}: ${price:,.2f}"


class SpotifyController:
    """Control Spotify via keyboard media keys"""
    def next_track(self) -> str:
        import keyboard
        keyboard.send('next track')
        return "⏭️ Next track!"

    def previous_track(self) -> str:
        import keyboard
        keyboard.send('previous track')
        return "⏮️ Previous track!"

    def play_pause(self) -> str:
        import keyboard
        keyboard.send('play/pause media')
        return "⏯️ Play/Pause!"

    def volume_up(self) -> str:
        import keyboard
        keyboard.send('volume up')
        return "🔊 Volume up!"

    def volume_down(self) -> str:
        import keyboard
        keyboard.send('volume down')
        return "🔉 Volume down!"


class PomodoroTimer:
    """Focus / Deep Work Mode"""
    def __init__(self):
        self.active = False
        self.thread = None

    def start_focus(self, minutes: int = 25) -> str:
        self.active = True
        self.thread = threading.Thread(
            target=self._timer_loop, args=(minutes,), daemon=True
        )
        self.thread.start()
        return f"🧘 Focus mode ON! {minutes} minutes of deep work."

    def _timer_loop(self, minutes: int):
        time.sleep(minutes * 60)
        if self.active:
            logger.info("Pomodoro timer ended!")
            # Notify user
            try:
                from app import show_notification
                show_notification("Pomodoro Timer", "Break time boss! ☕")
            except Exception:
                pass
        self.active = False

    def stop_focus(self) -> str:
        self.active = False
        return "⏹️ Focus mode stopped."


class PartyMode:
    """AI DJ Party Mode"""
    def start_party(self) -> str:
        # Start upbeat music
        import keyboard
        keyboard.send('play/pause media')
        return "🎉🪩 PARTY MODE ON! Let's go boss! 🎶"

    def stop_party(self) -> str:
        import keyboard
        keyboard.send('play/pause media')
        return "🛑 Party mode off. Back to work! 💼"


# Global instances
prayer_times = PrayerTimes()
crypto_tracker = CryptoTracker()
spotify = SpotifyController()
pomodoro = PomodoroTimer()
party_mode = PartyMode()