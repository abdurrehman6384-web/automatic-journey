"""
╔══════════════════════════════════════════════════════════════╗
║   config.py — RGS AI Core Configuration                      ║
║   (Really Great System AI — formerly RASHEED)                ║
║   Version: 7.0 — Supabase + Google Login + FaceLock + UI     ║
╚══════════════════════════════════════════════════════════════╝

All sensitive values live in .env (NEVER hardcoded here).
On first launch, the user is forced into the ENV EDITOR where they
paste their OWN API tokens.  No developer tokens are bundled.
"""

import os
import sys
import logging
from pathlib import Path
from dotenv import load_dotenv

# ─────────────────────────────────────────────────────────────
#  PATHS
# ─────────────────────────────────────────────────────────────
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
LOG_DIR  = BASE_DIR / "logs"
CACHE_DIR = BASE_DIR / "cache"
MODELS_DIR = BASE_DIR / "models"
AGENTS_DIR = BASE_DIR / "agents"
MODULES_DIR = BASE_DIR / "modules"
ASSETS_DIR = BASE_DIR / "assets"

for _d in (DATA_DIR, LOG_DIR, CACHE_DIR, MODELS_DIR, AGENTS_DIR, MODULES_DIR, ASSETS_DIR):
    _d.mkdir(parents=True, exist_ok=True)

ENV_FILE = BASE_DIR / ".env"
MEMORY_FILE = DATA_DIR / "memory.json"
LICENSE_FILE = DATA_DIR / "license.key"
FACE_MODEL_FILE = DATA_DIR / "face_model.yml"
USER_PROFILE_FILE = DATA_DIR / "profile.json"

# ─────────────────────────────────────────────────────────────
#  IDENTITY
# ─────────────────────────────────────────────────────────────
APP_NAME = "RGS AI"
APP_FULL_NAME = "Really Great System AI"
APP_VERSION = "7.0.0"
APP_TAGLINE = "Your Autonomous AI Operating System"
CREATOR = "Abdurrehman"
MARK_VERSION = "MARK XXVII"

# ─────────────────────────────────────────────────────────────
#  LOAD ENV (if present — on first run it won't be)
# ─────────────────────────────────────────────────────────────
if ENV_FILE.exists():
    load_dotenv(ENV_FILE)

def env(key: str, default: str = "") -> str:
    """Read an env var safely."""
    return os.getenv(key, default).strip()

def env_required(keys):
    """Return list of missing required keys."""
    if isinstance(keys, str):
        keys = [keys]
    return [k for k in keys if not env(k)]

# ─────────────────────────────────────────────────────────────
#  SUPABASE  (license + user auth backend)
# ─────────────────────────────────────────────────────────────
SUPABASE_URL       = env("SUPABASE_URL", "https://avznuwnwkellxyxgyewv.supabase.co")
SUPABASE_ANON_KEY  = env("SUPABASE_ANON_KEY",
                         "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9."
                         "eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImF2em51d253a2VsbHh5eGd5ZXd2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODE2MTcwMjIsImV4cCI6MjA5NzE5MzAyMn0."
                         "hEe0oboIzlY4sEBBwY4NRwUoNe4PX_znaZd3AljXfNY")
SUPABASE_REST_URL  = SUPABASE_URL.rstrip("/") + "/rest/v1/"

# ─────────────────────────────────────────────────────────────
#  GOOGLE OAUTH  (login flow)
# ─────────────────────────────────────────────────────────────
GOOGLE_CLIENT_ID     = env("GOOGLE_CLIENT_ID",
                            "101190322005-mtdqgosrt4js13tv3glbvs1rdb413kn6.apps.googleusercontent.com")
GOOGLE_CLIENT_SECRET = env("GOOGLE_CLIENT_SECRET",
                            "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")
GOOGLE_REDIRECT_URI  = env("GOOGLE_REDIRECT_URI", "http://localhost:8765/callback")
GOOGLE_AUTH_SCOPE    = "openid email profile"

# ─────────────────────────────────────────────────────────────
#  AI PROVIDERS  (user fills these in via ENV EDITOR)
# ─────────────────────────────────────────────────────────────
OPENAI_API_KEY       = env("OPENAI_API_KEY")
ANTHROPIC_API_KEY    = env("ANTHROPIC_API_KEY")
GEMINI_API_KEY       = env("GEMINI_API_KEY")
GROQ_API_KEY         = env("GROQ_API_KEY")
MISTRAL_API_KEY      = env("MISTRAL_API_KEY")
DEEPSEEK_API_KEY     = env("DEEPSEEK_API_KEY")
TOGETHER_API_KEY     = env("TOGETHER_API_KEY")
OPENROUTER_API_KEY   = env("OPENROUTER_API_KEY")
PERPLEXITY_API_KEY   = env("PERPLEXITY_API_KEY")
COHERE_API_KEY       = env("COHERE_API_KEY")
HUGGINGFACE_TOKEN    = env("HUGGINGFACE_TOKEN")
REPLICATE_API_TOKEN  = env("REPLICATE_API_TOKEN")
ZHIPU_API_KEY        = env("ZHIPU_API_KEY")   # GLM family
MOONSHOT_API_KEY     = env("MOONSHOT_API_KEY")
FIREWORKS_API_KEY    = env("FIREWORKS_API_KEY")

# Optional provider sub-tokens
BINANCE_API_KEY      = env("BINANCE_API_KEY")
BINANCE_SECRET       = env("BINANCE_SECRET")
TELEGRAM_BOT_TOKEN   = env("TELEGRAM_BOT_TOKEN")
TELEGRAM_CHAT_ID     = env("TELEGRAM_CHAT_ID")
NEWS_API_KEY         = env("NEWS_API_KEY")
WEATHER_API_KEY      = env("WEATHER_API_KEY")
ALPHA_VANTAGE_KEY    = env("ALPHA_VANTAGE_KEY")
GITHUB_TOKEN         = env("GITHUB_TOKEN")
HUGGINGFACE_HUB_TOKEN = env("HUGGINGFACE_HUB_TOKEN")

# ─────────────────────────────────────────────────────────────
#  DEFAULTS
# ─────────────────────────────────────────────────────────────
DEFAULT_MODEL        = env("DEFAULT_MODEL", "gpt-4o-mini")
DEFAULT_PROVIDER     = env("DEFAULT_PROVIDER", "openai")
DEFAULT_TEMPERATURE  = float(env("TEMPERATURE", "0.7"))
DEFAULT_MAX_TOKENS   = int(env("MAX_TOKENS", "4096"))

# ─────────────────────────────────────────────────────────────
#  FEATURE FLAGS
# ─────────────────────────────────────────────────────────────
ENABLE_FACE_LOCK     = env("ENABLE_FACE_LOCK", "true").lower() == "true"
ENABLE_GOOGLE_LOGIN  = env("ENABLE_GOOGLE_LOGIN", "true").lower() == "true"
ENABLE_LICENSE_CHECK = env("ENABLE_LICENSE_CHECK", "true").lower() == "true"
ENABLE_SELF_UPGRADE  = env("ENABLE_SELF_UPGRADE", "true").lower() == "true"
DRY_RUN_TRADING      = env("DRY_RUN_TRADING", "true").lower() == "true"

# ─────────────────────────────────────────────────────────────
#  SECURITY
# ─────────────────────────────────────────────────────────────
ENCRYPTION_KEY = env("ENCRYPTION_KEY")  # Fernet key — generated on first run if empty
VPN_CLI_PATH   = env("VPN_CLI_PATH", "")

# ─────────────────────────────────────────────────────────────
#  LOGGER
# ─────────────────────────────────────────────────────────────
class _Logger:
    def __init__(self):
        self._log = logging.getLogger("RGS_AI")
        self._log.setLevel(logging.DEBUG)
        if not self._log.handlers:
            fh = logging.FileHandler(LOG_DIR / "rgs_ai.log", encoding="utf-8")
            fh.setFormatter(logging.Formatter(
                "%(asctime)s [%(levelname)s] %(message)s"))
            self._log.addHandler(fh)
            ch = logging.StreamHandler(sys.stdout)
            ch.setLevel(logging.INFO)
            ch.setFormatter(logging.Formatter("[%(levelname)s] %(message)s"))
            self._log.addHandler(ch)

    def debug(self, m, *a, **k): self._log.debug(m, *a, **k)
    def info(self, m, *a, **k):  self._log.info(m, *a, **k)
    def warn(self, m, *a, **k):  self._log.warning(m, *a, **k)
    def error(self, m, *a, **k): self._log.error(m, *a, **k)
    def critical(self, m, *a, **k): self._log.critical(m, *a, **k)
    def exception(self, m, *a, **k): self._log.exception(m, *a, **k)

logger = _Logger()

# ─────────────────────────────────────────────────────────────
#  ENV BLUEPRINT  — used by env_manager to render the editor
#  Each entry: (key, label, category, required, is_secret, default, hint)
# ─────────────────────────────────────────────────────────────
ENV_BLUEPRINT = [
    # ── Supabase ───────────────────────────────────────────
    ("SUPABASE_URL",         "Supabase Project URL",        "Supabase",  True,  False,
     "https://avznuwnwkellxyxgyewv.supabase.co", "Your Supabase project URL"),
    ("SUPABASE_ANON_KEY",    "Supabase Anon Key",           "Supabase",  True,  True,
     "", "Public anon key from Supabase API settings"),
    ("SUPABASE_SERVICE_KEY", "Supabase Service Role Key",   "Supabase",  False, True,
     "", "Server-only key — leave blank for client-only mode"),

    # ── Google OAuth ───────────────────────────────────────
    ("GOOGLE_CLIENT_ID",     "Google OAuth Client ID",      "Google",    True,  False,
     "101190322005-mtdqgosrt4js13tv3glbvs1rdb413kn6.apps.googleusercontent.com",
     "From Google Cloud Console → APIs & Services → Credentials"),
    ("GOOGLE_CLIENT_SECRET", "Google OAuth Client Secret",  "Google",    True,  True,
     "", "From Google Cloud Console — NEVER share this"),
    ("GOOGLE_REDIRECT_URI",  "Google Redirect URI",         "Google",    False, False,
     "http://localhost:8765/callback", "Must match the URI in Google Console"),

    # ── LLM Providers ──────────────────────────────────────
    ("OPENAI_API_KEY",       "OpenAI API Key",              "AI Providers", False, True,
     "", "sk-... — for GPT-4o, GPT-4, GPT-3.5"),
    ("ANTHROPIC_API_KEY",    "Anthropic API Key",           "AI Providers", False, True,
     "", "sk-ant-... — for Claude 3.5, Claude 3 Opus"),
    ("GEMINI_API_KEY",       "Google Gemini API Key",       "AI Providers", False, True,
     "", "AIza... — for Gemini 1.5 Pro/Flash"),
    ("GROQ_API_KEY",         "Groq API Key",                "AI Providers", False, True,
     "", "gsk_... — fast Llama/Mixtral inference"),
    ("MISTRAL_API_KEY",      "Mistral API Key",             "AI Providers", False, True,
     "", "For Mistral Large/Medium/Small"),
    ("DEEPSEEK_API_KEY",     "DeepSeek API Key",            "AI Providers", False, True,
     "", "For DeepSeek V3 / R1"),
    ("TOGETHER_API_KEY",     "Together AI API Key",         "AI Providers", False, True,
     "", "Open-source models via Together"),
    ("OPENROUTER_API_KEY",   "OpenRouter API Key",          "AI Providers", False, True,
     "", "sk-or-... — gateway to 100+ models"),
    ("PERPLEXITY_API_KEY",   "Perplexity API Key",          "AI Providers", False, True,
     "", "pplx-... — for online-augmented chat"),
    ("COHERE_API_KEY",       "Cohere API Key",              "AI Providers", False, True,
     "", "For Command R+"),
    ("HUGGINGFACE_TOKEN",    "Hugging Face Token",          "AI Providers", False, True,
     "", "hf_... — for inference + model downloads"),
    ("REPLICATE_API_TOKEN",  "Replicate API Token",         "AI Providers", False, True,
     "", "r8_... — for image/video/audio models"),
    ("ZHIPU_API_KEY",        "Zhipu (GLM) API Key",         "AI Providers", False, True,
     "", "For GLM-4 / GLM-4V / CogView"),
    ("MOONSHOT_API_KEY",     "Moonshot (Kimi) API Key",     "AI Providers", False, True,
     "", "For Kimi K1.5 / Moonshot"),
    ("FIREWORKS_API_KEY",    "Fireworks AI API Key",        "AI Providers", False, True,
     "", "For fast serverless inference"),

    # ── Default Model ──────────────────────────────────────
    ("DEFAULT_PROVIDER",     "Default AI Provider",         "Defaults",  False, False,
     "openai", "openai | anthropic | gemini | groq | mistral | deepseek | zhipu | openrouter"),
    ("DEFAULT_MODEL",        "Default Model Name",          "Defaults",  False, False,
     "gpt-4o-mini", "e.g. gpt-4o-mini, claude-3-5-sonnet, gemini-1.5-flash"),
    ("TEMPERATURE",          "Temperature (0.0–1.5)",       "Defaults",  False, False,
     "0.7", "Creativity: 0=deterministic, 1.5=chaotic"),
    ("MAX_TOKENS",           "Max Tokens per Response",     "Defaults",  False, False,
     "4096", "Max output tokens per turn"),

    # ── Feature Flags ──────────────────────────────────────
    ("ENABLE_FACE_LOCK",     "Enable Face Lock on Startup", "Features",  False, False,
     "true", "true / false"),
    ("ENABLE_GOOGLE_LOGIN",  "Enable Google Login",         "Features",  False, False,
     "true", "true / false"),
    ("ENABLE_LICENSE_CHECK", "Enable License Verification", "Features",  False, False,
     "true", "true / false"),
    ("ENABLE_SELF_UPGRADE",  "Enable Self-Upgrade",         "Features",  False, False,
     "true", "true / false"),

    # ── Integrations ───────────────────────────────────────
    ("GITHUB_TOKEN",         "GitHub Personal Access Token","Integrations", False, True,
     "", "ghp_... — for repo search/clone via API"),
    ("TELEGRAM_BOT_TOKEN",   "Telegram Bot Token",          "Integrations", False, True,
     "", "From @BotFather"),
    ("TELEGRAM_CHAT_ID",     "Telegram Chat ID",            "Integrations", False, False,
     "", "Your personal chat ID for remote control"),
    ("NEWS_API_KEY",         "News API Key",                "Integrations", False, True,
     "", "From newsapi.org"),
    ("WEATHER_API_KEY",      "OpenWeatherMap API Key",      "Integrations", False, True,
     "", "From openweathermap.org"),
    ("ALPHA_VANTAGE_KEY",    "Alpha Vantage API Key",       "Integrations", False, True,
     "", "Stock/forex/crypto data"),
    ("BINANCE_API_KEY",      "Binance API Key",             "Integrations", False, True,
     "", "For quant trading module"),
    ("BINANCE_SECRET",       "Binance Secret",              "Integrations", False, True,
     "", "Binance API secret"),
    ("HUGGINGFACE_HUB_TOKEN","HF Hub Token (downloads)",    "Integrations", False, True,
     "", "For pulling models locally"),

    # ── Security ───────────────────────────────────────────
    ("ENCRYPTION_KEY",       "Fernet Encryption Key",       "Security",  False, True,
     "", "Leave blank — auto-generated on first run"),
    ("VPN_CLI_PATH",         "Optional VPN CLI Path",       "Security",  False, False,
     "", "Path to wireguard/openvpn CLI if using security_ghost"),
]

# Convenience list of categories for the UI
ENV_CATEGORIES = []
seen = set()
for _e in ENV_BLUEPRINT:
    if _e[2] not in seen:
        ENV_CATEGORIES.append(_e[2])
        seen.add(_e[2])

def env_is_configured() -> bool:
    """Return True only if required env vars are set."""
    required = [k for k, _, _, req, *_ in ENV_BLUEPRINT if req]
    return all(env(k) for k in required)


if __name__ == "__main__":
    print(f"{APP_NAME} v{APP_VERSION} — config OK")
    print(f"  Base dir:    {BASE_DIR}")
    print(f"  Env file:    {ENV_FILE}  ({'present' if ENV_FILE.exists() else 'MISSING'})")
    print(f"  Configured:  {env_is_configured()}")
    print(f"  Categories:  {ENV_CATEGORIES}")
    print(f"  Total env keys in blueprint: {len(ENV_BLUEPRINT)}")
