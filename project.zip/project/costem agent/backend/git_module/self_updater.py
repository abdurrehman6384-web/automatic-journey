"""RASHEED Self-Updater — git pull + restart"""
import os
import sys
import subprocess
import time


class SelfUpdater:

    @staticmethod
    def update() -> str:
        try:
            subprocess.run(["git", "stash"], shell=True, capture_output=True, timeout=10)
            result = subprocess.run(["git", "pull", "origin", "main"], shell=True, capture_output=True, text=True, timeout=30)
            
            if "Already up to date" in result.stdout:
                return "✅ Already running latest version!"
            
            # Install new dependencies
            subprocess.run([sys.executable, "-m", "pip", "install", "-r", "requirements.txt", "--quiet"], timeout=60)
            
            return "✅ Updated successfully! Restarting in 3 seconds..."
        except Exception as e:
            return f"❌ Update failed: {e}"

    @staticmethod
    def restart():
        """Restart the application"""
        time.sleep(2)
        os.execv(sys.executable, [sys.executable] + sys.argv)
