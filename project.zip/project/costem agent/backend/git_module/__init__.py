from git_module.self_updater import SelfUpdater
