"""RASHEED Settings — Loads .env and manages config"""
import os
from pathlib import Path
from dotenv import load_dotenv

ROOT_DIR = Path(__file__).parent.parent
load_dotenv(ROOT_DIR / ".env")


class Settings:

    def __init__(self):
        # API Keys
        self.GEMINI_KEY = os.getenv("GEMINI_API_KEY", "")
        self.GROQ_KEY = os.getenv("GROQ_API_KEY", "")
        self.DEEPSEEK_KEY = os.getenv("DEEPSEEK_API_KEY", "")
        self.TOGETHER_KEY = os.getenv("TOGETHER_API_KEY", "")
        self.MISTRAL_KEY = os.getenv("MISTRAL_API_KEY", "")
        
        # App Config
        self.creator = os.getenv("CREATOR_NAME", "Abdurrehman")
        self.city = os.getenv("DEFAULT_CITY", "Karachi")
        self.face_lock = os.getenv("FACE_LOCK_ENABLED", "true").lower() == "true"
        
        # Audio
        self.mic_rate = 16000
        self.spk_rate = 24000
        self.frames = int(self.mic_rate * 20 / 1000)
        
        # Paths
        self.data_dir = ROOT_DIR / "data"
        self.logs_dir = ROOT_DIR / "logs"
        self.data_dir.mkdir(exist_ok=True)
        self.logs_dir.mkdir(exist_ok=True)


_settings = None


def get_settings() -> Settings:
    global _settings
    if _settings is None:
        _settings = Settings()
    return _settings
