"""RASHEED System Control Module"""
import subprocess, os, time, pyautogui, webbrowser, psutil, mss, datetime
from pathlib import Path

DESKTOP = str(Path.home() / "Desktop")
APP_ALIASES = {
    "chrome": "chrome", "notepad": "notepad", "calculator": "calc", "cmd": "cmd",
    "vscode": "code", "whatsapp": "shell:AppsFolder\\5319275A.WhatsAppDesktop_cv1g1gvanyjgm!App",
    "spotify": "shell:AppsFolder\\SpotifyAB.SpotifyMusic_zpdnekdrzrea0!Spotify",
    "vlc": "vlc", "discord": "discord", "steam": "steam", "zoom": "zoom",
}
PS = r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe"


def open_app(app_name: str) -> str:
    name = app_name.lower().strip()
    search = APP_ALIASES.get(name, name)
    try:
        if search.startswith("shell:"):
            subprocess.Popen([PS, "-NoProfile", "-WindowStyle", "Hidden", "-Command", f"Start-Process '{search}'"], creationflags=subprocess.CREATE_NO_WINDOW)
        else:
            subprocess.Popen(["cmd", "/c", "start", "", search], shell=False, creationflags=subprocess.CREATE_NO_WINDOW)
        return f"✅ {app_name} khol diya boss!"
    except: return f"❌ {app_name} nahi khul raha."


def close_app(app_name: str) -> str:
    procs = {"chrome": "chrome.exe", "vscode": "Code.exe", "notepad": "notepad.exe", "discord": "Discord.exe"}
    proc = procs.get(app_name.lower(), f"{app_name}.exe")
    try:
        subprocess.run(["taskkill", "/f", "/im", proc], capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW)
        return f"🛑 {app_name} band kar diya!"
    except: return f"❌ {app_name} band nahi ho raha."


def type_text(text: str) -> str:
    time.sleep(0.3)
    pyautogui.write(text, interval=0.02)
    return f"✅ Likh diya: {text}"


def press_key(key: str) -> str:
    pyautogui.press(key)
    return f"✅ {key} press kiya"


def hotkey(keys: str) -> str:
    k = keys.split(",")
    pyautogui.hotkey(*k)
    return f"✅ Shortcut {keys} press kiya"


def click_at(x: int, y: int) -> str:
    pyautogui.click(x, y)
    return f"✅ Click kiya ({x}, {y})"


def scroll(direction: str, amount: int=3) -> str:
    pyautogui.scroll(amount if direction == "up" else -amount)
    return f"✅ Scroll {direction}"


def search_google(query: str) -> str:
    webbrowser.open(f"https://www.google.com/search?q={query.replace(' ', '+')}")
    return f"✅ Google par '{query}' search kiya!"


def play_youtube(query: str) -> str:
    webbrowser.open(f"https://www.youtube.com/results?search_query={query.replace(' ', '+')}")
    return f"✅ YouTube par '{query}' search kiya!"


def take_screenshot() -> str:
    ts = datetime.datetime.now().strftime("%H%M%S")
    path = os.path.join(DESKTOP, f"screenshot_{ts}.png")
    with mss.mss() as sct: sct.shot(output=path)
    return f"✅ Screenshot liya: {path}"


def get_weather(city: str="Karachi") -> str:
    import requests
    try:
        r = requests.get(f"https://wttr.in/{city}?format=3", timeout=5)
        return f"🌤️ {r.text.strip()}"
    except: return "❌ Weather nahi mila"


def get_system_info() -> str:
    b = psutil.sensors_battery()
    bat = f"{b.percent}% {'⚡' if b.power_plugged else '🔋'}" if b else "N/A"
    return f"CPU: {psutil.cpu_percent()}% | RAM: {psutil.virtual_memory().percent}% | Battery: {bat}"


def volume_up(steps: int=5) -> str:
    for _ in range(steps): pyautogui.press("volumeup")
    return "🔊 Volume badha diya!"


def volume_down(steps: int=5) -> str:
    for _ in range(steps): pyautogui.press("volumedown")
    return "🔉 Volume kam kar diya!"


def volume_mute() -> str:
    pyautogui.press("volumemute")
    return "🔇 Mute toggle kiya!"


def shutdown_pc() -> str:
    os.system("shutdown /s /t 10")
    return "⚠️ PC 10 sec mein band hoga!"


def restart_pc() -> str:
    os.system("shutdown /r /t 5")
    return "🔄 PC restart ho raha hai!"


def lock_pc() -> str:
    os.system("rundll32.exe user32.dll,LockWorkStation")
    return "🔒 PC lock ho gaya!"


def run_cmd(command: str) -> str:
    try:
        r = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=10)
        return r.stdout[:300] if r.stdout else "✅ Command chala diya"
    except Exception as e: return f"❌ Error: {e}"


def calculate(expression: str) -> str:
    try:
        return f"= {eval(expression.replace('^', '**'), {'__builtins__': {}}, {})}"
    except: return "❌ Calculation error"
