# typing_engine.py — RGS_AI Advanced Typing Engine v6.0
import pyautogui
import pyperclip
import keyboard
import time
import subprocess
from ..error_handler import safe_execute, logger

pyautogui.FAILSAFE = True
pyautogui.PAUSE = 0.01


class TypingEngine:
    def __init__(self):
        self.default_delay = 0.03
        self.human_mode = True

    def type_simple(self, text: str, delay: float = None) -> str:
        try:
            d = delay or self.default_delay
            time.sleep(0.3)
            pyautogui.write(text, interval=d)
            return f"✅ Typed: {text[:50]}"
        except Exception as e:
            return f"❌ Type error: {e}"

    def type_unicode(self, text: str) -> str:
        """Unicode typing — Urdu, Hindi, Arabic support"""
        try:
            time.sleep(0.3)
            keyboard.write(text, delay=0.03)
            return f"✅ Unicode typed: {text[:50]}"
        except Exception:
            try:
                old_clip = ""
                try:
                    old_clip = pyperclip.paste()
                except Exception:
                    pass
                pyperclip.copy(text)
                time.sleep(0.2)
                pyautogui.hotkey('ctrl', 'v')
                time.sleep(0.2)
                try:
                    pyperclip.copy(old_clip)
                except Exception:
                    pass
                return f"✅ Pasted: {text[:50]}"
            except Exception as e:
                return f"❌ Unicode type error: {e}"

    def type_smart(self, text: str) -> str:
        """Auto-detect: Unicode or ASCII"""
        has_unicode = any(ord(c) > 127 for c in text)
        if has_unicode:
            return self.type_unicode(text)
        return self.type_simple(text)

    def type_with_enter(self, text: str) -> str:
        result = self.type_smart(text)
        time.sleep(0.1)
        pyautogui.press('enter')
        return result + " + Enter"

    def type_in_notepad(self, text: str) -> str:
        try:
            subprocess.Popen(['notepad.exe'])
            time.sleep(1.5)
            return self.type_smart(text)
        except Exception as e:
            return f"❌ Notepad error: {e}"

    def fill_form(self, fields: list) -> str:
        try:
            for tabs, text in fields:
                for _ in range(tabs):
                    pyautogui.press('tab')
                    time.sleep(0.1)
                self.type_smart(text)
                time.sleep(0.2)
            return f"✅ Form filled: {len(fields)} fields"
        except Exception as e:
            return f"❌ Form fill error: {e}"

    def select_all_and_type(self, text: str) -> str:
        pyautogui.hotkey('ctrl', 'a')
        time.sleep(0.2)
        return self.type_smart(text)

    def type_search(self, query: str, search_bar_key: str = None) -> str:
        if search_bar_key:
            pyautogui.hotkey(*search_bar_key.split('+'))
            time.sleep(0.5)
        self.type_smart(query)
        time.sleep(0.2)
        pyautogui.press('enter')
        return f"✅ Searched: {query}"


typer = TypingEngine()