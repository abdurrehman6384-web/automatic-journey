# universe_mode.py — NASA API, ISS Tracker, Satellite Imagery, Meteor Showers
import os
import requests
import base64
from datetime import datetime
from ..config import NASA_API_KEY, DATA_DIR, logger
from ..error_handler import safe_execute


class UniverseMode:

    # ── 1. Live Satellite Imagery ────────────────────
    @safe_execute(max_retries=1)
    def get_satellite_image(self, lat: float = 24.86, lon: float = 67.01) -> str:
        """NASA Earth API se satellite image download karo"""
        if not NASA_API_KEY:
            return "❌ NASA API Key not set in .env"

        url = "https://api.nasa.gov/planetary/earth/imagery"
        params = {
            "lon": lon,
            "lat": lat,
            "dim": 0.15,       # Image width in degrees
            "date": datetime.now().strftime("%Y-%m-%d"),
            "cloud_score": "True",
            "api_key": NASA_API_KEY
        }

        r = requests.get(url, params=params, timeout=15)

        if r.status_code == 200:
            img_path = str(DATA_DIR / "satellite_view.png")
            with open(img_path, 'wb') as f:
                f.write(r.content)

            # Cloud score check
            try:
                data = r.json()
                cloud = data.get("cloud_score", "N/A")
                return f"🛰️ Satellite image saved! Cloud cover: {cloud}% | Location: {lat}, {lon}"
            except Exception:
                return f"🛰️ Satellite image saved at: {img_path}"

        elif r.status_code == 404:
            return "❌ Satellite imagery not available for this location. Try different coordinates."
        else:
            return f"❌ NASA API error: {r.status_code} — {r.text[:200]}"

    # ── 2. Enhanced Satellite with City Names ────────
    CITY_COORDS = {
        "karachi": (24.86, 67.01),
        "lahore": (31.55, 74.35),
        "islamabad": (33.69, 73.04),
        "delhi": (28.61, 77.21),
        "mumbai": (19.08, 72.88),
        "dubai": (25.20, 55.27),
        "london": (51.51, -0.13),
        "new york": (40.71, -74.01),
        "tokyo": (35.68, 139.69),
        "mecca": (21.39, 39.86),
        "medina": (24.47, 39.61),
        "istanbul": (41.01, 28.98),
        "paris": (48.86, 2.35),
        "beijing": (39.90, 116.40),
        "sydney": (-33.87, 151.21),
        "riyadh": (24.71, 46.68),
        "cairo": (30.04, 31.24),
        "kuala lumpur": (3.14, 101.69),
        "singapore": (1.35, 103.82),
        "dhaka": (23.81, 90.41),
    }

    def get_city_satellite(self, city: str) -> str:
        """City name se satellite image lo"""
        city_lower = city.lower().strip()
        coords = self.CITY_COORDS.get(city_lower)

        if not coords:
            # Try partial match
            for name, coord in self.CITY_COORDS.items():
                if city_lower in name or name in city_lower:
                    coords = coord
                    break

        if not coords:
            return f"❌ City '{city}' not found. Available: {', '.join(list(self.CITY_COORDS.keys())[:10])}..."

        return self.get_satellite_image(coords[0], coords[1])

    # ── 3. ISS Tracker (Live Location) ──────────────
    @safe_execute(max_retries=1)
    def track_iss(self) -> str:
        """International Space Station ka live location"""
        # Current position
        pos_url = "http://api.open-notify.org/iss-now.json"
        pos_r = requests.get(pos_url, timeout=5)
        pos_data = pos_r.json()

        if pos_data["message"] != "success":
            return "❌ ISS tracking failed"

        iss_pos = pos_data["iss_position"]
        lat = iss_pos["latitude"]
        lon = iss_pos["longitude"]

        # Pass times for your location (Karachi default)
        pass_url = "http://api.open-notify.org/iss-pass.json"
        pass_params = {"lat": 24.86, "lon": 67.01}
        try:
            pass_r = requests.get(pass_url, params=pass_params, timeout=5)
            if pass_r.status_code == 200:
                passes = pass_r.json().get("response", [])
                next_pass = ""
                if passes:
                    from datetime import datetime
                    pass_time = datetime.fromtimestamp(passes[0]["risetime"])
                    duration = passes[0]["duration"]
                    next_pass = f"\n🕐 Next visible pass (Karachi): {pass_time.strftime('%d %b %Y, %I:%M %p')} for {duration}s"
            else:
                next_pass = ""
        except Exception:
            next_pass = ""

        # Check if over land/ocean
        ocean_check = ""
        try:
            geocode_url = f"https://api.bigdatacloud.net/data/reverse-geocode-client?latitude={lat}&longitude={lon}&localityLanguage=en"
            geo_r = requests.get(geocode_url, timeout=5)
            if geo_r.status_code == 200:
                geo_data = geo_r.json()
                country = geo_data.get("countryName", "Ocean")
                if country:
                    ocean_check = f"\n📍 Currently over: {country}"
                else:
                    ocean_check = "\n📍 Currently over: Ocean/Sea"
        except Exception:
            pass

        return (
            f"🚀 ISS Live Location:\n"
            f"   Latitude: {lat}\n"
            f"   Longitude: {lon}"
            f"{ocean_check}"
            f"{next_pass}"
        )

    # ── 4. People in Space Right Now ─────────────────
    @safe_execute(max_retries=1)
    def people_in_space(self) -> str:
        """Abhi space mein kitne log hain?"""
        url = "http://api.open-notify.org/astros.json"
        r = requests.get(url, timeout=5)
        data = r.json()

        if data["message"] != "success":
            return "❌ Failed to fetch space crew data"

        total = data["number"]
        people = data["people"]

        iss_crew = [p["name"] for p in people if p["craft"] == "ISS"]
        other_crew = [p["name"] for p in people if p["craft"] != "ISS"]

        result = f"👨‍🚀 People in Space: {total}\n\n"
        if iss_crew:
            result += f"🚀 ISS Crew ({len(iss_crew)}):\n"
            for name in iss_crew:
                result += f"   • {name}\n"
        if other_crew:
            result += f"\n🛸 Other Spacecraft ({len(other_crew)}):\n"
            for name in other_crew:
                result += f"   • {name}\n"

        return result

    # ── 5. NASA Astronomy Picture of the Day ─────────
    @safe_execute(max_retries=1)
    def get_apod(self, set_wallpaper: bool = False) -> str:
        """NASA ka aaj ka best space image"""
        if not NASA_API_KEY:
            return "❌ NASA API Key not set"

        url = "https://api.nasa.gov/planetary/apod"
        params = {"api_key": NASA_API_KEY}

        r = requests.get(url, params=params, timeout=10)

        if r.status_code != 200:
            return f"❌ NASA APOD error: {r.status_code}"

        data = r.json()
        title = data.get("title", "Unknown")
        explanation = data.get("explanation", "")[:300]
        img_url = data.get("hdurl") or data.get("url", "")
        media_type = data.get("media_type", "image")

        if media_type == "video":
            return f"🎥 Today's Space Video: {title}\n📺 Watch: {img_url}\n📝 {explanation}..."

        # Download image
        if img_url:
            try:
                img_r = requests.get(img_url, timeout=20)
                if img_r.status_code == 200:
                    img_path = str(DATA_DIR / "nasa_apod.jpg")
                    with open(img_path, 'wb') as f:
                        f.write(img_r.content)

                    if set_wallpaper:
                        import ctypes
                        ctypes.windll.user32.SystemParametersInfoW(20, 0, img_path, 3)
                        return f"🌌 APOD Wallpaper set! Title: {title}\n📝 {explanation}..."

                    return f"🌌 NASA APOD: {title}\n📸 Saved: {img_path}\n📝 {explanation}..."
            except Exception as e:
                pass

        return f"🌌 NASA APOD: {title}\n📝 {explanation}..."

    # ── 6. Asteroid & Near-Earth Object Tracker ──────
    @safe_execute(max_retries=1)
    def check_asteroids(self) -> str:
        """Aaj koi asteroid Earth ke paas se ja raha hai?"""
        if not NASA_API_KEY:
            return "❌ NASA API Key not set"

        today = datetime.now().strftime("%Y-%m-%d")
        url = "https://api.nasa.gov/neo/rest/v1/feed"
        params = {
            "start_date": today,
            "end_date": today,
            "api_key": NASA_API_KEY
        }

        r = requests.get(url, params=params, timeout=10)

        if r.status_code != 200:
            return f"❌ Asteroid API error: {r.status_code}"

        data = r.json()
        neos = data.get("near_earth_objects", {}).get(today, [])

        if not neos:
            return "☄️ No asteroids near Earth today. Safe!"

        result = f"☄️ Asteroids Near Earth Today ({len(neos)}):\n\n"

        for i, neo in enumerate(neos[:5], 1):
            name = neo.get("name", "Unknown")
            diameter = neo.get("estimated_diameter", {}).get("meters", {})
            min_d = diameter.get("estimated_diameter_min", 0)
            max_d = diameter.get("estimated_diameter_max", 0)
            hazardous = "🔴 HAZARDOUS" if neo.get("is_potentially_hazardous_asteroid") else "🟢 Safe"

            approach = neo.get("close_approach_data", [{}])[0]
            velocity = approach.get("relative_velocity", {}).get("kilometers_per_hour", "N/A")
            distance = approach.get("miss_distance", {}).get("kilometers", "N/A")

            result += (
                f"{i}. {name}\n"
                f"   Size: {min_d:.0f}m - {max_d:.0f}m\n"
                f"   Speed: {float(velocity):,.0f} km/h\n"
                f"   Miss Distance: {float(distance):,.0f} km\n"
                f"   Status: {hazardous}\n\n"
            )

        return result

    # ── 7. Mars Weather (Perseverance Rover) ─────────
    @safe_execute(max_retries=1)
    def mars_weather(self) -> str:
        """NASA Mars Rover se latest Mars weather data"""
        # NASA InSight API (archived but still accessible)
        url = "https://api.nasa.gov/insight_weather/"
        params = {
            "api_key": NASA_API_KEY,
            "feedtype": "json",
            "ver": "1.0"
        }

        try:
            r = requests.get(url, params=params, timeout=10)
            if r.status_code == 200:
                data = r.json()
                sols = data.get("sol_keys", [])

                if not sols:
                    return "🔴 Mars weather data unavailable (InSight mission ended)."

                latest_sol = sols[-1]
                sol_data = data[latest_sol]

                temp = sol_data.get("AT", {})
                avg_temp = temp.get("av", "N/A")
                min_temp = temp.get("mn", "N/A")
                max_temp = temp.get("mx", "N/A")

                pressure = sol_data.get("PRE", {}).get("av", "N/A")
                wind = sol_data.get("HWS", {}).get("av", "N/A")

                season = sol_data.get("Season", "N/A")

                return (
                    f"🔴 Mars Weather (Sol {latest_sol}):\n"
                    f"🌡️ Avg Temp: {avg_temp}°C\n"
                    f"   Min: {min_temp}°C | Max: {max_temp}°C\n"
                    f"💨 Wind: {wind} m/s\n"
                    f"📊 Pressure: {pressure} Pa\n"
                    f"📅 Season: {season}"
                )
            else:
                return "🔴 Mars weather API unavailable right now."
        except Exception as e:
            return f"❌ Mars weather error: {e}"

    # ── 8. NASA Mars Rover Photos ────────────────────
    @safe_execute(max_retries=1)
    def mars_rover_photo(self, rover: str = "curiosity") -> str:
        """Mars rover ki latest photos download karo"""
        if not NASA_API_KEY:
            return "❌ NASA API Key not set"

        url = f"https://api.nasa.gov/mars-photos/api/v1/rovers/{rover}/latest_photos"
        params = {"api_key": NASA_API_KEY}

        r = requests.get(url, params=params, timeout=10)

        if r.status_code != 200:
            return f"❌ Rover API error: {r.status_code}"

        data = r.json()
        photos = data.get("latest_photos", [])

        if not photos:
            return f"🔴 No latest photos from {rover}"

        photo = photos[0]
        img_url = photo.get("img_src", "")
        camera = photo.get("camera", {}).get("full_name", "Unknown")
        earth_date = photo.get("earth_date", "Unknown")
        sol = photo.get("sol", "Unknown")

        # Download first photo
        try:
            img_r = requests.get(img_url, timeout=20)
            if img_r.status_code == 200:
                img_path = str(DATA_DIR / f"mars_{rover}_photo.jpg")
                with open(img_path, 'wb') as f:
                    f.write(img_r.content)
                return (
                    f"🔴 Mars {rover.title()} Photo!\n"
                    f"📸 Camera: {camera}\n"
                    f"📅 Date: {earth_date} (Sol {sol})\n"
                    f"💾 Saved: {img_path}"
                )
        except Exception:
            pass

        return f"🔴 Mars photo available at: {img_url}"

    # ── 9. Meteor Shower & Astronomical Events ──────
    @safe_execute(max_retries=1)
    def check_meteor_showers(self) -> str:
        """Upcoming meteor showers aur astronomical events"""
        # Major annual meteor showers data
        from datetime import datetime

        current_month = datetime.now().month

        showers = {
            1: ("Quadrantids", "Jan 3-4", "Up to 120/hour"),
            4: ("Lyrids", "Apr 22-23", "Up to 20/hour"),
            5: ("Eta Aquarids", "May 5-6", "Up to 50/hour"),
            7: ("Delta Aquarids", "Jul 28-29", "Up to 20/hour"),
            8: ("Perseids", "Aug 11-13", "Up to 100/hour 🔥"),
            10: ("Orionids", "Oct 20-21", "Up to 20/hour"),
            11: ("Leonids", "Nov 17-18", "Up to 15/hour"),
            12: ("Geminids", "Dec 13-14", "Up to 150/hour 🔥"),
        }

        result = "☄️ Meteor Shower Calendar:\n\n"

        # Show current + next 3 months
        months_to_show = [(current_month + i - 1) % 12 + 1 for i in range(4)]

        for m in months_to_show:
            month_name = datetime(2024, m, 1).strftime("%B")
            if m in showers:
                name, dates, rate = showers[m]
                result += f"📅 {month_name}: {name}\n   Dates: {dates}\n   Rate: {rate}\n\n"
            else:
                result += f"📅 {month_name}: No major showers\n\n"

        # Check if any shower is tonight
        today = datetime.now().strftime("%b %-d")
        for m, (name, dates, rate) in showers.items():
            if str(current_month).zfill(2) == str(m).zfill(2):
                day = datetime.now().day
                if 1 <= day <= 5 and m == 1:
                    result += "⚠️ Quadrantids tonight! Look up! 🔥"
                elif 10 <= day <= 14 and m == 8:
                    result += "⚠️ Perseids tonight! Look up! 🔥"
                elif 11 <= day <= 15 and m == 12:
                    result += "⚠️ Geminids tonight! Look up! 🔥"

        return result

    # ── 10. SpaceX Launch Tracker ────────────────────
    @safe_execute(max_retries=1)
    def spacex_launches(self) -> str:
        """Upcoming SpaceX launches"""
        url = "https://api.spacexdata.com/v4/launches/upcoming"
        r = requests.get(url, timeout=10)

        if r.status_code != 200:
            return "❌ SpaceX API error"

        launches = r.json()[:5]

        if not launches:
            return "🚀 No upcoming SpaceX launches found."

        result = "🚀 Upcoming SpaceX Launches:\n\n"
        for i, launch in enumerate(launches, 1):
            name = launch.get("name", "Unknown")
            date_utc = launch.get("date_utc", "TBD")[:10]
            flight_number = launch.get("flight_number", "?")
            rocket_id = launch.get("rocket", "")

            result += (
                f"{i}. {name}\n"
                f"   Flight #{flight_number}\n"
                f"   Date: {date_utc}\n\n"
            )

        return result

    # ── 11. Earth Polychromatic Imaging Camera ───────
    @safe_execute(max_retries=1)
    def epic_earth_image(self) -> str:
        """NASA EPIC - Full Earth image from DSCOVR satellite"""
        if not NASA_API_KEY:
            return "❌ NASA API Key not set"

        url = "https://api.nasa.gov/EPIC/api/natural"
        params = {"api_key": NASA_API_KEY}

        r = requests.get(url, params=params, timeout=10)

        if r.status_code != 200:
            return f"❌ EPIC API error: {r.status_code}"

        data = r.json()

        if not data:
            return "🌍 EPIC image not available right now"

        latest = data[0]
        image_name = latest.get("image", "")
        date_str = latest.get("date", "")[:10].replace("-", "/")

        if image_name and date_str:
            img_url = f"https://api.nasa.gov/EPIC/archive/natural/{date_str}/png/{image_name}.png"
            params_with_key = {"api_key": NASA_API_KEY}

            try:
                img_r = requests.get(img_url, params=params_with_key, timeout=20)
                if img_r.status_code == 200:
                    img_path = str(DATA_DIR / "epic_earth.png")
                    with open(img_path, 'wb') as f:
                        f.write(img_r.content)
                    return f"🌍 Full Earth image saved! (DSCOVR Satellite)\n💾 {img_path}"
            except Exception:
                pass

        return f"🌍 EPIC image available at NASA website"


# Global instance
universe = UniverseMode()