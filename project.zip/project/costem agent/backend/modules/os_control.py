# os_control.py — Deep Windows Control & Task Scheduler
import subprocess
import os
import time
from ..config import logger
from ..error_handler import safe_execute


class DeepOSControl:
    """Windows Registry & System Control"""

    @safe_execute(max_retries=1)
    def disable_telemetry(self) -> str:
        """Disable Windows tracking/telemetry via Registry"""
        import winreg
        key_path = r"SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\DataCollection"
        try:
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, key_path, 0, winreg.KEY_SET_VALUE)
            winreg.SetValueEx(key, "AllowTelemetry", 0, winreg.REG_DWORD, 0)
            winreg.CloseKey(key)
            return "🔒 Windows Telemetry Disabled!"
        except PermissionError:
            return "❌ Run as Administrator required!"
        except Exception as e:
            return f"❌ Registry error: {e}"

    @safe_execute(max_retries=1)
    def manage_startup(self, action: str = "list", app_name: str = None) -> str:
        """List or remove startup apps"""
        import winreg
        key_path = r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
        try:
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_ALL_ACCESS)
            
            if action == "list":
                apps = []
                i = 0
                while True:
                    try:
                        name, value, _ = winreg.EnumValue(key, i)
                        apps.append(f"{i+1}. {name}")
                        i += 1
                    except OSError:
                        break
                winreg.CloseKey(key)
                return "📋 Startup Apps:\n" + "\n".join(apps) if apps else "No startup apps found."
            
            elif action == "remove" and app_name:
                winreg.DeleteValue(key, app_name)
                winreg.CloseKey(key)
                return f"✅ Removed {app_name} from startup!"
                
        except Exception as e:
            return f"❌ Startup error: {e}"

    @safe_execute(max_retries=1)
    def create_cron_task(self, task_name: str, command: str, time: str = "08:00") -> str:
        """Create Windows Task Scheduler job"""
        hour, minute = time.split(":")
        python_exe = "python"  # Assumes python in PATH
        script_path = os.path.abspath("main.py")
        
        cmd = [
            "schtasks", "/create", "/tn", f"RGS_AI_{task_name}",
            "/tr", f'"{python_exe}" "{script_path}" --task "{command}"',
            "/sc", "daily", "/st", f"{hour}:{minute}:00", "/f"
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            return f"⏰ Cron job created: {task_name} at {time} daily!"
        return f"❌ Cron error: {result.stderr}"

    def setup_noise_cancellation(self) -> str:
        """Install and setup real-time noise cancellation for mic"""
        try:
            import noisereduce
            return "✅ Noise reduction library ready. Will apply to mic stream."
        except ImportError:
            return "❌ pip install noisereduce"

# Global instance
os_control = DeepOSControl()