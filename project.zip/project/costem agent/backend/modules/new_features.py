"""
╔══════════════════════════════════════════════════════════╗
║          RGS_AI - NEW FEATURES (Usman Jarvis + Extra)   ║
║          All Missing Features Added & Upgraded           ║
╚══════════════════════════════════════════════════════════╝
"""

import os
import re
import json
import time
import threading
import subprocess
import platform
import base64
from datetime import datetime

from ..error_handler import logger

import os
import sys
import time
import json
import socket
import threading
import subprocess
import webbrowser
import ctypes
import psutil
import requests
import platform
import signal
import shutil
from datetime import datetime
from pathlib import Path

# ═══════════════════════════════════════════════════════════
# 1. INTERNET SPEED TEST
# ═══════════════════════════════════════════════════════════

def internet_speed_test():
    """Full Internet Speed Test - Download, Upload, Ping"""
    try:
        import speedtest
        
        print("\n⚡ RGS_AI: Internet Speed Test Shuru Ho Raha Hai...")
        print("⏳ Please Wait... Yeh 15-30 seconds le sakta hai...\n")
        
        st = speedtest.Speedtest()
        
        # Best server select karo
        st.get_best_server()
        ping = st.results.ping
        
        # Download Speed
        print("📥 Download Speed Check Ho Rahi Hai...")
        download_speed = st.download() / 1_000_000  # Convert to Mbps
        
        # Upload Speed
        print("📤 Upload Speed Check Ho Rahi Hai...")
        upload_speed = st.upload() / 1_000_000  # Convert to Mbps
        
        result = f"""
╔════════════════════════════════════════════╗
║        🌐 INTERNET SPEED TEST RESULTS      ║
╠════════════════════════════════════════════╣
║  📥 Download Speed: {download_speed:.2f} Mbps
║  📤 Upload Speed:   {upload_speed:.2f} Mbps
║  📡 Ping:           {ping:.2f} ms
║  🌍 Server:         {st.results.server['sponsor']}
║  📍 Location:       {st.results.server['name']}, {st.results.server['country']}
╚════════════════════════════════════════════╝
"""
        print(result)
        
        # Speed Quality Rating
        if download_speed > 100:
            quality = "🟢 EXCELLENT - Lightning Fast!"
        elif download_speed > 50:
            quality = "🟢 GOOD - Smooth Streaming & Gaming"
        elif download_speed > 20:
            quality = "🟡 AVERAGE - Basic Usage OK"
        elif download_speed > 5:
            quality = "🟠 SLOW - Limited Usage"
        else:
            quality = "🔴 VERY SLOW - Connection Issues"
        
        print(f"📊 Speed Quality: {quality}")
        
        return {
            "download": f"{download_speed:.2f} Mbps",
            "upload": f"{upload_speed:.2f} Mbps",
            "ping": f"{ping:.2f} ms",
            "quality": quality
        }
        
    except ImportError:
        print("❌ speedtest-cli library install nahi hai!")
        print("💡 Run: pip install speedtest-cli")
        return None
    except Exception as e:
        print(f"❌ Speed Test Error: {e}")
        # Fallback - Simple speed test
        return _simple_speed_test()

def _simple_speed_test():
    """Fallback simple speed test using file download"""
    try:
        import time
        print("⚡ Simple Speed Test Chala Raha Hai...")
        start = time.time()
        
        # Download a small file from Cloudflare
        response = requests.get(
            "https://speed.cloudflare.com/__down?bytes=10000000",
            timeout=30, stream=True
        )
        
        total = 0
        for chunk in response.iter_content(chunk_size=8192):
            total += len(chunk)
        
        elapsed = time.time() - start
        speed_mbps = (total * 8) / (elapsed * 1_000_000)
        
        print(f"📥 Approx Download Speed: {speed_mbps:.2f} Mbps")
        return {"download": f"{speed_mbps:.2f} Mbps", "upload": "N/A", "ping": "N/A"}
    except:
        print("❌ Speed Test Fail Ho Gaya")
        return None


# ═══════════════════════════════════════════════════════════
# 2. IP LOCATION / WHERE AM I
# ═══════════════════════════════════════════════════════════

def get_my_location():
    """Current IP Location - City, Country, ISP, Coordinates"""
    try:
        print("📍 RGS_AI: Aapki Location Check Ho Rahi Hai...\n")
        
        # Primary API
        response = requests.get('https://ipinfo.io/json', timeout=10)
        data = response.json()
        
        loc = data.get('loc', '0,0').split(',')
        lat, lon = loc[0], loc[1]
        
        result = f"""
╔════════════════════════════════════════════╗
║          📍 YOUR CURRENT LOCATION          ║
╠════════════════════════════════════════════╣
║  🌐 IP Address:    {data.get('ip', 'N/A')}
║  🏙️  City:          {data.get('city', 'N/A')}
║  🗺️  Region:        {data.get('region', 'N/A')}
║  🌍 Country:       {data.get('country', 'N/A')}
║  📮 Postal:        {data.get('postal', 'N/A')}
║  📡 Timezone:      {data.get('timezone', 'N/A')}
║  🏢 ISP/Org:       {data.get('org', 'N/A')}
║  📌 Coordinates:   {lat}, {lon}
╚════════════════════════════════════════════╝
"""
        print(result)
        
        # Google Maps mein open karo
        maps_url = f"https://www.google.com/maps?q={lat},{lon}"
        print(f"🗺️  Google Maps: {maps_url}")
        
        return data
        
    except Exception as e:
        print(f"❌ Location Error: {e}")
        return _fallback_location()

def _fallback_location():
    """Fallback location using ip-api"""
    try:
        response = requests.get('http://ip-api.com/json/', timeout=10)
        data = response.json()
        
        print(f"""
📍 YOUR LOCATION:
  🌐 IP: {data.get('query', 'N/A')}
  🏙️  City: {data.get('city', 'N/A')}
  🗺️  Region: {data.get('regionName', 'N/A')}
  🌍 Country: {data.get('country', 'N/A')}
  📡 ISP: {data.get('isp', 'N/A')}
  📌 Lat: {data.get('lat', 'N/A')}, Lon: {data.get('lon', 'N/A')}
""")
        return data
    except:
        print("❌ Location nahi mil payi")
        return None


# ═══════════════════════════════════════════════════════════
# 3. CPU / GPU / SYSTEM TEMPERATURE
# ═══════════════════════════════════════════════════════════

def get_system_temperature():
    """CPU Temperature, GPU Temperature, Fan Speed"""
    try:
        print("🌡️ RGS_AI: System Temperature Check Ho Rahi Hai...\n")
        
        result = {
            "cpu_temp": "N/A",
            "gpu_temp": "N/A",
            "fan_speed": "N/A",
            "battery_temp": "N/A"
        }
        
        # Method 1: psutil (Linux/Some Windows)
        if hasattr(psutil, "sensors_temperatures"):
            temps = psutil.sensors_temperatures()
            if temps:
                for name, entries in temps.items():
                    for entry in entries:
                        if 'cpu' in name.lower() or 'core' in name.lower():
                            result["cpu_temp"] = f"{entry.current}°C"
                            print(f"🌡️ CPU ({name}): {entry.current}°C "
                                  f"(High: {entry.high}°C, Critical: {entry.critical}°C)")
                        elif 'gpu' in name.lower() or 'nvidia' in name.lower():
                            result["gpu_temp"] = f"{entry.current}°C"
                            print(f"🎮 GPU ({name}): {entry.current}°C")
        
        # Method 2: WMI for Windows (More reliable on Windows)
        if platform.system() == 'Windows':
            try:
                import wmi
                w = wmi.WMI(namespace="root\\OpenHardwareMonitor")
                for sensor in w.Sensor():
                    if sensor.SensorType == 'Temperature':
                        if 'CPU' in sensor.Name:
                            result["cpu_temp"] = f"{sensor.Value}°C"
                            print(f"🌡️ CPU {sensor.Name}: {sensor.Value}°C")
                        elif 'GPU' in sensor.Name:
                            result["gpu_temp"] = f"{sensor.Value}°C"
                            print(f"🎮 GPU {sensor.Name}: {sensor.Value}°C")
            except:
                pass
            
            # Alternative: Using WMI for MSStorageDriver_ATAPISmartData
            try:
                import wmi
                w = wmi.WMI(namespace="root\\wmi")
                temp_info = w.MSStorageDriver_ATAPISmartData()
            except:
                pass
        
        # Method 3: NVIDIA GPU Temp via nvidia-smi
        try:
            output = subprocess.check_output(
                ['nvidia-smi', '--query-gpu=temperature.gpu,fan.speed,power.draw',
                 '--format=csv,noheader,nounits'],
                timeout=5, text=True
            )
            parts = output.strip().split(', ')
            if len(parts) >= 3:
                result["gpu_temp"] = f"{parts[0]}°C"
                result["fan_speed"] = f"{parts[1]}%"
                print(f"🎮 NVIDIA GPU Temp: {parts[0]}°C")
                print(f"💨 GPU Fan Speed: {parts[1]}%")
                print(f"⚡ GPU Power Draw: {parts[2]}W")
        except:
            pass
        
        # Battery Temperature (if laptop)
        battery = psutil.sensors_battery()
        if battery:
            result["battery_temp"] = "Available via BIOS"
            print(f"🔋 Battery: {battery.percent}% "
                  f"({'Plugged In' if battery.power_plugged else 'On Battery'})")
        
        # System Health Assessment
        print("\n📊 System Health Assessment:")
        cpu_usage = psutil.cpu_percent(interval=1)
        memory = psutil.virtual_memory()
        
        print(f"  💻 CPU Usage: {cpu_usage}%")
        print(f"  🧠 RAM Usage: {memory.percent}% ({memory.used // (1024**3)}GB / "
              f"{memory.total // (1024**3)}GB)")
        
        if cpu_usage > 90:
            print("  ⚠️ CPU OVERLOADED! Close some apps!")
        elif cpu_usage > 70:
            print("  🟡 CPU Usage High")
        else:
            print("  🟢 CPU Usage Normal")
        
        if memory.percent > 90:
            print("  ⚠️ RAM ALMOST FULL!")
        elif memory.percent > 70:
            print("  🟡 RAM Usage High")
        else:
            print("  🟢 RAM Usage Normal")
        
        return result
        
    except Exception as e:
        print(f"❌ Temperature Check Error: {e}")
        return None


# ═══════════════════════════════════════════════════════════
# 4. WEBCAM PHOTO CAPTURE
# ═══════════════════════════════════════════════════════════

def capture_photo(save_path=None):
    """Webcam se photo capture karo"""
    try:
        import cv2
        
        print("📸 RGS_AI: Photo Capture Ho Rahi Hai...")
        
        if save_path is None:
            photo_dir = os.path.join(os.path.expanduser("~"), "RGS_AI_Photos")
            os.makedirs(photo_dir, exist_ok=True)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            save_path = os.path.join(photo_dir, f"photo_{timestamp}.jpg")
        
        cap = cv2.VideoCapture(0)
        
        if not cap.isOpened():
            print("❌ Webcam access nahi ho paya!")
            return None
        
        # Camera warmup
        time.sleep(1)
        
        # Multiple frames take karo (better quality ke liye)
        for _ in range(5):
            ret, frame = cap.read()
        
        ret, frame = cap.read()
        cap.release()
        
        if ret:
            # Photo save karo
            cv2.imwrite(save_path, frame)
            print(f"✅ Photo Save Ho Gayi: {save_path}")
            
            # Photo dikhao
            cv2.imshow("RGS_AI - Captured Photo", frame)
            cv2.waitKey(2000)
            cv2.destroyAllWindows()
            
            return save_path
        else:
            print("❌ Photo capture nahi ho payi!")
            return None
            
    except ImportError:
        print("❌ OpenCV install nahi hai! Run: pip install opencv-python")
        return None
    except Exception as e:
        print(f"❌ Photo Capture Error: {e}")
        return None

def capture_burst_photos(count=5, interval=1):
    """Burst mode - Multiple photos ek saath"""
    try:
        import cv2
        
        print(f"📸📸📸 RGS_AI: Burst Mode - {count} Photos Capture Ho Rahi Hain...")
        
        photo_dir = os.path.join(os.path.expanduser("~"), "RGS_AI_Photos", "Burst")
        os.makedirs(photo_dir, exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            print("❌ Webcam access nahi ho paya!")
            return None
        
        time.sleep(1)
        saved = []
        
        for i in range(count):
            ret, frame = cap.read()
            if ret:
                path = os.path.join(photo_dir, f"burst_{timestamp}_{i+1}.jpg")
                cv2.imwrite(path, frame)
                saved.append(path)
                print(f"  ✅ Photo {i+1}/{count} captured")
            time.sleep(interval)
        
        cap.release()
        print(f"\n✅ {len(saved)} Photos Save Ho Gayin! Location: {photo_dir}")
        return saved
        
    except Exception as e:
        print(f"❌ Burst Capture Error: {e}")
        return None


# ═══════════════════════════════════════════════════════════
# 5. WEBSITE BLOCKER (FOCUS MODE PRO)
# ═══════════════════════════════════════════════════════════

WEBSITE_BLOCKLIST = [
    "facebook.com", "www.facebook.com",
    "instagram.com", "www.instagram.com",
    "twitter.com", "www.twitter.com", "x.com",
    "youtube.com", "www.youtube.com",
    "tiktok.com", "www.tiktok.com",
    "reddit.com", "www.reddit.com",
    "netflix.com", "www.netflix.com",
    "twitch.tv", "www.twitch.tv",
    "discord.com", "www.discord.com",
    "pinterest.com", "www.pinterest.com",
    "snapchat.com", "www.snapchat.com",
]

HOSTS_FILE = r"C:\Windows\System32\drivers\etc\hosts"
REDIRECT_IP = "127.0.0.1"

def block_websites(custom_sites=None):
    """Websites block karo (Admin Required)"""
    try:
        sites = custom_sites if custom_sites else WEBSITE_BLOCKLIST
            
        print("🚫 RGS_AI: Websites Block Ho Rahi Hain...")
        print("⚠️ ADMIN RIGHTS REQUIRED!")
        
        # Read current hosts file
        with open(HOSTS_FILE, 'r') as f:
            content = f.read()
        
        # RGS_AI block marker
        start_marker = "# === RGS_AI BLOCK START ===\n"
        end_marker = "# === RGS_AI BLOCK END ===\n"
        
        # Remove existing RGS_AI blocks
        if start_marker in content:
            start_idx = content.find(start_marker)
            end_idx = content.find(end_marker) + len(end_marker)
            content = content[:start_idx] + content[end_idx:]
        
        # Add new blocks
        block_entries = start_marker
        for site in sites:
            entry = f"{REDIRECT_IP} {site}\n"
            if entry not in content:
                block_entries += entry
        block_entries += end_marker
        
        content += "\n" + block_entries
        
        # Write back
        with open(HOSTS_FILE, 'w') as f:
            f.write(content)
        
        # Flush DNS
        os.system('ipconfig /flushdns > nul 2>&1')
        
        print(f"✅ {len(sites)} Websites Block Ho Gayin!")
        print("🧘 Focus Mode ACTIVE!")
        
        return True
        
    except PermissionError:
        print("❌ ADMIN RIGHTS CHAHIYE! RGS_AI ko Run as Administrator mein chalao!")
        return False
    except Exception as e:
        print(f"❌ Website Block Error: {e}")
        return False

def unblock_websites():
    """Block kiye hue websites unblock karo"""
    try:
        print("✅ RGS_AI: Websites Unblock Ho Rahi Hain...")
        
        with open(HOSTS_FILE, 'r') as f:
            content = f.read()
        
        start_marker = "# === RGS_AI BLOCK START ===\n"
        end_marker = "# === RGS_AI BLOCK END ===\n"
        
        if start_marker in content:
            start_idx = content.find(start_marker)
            end_idx = content.find(end_marker) + len(end_marker)
            content = content[:start_idx] + content[end_idx:]
            
            with open(HOSTS_FILE, 'w') as f:
                f.write(content.strip() + "\n")
            
            os.system('ipconfig /flushdns > nul 2>&1')
            print("✅ Sab Websites Unblock Ho Gayin!")
            return True
        else:
            print("ℹ️ Koi blocked website nahi mili")
            return True
            
    except PermissionError:
        print("❌ ADMIN RIGHTS CHAHIYE!")
        return False
    except Exception as e:
        print(f"❌ Unblock Error: {e}")
        return False

def focus_mode_pro(duration_minutes=60, custom_blocked=None):
    """Enhanced Focus Mode - Websites Block + Pomodoro + DND"""
    try:
        print(f"""
╔════════════════════════════════════════════╗
║         🧘 FOCUS MODE PRO ACTIVATED        ║
║           Duration: {duration_minutes} Minutes            ║
╠════════════════════════════════════════════╣
║  🚫 Social Media Blocked                  ║
║  🔕 Notifications Muted                   ║
║  ⏰ Break Reminders Active                ║
║  📊 Productivity Tracking On              ║
╚════════════════════════════════════════════╝
""")
        
        # Block websites
        block_websites(custom_blocked)
        
        # Pomodoro cycle
        pomodoro_duration = 25  # 25 min work
        break_duration = 5     # 5 min break
        elapsed = 0
        
        while elapsed < duration_minutes:
            # Work period
            remaining_work = min(pomodoro_duration, duration_minutes - elapsed)
            print(f"\n💼 WORK TIME! {remaining_work} minutes focused work.")
            print("💪 Aap Kar Sakte Ho! Focus!\n")
            
            # Play start sound
            _play_alert_sound("focus_start")
            
            time.sleep(remaining_work * 60)
            elapsed += remaining_work
            
            if elapsed >= duration_minutes:
                break
            
            # Break period
            print(f"\n☕ BREAK TIME! {break_duration} minutes rest.")
            print("🧘 Stretch karo, Paani piyo!\n")
            _play_alert_sound("break_start")
            
            time.sleep(break_duration * 60)
            elapsed += break_duration
        
        # Focus mode complete
        unblock_websites()
        print("\n🎉 FOCUS MODE COMPLETE! Bohat Khoos!")
        _play_alert_sound("focus_complete")
        
        return True
        
    except KeyboardInterrupt:
        print("\n⚠️ Focus Mode Interrupted! Websites unblocking...")
        unblock_websites()
        return False
    except Exception as e:
        print(f"❌ Focus Mode Error: {e}")
        unblock_websites()
        return False


# ═══════════════════════════════════════════════════════════
# 6. ALARM SYSTEM WITH LOUD SOUND
# ═══════════════════════════════════════════════════════════

_active_alarms = {}

def set_alarm(alarm_time_str, message="Alarm!"):
    """Alarm set karo with loud sound - Format: 'HH:MM' or 'HH:MM AM/PM'"""
    try:
        alarm_time_str = alarm_time_str.strip().upper()
        
        # Parse time
        if 'AM' in alarm_time_str or 'PM' in alarm_time_str:
            alarm_time = datetime.strptime(alarm_time_str, "%I:%M %p").time()
        else:
            alarm_time = datetime.strptime(alarm_time_str, "%H:%M").time()
        
        now = datetime.now()
        alarm_datetime = now.replace(
            hour=alarm_time.hour, 
            minute=alarm_time.minute, 
            second=0, 
            microsecond=0
        )
        
        # Agar alarm time past mein hai, to kal set karo
        if alarm_datetime <= now:
            alarm_datetime = alarm_datetime.replace(day=now.day + 1)
        
        time_diff = (alarm_datetime - now).total_seconds()
        
        alarm_id = f"alarm_{len(_active_alarms)}"
        
        print(f"""
╔════════════════════════════════════════════╗
║            ⏰ ALARM SET SUCCESSFULLY       ║
╠════════════════════════════════════════════╣
║  🕐 Alarm Time: {alarm_time.strftime('%I:%M %p')}
║  📝 Message:    {message}
║  ⏳ Ringing in: {int(time_diff // 60)} minutes {int(time_diff % 60)} seconds
║  🆔 Alarm ID:   {alarm_id}
╚════════════════════════════════════════════╝
""")
        
        # Start alarm thread
        def alarm_thread():
            time.sleep(time_diff)
            _ring_alarm(message, alarm_id)
        
        t = threading.Thread(target=alarm_thread, daemon=True)
        t.start()
        
        _active_alarms[alarm_id] = {
            "time": alarm_time_str,
            "message": message,
            "thread": t,
            "active": True
        }
        
        return alarm_id
        
    except ValueError:
        print("❌ Invalid Time Format! Use: 'HH:MM' or 'HH:MM AM/PM'")
        return None
    except Exception as e:
        print(f"❌ Alarm Error: {e}")
        return None

def _ring_alarm(message, alarm_id):
    """Alarm ring karo with loud beeps"""
    print(f"\n{'🔔' * 20}")
    print(f"⏰ ALARM! ⏰ ALARM! ⏰ ALARM!")
    print(f"📝 {message}")
    print(f"{'🔔' * 20}\n")
    
    # Windows beep sound (loud)
    try:
        import winsound
        for i in range(10):
            winsound.Beep(2000, 500)  # 2000Hz, 500ms
            winsound.Beep(2500, 500)  # 2500Hz, 500ms
            time.sleep(0.2)
    except:
        # Fallback - System sound
        for i in range(10):
            print('\a', end='', flush=True)
            time.sleep(0.5)
    
    # Speak alarm
    try:
        from engine import speak
        speak(f"Alarm! {message}! Uth Jao!")
    except:
        pass
    
    if alarm_id in _active_alarms:
        _active_alarms[alarm_id]["active"] = False

def list_alarms():
    """Sab active alarms dikhao"""
    if not _active_alarms:
        print("ℹ️ Koi active alarm nahi hai")
        return
    
    print("\n⏰ Active Alarms:")
    for aid, info in _active_alarms.items():
        status = "🟢 Active" if info["active"] else "🔴 Ringed"
        print(f"  {aid}: {info['time']} - {info['message']} [{status}]")

def stop_all_alarms():
    """Sab alarms stop karo"""
    _active_alarms.clear()
    print("✅ Sab Alarms Stop Ho Gaye!")


# ═══════════════════════════════════════════════════════════
# 7. SCREEN RECORDING
# ═══════════════════════════════════════════════════════════

_is_recording = False

def start_screen_recording(duration_seconds=None, fps=20, output_path=None):
    """Screen recording start karo"""
    global _is_recording
    
    try:
        from mss import mss
        import cv2
        import numpy as np
        
        if _is_recording:
            print("⚠️ Already recording! Pehle stop karo!")
            return None
        
        print("🎬 RGS_AI: Screen Recording Shuru Ho Rahi Hai...")
        
        # Output path
        if output_path is None:
            rec_dir = os.path.join(os.path.expanduser("~"), "RGS_AI_Recordings")
            os.makedirs(rec_dir, exist_ok=True)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_path = os.path.join(rec_dir, f"recording_{timestamp}.mp4")
        
        # Get screen dimensions
        with mss() as sct:
            monitor = sct.monitors[1]
            width = monitor["width"]
            height = monitor["height"]
        
        # Video writer
        fourcc = cv2.VideoWriter_fourcc(*'mp4v')
        out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))
        
        _is_recording = True
        start_time = time.time()
        frame_count = 0
        
        print(f"✅ Recording Started! (FPS: {fps})")
        print(f"📁 Save Location: {output_path}")
        print("🛑 Stop ke liye: stop_screen_recording() call karo\n")
        
        def record():
            nonlocal frame_count
            with mss() as sct:
                while _is_recording:
                    # Check duration
                    if duration_seconds and (time.time() - start_time) >= duration_seconds:
                        break
                    
                    # Capture screen
                    screenshot = sct.grab(sct.monitors[1])
                    frame = np.array(screenshot)
                    
                    # Convert BGRA to BGR
                    frame = cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR)
                    
                    out.write(frame)
                    frame_count += 1
                    
                    # Small delay for target FPS
                    time.sleep(1/fps)
            
            out.release()
            _is_recording = False
            
            duration = time.time() - start_time
            print(f"\n✅ Recording Complete!")
            print(f"📁 File: {output_path}")
            print(f"⏱️  Duration: {duration:.1f} seconds")
            print(f"🖼️  Frames: {frame_count}")
        
        # Start in thread
        t = threading.Thread(target=record, daemon=True)
        t.start()
        
        return output_path
        
    except ImportError as e:
        print(f"❌ Missing library: {e}")
        print("💡 Run: pip install mss opencv-python numpy")
        return None
    except Exception as e:
        print(f"❌ Recording Error: {e}")
        _is_recording = False
        return None

def stop_screen_recording():
    """Screen recording stop karo"""
    global _is_recording
    if _is_recording:
        _is_recording = False
        print("🛑 Screen Recording Ruk Rahi Hai...")
        time.sleep(1)
        return True
    else:
        print("ℹ️ Koi recording chal nahi rahi")
        return False


# ═══════════════════════════════════════════════════════════
# 8. VOLUME CONTROL
# ═══════════════════════════════════════════════════════════

def set_volume(level):
    """Volume set karo (0-100)"""
    try:
        level = max(0, min(100, int(level)))
        
        if platform.system() == 'Windows':
            # Using nircmd (if available) or pycaw
            try:
                from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
                from comtypes import CLSCTX_ALL
                
                devices = AudioUtilities.GetSpeakers()
                interface = devices.Activate(
                    IAudioEndpointVolume._iid_, CLSCTX_ALL, None
                )
                volume = interface.QueryInterface(IAudioEndpointVolume)
                
                # Set volume (0.0 to 1.0)
                volume.SetMasterVolumeLevelScalar(level / 100.0, None)
                print(f"🔊 Volume Set: {level}%")
                return True
                
            except ImportError:
                # Fallback using nircmd
                try:
                    # Volume level mapping for nircmd (0-65535)
                    nircmd_vol = int((level / 100) * 65535)
                    subprocess.run(
                        ['nircmd.exe', 'setsysvolume', str(nircmd_vol)],
                        timeout=5
                    )
                    print(f"🔊 Volume Set: {level}%")
                    return True
                except:
                    # Final fallback - PowerShell
                    ps_script = f"""
                    $wshShell = new-object -com wscript.shell
                    1..{level} | % {{ $wshShell.SendKeys([char]174) }}
                    1..{level} | % {{ $wshShell.SendKeys([char]175) }}
                    """
                    subprocess.run(['powershell', '-Command', ps_script], timeout=10)
                    print(f"🔊 Volume Adjusted: ~{level}%")
                    return True
        
        elif platform.system() == 'Darwin':  # macOS
            os.system(f'osascript -e "set volume output volume {level}"')
            print(f"🔊 Volume Set: {level}%")
            return True
            
        elif platform.system() == 'Linux':
            os.system(f'amixer set Master {level}%')
            print(f"🔊 Volume Set: {level}%")
            return True
            
    except Exception as e:
        print(f"❌ Volume Control Error: {e}")
        return False

def volume_up(steps=10):
    """Volume badhao"""
    try:
        if platform.system() == 'Windows':
            try:
                from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
                from comtypes import CLSCTX_ALL
                
                devices = AudioUtilities.GetSpeakers()
                interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
                volume = interface.QueryInterface(IAudioEndpointVolume)
                current = volume.GetMasterVolumeLevelScalar() * 100
                new_level = min(100, current + steps)
                volume.SetMasterVolumeLevelScalar(new_level / 100.0, None)
                print(f"🔊 Volume Up: {int(new_level)}%")
            except:
                for _ in range(steps // 2):
                    import keyboard
                    keyboard.send('volume up')
                    time.sleep(0.05)
                print(f"🔊 Volume Up: +{steps}%")
        else:
            print("⚠️ Sirf Windows support hai abhi")
    except:
        print("❌ Volume Up Error")

def volume_down(steps=10):
    """Volume kam karo"""
    try:
        if platform.system() == 'Windows':
            try:
                from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
                from comtypes import CLSCTX_ALL
                
                devices = AudioUtilities.GetSpeakers()
                interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
                volume = interface.QueryInterface(IAudioEndpointVolume)
                current = volume.GetMasterVolumeLevelScalar() * 100
                new_level = max(0, current - steps)
                volume.SetMasterVolumeLevelScalar(new_level / 100.0, None)
                print(f"🔉 Volume Down: {int(new_level)}%")
            except:
                for _ in range(steps // 2):
                    import keyboard
                    keyboard.send('volume down')
                    time.sleep(0.05)
                print(f"🔉 Volume Down: -{steps}%")
        else:
            print("⚠️ Sirf Windows support hai abhi")
    except:
        print("❌ Volume Down Error")

def mute_volume():
    """Volume mute karo"""
    try:
        if platform.system() == 'Windows':
            try:
                from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
                from comtypes import CLSCTX_ALL
                
                devices = AudioUtilities.GetSpeakers()
                interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
                volume = interface.QueryInterface(IAudioEndpointVolume)
                volume.SetMute(1, None)
                print("🔇 Volume Muted!")
            except:
                import keyboard
                keyboard.send('volume mute')
                print("🔇 Volume Muted!")
    except:
        print("❌ Mute Error")

def unmute_volume():
    """Volume unmute karo"""
    try:
        if platform.system() == 'Windows':
            try:
                from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
                from comtypes import CLSCTX_ALL
                
                devices = AudioUtilities.GetSpeakers()
                interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
                volume = interface.QueryInterface(IAudioEndpointVolume)
                volume.SetMute(0, None)
                print("🔊 Volume Unmuted!")
            except:
                import keyboard
                keyboard.send('volume mute')
                print("🔊 Volume Unmuted!")
    except:
        print("❌ Unmute Error")


# ═══════════════════════════════════════════════════════════
# 9. BRIGHTNESS CONTROL
# ═══════════════════════════════════════════════════════════

def set_brightness(level):
    """Screen brightness set karo (0-100)"""
    try:
        level = max(0, min(100, int(level)))
        
        if platform.system() == 'Windows':
            try:
                import screen_brightness_control as sbc
                sbc.set_brightness(level)
                print(f"☀️ Brightness Set: {level}%")
                return True
            except ImportError:
                # Fallback using WMI
                try:
                    import wmi
                    wmi = wmi.WMI(namespace="wmi")
                    method = wmi.WmiMonitorBrightnessMethods()[0]
                    method.WmiSetBrightness(level, 0)
                    print(f"☀️ Brightness Set: {level}%")
                    return True
                except:
                    print("❌ Brightness control ke liye: pip install screen-brightness-control")
                    return False
        
        elif platform.system() == 'Darwin':
            os.system(f'brightness {level/100}')
            print(f"☀️ Brightness Set: {level}%")
            return True
            
        elif platform.system() == 'Linux':
            os.system(f'xrandr --output eDP-1 --brightness {level/100}')
            print(f"☀️ Brightness Set: {level}%")
            return True
            
    except Exception as e:
        print(f"❌ Brightness Error: {e}")
        return False

def get_brightness():
    """Current brightness level dikhao"""
    try:
        import screen_brightness_control as sbc
        current = sbc.get_brightness()
        print(f"☀️ Current Brightness: {current}%")
        return current
    except:
        return None


# ═══════════════════════════════════════════════════════════
# 10. YOUTUBE VIDEO DOWNLOADER
# ═══════════════════════════════════════════════════════════

def download_youtube_video(url, quality="best", audio_only=False):
    """YouTube video download karo"""
    try:
        import yt_dlp
            
        print(f"📥 RGS_AI: YouTube Video Download Ho Rahi Hai...")
        print(f"🔗 URL: {url}")
        
        # Download directory
        download_dir = os.path.join(os.path.expanduser("~"), "RGS_AI_Downloads")
        os.makedirs(download_dir, exist_ok=True)
        
        ydl_opts = {
            'outtmpl': os.path.join(download_dir, '%(title)s.%(ext)s'),
            'progress_hooks': [_yt_progress_hook],
        }
        
        if audio_only:
            ydl_opts.update({
                'format': 'bestaudio/best',
                'postprocessors': [{
                    'key': 'FFmpegExtractAudio',
                    'preferredcodec': 'mp3',
                    'preferredquality': '320',
                }],
            })
        elif quality == "best":
            ydl_opts['format'] = 'bestvideo+bestaudio/best'
        elif quality == "medium":
            ydl_opts['format'] = 'bestvideo[height<=720]+bestaudio/best'
        elif quality == "low":
            ydl_opts['format'] = 'bestvideo[height<=480]+bestaudio/best'
        
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=True)
            
            title = info.get('title', 'Unknown')
            duration = info.get('duration', 0)
            views = info.get('view_count', 0)
            
            print(f"""
╔════════════════════════════════════════════╗
║        ✅ DOWNLOAD COMPLETE!               ║
╠════════════════════════════════════════════╣
║  🎬 Title:    {title[:40]}
║  ⏱️  Duration: {duration // 60}:{duration % 60:02d}
║  👁️  Views:    {views:,}
║  📁 Saved to: {download_dir}
╚════════════════════════════════════════════╝
""")
            return True
            
    except ImportError:
        print("❌ yt-dlp install nahi hai! Run: pip install yt-dlp")
        return False
    except Exception as e:
        print(f"❌ Download Error: {e}")
        return False

def _yt_progress_hook(d):
    """YouTube download progress"""
    if d['status'] == 'downloading':
        percent = d.get('_percent_str', 'N/A')
        speed = d.get('_speed_str', 'N/A')
        eta = d.get('_eta_str', 'N/A')
        print(f"\r  📥 {percent} | Speed: {speed} | ETA: {eta}", end='', flush=True)
    elif d['status'] == 'finished':
        print("\n  ✅ Download Complete! Processing...")


# ═══════════════════════════════════════════════════════════
# 11. PRAYER TIMES (ISLAMIC)
# ═══════════════════════════════════════════════════════════

def get_prayer_times(city="Karachi", country="Pakistan", method=1):
    """Namaz ke waqt dikhao - Aladhan API"""
    try:
        print(f"🕌 RGS_AI: Prayer Times Check Ho Rahe Hain ({city})...\n")
        
        # Get coordinates from city
        geo_url = f"https://api.aladhan.com/v1/cityInfo?city={city}&country={country}"
        geo_resp = requests.get(geo_url, timeout=10)
        geo_data = geo_resp.json()
        
        if geo_data.get('code') != 200:
            # Fallback - Use ipinfo for location
            loc_data = get_my_location()
            if loc_data:
                lat = loc_data.get('loc', '0,0').split(',')[0]
                lon = loc_data.get('loc', '0,0').split(',')[1]
            else:
                lat, lon = "24.8607", "67.0011"  # Karachi default
        else:
            lat = str(geo_data['data']['latitude'])
            lon = str(geo_data['data']['longitude'])
        
        # Get prayer times
        today = datetime.now().strftime("%d-%m-%Y")
        prayer_url = (
            f"https://api.aladhan.com/v1/timings/{today}"
            f"?latitude={lat}&longitude={lon}&method={method}"
        )
        
        response = requests.get(prayer_url, timeout=10)
        data = response.json()
        
        if data.get('code') == 200:
            timings = data['data']['timings']
            hijri = data['data']['date']['hijri']
            
            result = f"""
╔════════════════════════════════════════════╗
║          🕌 PRAYER TIMES - {city.upper():<17}  ║
╠════════════════════════════════════════════╣
║  🌅 Fajr:      {timings.get('Fajr', 'N/A')}
║  ☀️  Sunrise:   {timings.get('Sunrise', 'N/A')}
║  🌞 Dhuhr:     {timings.get('Dhuhr', 'N/A')}
║  ☀️  Asr:       {timings.get('Asr', 'N/A')}
║  🌅 Maghrib:   {timings.get('Maghrib', 'N/A')}
║  🌙 Isha:      {timings.get('Isha', 'N/A')}
╠════════════════════════════════════════════╣
║  📅 Hijri Date: {hijri.get('date', 'N/A')} ({hijri.get('month', {}).get('en', 'N/A')})
║  📅 Gregorian:  {today}
║  🧭 Qibla:      {data['data'].get('meta', {}).get('qibla', 'N/A')}°
╚════════════════════════════════════════════╝
"""
            print(result)
            
            # Next prayer check
            now = datetime.now().strftime("%H:%M")
            prayers = [
                ("Fajr", timings.get('Fajr', '')),
                ("Sunrise", timings.get('Sunrise', '')),
                ("Dhuhr", timings.get('Dhuhr', '')),
                ("Asr", timings.get('Asr', '')),
                ("Maghrib", timings.get('Maghrib', '')),
                ("Isha", timings.get('Isha', '')),
            ]
            
            next_prayer = None
            for name, ptime in prayers:
                if ptime and ptime.split(':')[0].zfill(2) > now:
                    next_prayer = (name, ptime)
                    break
            
            if next_prayer:
                print(f"⏭️  Next Prayer: {next_prayer[0]} at {next_prayer[1]}")
            else:
                print("⏭️  Next Prayer: Fajr (Kal)")
            
            return timings
        else:
            print("❌ Prayer times nahi mil paye")
            return None
            
    except Exception as e:
        print(f"❌ Prayer Times Error: {e}")
        return None


# ═══════════════════════════════════════════════════════════
# 12. CLIPBOARD MANAGER
# ═══════════════════════════════════════════════════════════

_clipboard_history = []

def copy_to_clipboard(text):
    """Text clipboard mein copy karo"""
    try:
        import pyperclip
        pyperclip.copy(text)
        _clipboard_history.append({"text": text, "time": datetime.now().isoformat()})
        print(f"✅ Clipboard Copy: {text[:50]}...")
        return True
    except ImportError:
        # Windows fallback
        try:
            process = subprocess.Popen(['clip'], stdin=subprocess.PIPE)
            process.communicate(text.encode('utf-16'))
            _clipboard_history.append({"text": text, "time": datetime.now().isoformat()})
            print(f"✅ Clipboard Copy: {text[:50]}...")
            return True
        except:
            print("❌ Clipboard access nahi hua")
            return False

def paste_from_clipboard():
    """Clipboard se paste karo"""
    try:
        import pyperclip
        text = pyperclip.paste()
        print(f"📋 Clipboard Content:\n{text}")
        return text
    except:
        try:
            # Windows fallback using PowerShell
            result = subprocess.run(
                ['powershell', '-command', 'Get-Clipboard'],
                capture_output=True, text=True, timeout=5
            )
            print(f"📋 Clipboard Content:\n{result.stdout}")
            return result.stdout
        except:
            print("❌ Clipboard read nahi hua")
            return None

def show_clipboard_history():
    """Clipboard history dikhao"""
    if not _clipboard_history:
        print("ℹ️ Clipboard history khaali hai")
        return
    
    print("\n📋 Clipboard History:")
    for i, entry in enumerate(_clipboard_history[-10:], 1):
        text = entry['text'][:60]
        time_str = entry['time'][:19]
        print(f"  {i}. [{time_str}] {text}...")


# ═══════════════════════════════════════════════════════════
# 13. SYSTEM POWER CONTROL
# ═══════════════════════════════════════════════════════════

def shutdown_system(minutes=0):
    """System shutdown karo"""
    try:
        if minutes > 0:
            print(f"⏳ System {minutes} minutes mein shutdown hoga...")
            os.system(f'shutdown /s /t {minutes * 60}')
        else:
            confirm = input("⚠️ Kya aap sure ho? System turant shutdown hoga! (yes/no): ")
            if confirm.lower() == 'yes':
                os.system('shutdown /s /t 0')
            else:
                print("✅ Shutdown Cancelled!")
    except:
        print("❌ Shutdown Error - Admin Rights Chahiye")

def restart_system(minutes=0):
    """System restart karo"""
    try:
        if minutes > 0:
            print(f"⏳ System {minutes} minutes mein restart hoga...")
            os.system(f'shutdown /r /t {minutes * 60}')
        else:
            confirm = input("⚠️ Kya aap sure ho? System turant restart hoga! (yes/no): ")
            if confirm.lower() == 'yes':
                os.system('shutdown /r /t 0')
            else:
                print("✅ Restart Cancelled!")
    except:
        print("❌ Restart Error - Admin Rights Chahiye")

def sleep_system():
    """System sleep/hibernate karo"""
    try:
        print("💤 System Sleep Mode Mein Ja Raha Hai...")
        os.system('rundll32.exe powrprof.dll,SetSuspendState 0,1,0')
    except:
        print("❌ Sleep Error")

def lock_screen():
    """Screen lock karo"""
    try:
        print("🔒 Screen Lock Ho Rahi Hai...")
        ctypes.windll.user32.LockWorkStation()
    except:
        print("❌ Lock Error")

def cancel_shutdown():
    """Pending shutdown/restart cancel karo"""
    try:
        os.system('shutdown /a')
        print("✅ Shutdown/Restart Cancelled!")
    except:
        print("❌ Cancel Error")


# ═══════════════════════════════════════════════════════════
# 14. MOUSE & KEYBOARD AUTOMATION
# ═══════════════════════════════════════════════════════════

def mouse_click(x=None, y=None, button="left", clicks=1):
    """Mouse click karo at specific position or current position"""
    try:
        import pyautogui
        pyautogui.FAILSAFE = True
        
        if x and y:
            pyautogui.click(x=x, y=y, button=button, clicks=clicks)
            print(f"🖱️ Clicked at ({x}, {y}) - {button} button, {clicks} time(s)")
        else:
            pyautogui.click(button=button, clicks=clicks)
            pos = pyautogui.position()
            print(f"🖱️ Clicked at current position ({pos.x}, {pos.y})")
        return True
    except ImportError:
        print("❌ pyautogui install nahi hai! Run: pip install pyautogui")
        return False

def mouse_move(x, y, duration=0.5):
    """Mouse move karo smoothly"""
    try:
        import pyautogui
        pyautogui.FAILSAFE = True
        pyautogui.moveTo(x, y, duration=duration)
        print(f"🖱️ Mouse moved to ({x}, {y})")
        return True
    except:
        return False

def mouse_drag(start_x, start_y, end_x, end_y, duration=1):
    """Mouse drag karo"""
    try:
        import pyautogui
        pyautogui.FAILSAFE = True
        pyautogui.moveTo(start_x, start_y)
        pyautogui.drag(end_x - start_x, end_y - start_y, duration=duration)
        print(f"🖱️ Dragged from ({start_x}, {start_y}) to ({end_x}, {end_y})")
        return True
    except:
        return False

def type_text(text, interval=0.05):
    """Text automatically type karo"""
    try:
        import pyautogui
        pyautogui.FAILSAFE = True
        pyautogui.typewrite(text, interval=interval)
        print(f"⌨️ Typed: {text[:50]}...")
        return True
    except:
        return False

def press_key(key, presses=1):
    """Specific key press karo"""
    try:
        import pyautogui
        for _ in range(presses):
            pyautogui.press(key)
            time.sleep(0.1)
        print(f"⌨️ Pressed: {key} ({presses}x)")
        return True
    except:
        return False

def hotkey(*keys):
    """Keyboard shortcut press karo"""
    try:
        import pyautogui
        pyautogui.hotkey(*keys)
        print(f"⌨️ Hotkey: {'+'.join(keys)}")
        return True
    except:
        return False

def scroll(direction="down", amount=3):
    """Scroll up or down"""
    try:
        import pyautogui
        scroll_amount = amount if direction == "up" else -amount
        pyautogui.scroll(scroll_amount)
        print(f"🖱️ Scrolled {direction}: {amount} clicks")
        return True
    except:
        return False

def get_mouse_position():
    """Current mouse position dikhao"""
    try:
        import pyautogui
        pos = pyautogui.position()
        print(f"🖱️ Mouse Position: ({pos.x}, {pos.y})")
        return (pos.x, pos.y)
    except:
        return None

def take_screenshot_region(x, y, width, height, save_path=None):
    """Specific screen region ka screenshot lo"""
    try:
        import pyautogui
        
        if save_path is None:
            ss_dir = os.path.join(os.path.expanduser("~"), "RGS_AI_Screenshots")
            os.makedirs(ss_dir, exist_ok=True)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            save_path = os.path.join(ss_dir, f"region_{timestamp}.png")
        
        screenshot = pyautogui.screenshot(region=(x, y, width, height))
        screenshot.save(save_path)
        print(f"📸 Region Screenshot Saved: {save_path}")
        return save_path
    except:
        return None


# ═══════════════════════════════════════════════════════════
# 15. PDF READER
# ═══════════════════════════════════════════════════════════

def read_pdf(file_path):
    """PDF file read karo aur content dikhao"""
    try:
        import PyPDF2
            
        print(f"📄 RGS_AI: PDF Read Ho Rahi Hai: {file_path}\n")
        
        with open(file_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            total_pages = len(reader.pages)
            
            print(f"📖 Total Pages: {total_pages}")
            print(f"📝 Title: {reader.metadata.title if reader.metadata else 'N/A'}")
            print(f"👤 Author: {reader.metadata.author if reader.metadata else 'N/A'}")
            print("\n" + "="*50)
            
            # First 5 pages read karo
            pages_to_read = min(5, total_pages)
            content = ""
            
            for i in range(pages_to_read):
                page = reader.pages[i]
                text = page.extract_text()
                content += f"\n--- Page {i+1} ---\n{text}\n"
            
            print(content[:3000])  # First 3000 chars
            
            if len(content) > 3000:
                print(f"\n... aur {len(content) - 3000} characters bhi hain")
            
            return content
            
    except ImportError:
        print("❌ PyPDF2 install nahi hai! Run: pip install PyPDF2")
        return None
    except Exception as e:
        print(f"❌ PDF Read Error: {e}")
        return None

def pdf_to_audio(file_path):
    """PDF ko audio mein convert karo (Text-to-Speech)"""
    try:
        import PyPDF2
        from engine import speak
            
        with open(file_path, 'rb') as file:
            reader = PyPDF2.PdfReader(file)
            print(f"📖 RGS_AI PDF Padh Raha Hai: {file_path}")
            print(f"📖 Total Pages: {len(reader.pages)}")
            
            for i, page in enumerate(reader.pages):
                text = page.extract_text()
                if text.strip():
                    print(f"\n📄 Page {i+1}...")
                    speak(text)
            
            print("\n✅ PDF Complete!")
            
    except Exception as e:
        print(f"❌ PDF Audio Error: {e}")


# ═══════════════════════════════════════════════════════════
# 16. WINDOW MANAGEMENT
# ═══════════════════════════════════════════════════════════

def get_active_windows():
    """Sab active windows dikhao"""
    try:
        import pygetwindows as gw
            
        windows = gw.getAllWindows()
        print("\n🪟 Active Windows:\n")
        
        for i, win in enumerate(windows, 1):
            if win.title:
                is_active = "🟢" if win.isActive else "⚪"
                is_visible = "👁️" if win.visible else "🚫"
                print(f"  {is_active} {i}. {win.title} {is_visible}")
                print(f"      Size: {win.width}x{win.height} | Pos: ({win.left}, {win.top})")
        
        return windows
        
    except ImportError:
        # Fallback using tasklist
        result = subprocess.run(['tasklist'], capture_output=True, text=True)
        print(result.stdout[:2000])
        return None

def minimize_window(title=None):
    """Window minimize karo"""
    try:
        import pygetwindows as gw
            
        if title:
            windows = gw.getWindowsWithTitle(title)
        else:
            windows = [gw.getActiveWindow()]
        
        for win in windows:
            win.minimize()
            print(f"🪟 Minimized: {win.title}")
            
    except Exception as e:
        print(f"❌ Minimize Error: {e}")

def maximize_window(title=None):
    """Window maximize karo"""
    try:
        import pygetwindows as gw
            
        if title:
            windows = gw.getWindowsWithTitle(title)
        else:
            windows = [gw.getActiveWindow()]
        
        for win in windows:
            win.maximize()
            print(f"🪟 Maximized: {win.title}")
            
    except Exception as e:
        print(f"❌ Maximize Error: {e}")

def close_window(title=None):
    """Window close karo"""
    try:
        import pygetwindows as gw
            
        if title:
            windows = gw.getWindowsWithTitle(title)
        else:
            windows = [gw.getActiveWindow()]
        
        for win in windows:
            win.close()
            print(f"🪟 Closed: {win.title}")
            
    except Exception as e:
        print(f"❌ Close Error: {e}")


# ═══════════════════════════════════════════════════════════
# 17. HELPER: PLAY ALERT SOUND
# ═══════════════════════════════════════════════════════════

def _play_alert_sound(sound_type="default"):
    """Alert sound play karo"""
    try:
        import winsound
        
        sounds = {
            "focus_start": [(800, 300), (1000, 300), (1200, 500)],
            "break_start": [(1200, 300), (1000, 300), (800, 500)],
            "focus_complete": [(800, 200), (1000, 200), (1200, 200), (1400, 500)],
            "alarm": [(2000, 500), (2500, 500)],
            "success": [(1000, 200), (1200, 200), (1500, 400)],
            "error": [(400, 500), (300, 800)],
            "default": [(800, 300), (1000, 300)],
        }
        
        for freq, duration in sounds.get(sound_type, sounds["default"]):
            winsound.Beep(freq, duration)
            
    except:
        # Fallback
        print('\a', end='', flush=True)


# ═══════════════════════════════════════════════════════════
# 18. WHATSAPP SCHEDULER (BONUS - Usman's doesn't have this)
# ═══════════════════════════════════════════════════════════

def schedule_whatsapp_message(phone_number, message, hour, minute):
    """WhatsApp message schedule karo"""
    try:
        import pywhatkit
            
        print(f"💬 WhatsApp Message Scheduled!")
        print(f"📱 To: {phone_number}")
        print(f"📝 Message: {message[:50]}...")
        print(f"⏰ Time: {hour}:{minute}")
        
        pywhatkit.sendwhatmsg(phone_number, message, hour, minute)
        return True
        
    except Exception as e:
        print(f"❌ WhatsApp Schedule Error: {e}")
        return False


# ═══════════════════════════════════════════════════════════
# 19. QR CODE GENERATOR (BONUS)
# ═══════════════════════════════════════════════════════════

def generate_qr_code(data, save_path=None):
    """QR Code generate karo"""
    try:
        import qrcode
            
        if save_path is None:
            qr_dir = os.path.join(os.path.expanduser("~"), "RGS_AI_QR_Codes")
            os.makedirs(qr_dir, exist_ok=True)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            save_path = os.path.join(qr_dir, f"qr_{timestamp}.png")
        
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(data)
        qr.make(fit=True)
        
        img = qr.make_image(fill_color="black", back_color="white")
        img.save(save_path)
        
        print(f"✅ QR Code Generated: {save_path}")
        print(f"📝 Data: {data}")
        
        # Open QR code
        os.startfile(save_path)
        
        return save_path
        
    except ImportError:
        print("❌ qrcode library install nahi hai! Run: pip install qrcode[pil]")
        return None
    except Exception as e:
        print(f"❌ QR Code Error: {e}")
        return None


# ═══════════════════════════════════════════════════════════
# 20. SYSTEM INFO DETAILED (BONUS - Better than Usman's)
# ═══════════════════════════════════════════════════════════

def detailed_system_info():
    """Complete System Information"""
    try:
        print("\n📊 RGS_AI: Detailed System Information\n")
        
        info = {}
        
        # OS Info
        info['os'] = platform.system()
        info['os_version'] = platform.version()
        info['os_release'] = platform.release()
        info['machine'] = platform.machine()
        info['processor'] = platform.processor()
        
        # CPU Info
        info['cpu_count_physical'] = psutil.cpu_count(logical=False)
        info['cpu_count_logical'] = psutil.cpu_count(logical=True)
        info['cpu_freq'] = psutil.cpu_freq()
        info['cpu_usage'] = psutil.cpu_percent(interval=1)
        
        # Memory Info
        mem = psutil.virtual_memory()
        info['ram_total'] = f"{mem.total / (1024**3):.1f} GB"
        info['ram_used'] = f"{mem.used / (1024**3):.1f} GB"
        info['ram_available'] = f"{mem.available / (1024**3):.1f} GB"
        info['ram_percent'] = f"{mem.percent}%"
        
        # Disk Info
        disks = []
        for partition in psutil.disk_partitions():
            try:
                usage = psutil.disk_usage(partition.mountpoint)
                disks.append({
                    'device': partition.device,
                    'mountpoint': partition.mountpoint,
                    'total': f"{usage.total / (1024**3):.1f} GB",
                    'used': f"{usage.used / (1024**3):.1f} GB",
                    'free': f"{usage.free / (1024**3):.1f} GB",
                    'percent': f"{usage.percent}%"
                })
            except:
                pass
        info['disks'] = disks
        
        # Network Info
        info['hostname'] = socket.gethostname()
        info['ip_local'] = socket.gethostbyname(socket.gethostname())
        
        # Battery
        battery = psutil.sensors_battery()
        if battery:
            info['battery_percent'] = f"{battery.percent}%"
            info['battery_plugged'] = battery.power_plugged
        
        # Boot Time
        boot_time = datetime.fromtimestamp(psutil.boot_time())
        info['boot_time'] = boot_time.strftime("%Y-%m-%d %H:%M:%S")
        uptime = datetime.now() - boot_time
        info['uptime'] = f"{uptime.days} days, {uptime.seconds // 3600} hours"
        
        # Print formatted
        print(f"""
╔══════════════════════════════════════════════════════╗
║            📊 RGS_AI SYSTEM REPORT                  ║
╠══════════════════════════════════════════════════════╣
║  💻 OS:           {info['os']} {info['os_release']}
║  🖥️  Machine:     {info['machine']}
║  ⚡ Processor:    {info['processor'][:50]}
║  🧠 CPU Cores:    {info['cpu_count_physical']} Physical / {info['cpu_count_logical']} Logical
║  📈 CPU Usage:    {info['cpu_usage']}%
║  💾 RAM:          {info['ram_used']} / {info['ram_total']} ({info['ram_percent']})
║  🔋 Battery:     {info.get('battery_percent', 'N/A')} {'(Plugged)' if info.get('battery_plugged') else ''}
║  🌐 Hostname:    {info['hostname']}
║  📡 Local IP:    {info['ip_local']}
║  ⏰ Boot Time:   {info['boot_time']}
║  ⏱️  Uptime:      {info['uptime']}
╠══════════════════════════════════════════════════════╣
║  💽 DISK INFORMATION:""")
        
        for disk in disks:
            print(f"║    {disk['device']} ({disk['mountpoint']}): "
                  f"{disk['used']}/{disk['total']} ({disk['percent']})")
        
        print("╚══════════════════════════════════════════════════════╝")
        
        return info
        
    except Exception as e:
        print(f"❌ System Info Error: {e}")
        return None
        
        
        # new_features.py — RGS_AI New Features Module v10.0
# All new voice-command features in one place


# ── State Storage ──────────────────────────────────
_alarms = {}
_screen_recording = {"active": False, "process": None}
_blocked_sites = []


# ═══════════════════════════════════════════════════
#  INTERNET SPEED TEST
# ═══════════════════════════════════════════════════
def internet_speed_test():
    """Run internet speed test using speedtest-cli"""
    try:
        import speedtest
        st = speedtest.Speedtest()
        st.get_best_server()
        download = st.download() / 1_000_000
        upload = st.upload() / 1_000_000
        ping = st.results.ping
        return (
            f"🌐 Internet Speed Test Results:\n"
            f"   📥 Download: {download:.2f} Mbps\n"
            f"   📤 Upload: {upload:.2f} Mbps\n"
            f"   🏓 Ping: {ping:.2f} ms"
        )
    except ImportError:
        return "⚠️ speedtest-cli not installed. Run: pip install speedtest-cli"
    except Exception as e:
        return f"❌ Speed test error: {e}"


# ═══════════════════════════════════════════════════
#  LOCATION / WHERE AM I
# ═══════════════════════════════════════════════════
def get_my_location():
    """Get current location via IP"""
    try:
        import requests
        resp = requests.get("http://ip-api.com/json/", timeout=5)
        data = resp.json()
        return (
            f"📍 Your Location:\n"
            f"   🏙️ City: {data.get('city', 'Unknown')}\n"
            f"   🌍 Region: {data.get('regionName', 'Unknown')}\n"
            f"   🇵🇰 Country: {data.get('country', 'Unknown')}\n"
            f"   📌 Lat: {data.get('lat', 0)}, Lon: {data.get('lon', 0)}\n"
            f"   🌐 IP: {data.get('query', 'Unknown')}\n"
            f"   🏢 ISP: {data.get('isp', 'Unknown')}"
        )
    except Exception as e:
        return f"❌ Location error: {e}"


# ═══════════════════════════════════════════════════
#  SYSTEM TEMPERATURE
# ═══════════════════════════════════════════════════
def get_system_temperature():
    """Get CPU/GPU temperature"""
    try:
        temps = []
        system = platform.system()

        if system == "Windows":
            try:
                import wmi
                w = wmi.WMI(namespace="root\\OpenHardwareMonitor")
                for sensor in w.Sensor():
                    if sensor.SensorType == "Temperature":
                        temps.append(
                            f"   🌡️ {sensor.Name}: {sensor.Value:.1f}°C"
                        )
            except Exception:
                try:
                    output = subprocess.check_output(
                        ["wmic", "/namespace:\\\\root\\wmi",
                         "PATH", "MSAcpi_ThermalZoneTemperature",
                         "get", "CurrentTemperature"],
                        text=True, timeout=5
                    )
                    for line in output.strip().split("\n")[1:]:
                        line = line.strip()
                        if line:
                            val = int(line) - 2732
                            temps.append(
                                f"   🌡️ Thermal Zone: {val/10:.1f}°C"
                            )
                except Exception:
                    pass

        elif system == "Linux":
            try:
                output = subprocess.check_output(
                    ["sensors"], text=True, timeout=5
                )
                for line in output.split("\n"):
                    if "°C" in line or "+" in line:
                        temps.append(f"   🌡️ {line.strip()}")
            except Exception:
                pass

        if temps:
            return f"🌡️ System Temperatures:\n" + "\n".join(temps)
        return "⚠️ Temperature sensors not available. Try: pip install wmi (Windows) or lm-sensors (Linux)"
    except Exception as e:
        return f"❌ Temperature error: {e}"


# ═══════════════════════════════════════════════════
#  PHOTO CAPTURE (WEBCAM)
# ═══════════════════════════════════════════════════
def capture_photo():
    """Capture single photo from webcam"""
    try:
        import cv2
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            return "❌ Webcam not available"

        ret, frame = cap.read()
        cap.release()

        if not ret:
            return "❌ Failed to capture photo"

        folder = os.path.join(os.path.expanduser("~"), "RGS_AI_Photos")
        os.makedirs(folder, exist_ok=True)

        filename = f"photo_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg"
        filepath = os.path.join(folder, filename)
        cv2.imwrite(filepath, frame)

        return f"📸 Photo saved: {filepath}"
    except Exception as e:
        return f"❌ Photo error: {e}"


def capture_burst_photos(count=5):
    """Capture burst photos from webcam"""
    try:
        import cv2
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            return "❌ Webcam not available"

        folder = os.path.join(os.path.expanduser("~"), "RGS_AI_Photos")
        os.makedirs(folder, exist_ok=True)

        saved = []
        for i in range(count):
            ret, frame = cap.read()
            if ret:
                filename = f"burst_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{i}.jpg"
                filepath = os.path.join(folder, filename)
                cv2.imwrite(filepath, frame)
                saved.append(filepath)
            time.sleep(0.3)

        cap.release()
        return f"📸 Burst photos saved ({len(saved)}/{count}): {folder}"
    except Exception as e:
        return f"❌ Burst photo error: {e}"


# ═══════════════════════════════════════════════════
#  WEBSITE BLOCKING / FOCUS MODE
# ═══════════════════════════════════════════════════
def _get_hosts_path():
    if platform.system() == "Windows":
        return r"C:\Windows\System32\drivers\etc\hosts"
    return "/etc/hosts"


def block_websites(sites=None):
    """Block distracting websites"""
    global _blocked_sites
    if sites is None:
        sites = [
            "facebook.com", "www.facebook.com",
            "twitter.com", "www.twitter.com",
            "instagram.com", "www.instagram.com",
            "youtube.com", "www.youtube.com",
            "tiktok.com", "www.tiktok.com",
            "reddit.com", "www.reddit.com",
        ]

    hosts_path = _get_hosts_path()
    redirect = "127.0.0.1"

    try:
        blocked = []
        with open(hosts_path, "a") as f:
            for site in sites:
                if site not in _blocked_sites:
                    f.write(f"\n{redirect} {site}")
                    _blocked_sites.append(site)
                    blocked.append(site)

        if blocked:
            return f"🔒 Focus Mode ON! Blocked: {', '.join(blocked)}"
        return "✅ All sites already blocked"
    except PermissionError:
        return "❌ Run as Administrator to block websites"
    except Exception as e:
        return f"❌ Block error: {e}"


def unblock_websites():
    """Unblock all previously blocked websites"""
    global _blocked_sites

    hosts_path = _get_hosts_path()

    try:
        with open(hosts_path, "r") as f:
            lines = f.readlines()

        cleaned = [l for l in lines if "127.0.0.1" not in l or "localhost" in l]

        with open(hosts_path, "w") as f:
            f.writelines(cleaned)

        count = len(_blocked_sites)
        _blocked_sites = []
        return f"🔓 Focus Mode OFF! Unblocked {count} sites"
    except PermissionError:
        return "❌ Run as Administrator to unblock"
    except Exception as e:
        return f"❌ Unblock error: {e}"


def focus_mode_pro():
    """Pro focus mode — block + notification"""
    result = block_websites()
    return result + "\n🎯 Pro Focus Mode Active! Study hard, Boss! 💪"


# ═══════════════════════════════════════════════════
#  ALARM SYSTEM
# ═══════════════════════════════════════════════════
def set_alarm(time_str, label="RGS_AI Alarm"):
    """Set an alarm for specific time"""
    global _alarms
    try:
        time_str = time_str.strip().upper()

        formats = ["%I:%M %p", "%I:%M%p", "%H:%M", "%I:%M"]
        alarm_time = None

        for fmt in formats:
            try:
                alarm_time = datetime.strptime(time_str, fmt)
                break
            except ValueError:
                continue

        if alarm_time is None:
            return f"❌ Invalid time format: {time_str}. Use HH:MM AM/PM"

        now = datetime.now()
        target = now.replace(
            hour=alarm_time.hour,
            minute=alarm_time.minute,
            second=0, microsecond=0
        )

        if target <= now:
            target = target.replace(day=target.day + 1)

        alarm_id = f"alarm_{len(_alarms)}"
        _alarms[alarm_id] = {
            "time": target,
            "label": label,
            "active": True,
            "thread": None,
        }

        def _alarm_worker():
            while _alarms.get(alarm_id, {}).get("active"):
                if datetime.now() >= target:
                    try:
                        import winsound
                        for _ in range(5):
                            winsound.Beep(1000, 500)
                    except Exception:
                        os.system(
                            'powershell -Command '
                            '"[console]::beep(1000,500)"'
                        )
                    print(f"\n⏰ ALARM! {label}")
                    _alarms[alarm_id]["active"] = False
                    break
                time.sleep(1)

        t = threading.Thread(target=_alarm_worker, daemon=True)
        _alarms[alarm_id]["thread"] = t
        t.start()

        return f"⏰ Alarm set for {target.strftime('%I:%M %p')} — {label}"
    except Exception as e:
        return f"❌ Alarm error: {e}"


def stop_all_alarms():
    """Stop all active alarms"""
    global _alarms
    count = sum(1 for a in _alarms.values() if a.get("active"))
    for aid in _alarms:
        _alarms[aid]["active"] = False
    _alarms = {}
    return f"🔕 Stopped {count} alarm(s)"


def list_alarms():
    """List all active alarms"""
    active = {
        k: v for k, v in _alarms.items() if v.get("active")
    }
    if not active:
        return "📭 No active alarms"

    lines = ["⏰ Active Alarms:"]
    for aid, info in active.items():
        lines.append(
            f"   {aid}: {info['time'].strftime('%I:%M %p')} — {info['label']}"
        )
    return "\n".join(lines)


# ═══════════════════════════════════════════════════
#  SCREEN RECORDING
# ═══════════════════════════════════════════════════
def start_screen_recording():
    """Start screen recording"""
    global _screen_recording

    if _screen_recording["active"]:
        return "⚠️ Recording already in progress!"

    try:
        folder = os.path.join(
            os.path.expanduser("~"), "RGS_AI_Recordings"
        )
        os.makedirs(folder, exist_ok=True)

        filename = os.path.join(
            folder,
            f"recording_{datetime.now().strftime('%Y%m%d_%H%M%S')}.mp4"
        )

        try:
            import mss
            import numpy as np

            def _record():
                import cv2
                sct = mss.mss()
                mon = sct.monitors[1]

                fourcc = cv2.VideoWriter_fourcc(*"mp4v")
                out = cv2.VideoWriter(
                    filename, fourcc, 10.0,
                    (mon["width"], mon["height"])
                )

                _screen_recording["active"] = True

                while _screen_recording["active"]:
                    img = np.array(sct.grab(mon))
                    frame = cv2.cvtColor(img, cv2.COLOR_BGRA2BGR)
                    out.write(frame)
                    time.sleep(0.05)

                out.release()

            t = threading.Thread(target=_record, daemon=True)
            _screen_recording["process"] = t
            t.start()

            return f"🔴 Screen recording started! Saving to: {filename}"

        except ImportError:
            return "⚠️ Need: pip install mss opencv-python numpy"

    except Exception as e:
        return f"❌ Recording error: {e}"


def stop_screen_recording():
    """Stop screen recording"""
    global _screen_recording

    if not _screen_recording["active"]:
        return "⚠️ No recording in progress!"

    _screen_recording["active"] = False

    if _screen_recording["process"]:
        _screen_recording["process"].join(timeout=5)

    _screen_recording["process"] = None
    return "⏹️ Screen recording stopped! Check RGS_AI_Recordings folder"


# ═══════════════════════════════════════════════════
#  BRIGHTNESS CONTROL
# ═══════════════════════════════════════════════════
def set_brightness(level):
    """Set screen brightness (0-100)"""
    try:
        level = max(0, min(100, int(level)))
        system = platform.system()

        if system == "Windows":
            try:
                import screen_brightness_control as sbc
                sbc.set_brightness(level)
                return f"🔆 Brightness set to {level}%"
            except ImportError:
                subprocess.run(
                    [
                        "powershell",
                        "-Command",
                        f"(Get-WmiObject -Namespace "
                        f"root/WMI -Class WmiMonitorBrightnessMethods)"
                        f".WmiSetBrightness(1,{level})"
                    ],
                    timeout=5
                )
                return f"🔆 Brightness set to {level}%"

        elif system == "Linux":
            subprocess.run(
                ["xrandr", "--output", "eDP-1",
                 "--brightness", str(level / 100)],
                timeout=5
            )
            return f"🔆 Brightness set to {level}%"

        return "⚠️ Brightness control not supported on this OS"
    except Exception as e:
        return f"❌ Brightness error: {e}"


def get_brightness():
    """Get current brightness level"""
    try:
        import screen_brightness_control as sbc
        level = sbc.get_brightness()
        if isinstance(level, list):
            level = level[0]
        return f"🔆 Current brightness: {level}%"
    except ImportError:
        return "⚠️ pip install screen-brightness-control"
    except Exception as e:
        return f"❌ Brightness read error: {e}"


# ═══════════════════════════════════════════════════
#  YOUTUBE DOWNLOAD
# ═══════════════════════════════════════════════════
def download_youtube_video(url, audio_only=False):
    """Download YouTube video or audio"""
    try:
        from media_downloader import media_downloader

        if audio_only:
            return media_downloader.download_mp3(url)
        return media_downloader.download_youtube(url, "best")
    except Exception as e:
        return f"❌ YouTube download error: {e}"


# ═══════════════════════════════════════════════════
#  PRAYER TIMES
# ═══════════════════════════════════════════════════
def get_prayer_times(city="Karachi"):
    """Get prayer times for a city"""
    try:
        from lifestyle import prayer_times
        return prayer_times.get_times(city)
    except Exception:
        try:
            import requests
            resp = requests.get(
                f"http://api.aladhan.com/v1/timingsByCity"
                f"?city={city}&country=Pakistan&method=1",
                timeout=5
            )
            data = resp.json()["data"]["timings"]
            return (
                f"🕌 Prayer Times ({city}):\n"
                f"   🌅 Fajr: {data.get('Fajr', 'N/A')}\n"
                f"   ☀️ Dhuhr: {data.get('Dhuhr', 'N/A')}\n"
                f"   🌤️ Asr: {data.get('Asr', 'N/A')}\n"
                f"   🌇 Maghrib: {data.get('Maghrib', 'N/A')}\n"
                f"   🌙 Isha: {data.get('Isha', 'N/A')}"
            )
        except Exception as e:
            return f"❌ Prayer times error: {e}"


# ═══════════════════════════════════════════════════
#  CLIPBOARD MANAGEMENT
# ═══════════════════════════════════════════════════
_clipboard_history = []


def copy_to_clipboard_new(text):
    """Copy text to clipboard"""
    try:
        import pyperclip
        pyperclip.copy(text)
        _clipboard_history.append(text)
        return f"📋 Copied to clipboard: {text[:50]}..."
    except Exception as e:
        return f"❌ Copy error: {e}"


def paste_from_clipboard():
    """Read current clipboard"""
    try:
        import pyperclip
        text = pyperclip.paste()
        return f"📋 Clipboard: {text[:200]}"
    except Exception as e:
        return f"❌ Paste error: {e}"


def show_clipboard_history():
    """Show clipboard history"""
    if not _clipboard_history:
        return "📋 Clipboard history is empty"
    lines = ["📋 Clipboard History:"]
    for i, item in enumerate(_clipboard_history[-10:], 1):
        lines.append(f"   {i}. {item[:80]}")
    return "\n".join(lines)


# ═══════════════════════════════════════════════════
#  SYSTEM POWER
# ═══════════════════════════════════════════════════
def shutdown_system():
    try:
        from app import shutdown_pc
        return shutdown_pc()
    except Exception:
        os.system("shutdown /s /t 10")
        return "🔌 Shutting down in 10 seconds..."


def restart_system():
    try:
        from app import restart_pc
        return restart_pc()
    except Exception:
        os.system("shutdown /r /t 10")
        return "🔄 Restarting in 10 seconds..."


def sleep_system():
    try:
        from app import sleep_pc
        return sleep_pc()
    except Exception:
        os.system("rundll32.exe powrprof.dll,SetSuspendState 0,1,0")
        return "💤 Going to sleep..."


def lock_screen():
    try:
        from app import lock_pc
        return lock_pc()
    except Exception:
        os.system("rundll32.exe user32.dll,LockWorkStation")
        return "🔒 Screen locked"


# ═══════════════════════════════════════════════════
#  MOUSE CLICK
# ═══════════════════════════════════════════════════
def mouse_click():
    """Click at current mouse position"""
    try:
        import pyautogui
        pyautogui.click()
        return "🖱️ Clicked!"
    except Exception as e:
        return f"❌ Click error: {e}"


# ═══════════════════════════════════════════════════
#  PDF READER
# ═══════════════════════════════════════════════════
def read_pdf(pdf_path):
    """Read PDF file content"""
    try:
        from pdf_assistant import pdf_assistant
        return pdf_assistant.summarize_pdf(pdf_path)
    except Exception as e:
        return f"❌ PDF read error: {e}"


def pdf_to_audio(pdf_path):
    """Convert PDF to audio"""
    try:
        from pdf_assistant import pdf_assistant
        return pdf_assistant.read_document_aloud(pdf_path)
    except Exception as e:
        return f"❌ PDF audio error: {e}"


# ═══════════════════════════════════════════════════
#  WINDOW MANAGEMENT
# ═══════════════════════════════════════════════════
def get_active_windows():
    """List all active windows"""
    try:
        import pyautogui
        try:
            import pygetwindow as gw
            windows = gw.getAllTitles()
            active = [w for w in windows if w.strip()]
            return (
                f"🪟 Active Windows ({len(active)}):\n" +
                "\n".join(f"   • {w}" for w in active[:20])
            )
        except ImportError:
            return "⚠️ pip install pygetwindow"
    except Exception as e:
        return f"❌ Window list error: {e}"


def minimize_window(title=None):
    try:
        import pygetwindow as gw
        if title:
            wins = gw.getWindowsWithTitle(title)
        else:
            wins = [gw.getActiveWindow()]

        for w in wins:
            if w:
                w.minimize()
        return f"🪟 Minimized: {title or 'active window'}"
    except Exception as e:
        return f"❌ Minimize error: {e}"


def maximize_window(title=None):
    try:
        import pygetwindow as gw
        if title:
            wins = gw.getWindowsWithTitle(title)
        else:
            wins = [gw.getActiveWindow()]

        for w in wins:
            if w:
                w.maximize()
        return f"🪟 Maximized: {title or 'active window'}"
    except Exception as e:
        return f"❌ Maximize error: {e}"


def close_window(title=None):
    try:
        import pygetwindow as gw
        if title:
            wins = gw.getWindowsWithTitle(title)
        else:
            wins = [gw.getActiveWindow()]

        for w in wins:
            if w:
                w.close()
        return f"🪟 Closed: {title or 'active window'}"
    except Exception as e:
        return f"❌ Close window error: {e}"


# ═══════════════════════════════════════════════════
#  QR CODE
# ═══════════════════════════════════════════════════
def generate_qr_code(data):
    """Generate QR code from text/URL"""
    try:
        import qrcode
        qr = qrcode.QRCode(version=1, box_size=10, border=2)
        qr.add_data(data)
        qr.make(fit=True)

        folder = os.path.join(
            os.path.expanduser("~"), "RGS_AI_QRCodes"
        )
        os.makedirs(folder, exist_ok=True)

        filename = os.path.join(
            folder,
            f"qr_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
        )

        img = qr.make_image(fill_color="black", back_color="white")
        img.save(filename)

        return f"📱 QR Code saved: {filename}"
    except ImportError:
        return "⚠️ pip install qrcode[pil]"
    except Exception as e:
        return f"❌ QR error: {e}"


# ═══════════════════════════════════════════════════
#  DETAILED SYSTEM INFO
# ═══════════════════════════════════════════════════
def detailed_system_info():
    """Get comprehensive system information"""
    try:
        import psutil
        import platform as pl

        cpu_percent = psutil.cpu_percent(interval=1)
        ram = psutil.virtual_memory()
        disk = psutil.disk_usage("/")
        boot = datetime.fromtimestamp(psutil.boot_time())

        return (
            f"🖥️ System Information:\n"
            f"   📌 OS: {pl.system()} {pl.release()}\n"
            f"   💻 Machine: {pl.machine()}\n"
            f"   🧠 CPU: {pl.processor()}\n"
            f"   📊 CPU Usage: {cpu_percent}%\n"
            f"   💾 RAM: {ram.percent}% "
            f"({ram.used // (1024**3)}/{ram.total // (1024**3)} GB)\n"
            f"   💿 Disk: {disk.percent}% "
            f"({disk.used // (1024**3)}/{disk.total // (1024**3)} GB)\n"
            f"   ⏰ Boot Time: {boot.strftime('%Y-%m-%d %H:%M:%S')}\n"
            f"   🔋 Battery: {_get_battery_info()}\n"
            f"   🌐 Hostname: {pl.node()}"
        )
    except Exception as e:
        return f"❌ System info error: {e}"


def _get_battery_info():
    try:
        import psutil
        bat = psutil.sensors_battery()
        if bat:
            plug = "⚡ Plugged" if bat.power_plugged else "🔋 On Battery"
            return f"{bat.percent}% {plug}"
        return "N/A"
    except Exception:
        return "N/A"