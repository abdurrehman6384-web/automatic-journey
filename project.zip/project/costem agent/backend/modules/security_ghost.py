# security_ghost.py — Network Scanner, VPN, Encryption, Anti-Spyware
import subprocess
import os
from cryptography.fernet import Fernet
from ..config import VPN_CLI_PATH, ENCRYPTION_KEY, MEMORY_FILE, logger
from ..error_handler import safe_execute


class IntrusionDetector:
    """Scan network for unauthorized devices"""
    @safe_execute(max_retries=1)
    def scan_network(self) -> str:
        try:
            # Using arp -a for Windows (no nmap dependency required)
            result = subprocess.run(
                ["arp", "-a"],
                capture_output=True, text=True, timeout=10
            )
            lines = result.stdout.strip().split('\n')
            devices = [l.strip() for l in lines if "---" not in l and "Interface" not in l and l.strip()]
            return f"🌐 Found {len(devices)} devices on network:\n" + "\n".join(devices[:15])
        except Exception as e:
            return f"❌ Scan error: {e}"


class VPNController:
    """Control VPN via CLI"""
    def connect(self) -> str:
        if not VPN_CLI_PATH:
            return "❌ VPN CLI path not set in .env"
        try:
            subprocess.Popen([VPN_CLI_PATH, "connect"], shell=True)
            return "🔐 VPN connecting..."
        except Exception as e:
            return f"❌ VPN error: {e}"

    def disconnect(self) -> str:
        if not VPN_CLI_PATH:
            return "❌ VPN CLI path not set"
        try:
            subprocess.Popen([VPN_CLI_PATH, "disconnect"], shell=True)
            return "🔓 VPN disconnected"
        except Exception as e:
            return f"❌ VPN error: {e}"


class MemoryEncryptor:
    """Encrypt/Decrypt memory file with Fernet"""
    def __init__(self):
        key = ENCRYPTION_KEY.encode()[:32].ljust(32, b'0')
        import base64
        self.fernet = Fernet(base64.urlsafe_b64encode(key))

    @safe_execute(max_retries=1)
    def encrypt_memory(self) -> str:
        if not os.path.exists(MEMORY_FILE):
            return "❌ Memory file not found"
        with open(MEMORY_FILE, 'rb') as f:
            data = f.read()
        encrypted = self.fernet.encrypt(data)
        with open(MEMORY_FILE + ".enc", 'wb') as f:
            f.write(encrypted)
        os.remove(MEMORY_FILE)
        return "🔒 Memory encrypted!"

    @safe_execute(max_retries=1)
    def decrypt_memory(self) -> str:
        enc_file = MEMORY_FILE + ".enc"
        if not os.path.exists(enc_file):
            return "❌ Encrypted file not found"
        with open(enc_file, 'rb') as f:
            data = f.read()
        decrypted = self.fernet.decrypt(data)
        with open(MEMORY_FILE, 'wb') as f:
            f.write(decrypted)
        os.remove(enc_file)
        return "🔓 Memory decrypted!"


class AntiSpyware:
    """Kill known suspicious processes"""
    SUSPICIOUS_PROCS = [
        "keylogger.exe", "spy.exe", "stealer.exe", "rat.exe", 
        "vnc.exe", "teamviewer.exe", "anydesk.exe"  # Add/remove as needed
    ]

    def scan_and_kill(self) -> str:
        import psutil
        killed = []
        for proc in psutil.process_iter(['name']):
            try:
                if proc.info['name'].lower() in self.SUSPICIOUS_PROCS:
                    proc.kill()
                    killed.append(proc.info['name'])
            except Exception:
                pass
        if killed:
            return f"🛡️ Killed suspicious processes: {', '.join(killed)}"
        return "✅ System clean! No spyware detected."

# Global instances
intrusion_detector = IntrusionDetector()
vpn_controller = VPNController()
memory_encryptor = MemoryEncryptor()
anti_spyware = AntiSpyware()