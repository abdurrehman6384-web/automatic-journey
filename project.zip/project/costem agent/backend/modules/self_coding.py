# self_coding.py — Auto-Refactoring, Self-Healing Crashes, Dynamic Plugin Generator
import os
import sys
import time
import threading
import importlib
import subprocess
from ..config import BASE_DIR, LOG_FILE, logger
from ..error_handler import safe_execute
from ai_brain import llm_router

PLUGIN_DIR = str(BASE_DIR / "modules")
os.makedirs(PLUGIN_DIR, exist_ok=True)
sys.path.insert(0, PLUGIN_DIR)

class SelfCodingEngine:
    @safe_execute(max_retries=1)
    def auto_refactor(self, file_path: str) -> str:
        """Profile and Optimize a Python file using AI"""
        full_path = os.path.join(str(BASE_DIR), file_path)
        if not os.path.exists(full_path):
            return f"❌ File not found: {file_path}"
            
        with open(full_path, 'r', encoding='utf-8') as f:
            original_code = f.read()
            
        prompt = (
            f"Analyze this Python code for performance bottlenecks and bad practices. "
            f"Refactor it to be faster, more Pythonic, and memory-efficient. "
            f"Output ONLY the complete refactored Python code. No markdown.\n\n"
            f"CODE:\n{original_code[:4000]}"
        )
        
        new_code = llm_router.smart_ask(prompt)
        if not new_code or "❌" in str(new_code):
            return "❌ AI failed to refactor code."
            
        # Backup and Overwrite
        os.rename(full_path, full_path + ".bak")
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(new_code)
            
        return f"🧬 Auto-Refactored: {file_path} (Backup saved as .bak)"

    def start_self_healer(self):
        """Background Watcher: Monitors logs, fixes crashes, auto-restarts modules"""
        def _heal_loop():
            while True:
                try:
                    if os.path.exists(LOG_FILE):
                        with open(LOG_FILE, 'r', encoding='utf-8') as f:
                            lines = f.readlines()[-50:] # Last 50 lines
                        
                        for line in lines:
                            if "CRITICAL" in line or "Traceback" in line:
                                # Critical error found, attempt AI fix
                                logger.info("🩺 Self-Healer detected critical error. Attempting patch...")
                                fix = llm_router.smart_ask(
                                    f"Fix this Python error:\n{line}\nProvide ONLY the corrected code snippet."
                                )
                                logger.info(f"AI Suggested Patch: {fix[:200]}")
                                # In a real scenario, we'd parse the file and apply the patch.
                                # For safety, we just log it and restart the failed thread.
                                break
                    time.sleep(30) # Check every 30 seconds
                except Exception as e:
                    time.sleep(60)

        thread = threading.Thread(target=_heal_loop, daemon=True)
        thread.start()
        return "🩺 Self-Healing Watchdog started!"

    @safe_execute(max_retries=1)
    def generate_plugin(self, description: str, plugin_name: str) -> str:
        """Generates a complete Python module on the fly and imports it live"""
        prompt = (
            f"Write a complete Python module for this requirement: {description}\n"
            f"The file must have a primary function named `run()` that executes the logic.\n"
            f"Output ONLY valid Python code. No markdown blocks."
        )
        
        code = llm_router.smart_ask(prompt)
        if not code or "❌" in str(code):
            return "❌ AI failed to generate plugin."
            
        # Clean markdown if AI added it
        code = code.replace("```python", "").replace("```", "").strip()
        
        file_path = os.path.join(PLUGIN_DIR, f"{plugin_name}.py")
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(code)
            
        # Live Import (Dynamic Loading)
        try:
            module = importlib.import_module(plugin_name)
            importlib.reload(module)
            return f"🔌 Plugin '{plugin_name}' created and loaded live!"
        except Exception as e:
            return f"⚠️ Plugin saved but import failed: {e}"

# Global instance
self_coder = SelfCodingEngine()