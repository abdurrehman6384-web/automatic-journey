# screen_translator.py — Real-Time Screen Translator
import threading
import time
from ..config import logger
from ..error_handler import safe_execute

class ScreenTranslator:
    """
    Captures screen regions, OCRs text, translates it, 
    and shows in a floating window.
    """

    @safe_execute(max_retries=1)
    def translate_screen_region(self, target_lang: str = "en") -> str:
        """OCR current screen and translate all text"""
        from vision import vision
        from deep_translator import GoogleTranslator
        
        # Get screen text via OCR
        text = vision.read_screen_text()
        if not text or len(text.strip()) < 3:
            return "❌ No text found on screen to translate."
        
        # Translate
        try:
            translator = GoogleTranslator(source='auto', target=target_lang)
            translated = translator.translate(text[:5000])
            return f"🌐 Translated Screen:\n\n{translated}"
        except Exception as e:
            return f"❌ Translation error: {e}"

    @safe_execute(max_retries=1)
    def open_translation_overlay(self, target_lang: str = "en") -> str:
        """Open a floating window that continuously translates screen text"""
        def _overlay_loop():
            try:
                import tkinter as tk
                from deep_translator import GoogleTranslator
                from vision import vision
                
                root = tk.Tk()
                root.title("🌐 RGS_AI Translator")
                root.geometry("400x300+10+10")
                root.attributes("-topmost", True)
                root.configure(bg="#1a1a2e")
                
                text_widget = tk.Text(root, wrap=tk.WORD, bg="#1a1a2e", fg="#00ff88",
                                      font=("Consolas", 10), padx=10, pady=10)
                text_widget.pack(fill=tk.BOTH, expand=True)
                
                translator = GoogleTranslator(source='auto', target=target_lang)
                
                def update_translation():
                    try:
                        screen_text = vision.read_screen_text()
                        if screen_text and len(screen_text.strip()) > 2:
                            translated = translator.translate(screen_text[:2000])
                            text_widget.delete(1.0, tk.END)
                            text_widget.insert(tk.END, translated)
                    except Exception:
                        pass
                    root.after(3000, update_translation)  # Update every 3 seconds
                
                update_translation()
                root.mainloop()
            except Exception as e:
                logger.error(f"Overlay error: {e}")
        
        t = threading.Thread(target=_overlay_loop, daemon=True)
        t.start()
        return "🌐 Translation overlay opened! (Close window to stop)"


# Global instance
screen_translator = ScreenTranslator()