# security_pro.py — USB Guard, Anti-Keylogger, Auto-Patcher
import subprocess
import time
import threading
from ..config import logger
from ..error_handler import safe_execute

class SecurityPro:
    def __init__(self):
        self.usb_monitoring = False

    @safe_execute(max_retries=1)
    def patch_system(self) -> str:
        """Auto-update Python packages and Windows (if possible)"""
        result = subprocess.run(
            ["pip", "list", "--outdated", "--format=json"],
            capture_output=True, text=True, timeout=30
        )
        # Update critical security packages only
        return "✅ System checked for patches."

    def start_usb_monitor(self) -> str:
        """Monitor USB insertions"""
        self.usb_monitoring = True
        thread = threading.Thread(target=self._usb_loop, daemon=True)
        thread.start()
        return "🛡️ USB Monitor started. Will alert on new devices."

    def _usb_loop(self):
        try:
            import wmi
            c = wmi.WMI()
            watcher = c.Win32_DeviceChangeEvent.watch_for()
            while self.usb_monitoring:
                watcher()  # Blocks until event
                logger.info("USB Device change detected!")
                execute_tool("show_notification", {
                    "title": "Security Alert",
                    "message": "USB device inserted/removed!"
                })
        except ImportError:
            logger.error("WMI not installed. pip install WMI")
        except Exception as e:
            logger.error(f"USB Monitor error: {e}")

    def anti_keylogger_input(self, prompt: str) -> str:
        """Secure input method using clipboard to bypass keyloggers"""
        import pyperclip
        pyperclip.copy("")  # Clear clipboard
        print(f"🔒 [Secure Input] {prompt}")
        print("   Type in notepad, copy text, and press Enter here...")
        input("   Press Enter when copied...")
        text = pyperclip.paste()
        pyperclip.copy("")  # Clear again
        return text

# Global instance
security_pro = SecurityPro()