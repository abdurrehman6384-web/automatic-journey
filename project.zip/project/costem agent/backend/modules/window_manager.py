# window_manager.py — Window Manager (Snap, Resize, Minimize)
from ..error_handler import safe_execute

class WindowManager:

    @safe_execute(max_retries=1)
    def snap_left(self) -> str:
        """Snap active window to left half"""
        import pygetwindow as gw
        win = gw.getActiveWindow()
        if win:
            screen = gw.getWindowsWithTitle(win.title)[0]
            screen.moveTo(0, 0)
            screen.resizeTo(960, 1080)
            return "🪟 Window snapped left!"
        return "❌ No active window"

    @safe_execute(max_retries=1)
    def snap_right(self) -> str:
        """Snap active window to right half"""
        import pygetwindow as gw
        win = gw.getActiveWindow()
        if win:
            screen = gw.getWindowsWithTitle(win.title)[0]
            screen.moveTo(960, 0)
            screen.resizeTo(960, 1080)
            return "🪟 Window snapped right!"
        return "❌ No active window"

    @safe_execute(max_retries=1)
    def minimize_all(self) -> str:
        """Minimize all windows"""
        import pygetwindow as gw
        for w in gw.getAllWindows():
            if w.title:
                w.minimize()
        return "🪟 All windows minimized!"

    @safe_execute(max_retries=1)
    def maximize(self) -> str:
        """Maximize active window"""
        import pygetwindow as gw
        win = gw.getActiveWindow()
        if win:
            win.maximize()
            return "🪟 Window maximized!"
        return "❌ No active window"

    @safe_execute(max_retries=1)
    def always_on_top(self) -> str:
        """Set active window always on top"""
        import ctypes
        import pygetwindow as gw
        win = gw.getActiveWindow()
        if win:
            hwnd = win._hWnd
            ctypes.windll.user32.SetWindowPos(hwnd, -1, 0, 0, 0, 0, 0x0003)
            return "📌 Window set to always on top!"
        return "❌ No active window"


# Global instance
window_mgr = WindowManager()