# uploader.py — RGS_AI YouTube + Instagram Auto Uploader v6.0
import os
import time
import json
import requests
from pathlib import Path
from ..error_handler import safe_execute, logger
from ..config import YOUTUBE_CREDENTIALS_FILE

try:
    from googleapiclient.discovery import build
    from googleapiclient.http import MediaFileUpload
    from google_auth_oauthlib.flow import InstalledAppScope
    from google.auth.transport.requests import Request
    from google.oauth2.credentials import Credentials
    import pickle
    YOUTUBE_AVAILABLE = True
except ImportError:
    YOUTUBE_AVAILABLE = False
    logger.warning("Google API packages not installed. YouTube upload disabled.")

YOUTUBE_SCOPES = [
    "https://www.googleapis.com/auth/youtube.upload",
    "https://www.googleapis.com/auth/youtube"
]
YOUTUBE_TOKEN_FILE = str(Path.home() / "rgs_ai_youtube_token.pkl")
INSTAGRAM_CREDS_FILE = str(Path.home() / "rgs_ai_instagram.json")


def get_youtube_service():
    if not YOUTUBE_AVAILABLE:
        return None, "❌ Google API packages not installed."
    creds = None
    if os.path.exists(YOUTUBE_TOKEN_FILE):
        with open(YOUTUBE_TOKEN_FILE, 'rb') as f:
            creds = pickle.load(f)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            if not os.path.exists(YOUTUBE_CREDENTIALS_FILE):
                return None, "❌ youtube_credentials.json not found!"
            flow = InstalledAppFlow.from_client_secrets_file(
                YOUTUBE_CREDENTIALS_FILE, YOUTUBE_SCOPES
            )
            creds = flow.run_local_server(port=0)
        with open(YOUTUBE_TOKEN_FILE, 'wb') as f:
            pickle.dump(creds, f)
    service = build('youtube', 'v3', credentials=creds)
    return service, None


@safe_execute(max_retries=2)
def upload_youtube_video(
    video_path, title="My Video",
    description="Uploaded by RGS_AI AI",
    tags=None, privacy="private", category="22"
):
    if not os.path.exists(video_path):
        return f"❌ Video not found: {video_path}"
    service, error = get_youtube_service()
    if error:
        return error
    body = {
        "snippet": {
            "title": title, "description": description,
            "tags": tags or ["RGS_AI", "AI", "Abdurrehman"],
            "categoryId": category
        },
        "status": {"privacyStatus": privacy}
    }
    media = MediaFileUpload(
        video_path, chunksize=-1, resumable=True, mimetype="video/*"
    )
    request = service.videos().insert(
        part=",".join(body.keys()), body=body, media_body=media
    )
    response = None
    while response is None:
        status, response = request.next_chunk()
        if status:
            print(f"   Upload: {int(status.progress() * 100)}%")
    vid = response.get("id", "")
    return f"✅ YouTube upload done! https://youtube.com/watch?v={vid}"


def get_my_youtube_videos():
    service, error = get_youtube_service()
    if error:
        return error
    try:
        resp = service.videos().list(
            part="snippet,statistics", mine=True, maxResults=10
        ).execute()
        items = resp.get("items", [])
        if not items:
            return "No videos found."
        result = "📺 Your Videos:\n"
        for i, item in enumerate(items, 1):
            t = item["snippet"]["title"]
            v = item.get("statistics", {}).get("viewCount", "0")
            result += f"{i}. {t} (Views: {v})\n"
        return result
    except Exception as e:
        return f"❌ Error: {e}"


def save_instagram_creds(username, password):
    with open(INSTAGRAM_CREDS_FILE, 'w') as f:
        json.dump({"username": username, "password": password}, f)
    return "✅ Instagram credentials saved!"


def load_instagram_creds():
    if not os.path.exists(INSTAGRAM_CREDS_FILE):
        return None, None
    with open(INSTAGRAM_CREDS_FILE, 'r') as f:
        data = json.load(f)
    return data.get("username"), data.get("password")


def upload_instagram_photo(
    image_path, caption="Posted by RGS_AI AI 🤖",
    username=None, password=None
):
    try:
        from instagrapi import Client
        if not os.path.exists(image_path):
            return f"❌ Image not found: {image_path}"
        if not username or not password:
            username, password = load_instagram_creds()
        if not username:
            return "❌ Instagram login first!"
        cl = Client()
        session = str(Path.home() / f"rgs_ai_ig_{username}.json")
        if os.path.exists(session):
            try:
                cl.load_settings(session)
                cl.login(username, password)
            except Exception:
                cl = Client()
                cl.login(username, password)
        else:
            cl.login(username, password)
        cl.dump_settings(session)
        media = cl.photo_upload(path=image_path, caption=caption)
        return f"✅ Instagram photo uploaded! ID: {media.id}"
    except ImportError:
        return "❌ pip install instagrapi"
    except Exception as e:
        return f"❌ Instagram error: {e}"


def upload_instagram_video(
    video_path, caption="Posted by RGS_AI AI 🤖",
    username=None, password=None
):
    try:
        from instagrapi import Client
        if not os.path.exists(video_path):
            return f"❌ Video not found: {video_path}"
        if not username or not password:
            username, password = load_instagram_creds()
        if not username:
            return "❌ Instagram login first!"
        cl = Client()
        session = str(Path.home() / f"rgs_ai_ig_{username}.json")
        if os.path.exists(session):
            try:
                cl.load_settings(session)
                cl.login(username, password)
            except Exception:
                cl = Client()
                cl.login(username, password)
        else:
            cl.login(username, password)
        cl.dump_settings(session)
        media = cl.clip_upload(path=video_path, caption=caption)
        return f"✅ Instagram video uploaded! ID: {media.id}"
    except Exception as e:
        return f"❌ Instagram video error: {e}"


def get_instagram_profile(
    username_target=None, username=None, password=None
):
    try:
        from instagrapi import Client
        if not username or not password:
            username, password = load_instagram_creds()
        if not username:
            return "❌ Instagram login first!"
        cl = Client()
        cl.login(username, password)
        target = username_target or username
        user = cl.user_info_by_username(target)
        return (
            f"📱 @{target}\n"
            f"Followers: {user.follower_count}\n"
            f"Following: {user.following_count}\n"
            f"Posts: {user.media_count}"
        )
    except Exception as e:
        return f"❌ Profile error: {e}"