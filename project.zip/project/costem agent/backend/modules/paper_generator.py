# ╔══════════════════════════════════════════════════════════╗
# ║       paper_generator.py — RGS_AI PDF Paper Generator   ║
# ║       Generates 5-Year Past Papers for Class 9           ║
# ║       All Subjects — Print-Ready PDFs                    ║
# ╚══════════════════════════════════════════════════════════╝

import os
from fpdf import FPDF
import random

class PaperPDF(FPDF):
    """Custom PDF class with Header/Footer"""
    
    def header(self):
        self.set_font('Helvetica', 'B', 14)
        self.cell(0, 10, 'BOARD OF INTERMEDIATE & SECONDARY EDUCATION', 0, 1, 'C')
        self.set_font('Helvetica', '', 10)
        self.cell(0, 6, 'MODEL / PAST PAPER EXAMINATION', 0, 1, 'C')
        self.line(10, self.get_y(), 200, self.get_y())
        self.ln(5)

    def footer(self):
        self.set_y(-15)
        self.set_font('Helvetica', 'I', 8)
        self.cell(0, 10, f'Page {self.page_no()}/{{nb}}', 0, 0, 'C')

    def section_title(self, title):
        self.set_font('Helvetica', 'B', 12)
        self.set_fill_color(230, 230, 250)
        self.cell(0, 10, title, 0, 1, 'L', True)
        self.ln(3)

    def question(self, num, text, marks=""):
        self.set_font('Helvetica', '', 10)
        q_text = f"Q{num}. {text}"
        if marks:
            q_text += f"  [{marks}]"
        self.multi_cell(0, 7, q_text)
        self.ln(2)

    def mcq(self, num, question_text, options):
        self.set_font('Helvetica', 'B', 10)
        self.multi_cell(0, 7, f"Q{num}. {question_text}")
        self.set_font('Helvetica', '', 10)
        for opt, text in options.items():
            self.cell(10)
            self.cell(0, 6, f"({opt}) {text}")
            self.ln()
        self.ln(3)


# ════════════════════════════════════════════════════════
# QUESTION BANKS (5 Years Variety)
# ════════════════════════════════════════════════════════

QUESTION_BANKS = {
    "Mathematics": {
        "mcqs": [
            ("det[[2,3],[1,4]] ka maan hai:", {"A": "5", "B": "11", "C": "-5", "D": "8"}, "B"),
            ("log10(1000) ka maan hai:", {"A": "2", "B": "3", "C": "4", "D": "10"}, "B"),
            ("(a+b)^2 = ?", {"A": "a^2+b^2", "B": "a^2+2ab+b^2", "C": "a^2-2ab+b^2", "D": "2ab"}, "B"),
            ("Identity matrix mein diagonal elements:", {"A": "0", "B": "1", "C": "-1", "D": "2"}, "B"),
            ("sqrt(-1) kya kehlata hai?", {"A": "Real", "B": "Irrational", "C": "Imaginary (i)", "D": "Zero"}, "C"),
            ("2x + 3 = 7 mein x = ?", {"A": "1", "B": "2", "C": "3", "D": "4"}, "B"),
            ("Right angle ki measurement hai:", {"A": "60 deg", "B": "90 deg", "C": "180 deg", "D": "360 deg"}, "B"),
            ("Complementary angles ka total:", {"A": "45 deg", "B": "90 deg", "C": "180 deg", "D": "360 deg"}, "B"),
            ("Midpoint formula mein (x1+x2)/2 kya hai?", {"A": "x-coordinate", "B": "y-coordinate", "C": "Slope", "D": "Distance"}, "A"),
            ("HCF of 12 and 18:", {"A": "2", "B": "4", "C": "6", "D": "36"}, "C"),
        ],
        "short": [
            "Matrix ke determinant kaise nikalte hain? Example dein.",
            "log ab = log a + log b ko explain karein.",
            "Real aur Complex numbers mein farq batayein.",
            "a^2 - b^2 ka formula likhein aur solve karein: 9x^2 - 16y^2",
            "Distance formula likhein aur ek example solve karein.",
            "x+y=5, x-y=1 ko substitution method se solve karein.",
            "Pythagoras theorem explain karein.",
            "Similar aur Congruent triangles mein farq batayein.",
            "Coordinate Geometry mein slope kya hai? Formula likhein.",
            "Ratio aur Proportion mein farq batayein with example.",
            "HCF aur LCM mein farq batayein.",
            "Linear equation ka graph kaise banate hain?",
            "Inequality kya hai? 2x > 6 ko solve karein.",
            "Collinear points kya hain? How to check them?",
            "Angle bisector ka theorem likhein.",
        ],
        "long": [
            "Simultaneous linear equations ko Elimination method se solve karein. 2 examples dein.",
            "Pythagoras Theorem prove karein aur uska practical use batayein.",
            "Factorization ke 5 methods batayein with examples.",
            "Congruent triangles ke 4 postulates explain karein with diagrams.",
            "Distance aur Midpoint formula derive karein aur examples solve karein.",
        ]
    },
    "Chemistry": {
        "mcqs": [
            ("Atom ka nucleus kis cheez se bana hai?", {"A": "Electrons", "B": "Protons & Neutrons", "C": "Only Protons", "D": "Only Neutrons"}, "B"),
            ("Avogadro's number ka maan hai:", {"A": "6.022x10^23", "B": "6.022x10^22", "C": "3.14x10^23", "D": "1.6x10^-19"}, "A"),
            ("pH 7 ka matlab hai:", {"A": "Acidic", "B": "Basic", "C": "Neutral", "D": "Salt"}, "C"),
            ("Oxygen ka atomic number:", {"A": "6", "B": "7", "C": "8", "D": "9"}, "C"),
            ("Konsa period mein elements sabse kam hain?", {"A": "1st", "B": "2nd", "C": "3rd", "D": "6th"}, "A"),
            ("Ionic bond banta hai:", {"A": "Metal + Metal", "B": "Non-metal + Non-metal", "C": "Metal + Non-metal", "D": "Same elements"}, "C"),
            ("Kelvin mein 0 C = ?", {"A": "0 K", "B": "100 K", "C": "273 K", "D": "-273 K"}, "C"),
            ("Molecular formula batata hai:", {"A": "Only types of atoms", "B": "Types and actual number of atoms", "C": "Only mass", "D": "Only charge"}, "B"),
            ("Cathode ray tube mein particles:", {"A": "Protons", "B": "Neutrons", "C": "Electrons", "D": "Alpha particles"}, "C"),
            ("Solution ka example:", {"A": "Sand + Water", "B": "Oil + Water", "C": "Salt + Water", "D": "Chalk + Water"}, "C"),
        ],
        "short": [
            "Molecular mass aur Formula mass mein farq batayein.",
            "Rutherford ka Atomic Model explain karein.",
            "Periodic Table mein groups aur periods kya hain?",
            "Ionic bond aur Covalent bond mein farq batayein.",
            "Solid, Liquid aur Gas ke properties likhein.",
            "Solution ki 3 types batayein with examples.",
            "Oxidation aur Reduction kya hai?",
            "Electronegativity kya hai? Trend explain karein.",
            "Isotopes kya hain? Carbon ke isotopes batayein.",
            "Bohr's Atomic Model ki 3 main points likhein.",
            "Dalton's Atomic Theory ki 4 points likhein.",
            "Suspension aur Solution mein farq batayein.",
            "Valency kya hai? Mg aur O ki valency batayein.",
            "Diffusion kya hai? Example dein.",
            "Evaporation kya hai? Factors batayein.",
        ],
        "long": [
            "Bohr's Atomic Model explain karein with diagram. Iske merits aur demerits batayein.",
            "Periodic Table ki properties (Group 1, 17, 18) explain karein with trends.",
            "Evaporation aur Boiling mein 5 farq batayein. Evaporation ke factors explain karein.",
            "Rutherford's gold foil experiment describe karein aur model ki limitations batayein.",
            "Ionic aur Covalent compounds ki properties compare karein in a table.",
        ]
    },
    "Physics": {
        "mcqs": [
            ("Force ka SI unit:", {"A": "Joule", "B": "Newton", "C": "Watt", "D": "Pascal"}, "B"),
            ("Acceleration ka formula:", {"A": "v/t", "B": "v*t", "C": "Delta-v/Delta-t", "D": "s/t"}, "C"),
            ("1 Joule = ?", {"A": "N*m", "B": "N/m", "C": "N*s", "D": "kg*m"}, "A"),
            ("Sound travel karta hai:", {"A": "Solid", "B": "Liquid", "C": "Gas", "D": "All"}, "D"),
            ("Gravitational acceleration (g):", {"A": "9.8 m/s^2", "B": "10 m/s^2", "C": "8.9 m/s^2", "D": "9.8 cm/s^2"}, "A"),
            ("Inertia kis law se related hai?", {"A": "1st", "B": "2nd", "C": "3rd", "D": "None"}, "A"),
            ("Work tab hota hai jab:", {"A": "Force lage", "B": "Displacement ho", "C": "Force aur displacement dono", "D": "Kuch bhi na ho"}, "C"),
            ("Density ka formula:", {"A": "m/v", "B": "v/m", "C": "m*a", "D": "F/a"}, "A"),
            ("Conduction heat transfer mein:", {"A": "Particles move", "B": "Vibrations transfer", "C": "Waves travel", "D": "No transfer"}, "B"),
            ("1 Watt = ?", {"A": "1 J/s", "B": "1 N/s", "C": "1 J*m", "D": "1 kg*m/s"}, "A"),
        ],
        "short": [
            "Base quantities aur Derived quantities mein farq batayein.",
            "Velocity aur Speed mein farq kya hai?",
            "Newton ka First Law of Motion explain karein.",
            "Torque kya hai? Formula aur unit likhein.",
            "Law of Gravitation likhein aur explain karein.",
            "Kinetic Energy aur Potential Energy mein farq batayein.",
            "Pressure kya hai? Liquid pressure ka formula likhein.",
            "Thermal Expansion kya hai? Types batayein.",
            "Scalar aur Vector quantities mein farq batayein (3 examples each).",
            "Uniform aur Non-uniform acceleration mein farq batayein.",
            "Hooks Law kya hai? Formula likhein.",
            "Archimedes Principle explain karein.",
            "Conduction, Convection aur Radiation mein farq batayein.",
            "Equilibrium kya hai? Types batayein.",
            "Why does a passenger lean forward when a bus stops?",
        ],
        "long": [
            "Newton ke Three Laws of Motion explain karein with daily life examples.",
            "Resolution of Forces kya hai? Mathematical example se explain karein.",
            "Work aur Energy mein relationship explain karein. Work-Energy theorem state karein.",
            "Thermal Expansion ke 3 types detail mein explain karein with real-life examples.",
            "Derive the equation: 2as = vf^2 - vi^2 using kinematic equations.",
        ]
    },
    "Computer_Science": {
        "mcqs": [
            ("Binary system mein digits:", {"A": "8", "B": "10", "C": "2", "D": "16"}, "C"),
            ("1 KB = ?", {"A": "1000 bytes", "B": "1024 bytes", "C": "1024 bits", "D": "1000 bits"}, "B"),
            ("HTML full form:", {"A": "Hyper Text Markup Language", "B": "High Text Machine Language", "C": "Hyper Transfer Main Language", "D": "Home Tool Markup Language"}, "A"),
            ("Database mein data store hota hai:", {"A": "Tables", "B": "Files", "C": "Folders", "D": "Images"}, "A"),
            ("CPU full form:", {"A": "Central Processing Unit", "B": "Computer Personal Unit", "C": "Central Program Utility", "D": "Central Power Unit"}, "A"),
            ("AND gate ka output 1 tab hai jab:", {"A": "Any input is 1", "B": "All inputs are 1", "C": "All inputs are 0", "D": "One input is 0"}, "B"),
            ("Hexadecimal system mein digits:", {"A": "2", "B": "8", "C": "10", "D": "16"}, "D"),
            ("Internet is an example of:", {"A": "LAN", "B": "MAN", "C": "WAN", "D": "PAN"}, "C"),
            ("<br> tag in HTML is used for:", {"A": "Bold", "B": "Break", "C": "Border", "D": "Background"}, "B"),
            ("Primary Key must be:", {"A": "Duplicate", "B": "Null", "C": "Unique", "D": "Empty"}, "C"),
        ],
        "short": [
            "Problem solving ke 5 steps batayein.",
            "Decimal 15 ko Binary mein convert karein.",
            "LAN aur WAN mein farq batayein.",
            "Virus se bachne ke 3 tareeqe batayein.",
            "ASCII code kya hai? Range batayein.",
            "AND gate aur OR gate ka truth table banayein.",
            "Database kya hai? 2 examples batayein.",
            "<p> aur <br> tag ka farq batayein.",
            "1 GB mein kitne MB hote hain?",
            "Algorithm kya hai? Example dein.",
            "Flowchart kya hai? 3 symbols batayein.",
            "Data security kya hai? Importance batayein.",
            "Boolean algebra kya hai?",
            "Browser kya hai? 2 examples batayein.",
            "Search Engine aur Browser mein farq batayein.",
        ],
        "long": [
            "Problem Solving ke phases detail mein explain karein with flowchart example.",
            "Boolean Algebra ke 3 laws batayein aur truth tables banayein.",
            "Database Management System (DBMS) kya hai? Advantages aur types batayein.",
            "HTML ki basic structure likhein aur 5 tags explain karein with example.",
            "Decimal to Binary conversion ke 2 methods explain karein with examples.",
        ]
    },
    "English": {
        "mcqs": [
            ("Choose correct spelling:", {"A": "Recieve", "B": "Receive", "C": "Receeve", "D": "Receve"}, "B"),
            ("Passive of 'She writes a letter':", {"A": "A letter is written by her", "B": "A letter was written", "C": "A letter is being written", "D": "A letter has been written"}, "A"),
            ("Antonym of 'Ancient':", {"A": "Old", "B": "Modern", "C": "Past", "D": "Historic"}, "B"),
            ("Which is a conjunction?", {"A": "Beautiful", "B": "Quickly", "C": "But", "D": "They"}, "C"),
            ("Plural of 'Child':", {"A": "Childs", "B": "Children", "C": "Childes", "D": "Childrens"}, "B"),
            ("'The Quaid's Vision' is about:", {"A": "Allama Iqbal", "B": "Quaid-e-Azam", "C": "Liaquat Ali", "D": "Sir Syed"}, "B"),
            ("Choose the correct preposition: He is fond ___ reading.", {"A": "in", "B": "of", "C": "at", "D": "on"}, "B"),
            ("Synonym of 'Huge':", {"A": "Tiny", "B": "Massive", "C": "Small", "D": "Slow"}, "B"),
            ("Narration: He said, 'I am busy.'", {"A": "He said he is busy", "B": "He said he was busy", "C": "He said I am busy", "D": "He says he is busy"}, "B"),
            ("Which is a vowel?", {"A": "B", "B": "C", "C": "E", "D": "D"}, "C"),
        ],
        "short": [
            "Write a paragraph on 'My Aim in Life' (50 words).",
            "Change the voice: 'They are playing cricket.'",
            "Use in sentences: 'Break the ice', 'A piece of cake'.",
            "Summarize the chapter 'The Saviour of Mankind' in 3 lines.",
            "Write an application to the Principal for fee concession.",
            "What is the central idea of the poem 'Daffodils'?",
            "Punctuate: ali ahmed and hamza are friends",
            "Write antonyms: Accept, Ancient, Brave, Create.",
            "Change narration: The teacher said, 'Do your homework.'",
            "Write 5 sentences in Present Continuous tense.",
            "Translate into English: Mujhe parhai pasand hai.",
            "What is the moral of the chapter 'All is Not Lost'?",
            "Define Noun and give 3 examples.",
            "What is the difference between 'Their' and 'There'?",
            "Write a formal greeting and closing for a letter.",
        ],
        "long": [
            "Write an essay on 'Patriotism' (200 words) with outline.",
            "Write a story with moral: 'Honesty is the Best Policy' (150 words).",
            "Summarize the chapter 'Hazrat Asma (R.A)' and write its moral lesson.",
            "Write a letter to your friend inviting him to your birthday party.",
            "Explain the poem 'Stopping by Woods on a Snowy Evening' in your own words.",
        ]
    }
}

# Map aliases
SUBJECT_MAP = {
    "math": "Mathematics", "maths": "Mathematics", "mathematics": "Mathematics",
    "chem": "Chemistry", "chemistry": "Chemistry",
    "phy": "Physics", "physics": "Physics",
    "comp": "Computer_Science", "cs": "Computer_Science", "computer": "Computer_Science",
    "eng": "English", "english": "English",
}


def generate_paper_pdf(subject_name, year, save_folder="Class_9_Past_Papers"):
    """Generate a single PDF paper"""
    
    # Find the actual subject key
    subject_key = SUBJECT_MAP.get(subject_name.lower(), subject_name)
    
    if subject_key not in QUESTION_BANKS:
        return f"❌ Subject '{subject_name}' not found! Available: math, chemistry, physics, computer, english"
    
    questions = QUESTION_BANKS[subject_key]
    
    # Create save folder
    os.makedirs(save_folder, exist_ok=True)
    
    # Create PDF
    pdf = PaperPDF()
    pdf.alias_nb_pages()
    pdf.add_page()
    pdf.set_auto_page_break(auto=True, margin=15)
    
    # Subject Header
    pdf.set_font('Helvetica', 'B', 12)
    pdf.cell(0, 10, f'Subject: {subject_key.replace("_", " ")}', 0, 1, 'L')
    pdf.cell(0, 8, f'Class: 9th  |  Year: {year}  |  Time: 2:30 Hours  |  Total Marks: 75', 0, 1, 'L')
    pdf.ln(5)
    
    # ── SECTION A: MCQs (15 Marks) ───────────────────
    pdf.section_title("SECTION A - Multiple Choice Questions (15 Marks)")
    pdf.set_font('Helvetica', 'I', 9)
    pdf.cell(0, 6, "Note: Attempt all questions. Each carries 1 mark.", 0, 1)
    pdf.ln(3)
    
    mcqs = random.sample(questions["mcqs"], min(10, len(questions["mcqs"])))
    for i, (q, opts, ans) in enumerate(mcqs, 1):
        pdf.mcq(i, q, opts)
    
    # ── SECTION B: Short Questions (36 Marks) ────────
    pdf.section_title("SECTION B - Short Answer Questions (36 Marks)")
    pdf.set_font('Helvetica', 'I', 9)
    pdf.cell(0, 6, "Note: Attempt any 12 questions. Each carries 3 marks.", 0, 1)
    pdf.ln(3)
    
    short_qs = random.sample(questions["short"], min(12, len(questions["short"])))
    for i, q in enumerate(short_qs, 1):
        pdf.question(i, q, "3 Marks")
    
    # ── SECTION C: Long Questions (24 Marks) ─────────
    pdf.section_title("SECTION C - Long Answer Questions (24 Marks)")
    pdf.set_font('Helvetica', 'I', 9)
    pdf.cell(0, 6, "Note: Attempt any 3 questions. Each carries 8 marks.", 0, 1)
    pdf.ln(3)
    
    long_qs = random.sample(questions["long"], min(4, len(questions["long"])))
    for i, q in enumerate(long_qs, 1):
        pdf.question(i, q, "8 Marks")
    
    # Save PDF
    safe_name = subject_key.replace(" ", "_")
    filename = f"{safe_name}_Class9_{year}.pdf"
    filepath = os.path.join(save_folder, filename)
    pdf.output(filepath)
    
    return filepath


def generate_all_papers_5_years(subjects=None, save_folder="Class_9_Past_Papers"):
    """Generate 5 years of papers for all or selected subjects"""
    
    if subjects is None:
        subjects = ["Mathematics", "Chemistry", "Physics", "Computer_Science", "English"]
    
    years = ["2020", "2021", "2022", "2023", "2024"]
    
    generated_files = []
    
    print(f"""
╔══════════════════════════════════════════════════════════╗
║   📄 RGS_AI PDF Paper Generator — 5 Years              ║
║   Generating {len(subjects)} subjects x {len(years)} years = {len(subjects)*len(years)} PDFs  ║
╚══════════════════════════════════════════════════════════╝
""")
    
    for subject in subjects:
        print(f"\n📚 Generating {subject}...")
        for year in years:
            filepath = generate_paper_pdf(subject, year, save_folder)
            if filepath and not filepath.startswith("❌"):
                generated_files.append(filepath)
                print(f"   ✅ {year} → {filepath}")
    
    print(f"""
╔══════════════════════════════════════════════════════════╗
║   ✅ COMPLETE! {len(generated_files)} PDF Papers Generated!       ║
║   📂 Folder: {save_folder}                  ║
╚══════════════════════════════════════════════════════════╝
""")
    
    return generated_files


# ════════════════════════════════════════════════════════
# QUICK RUN
# ════════════════════════════════════════════════════════

if __name__ == "__main__":
    # Generate all 5 years for all subjects
    generate_all_papers_5_years()
    
    # OR generate for specific subject:
    # generate_paper_pdf("math", "2024")