# proactive_engine.py — Zero-Prompt Proactive Engine
import threading
import time
import psutil
from ..config import logger
from ..error_handler import safe_execute

class ProactiveEngine:
    """
    Watches your screen and actions.
    Automatically does things without you asking.
    """

    def __init__(self):
        self.active = False
        self.last_window = ""
        self.last_save_time = time.time()
        self.last_typing_time = time.time()

    def start(self) -> str:
        if self.active:
            return "Already running!"
        self.active = True
        t = threading.Thread(target=self._watch_loop, daemon=True)
        t.start()
        return "🧠 Proactive engine started! I'll watch and help silently."

    def stop(self) -> str:
        self.active = False
        return "🧠 Proactive engine stopped."

    def _watch_loop(self):
        while self.active:
            try:
                # 1. Check active window
                try:
                    import pygetwindow as gw
                    window = gw.getActiveWindow()
                    if window:
                        title = window.title.lower()
                        self._handle_window_change(title)
                except Exception:
                    pass

                time.sleep(5)
            except Exception:
                time.sleep(10)

    def _handle_window_change(self, title: str):
        """React to window changes"""
        if title == self.last_window:
            return
        
        # Netflix/YouTube detected → Suggest dimming
        if "netflix" in title or "youtube" in title:
            logger.info("Proactive: Media detected, suggesting focus mode")
            # Auto action could go here
        
        # VS Code detected → Start auto-save guard
        if "visual studio code" in title or "vscode" in title:
            self._start_autosave_guard()

        self.last_window = title

    def _start_autosave_guard(self):
        """Auto-save if coding for 5 min without save"""
        def _guard():
            while self.active and "code" in self.last_window.lower():
                time.sleep(30)  # Check every 30s
                # If 5 minutes passed, auto-save
                if time.time() - self.last_save_time > 300:
                    try:
                        import pyautogui
                        pyautogui.hotkey('ctrl', 's')
                        logger.info("Proactive: Auto-saved your code!")
                        self.last_save_time = time.time()
                    except Exception:
                        pass
        
        t = threading.Thread(target=_guard, daemon=True)
        t.start()


# Global instance
proactive = ProactiveEngine()