# rpa_engine.py — Record & Replay Automation (RPA)
import json
import os
import time
import threading
from pynput import mouse, keyboard
from ..config import DATA_DIR, logger
from ..error_handler import safe_execute

MACROS_DIR = str(DATA_DIR / "macros")
os.makedirs(MACROS_DIR, exist_ok=True)

class RPAEngine:
    """
    Records mouse clicks and keyboard actions.
    Replays them exactly.
    """

    def __init__(self):
        self.recording = False
        self.actions = []
        self.start_time = 0
        self._mouse_listener = None
        self._key_listener = None

    def start_recording(self, name: str = "macro_1") -> str:
        if self.recording:
            return "⚠️ Already recording!"
        
        self.recording = True
        self.actions = []
        self.macro_name = name
        self.start_time = time.time()
        
        # Start listeners
        self._mouse_listener = mouse.Listener(on_click=self._on_click, on_move=self._on_move)
        self._key_listener = keyboard.Listener(on_press=self._on_key)
        
        self._mouse_listener.start()
        self._key_listener.start()
        
        return "🔴 Recording started! Do your actions. Say 'stop recording' when done."

    def _on_click(self, x, y, button, pressed):
        if self.recording and pressed:
            self.actions.append({
                "type": "click",
                "x": x, "y": y,
                "button": str(button),
                "time": time.time() - self.start_time
            })

    def _on_move(self, x, y):
        if self.recording and self.actions and self.actions[-1]["type"] != "move":
            self.actions.append({
                "type": "move",
                "x": x, "y": y,
                "time": time.time() - self.start_time
            })

    def _on_key(self, key):
        if self.recording:
            try:
                key_name = key.char
            except AttributeError:
                key_name = str(key)
            self.actions.append({
                "type": "key",
                "key": key_name,
                "time": time.time() - self.start_time
            })

    def stop_recording(self) -> str:
        if not self.recording:
            return "⚠️ Not recording!"
        
        self.recording = False
        self._mouse_listener.stop()
        self._key_listener.stop()
        
        # Save macro
        filepath = os.path.join(MACROS_DIR, f"{self.macro_name}.json")
        with open(filepath, 'w') as f:
            json.dump(self.actions, f, indent=2)
        
        return f"✅ Macro '{self.macro_name}' saved! {len(self.actions)} actions recorded."

    @safe_execute(max_retries=1)
    def play_macro(self, name: str, speed: float = 1.0) -> str:
        filepath = os.path.join(MACROS_DIR, f"{name}.json")
        if not os.path.exists(filepath):
            return f"❌ Macro '{name}' not found."
        
        with open(filepath, 'r') as f:
            actions = json.load(f)
        
        def _play():
            import pyautogui
            prev_time = 0
            for action in actions:
                delay = (action["time"] - prev_time) / speed
                if delay > 0:
                    time.sleep(delay)
                prev_time = action["time"]
                
                if action["type"] == "click":
                    pyautogui.click(action["x"], action["y"])
                elif action["type"] == "key":
                    key = action["key"]
                    if len(key) == 1:
                        pyautogui.write(key)
                    else:
                        pyautogui.press(key.replace("Key.", ""))
        
        t = threading.Thread(target=_play, daemon=True)
        t.start()
        return f"▶️ Playing macro '{name}' at {speed}x speed..."

    def list_macros(self) -> str:
        macros = [f.replace(".json", "") for f in os.listdir(MACROS_DIR) if f.endswith(".json")]
        if not macros:
            return "No macros recorded yet."
        return "📋 Saved Macros:\n" + "\n".join(f"  • {m}" for m in macros)


# Global instance
rpa_engine = RPAEngine()