"""
╔══════════════════════════════════════════════════════════════╗
║   google_login.py — Google OAuth2 Login Flow                 ║
║                                                              ║
║   Opens a browser window → user signs in → callback          ║
║   captures the auth code → exchanges for tokens →            ║
║   fetches user profile.  Stores tokens in data/profile.json  ║
║                                                              ║
║   Uses the standard Google OAuth2 Authorization Code flow    ║
║   with a local loopback HTTP server.                         ║
╚══────────────────────────────────────────────────────────══════╝
"""

from __future__ import annotations
import json
import http.server
import socketserver
import threading
import urllib.parse
import webbrowser
import base64
import time
import secrets
from pathlib import Path
from typing import Optional, Dict

import requests

from config import (
    GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GOOGLE_REDIRECT_URI,
    GOOGLE_AUTH_SCOPE, USER_PROFILE_FILE, ENABLE_GOOGLE_LOGIN,
    logger,
)


GOOGLE_AUTH_URL  = "https://accounts.google.com/o/oauth2/v2/auth"
GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token"
GOOGLE_USERINFO  = "https://www.googleapis.com/oauth2/v3/userinfo"


class GoogleLogin:
    """OAuth2 Authorization Code flow with loopback callback."""

    def __init__(self):
        self.client_id     = GOOGLE_CLIENT_ID
        self.client_secret = GOOGLE_CLIENT_SECRET
        self.redirect_uri  = GOOGLE_REDIRECT_URI
        self.scope         = GOOGLE_AUTH_SCOPE
        self.state         = secrets.token_urlsafe(24)
        self.auth_code: Optional[str] = None
        self.tokens: Optional[Dict]   = None
        self.user_profile: Optional[Dict] = None

    # ─────────────────────────────────────────────────────
    #  Parse the redirect URI to extract port
    # ─────────────────────────────────────────────────────
    def _parse_redirect(self) -> tuple[str, int, str]:
        parsed = urllib.parse.urlparse(self.redirect_uri)
        host = parsed.hostname or "localhost"
        port = parsed.port or 8765
        path = parsed.path or "/callback"
        return host, port, path

    # ─────────────────────────────────────────────────────
    #  Local callback server
    # ─────────────────────────────────────────────────────
    def _make_handler(self, path: str):
        outer = self

        class _CB(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                parsed = urllib.parse.urlparse(self.path)
                if parsed.path != path:
                    self.send_response(404)
                    self.end_headers()
                    return
                q = urllib.parse.parse_qs(parsed.query)
                if "error" in q:
                    body = f"<h2>Login failed</h2><p>{q['error'][0]}</p>"
                    self.send_response(400)
                    self.send_header("Content-Type", "text/html")
                    self.end_headers()
                    self.wfile.write(body.encode())
                    return
                if "code" in q:
                    outer.auth_code = q["code"][0]
                    body = ("<html><body style='font-family:sans-serif;text-align:center;padding:60px'>"
                            "<h2>✓ Login successful</h2>"
                            "<p>You can close this window and return to RGS AI.</p>"
                            "<script>setTimeout(()=>window.close(),3000)</script>"
                            "</body></html>")
                    self.send_response(200)
                    self.send_header("Content-Type", "text/html")
                    self.end_headers()
                    self.wfile.write(body.encode())
                else:
                    self.send_response(404)
                    self.end_headers()

            def log_message(self, *a, **k): pass  # silence

        return _CB

    # ─────────────────────────────────────────────────────
    #  Build the consent URL
    # ─────────────────────────────────────────────────────
    def build_auth_url(self) -> str:
        params = {
            "client_id": self.client_id,
            "redirect_uri": self.redirect_uri,
            "response_type": "code",
            "scope": self.scope,
            "state": self.state,
            "access_type": "offline",
            "prompt": "consent",
        }
        return GOOGLE_AUTH_URL + "?" + urllib.parse.urlencode(params)

    # ─────────────────────────────────────────────────────
    #  Exchange code for tokens
    # ─────────────────────────────────────────────────────
    def exchange_code(self, code: str) -> Optional[Dict]:
        data = {
            "code": code,
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "redirect_uri": self.redirect_uri,
            "grant_type": "authorization_code",
        }
        try:
            r = requests.post(GOOGLE_TOKEN_URL, data=data, timeout=20)
            if r.status_code == 200:
                self.tokens = r.json()
                logger.info("Got Google tokens.")
                return self.tokens
            logger.error(f"Token exchange failed: {r.status_code} {r.text}")
        except Exception as e:
            logger.exception(f"Token exchange error: {e}")
        return None

    # ─────────────────────────────────────────────────────
    #  Fetch userinfo
    # ─────────────────────────────────────────────────────
    def fetch_profile(self, access_token: str) -> Optional[Dict]:
        try:
            r = requests.get(GOOGLE_USERINFO,
                             headers={"Authorization": f"Bearer {access_token}"},
                             timeout=15)
            if r.status_code == 200:
                self.user_profile = r.json()
                return self.user_profile
            logger.error(f"Userinfo fetch failed: {r.status_code}")
        except Exception as e:
            logger.exception(f"Userinfo error: {e}")
        return None

    # ─────────────────────────────────────────────────────
    #  Save profile
    # ─────────────────────────────────────────────────────
    def save_profile(self):
        payload = {
            "google_user": self.user_profile,
            "tokens": self.tokens,
            "logged_in_at": int(time.time()),
        }
        USER_PROFILE_FILE.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        USER_PROFILE_FILE.chmod(0o600)
        logger.info(f"Profile saved → {USER_PROFILE_FILE}")

    def load_profile(self) -> Optional[Dict]:
        if USER_PROFILE_FILE.exists():
            try:
                return json.loads(USER_PROFILE_FILE.read_text(encoding="utf-8"))
            except Exception:
                return None
        return None

    def is_logged_in(self) -> bool:
        return bool(self.load_profile())

    # ─────────────────────────────────────────────────────
    #  Full flow
    # ─────────────────────────────────────────────────────
    def login(self, timeout: int = 180) -> bool:
        if not ENABLE_GOOGLE_LOGIN:
            logger.info("Google login disabled by config.")
            return True

        if not self.client_id or not self.client_secret:
            logger.warn("Google client_id/secret not set — skipping Google login.")
            return False

        host, port, path = self._parse_redirect()
        handler = self._make_handler(path)

        # Start local server
        try:
            srv = socketserver.TCPServer((host, port), handler)
        except OSError as e:
            logger.error(f"Cannot bind {host}:{port} — {e}")
            return False

        srv.timeout = 1
        thread = threading.Thread(target=srv.serve_forever, daemon=True)
        thread.start()

        # Open browser
        url = self.build_auth_url()
        print(f"\n[Google Login] Opening browser to:\n  {url}\n")
        try:
            webbrowser.open(url)
        except Exception:
            pass

        # Wait for callback
        start = time.time()
        while self.auth_code is None and time.time() - start < timeout:
            time.sleep(0.5)
        srv.shutdown()
        srv.server_close()

        if not self.auth_code:
            logger.error("Google login timed out.")
            return False

        # Exchange
        tokens = self.exchange_code(self.auth_code)
        if not tokens:
            return False

        # Profile
        profile = self.fetch_profile(tokens.get("access_token", ""))
        if profile:
            self.save_profile()
            print(f"\n[Google Login] ✓ Logged in as {profile.get('email', '?')}")
            return True
        return False


def logout():
    """Wipe the saved Google profile."""
    if USER_PROFILE_FILE.exists():
        USER_PROFILE_FILE.unlink()
        logger.info("Logged out — profile removed.")


if __name__ == "__main__":
    g = GoogleLogin()
    ok = g.login()
    print("Login OK" if ok else "Login failed")
    if g.user_profile:
        print(json.dumps(g.user_profile, indent=2))
