"""
RASHEED Reminders — Background scheduler for alarms and reminders
"""
import time, threading, json
from pathlib import Path
from datetime import datetime


class ReminderManager:

    def __init__(self, filepath="data/reminders.json"):
        self.filepath = Path(filepath)
        self.reminders = []
        self._load()
        self._running = False

    def _load(self):
        if self.filepath.exists():
            try:
                with open(self.filepath, 'r') as f: self.reminders = json.load(f)
            except: self.reminders = []

    def _save(self):
        self.filepath.parent.mkdir(exist_ok=True)
        with open(self.filepath, 'w') as f: json.dump(self.reminders, f, indent=2)

    def add_reminder(self, text: str, minutes: int) -> str:
        trigger_time = time.time() + (minutes * 60)
        self.reminders.append({"text": text, "time": trigger_time, "triggered": False})
        self._save()
        return f"⏰ Reminder set: '{text}' in {minutes} minutes"

    def check_reminders(self) -> list:
        triggered = []
        now = time.time()
        for rem in self.reminders:
            if not rem["triggered"] and now >= rem["time"]:
                rem["triggered"] = True
                triggered.append(rem["text"])
        if triggered: self._save()
        return triggered

    def start_monitor(self, callback):
        self._running = True

        def loop():
            while self._running:
                triggered = self.check_reminders()
                for text in triggered:
                    callback(text)
                time.sleep(5)

        threading.Thread(target=loop, daemon=True).start()

    def stop_monitor(self):
        self._running = False
