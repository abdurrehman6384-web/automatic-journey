"""
RASHEED Todo Manager — Persistent task list
"""
import json, time
from pathlib import Path


class TodoManager:

    def __init__(self, filepath="data/todos.json"):
        self.filepath = Path(filepath)
        self.todos = []
        self._load()

    def _load(self):
        if self.filepath.exists():
            try:
                with open(self.filepath, 'r') as f: self.todos = json.load(f)
            except: self.todos = []

    def _save(self):
        self.filepath.parent.mkdir(exist_ok=True)
        with open(self.filepath, 'w') as f: json.dump(self.todos, f, indent=2)

    def add_todo(self, text: str, priority: str="medium") -> str:
        self.todos.append({"id": len(self.todos) + 1, "text": text, "done": False, "priority": priority})
        self._save()
        return f"✅ Todo added: {text}"

    def complete_todo(self, todo_id: int) -> str:
        for t in self.todos:
            if t["id"] == todo_id:
                t["done"] = True
                self._save()
                return f"✅ Completed: {t['text']}"
        return "❌ Todo not found"

    def list_todos(self) -> str:
        if not self.todos: return "No todos!"
        lines = []
        for t in self.todos:
            status = "✅" if t["done"] else "⬜"
            lines.append(f"{status} [{t['id']}] {t['text']} ({t['priority']})")
        return "\n".join(lines)
