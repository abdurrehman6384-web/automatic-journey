"""
╔══════════════════════════════════════════════════════════════╗
║   error_handler.py — Safe Execution Wrapper                  ║
║                                                              ║
║   Wraps any function call in a try/except so a single tool   ║
║   failure never crashes the whole assistant.                 ║
╚══────────────────────────────────────────────────────────══════╝
"""

from __future__ import annotations
import functools
import traceback
from typing import Callable, Any

from config import logger


class RGSException(Exception):
    """Base class for RGS AI exceptions."""
    def __init__(self, msg: str, *, recoverable: bool = True, original: Exception = None):
        super().__init__(msg)
        self.recoverable = recoverable
        self.original = original


def safe_execute(func: Callable, *args, **kwargs) -> Any:
    """Run a function; on error, log + return a dict with error info."""
    try:
        result = func(*args, **kwargs)
        return {"ok": True, "result": result}
    except Exception as e:
        tb = traceback.format_exc()
        logger.exception(f"safe_execute caught error in {func.__name__}: {e}")
        return {
            "ok": False,
            "error": str(e),
            "type": type(e).__name__,
            "traceback": tb,
        }


def safe_tool(func):
    """Decorator version of safe_execute, for tool handlers."""
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return {"ok": True, "result": func(*args, **kwargs)}
        except Exception as e:
            logger.exception(f"Tool {func.__name__} failed: {e}")
            return {"ok": False, "error": str(e), "type": type(e).__name__}
    return wrapper


def retry(max_attempts: int = 3, delay: float = 0.5, exceptions=(Exception,)):
    """Simple retry decorator."""
    def deco(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            last_err = None
            for i in range(1, max_attempts + 1):
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    last_err = e
                    logger.warn(f"{func.__name__} attempt {i}/{max_attempts} failed: {e}")
                    import time
                    time.sleep(delay * i)
            raise last_err
        return wrapper
    return deco
