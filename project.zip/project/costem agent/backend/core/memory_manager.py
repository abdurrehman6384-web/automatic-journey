"""RASHEED Memory — Saves user identity, preferences, projects"""
import json
import time
import re
from pathlib import Path
from typing import Dict, Any, Optional


class MemoryManager:

    def __init__(self, filepath: str="data/memory.json"):
        self.filepath = Path(filepath)
        self.data: Dict[str, Dict[str, Any]] = {
            "identity": {}, "preferences": {}, "projects": {}, "notes": {}
        }
        self._load()

    def _load(self):
        if self.filepath.exists():
            try:
                with open(self.filepath, 'r', encoding='utf-8') as f:
                    self.data.update(json.load(f))
            except Exception: pass

    def save(self):
        self.filepath.parent.mkdir(parents=True, exist_ok=True)
        with open(self.filepath, 'w', encoding='utf-8') as f:
            json.dump(self.data, f, indent=2, ensure_ascii=False)

    def save_memory(self, category: str, key: str, value: str):
        if category not in self.data: self.data[category] = {}
        self.data[category][key] = {"value": value, "time": time.strftime("%H:%M:%S")}
        self.save()

    def auto_extract(self, text: str):
        t = text.lower()
        name_match = re.search(r"mera naam (\w+)", t)
        if name_match:
            self.save_memory("identity", "name", name_match.group(1))
        
        city_match = re.search(r"main (\w+) mein rehta", t)
        if city_match:
            self.save_memory("identity", "city", city_match.group(1))

        fav_match = re.search(r"mera favorite (\w+) (\w+)", t)
        if fav_match:
            self.save_memory("preferences", fav_match.group(1), fav_match.group(2))

    def get_context(self) -> str:
        lines = []
        for cat, items in self.data.items():
            if items:
                lines.append(f"[{cat.upper()}]")
                for k, v in items.items():
                    lines.append(f"  {k}: {v.get('value', v)}")
        return "\n".join(lines) if lines else "No memory yet."
