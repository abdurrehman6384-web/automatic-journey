"""RASHEED Multi-Model Router — Fallback AI providers"""
import time
import requests
from typing import Dict, Any, Optional
from config.settings import get_settings


class ModelResponse:

    def __init__(self, provider: str, content: str, success: bool, error: str=""):
        self.provider = provider
        self.content = content
        self.success = success
        self.error = error


class MultiModelRouter:

    def __init__(self):
        self.s = get_settings()

    def query(self, prompt: str, system: str="") -> ModelResponse:
        # Try Groq first (fastest)
        if self.s.GROQ_KEY:
            r = self._call_groq(prompt, system)
            if r.success: return r
        # Try DeepSeek
        if self.s.DEEPSEEK_KEY:
            r = self._call_deepseek(prompt, system)
            if r.success: return r
        return ModelResponse("none", "", False, "All providers failed")

    def _call_groq(self, prompt: str, system: str) -> ModelResponse:
        try:
            headers = {"Authorization": f"Bearer {self.s.GROQ_KEY}", "Content-Type": "application/json"}
            msgs = []
            if system: msgs.append({"role": "system", "content": system})
            msgs.append({"role": "user", "content": prompt})
            r = requests.post("https://api.groq.com/openai/v1/chat/completions",
                headers=headers, json={"model": "llama-3.3-70b-versatile", "messages": msgs}, timeout=15)
            return ModelResponse("groq", r.json()['choices'][0]['message']['content'], True)
        except Exception as e:
            return ModelResponse("groq", "", False, str(e))

    def _call_deepseek(self, prompt: str, system: str) -> ModelResponse:
        try:
            headers = {"Authorization": f"Bearer {self.s.DEEPSEEK_KEY}", "Content-Type": "application/json"}
            msgs = []
            if system: msgs.append({"role": "system", "content": system})
            msgs.append({"role": "user", "content": prompt})
            r = requests.post("https://api.deepseek.com/v1/chat/completions",
                headers=headers, json={"model": "deepseek-chat", "messages": msgs}, timeout=20)
            return ModelResponse("deepseek", r.json()['choices'][0]['message']['content'], True)
        except Exception as e:
            return ModelResponse("deepseek", "", False, str(e))
