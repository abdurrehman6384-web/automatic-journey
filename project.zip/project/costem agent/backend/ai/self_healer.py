"""
RASHEED Self-Healer — Auto-detect and fix Python errors
"""
import traceback
import sys
from api.multi_model_router import MultiModelRouter

class SelfHealer:
    def __init__(self):
        self.ai = MultiModelRouter()

    def analyze_error(self, error_trace: str, file_path: str = "") -> str:
        """Analyze error and get AI fix suggestion"""
        prompt = f"""
You are RASHEED AI Self-Healer. Analyze this Python error and provide ONLY the corrected code.

File: {file_path}
Error:
{error_trace}

Provide the complete fixed code block. No explanations, just code.
"""
        response = self.ai.query(prompt, system="You are a Python debugging expert.")
        if response.success:
            return response.content
        return "❌ Could not auto-heal. Manual fix required."

    def install_hook(self):
        """Install global exception hook to auto-heal crashes"""
        def heal_hook(exc_type, exc_value, exc_traceback):
            error_text = ''.join(traceback.format_exception(exc_type, exc_value, exc_traceback))
            print(f"\n🚨 ERROR DETECTED:\n{error_text}")
            
            # Try to find file name
            if exc_traceback:
                tb = exc_traceback
                while tb.tb_next: tb = tb.tb_next
                filename = tb.tb_frame.f_code.co_filename
                print(f"🔍 Analyzing {filename} for auto-fix...")
                
                fix = self.analyze_error(error_text, filename)
                print(f"\n🩹 SUGGESTED FIX:\n{fix}\n")
                print("Apply this fix manually or ask RASHEED to fix it.")
        
        sys.excepthook = heal_hook
