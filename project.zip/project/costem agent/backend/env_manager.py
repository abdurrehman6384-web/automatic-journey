"""
╔══════════════════════════════════════════════════════════════╗
║   env_manager.py — Interactive .ENV Editor                   ║
║                                                              ║
║   • Shows ALL env vars side-by-side on Enter                 ║
║   • User types their OWN API tokens (no dev tokens bundled)  ║
║   • Saves to .env, validates, then triggers FaceLock         ║
║                                                              ║
║   UI: customtkinter dark form (ChatGPT/Claude aesthetic)     ║
╚════════════────────────────────────────────────────────────════╝
"""

from __future__ import annotations
import os
import sys
import tkinter as tk
from tkinter import messagebox
from pathlib import Path
from typing import Dict, List, Optional

try:
    import customtkinter as ctk
    from CTkToolTip import CTkToolTip
except ImportError:
    print("customtkinter not installed. Run: pip install customtkinter CTkToolTip")
    raise

from config import (
    ENV_FILE, ENV_BLUEPRINT, ENV_CATEGORIES,
    env, logger,
)


# ─────────────────────────────────────────────────────────────
#  THEME  (ChatGPT / Claude dark palette)
# ─────────────────────────────────────────────────────────────
THEME = {
    "bg":            "#1e1e1e",   # main bg (vscode dark)
    "bg_alt":        "#252526",   # secondary bg
    "bg_input":      "#2d2d30",   # input fields
    "bg_hover":      "#3c3c3c",
    "text":          "#d4d4d4",
    "text_dim":      "#858585",
    "accent":        "#10a37f",   # ChatGPT green
    "accent_2":      "#d97757",   # Claude orange
    "accent_3":      "#0ea5e9",   # bolt blue
    "error":         "#f87171",
    "success":       "#4ade80",
    "warning":       "#fbbf24",
    "border":        "#3c3c3c",
}

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("dark-blue")


class EnvEditorWindow(ctk.CTkToplevel):
    """Full-screen modal .env editor."""

    def __init__(self, master, on_complete: Optional[callable] = None):
        super().__init__(master)
        self.title("RGS AI — Environment Setup")
        self.geometry("1100x780")
        self.minsize(900, 650)
        self.configure(fg_color=THEME["bg"])

        # Block parent until done
        self.transient(master)
        self.grab_set()

        self.on_complete = on_complete
        self.entries: Dict[str, ctk.CTkEntry] = {}
        self.show_secret: Dict[str, tk.BooleanVar] = {}

        self._build_header()
        self._build_body()
        self._build_footer()
        self._load_current_values()

        # Enter key global binding — show all values in a popup
        self.bind("<Return>", self._on_enter_show_all)
        self.bind("<Control-s>", lambda e: self._save_and_continue())

    # ─────────────────────────────────────────────────────
    #  HEADER
    # ─────────────────────────────────────────────────────
    def _build_header(self):
        h = ctk.CTkFrame(self, fg_color=THEME["bg_alt"], corner_radius=0, height=110)
        h.pack(fill="x", side="top")
        h.pack_propagate(False)

        title = ctk.CTkLabel(h, text="RGS AI  ·  Environment Setup",
                             font=ctk.CTkFont(family="Segoe UI", size=26, weight="bold"),
                             text_color=THEME["text"])
        title.pack(anchor="w", padx=30, pady=(18, 0))

        subtitle = ctk.CTkLabel(
            h,
            text=("Enter your OWN API tokens below.  No developer tokens are bundled.\n"
                  "Press  ENTER  at any time to preview all values in one panel.   "
                  "Press  Ctrl+S  to save & continue → FaceLock."),
            font=ctk.CTkFont(family="Segoe UI", size=12),
            text_color=THEME["text_dim"], justify="left")
        subtitle.pack(anchor="w", padx=30, pady=(2, 0))

        # Progress strip
        self.progress = ctk.CTkProgressBar(h, progress_color=THEME["accent"],
                                           fg_color=THEME["bg_input"], height=4)
        self.progress.pack(fill="x", padx=30, pady=(10, 0))
        self.progress.set(0)

    # ─────────────────────────────────────────────────────
    #  BODY  — tabbed by category
    # ─────────────────────────────────────────────────────
    def _build_body(self):
        body = ctk.CTkFrame(self, fg_color=THEME["bg"], corner_radius=0)
        body.pack(fill="both", expand=True, padx=0, pady=0)

        self.tabs = ctk.CTkTabview(body, fg_color=THEME["bg_alt"],
                                   segmented_button_fg_color=THEME["bg_alt"],
                                   segmented_button_selected_color=THEME["accent"],
                                   segmented_button_selected_hover_color=THEME["accent"],
                                   segmented_button_unselected_color=THEME["bg_alt"],
                                   corner_radius=10)
        self.tabs.pack(fill="both", expand=True, padx=20, pady=20)

        # Create tab per category
        for cat in ENV_CATEGORIES:
            self.tabs.add(cat)

        # Populate fields
        for entry in ENV_BLUEPRINT:
            (key, label, category, required, is_secret, default, hint) = entry
            tab = self.tabs.tab(category)

            row = ctk.CTkFrame(tab, fg_color=THEME["bg_alt"], corner_radius=8)
            row.pack(fill="x", padx=10, pady=4)

            # Label
            req_mark = " *" if required else ""
            lbl_txt = f"{label}{req_mark}"
            lbl = ctk.CTkLabel(row, text=lbl_txt, width=280, anchor="w",
                               font=ctk.CTkFont(family="Segoe UI", size=13, weight="bold"),
                               text_color=THEME["text"])
            lbl.pack(side="left", padx=(12, 8), pady=8)

            # Show/Hide toggle for secrets
            if is_secret:
                show_var = tk.BooleanVar(value=False)
                self.show_secret[key] = show_var

            # Entry
            entry_widget = ctk.CTkEntry(
                row, width=420,
                fg_color=THEME["bg_input"],
                border_color=THEME["border"],
                text_color=THEME["text"],
                corner_radius=6,
                show="•" if is_secret else "",
                placeholder_text=hint or "",
                font=ctk.CTkFont(family="Consolas", size=13))
            entry_widget.pack(side="left", padx=4, pady=8, fill="x", expand=True)
            self.entries[key] = entry_widget

            # Eye toggle for secrets
            if is_secret:
                def _toggle(k=key, v=show_var, e=entry_widget):
                    e.configure(show="" if v.get() else "•")
                eye = ctk.CTkCheckBox(row, text="👁", variable=show_var,
                                      command=_toggle, width=40,
                                      fg_color=THEME["accent"],
                                      font=ctk.CTkFont(size=12))
                eye.pack(side="left", padx=4)

            # Tooltip
            if hint:
                CTkToolTip(lbl, message=f"{key}\n{hint}", delay=0.3)

    # ─────────────────────────────────────────────────────
    #  FOOTER
    # ─────────────────────────────────────────────────────
    def _build_footer(self):
        f = ctk.CTkFrame(self, fg_color=THEME["bg_alt"], corner_radius=0, height=70)
        f.pack(fill="x", side="bottom")
        f.pack_propagate(False)

        # Required count
        self.status_lbl = ctk.CTkLabel(
            f, text="Checking required fields…",
            font=ctk.CTkFont(family="Segoe UI", size=12),
            text_color=THEME["text_dim"])
        self.status_lbl.pack(side="left", padx=30)

        # Preview button (Enter)
        btn_preview = ctk.CTkButton(
            f, text="Preview All (Enter)", width=160,
            fg_color=THEME["bg_input"], hover_color=THEME["bg_hover"],
            border_color=THEME["border"], border_width=1,
            text_color=THEME["text"],
            command=self._on_enter_show_all)
        btn_preview.pack(side="right", padx=(6, 12), pady=15)

        # Skip (just save what's filled)
        btn_skip = ctk.CTkButton(
            f, text="Save & Skip FaceLock", width=180,
            fg_color=THEME["bg_input"], hover_color=THEME["bg_hover"],
            border_color=THEME["border"], border_width=1,
            text_color=THEME["text"],
            command=self._save_skip)
        btn_skip.pack(side="right", padx=6, pady=15)

        # Save & Continue → FaceLock
        btn_save = ctk.CTkButton(
            f, text="Save & Continue →", width=180,
            fg_color=THEME["accent"], hover_color="#0e8c6d",
            text_color="white", font=ctk.CTkFont(weight="bold"),
            command=self._save_and_continue)
        btn_save.pack(side="right", padx=(12, 30), pady=15)

        # Update status whenever an entry changes
        for e in self.entries.values():
            e.bind("<KeyRelease>", lambda ev: self._update_status())
        self._update_status()

    # ─────────────────────────────────────────────────────
    #  LOAD / SAVE
    # ─────────────────────────────────────────────────────
    def _load_current_values(self):
        for key, entry in self.entries.items():
            v = env(key) or next(
                (e[5] for e in ENV_BLUEPRINT if e[0] == key), "")
            if v:
                entry.insert(0, v)

    def _collect(self) -> Dict[str, str]:
        out = {}
        for key, entry in self.entries.items():
            v = entry.get().strip()
            if v:
                out[key] = v
        return out

    def _save_env_file(self, values: Dict[str, str]):
        lines = ["# ═══════════════════════════════════════════════════════════",
                 "#   RGS AI  —  .env  (user-supplied credentials)",
                 "#   DO NOT COMMIT TO GIT.  DO NOT SHARE.",
                 "# ═══════════════════════════════════════════════════════════",
                 ""]
        for (key, label, cat, req, secret, default, hint) in ENV_BLUEPRINT:
            lines.append(f"# [{cat}] {label}")
            if hint:
                lines.append(f"# Hint: {hint}")
            lines.append(f"{key}={values.get(key, '')}")
            lines.append("")
        ENV_FILE.write_text("\n".join(lines), encoding="utf-8")
        logger.info(f".env written → {ENV_FILE}")

    # ─────────────────────────────────────────────────────
    #  STATUS / VALIDATION
    # ─────────────────────────────────────────────────────
    def _missing_required(self) -> List[str]:
        out = []
        for (key, label, cat, req, *_rest) in ENV_BLUEPRINT:
            if req and not self.entries[key].get().strip():
                out.append(key)
        return out

    def _update_status(self):
        miss = self._missing_required()
        total_req = sum(1 for e in ENV_BLUEPRINT if e[3])
        filled = total_req - len(miss)
        self.progress.set(filled / max(total_req, 1))
        if miss:
            self.status_lbl.configure(
                text=f"⚠  Required fields still empty:  {', '.join(miss)}",
                text_color=THEME["warning"])
        else:
            self.status_lbl.configure(
                text="✓  All required fields filled — you can Save & Continue.",
                text_color=THEME["success"])

    # ─────────────────────────────────────────────────────
    #  PREVIEW ALL  (triggered by Enter)
    # ─────────────────────────────────────────────────────
    def _on_enter_show_all(self, event=None):
        """ENTER  →  show ALL .env values in one scrollable panel."""
        win = ctk.CTkToplevel(self)
        win.title("All .env values — preview")
        win.geometry("780x680")
        win.configure(fg_color=THEME["bg"])
        win.transient(self)
        win.grab_set()

        hdr = ctk.CTkLabel(win, text="All .env values  (secrets shown as •)",
                           font=ctk.CTkFont(family="Segoe UI", size=18, weight="bold"),
                           text_color=THEME["text"])
        hdr.pack(pady=15)

        sub = ctk.CTkLabel(win, text="Press Save in the main window to write these to .env",
                           font=ctk.CTkFont(size=11), text_color=THEME["text_dim"])
        sub.pack(pady=(0, 5))

        scroll = ctk.CTkScrollableFrame(win, fg_color=THEME["bg_alt"],
                                        corner_radius=10, height=520)
        scroll.pack(fill="both", expand=True, padx=20, pady=10)

        # Group by category for readability
        for cat in ENV_CATEGORIES:
            cat_lbl = ctk.CTkLabel(scroll, text=cat.upper(),
                                   font=ctk.CTkFont(family="Segoe UI", size=13, weight="bold"),
                                   text_color=THEME["accent"])
            cat_lbl.pack(anchor="w", padx=12, pady=(10, 2))
            for (key, label, c, req, secret, default, hint) in ENV_BLUEPRINT:
                if c != cat:
                    continue
                v = self.entries[key].get().strip()
                shown = ("•" * min(len(v), 24)) if (secret and v) else (v or "(empty)")
                if not v and default:
                    shown = f"(empty — default: {default})"
                row = ctk.CTkFrame(scroll, fg_color=THEME["bg_input"], corner_radius=6)
                row.pack(fill="x", padx=12, pady=2)
                k = ctk.CTkLabel(row, text=key, width=240, anchor="w",
                                 font=ctk.CTkFont(family="Consolas", size=12, weight="bold"),
                                 text_color=THEME["text_dim"])
                k.pack(side="left", padx=(10, 5), pady=6)
                val_lbl = ctk.CTkLabel(row, text=shown, anchor="w",
                                       font=ctk.CTkFont(family="Consolas", size=12),
                                       text_color=THEME["text"])
                val_lbl.pack(side="left", fill="x", expand=True, padx=4, pady=6)
                if req and not v:
                    warn = ctk.CTkLabel(row, text="REQUIRED",
                                        font=ctk.CTkFont(size=10, weight="bold"),
                                        text_color=THEME["error"])
                    warn.pack(side="right", padx=10)

        btn = ctk.CTkButton(win, text="Close", width=120,
                            fg_color=THEME["bg_input"], hover_color=THEME["bg_hover"],
                            text_color=THEME["text"], command=win.destroy)
        btn.pack(pady=10)

    # ─────────────────────────────────────────────────────
    #  SAVE & CONTINUE
    # ─────────────────────────────────────────────────────
    def _save_and_continue(self):
        miss = self._missing_required()
        if miss:
            if not messagebox.askyesno(
                "Required fields missing",
                f"These REQUIRED fields are still empty:\n  {', '.join(miss)}\n\n"
                f"Save anyway? (RGS AI may not work until you set them later)"):
                return
        values = self._collect()
        self._save_env_file(values)

        # Reload config so other modules see new values
        from importlib import reload
        import config as _c
        reload(_c)

        messagebox.showinfo(
            "Saved",
            ".env written successfully.\n\nClick OK to start FACE LOCK.",
            parent=self)
        self._finish(skip_face=False)

    def _save_skip(self):
        values = self._collect()
        self._save_env_file(values)
        self._finish(skip_face=True)

    def _finish(self, skip_face: bool = False):
        self.grab_release()
        self.destroy()
        if self.on_complete:
            self.on_complete(skip_face=skip_face)


# ─────────────────────────────────────────────────────────────
#  CLI entry  (for headless / testing)
# ─────────────────────────────────────────────────────────────
def cli_fill_env():
    """Walk the user through env vars on the terminal."""
    print("\n" + "=" * 60)
    print("  RGS AI  —  Environment Setup  (CLI mode)")
    print("=" * 60)
    values = {}
    for (key, label, cat, req, secret, default, hint) in ENV_BLUEPRINT:
        prompt = f"[{cat}] {label}"
        if default:
            prompt += f"  (default: {default})"
        if req:
            prompt += "  *"
        prompt += "\n  > "
        v = input(prompt).strip()
        if not v and default:
            v = default
        if v:
            values[key] = v
    # Write
    lines = ["# RGS AI .env (CLI-filled)"]
    for (key, *_r) in ENV_BLUEPRINT:
        lines.append(f"{key}={values.get(key, '')}")
    ENV_FILE.write_text("\n".join(lines), encoding="utf-8")
    print(f"\n✓  .env written → {ENV_FILE}")
    return values


if __name__ == "__main__":
    if "--cli" in sys.argv:
        cli_fill_env()
    else:
        root = ctk.CTk()
        root.withdraw()
        EnvEditorWindow(root)
        root.mainloop()
