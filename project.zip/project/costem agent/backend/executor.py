"""
╔══════════════════════════════════════════════════════════════╗
║   executor.py — Tool Execution Engine                        ║
║                                                              ║
║   Maps tool-name → handler-function.  Used by the chat loop  ║
║   to dispatch AI-requested tool calls safely.                ║
║                                                              ║
║   All handlers go through error_handler.safe_tool.           ║
╚══────────────────────────────────────────────────────────══════╝
"""

from __future__ import annotations
import os
import sys
import json
import shutil
import subprocess
import webbrowser
from pathlib import Path
from typing import Callable, Dict, Any, List, Optional

from config import logger, BASE_DIR, DATA_DIR
from error_handler import safe_tool


# ─────────────────────────────────────────────────────────────
#  TOOL REGISTRY
# ─────────────────────────────────────────────────────────────
TOOL_REGISTRY: Dict[str, Callable] = {}


def register_tool(name: str, fn: Optional[Callable] = None):
    """Register a tool.  Usable as both a direct call and a decorator."""
    def _do(f):
        TOOL_REGISTRY[name] = f
        return f
    if fn is None:
        return _do
    return _do(fn)


def execute_tool(name: str, **kwargs) -> Dict[str, Any]:
    """Look up a tool by name and execute it."""
    fn = TOOL_REGISTRY.get(name)
    if fn is None:
        return {"ok": False, "error": f"unknown tool: {name}"}
    return fn(**kwargs)


def list_tools() -> List[str]:
    return sorted(TOOL_REGISTRY.keys())


# ─────────────────────────────────────────────────────────────
#  Built-in tools
# ─────────────────────────────────────────────────────────────
@register_tool("web_search")
@safe_tool
def web_search(query: str, max_results: int = 5):
    """Search the web using DuckDuckGo's HTML endpoint (no key needed)."""
    import requests
    from urllib.parse import quote_plus
    url = f"https://html.duckduckgo.com/html/?q={quote_plus(query)}"
    r = requests.get(url, headers={"User-Agent": "Mozilla/5.0"}, timeout=15)
    if r.status_code != 200:
        return []
    # Parse results
    import re
    results = []
    for m in re.finditer(r'<a rel="nofollow" class="result__a" href="([^"]+)">(.*?)</a>',
                         r.text, flags=re.S):
        href = m.group(1)
        text = re.sub(r"<[^>]+>", "", m.group(2))
        if href.startswith("//duckduckgo.com/l/?uddg="):
            from urllib.parse import unquote, parse_qs
            qs = href.split("?", 1)[1]
            u = parse_qs(qs).get("uddg", [""])[0]
            href = unquote(u)
        results.append({"title": text.strip(), "url": href})
        if len(results) >= max_results:
            break
    return results


@register_tool("search_github")
@safe_tool
def search_github(query: str, max_results: int = 5):
    """Search GitHub repositories.  Uses GITHUB_TOKEN if available."""
    import requests
    from config import env
    headers = {"Accept": "application/vnd.github+json"}
    tok = env("GITHUB_TOKEN")
    if tok:
        headers["Authorization"] = f"Bearer {tok}"
    r = requests.get("https://api.github.com/search/repositories",
                     params={"q": query, "per_page": max_results, "sort": "stars"},
                     headers=headers, timeout=15)
    if r.status_code != 200:
        return []
    return [
        {"name": it["full_name"], "url": it["html_url"],
         "stars": it["stargazers_count"], "desc": it.get("description", "")}
        for it in r.json().get("items", [])[:max_results]
    ]


@register_tool("generate_code")
@safe_tool
def generate_code(language: str, description: str, filename: str = ""):
    """Stub: returns a prompt template — the actual generation is done
    by the LLM in the chat loop.  This tool is just a marker."""
    return {
        "language": language,
        "description": description,
        "filename": filename,
        "note": "Use the chat to ask the LLM to generate this code."
    }


@register_tool("run_command")
@safe_tool
def run_command(command: str, cwd: str = "", timeout: int = 30):
    """Run a shell command (sandboxed — only allowed if RGS_AI_ALLOW_SHELL=1)."""
    if os.environ.get("RGS_AI_ALLOW_SHELL") != "1":
        return {"ok": False,
                "error": "shell disabled — set RGS_AI_ALLOW_SHELL=1 to enable"}
    if not cwd:
        cwd = str(BASE_DIR)
    try:
        r = subprocess.run(command, shell=True, capture_output=True,
                           text=True, timeout=timeout, cwd=cwd)
        return {
            "stdout": r.stdout[-4000:],
            "stderr": r.stderr[-4000:],
            "returncode": r.returncode,
        }
    except subprocess.TimeoutExpired:
        return {"error": "timeout", "timeout": timeout}


@register_tool("run_tests")
@safe_tool
def run_tests(path: str = ""):
    """Run pytest in the given path (or project root)."""
    if not path:
        path = str(BASE_DIR)
    if not os.environ.get("RGS_AI_ALLOW_SHELL") == "1":
        return {"ok": False, "error": "shell disabled"}
    r = subprocess.run([sys.executable, "-m", "pytest", path, "-q"],
                       capture_output=True, text=True, timeout=120)
    return {"stdout": r.stdout[-4000:], "stderr": r.stderr[-4000:],
            "returncode": r.returncode}


@register_tool("open_url")
@safe_tool
def open_url(url: str):
    webbrowser.open(url)
    return {"opened": url}


@register_tool("read_file")
@safe_tool
def read_file(path: str, max_bytes: int = 100_000):
    p = Path(path).expanduser()
    if not p.exists():
        return {"error": f"not found: {path}"}
    data = p.read_bytes()[:max_bytes]
    try:
        return {"text": data.decode("utf-8", errors="replace")}
    except Exception:
        return {"bytes": len(data)}


@register_tool("write_file")
@safe_tool
def write_file(path: str, content: str):
    p = Path(path).expanduser()
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(content, encoding="utf-8")
    return {"written": str(p), "bytes": len(content)}


@register_tool("list_dir")
@safe_tool
def list_dir(path: str = "."):
    p = Path(path).expanduser()
    if not p.exists():
        return {"error": f"not found: {path}"}
    items = []
    for child in p.iterdir():
        items.append({
            "name": child.name,
            "is_dir": child.is_dir(),
            "size": child.stat().st_size if child.is_file() else 0,
        })
    return {"items": items}


@register_tool("memory_get")
@safe_tool
def memory_get(key: str):
    """Read a value from RGS AI persistent memory."""
    mem_file = DATA_DIR / "memory.json"
    if not mem_file.exists():
        return None
    try:
        mem = json.loads(mem_file.read_text(encoding="utf-8"))
        return mem.get(key)
    except Exception:
        return None


@register_tool("memory_set")
@safe_tool
def memory_set(key: str, value):
    """Write a value to RGS AI persistent memory."""
    mem_file = DATA_DIR / "memory.json"
    mem = {}
    if mem_file.exists():
        try:
            mem = json.loads(mem_file.read_text(encoding="utf-8"))
        except Exception:
            mem = {}
    mem[key] = value
    mem_file.write_text(json.dumps(mem, indent=2, default=str), encoding="utf-8")
    return {"ok": True, "key": key}


# ─────────────────────────────────────────────────────────────
#  Tool catalog (for the AI to know what's available)
# ─────────────────────────────────────────────────────────────
TOOL_CATALOG = [
    {"name": "web_search", "description": "Search the web via DuckDuckGo.",
     "parameters": {"query": "string", "max_results": "int"}},
    {"name": "search_github", "description": "Search GitHub repos by query.",
     "parameters": {"query": "string", "max_results": "int"}},
    {"name": "generate_code", "description": "Mark a code-gen request.",
     "parameters": {"language": "string", "description": "string", "filename": "string"}},
    {"name": "run_command", "description": "Run a shell command (needs RGS_AI_ALLOW_SHELL=1).",
     "parameters": {"command": "string", "cwd": "string", "timeout": "int"}},
    {"name": "run_tests", "description": "Run pytest in a path.",
     "parameters": {"path": "string"}},
    {"name": "open_url", "description": "Open a URL in the browser.",
     "parameters": {"url": "string"}},
    {"name": "read_file", "description": "Read a text file.",
     "parameters": {"path": "string", "max_bytes": "int"}},
    {"name": "write_file", "description": "Write a text file.",
     "parameters": {"path": "string", "content": "string"}},
    {"name": "list_dir", "description": "List a directory.",
     "parameters": {"path": "string"}},
    {"name": "memory_get", "description": "Read from persistent memory.",
     "parameters": {"key": "string"}},
    {"name": "memory_set", "description": "Write to persistent memory.",
     "parameters": {"key": "string", "value": "any"}},
]


if __name__ == "__main__":
    print("Available tools:")
    for t in list_tools():
        print("  -", t)
