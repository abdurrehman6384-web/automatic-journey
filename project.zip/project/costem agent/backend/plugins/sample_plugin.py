"""
RASHEED Plugin Example — Custom skills
Place .py files in /plugins/ folder. They auto-load on startup.
"""

# Required: Plugin Metadata
PLUGIN_NAME = "Crypto Price Checker"
PLUGIN_VERSION = "1.0"

def init():
    """Called when plugin loads"""
    print(f"[PLUGIN] {PLUGIN_NAME} v{PLUGIN_VERSION} loaded!")

def handle_command(text: str) -> str:
    """Process command. Return result string or empty string if not handled."""
    text_lower = text.lower()
    
    if "bitcoin price" in text_lower or "btc price" in text_lower:
        try:
            import requests
            r = requests.get("https://api.coingecko.com/api/v3/simple/price?ids=bitcoin&vs_currencies=usd", timeout=5)
            data = r.json()
            price = data['bitcoin']['usd']
            return f"₿ Bitcoin Price: ${price:,}"
        except:
            return "❌ Could not fetch BTC price"
    
    return ""  # Not handled by this plugin

def cleanup():
    """Called when plugin unloads"""
    pass
