"""
╔══════════════════════════════════════════════════════════════╗
║   face_lock.py — Face Recognition + PIN Fallback             ║
║                                                              ║
║   Runs AFTER the user finishes the .env editor.              ║
║                                                              ║
║   Flow:                                                      ║
║     1. If no face model exists → ENROLLMENT                  ║
║         (capture 30 frames, train LBPH recognizer)           ║
║     2. If model exists → VERIFICATION                        ║
║         (match current face against stored model)            ║
║     3. Three failed attempts → PIN fallback                  ║
║                                                              ║
║   Uses: OpenCV (cv2) + numpy.  Falls back to PIN-only mode   ║
║   if no camera is detected.                                  ║
╚══────────────────────────────────────────────────────────══════╝
"""

from __future__ import annotations
import os
import sys
import time
import json
import hashlib
import getpass
from pathlib import Path
from typing import Optional, Tuple

from config import (
    FACE_MODEL_FILE, DATA_DIR, USER_PROFILE_FILE,
    ENABLE_FACE_LOCK, logger,
)


class FaceLock:
    """Face recognition + PIN fallback."""

    def __init__(self):
        self.cap = None
        self.face_cascade = None
        self.recognizer = None
        self.has_camera = False
        self._init_opencv()

    def _init_opencv(self):
        try:
            import cv2
            import numpy as np
            self.cv2 = cv2
            self.np = np
            # Haar cascade for frontal face
            cascade_path = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
            self.face_cascade = cv2.CascadeClassifier(cascade_path)
            # LBPH recognizer
            try:
                self.recognizer = cv2.face.LBPHFaceRecognizer_create()
            except Exception:
                self.recognizer = None
                logger.warn("LBPH recognizer unavailable — face match will be approximate.")
            # Test camera
            self.cap = cv2.VideoCapture(0)
            self.has_camera = self.cap.isOpened()
            if not self.has_camera:
                logger.warn("No webcam detected — FaceLock will use PIN fallback only.")
        except ImportError:
            logger.warn("opencv-python not installed — FaceLock falls back to PIN.")
            self.has_camera = False

    # ─────────────────────────────────────────────────────
    #  PIN management (always available)
    # ─────────────────────────────────────────────────────
    def _pin_file(self) -> Path:
        return DATA_DIR / "pin.hash"

    def set_pin(self, pin: str) -> bool:
        if len(pin) < 4:
            return False
        salt = os.urandom(16).hex()
        h = hashlib.pbkdf2_hmac("sha256", pin.encode(), salt.encode(), 200_000).hex()
        self._pin_file().write_text(f"{salt}${h}", encoding="utf-8")
        return True

    def verify_pin(self, pin: str) -> bool:
        if not self._pin_file().exists():
            return False
        try:
            salt, h = self._pin_file().read_text().strip().split("$")
            calc = hashlib.pbkdf2_hmac("sha256", pin.encode(), salt.encode(), 200_000).hex()
            return calc == h
        except Exception:
            return False

    def has_pin(self) -> bool:
        return self._pin_file().exists()

    # ─────────────────────────────────────────────────────
    #  Enrollment
    # ─────────────────────────────────────────────────────
    def has_face_model(self) -> bool:
        return FACE_MODEL_FILE.exists() and FACE_MODEL_FILE.stat().st_size > 0

    def enroll_face(self, label: int = 0) -> bool:
        """Capture 30 face samples and train the LBPH model."""
        if not self.has_camera or self.recognizer is None:
            logger.warn("Cannot enroll face — no camera or recognizer. PIN-only mode.")
            return False

        cv2 = self.cv2
        np  = self.np
        samples = []
        labels  = []

        print("\n[FaceLock] Enrollment starting.  Look at the camera.")
        print("[FaceLock] Press  Q  in the camera window to abort.\n")

        count = 0
        target = 30
        while count < target:
            ret, frame = self.cap.read()
            if not ret:
                continue
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            faces = self.face_cascade.detectMultiScale(gray, 1.3, 5)
            for (x, y, w, h) in faces:
                face = gray[y:y+h, x:x+w]
                face = cv2.resize(face, (200, 200))
                samples.append(face)
                labels.append(label)
                count += 1
                cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
                cv2.putText(frame, f"Captured {count}/{target}", (10, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 0), 2)
            cv2.imshow("RGS AI — Face Enrollment (press Q to abort)", frame)
            if cv2.waitKey(1) & 0xFF in (ord('q'), ord('Q')):
                cv2.destroyAllWindows()
                return False

        cv2.destroyAllWindows()
        if len(samples) < 5:
            logger.error("Too few face samples captured.  Try again in better lighting.")
            return False

        self.recognizer.train(samples, np.array(labels))
        self.recognizer.save(str(FACE_MODEL_FILE))
        FACE_MODEL_FILE.chmod(0o600)
        logger.info(f"Face model saved → {FACE_MODEL_FILE}")
        return True

    # ─────────────────────────────────────────────────────
    #  Verification
    # ─────────────────────────────────────────────────────
    def verify_face(self, max_attempts: int = 3, threshold: int = 70) -> bool:
        """Try to match a face against the stored model."""
        if not self.has_camera or self.recognizer is None or not self.has_face_model():
            logger.warn("Face verify unavailable — falling back to PIN.")
            return False

        self.recognizer.read(str(FACE_MODEL_FILE))
        cv2 = self.cv2

        for attempt in range(1, max_attempts + 1):
            print(f"\n[FaceLock] Verification attempt {attempt}/{max_attempts}.  Look at the camera.  (Q to abort)")
            t_start = time.time()
            matched = False
            while time.time() - t_start < 12:  # 12-second window
                ret, frame = self.cap.read()
                if not ret:
                    continue
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                faces = self.face_cascade.detectMultiScale(gray, 1.3, 5)
                for (x, y, w, h) in faces:
                    face = gray[y:y+h, x:x+w]
                    face = cv2.resize(face, (200, 200))
                    label, confidence = self.recognizer.predict(face)
                    color = (0, 255, 0) if confidence < threshold else (0, 0, 255)
                    cv2.rectangle(frame, (x, y), (x+w, y+h), color, 2)
                    cv2.putText(frame, f"conf={confidence:.0f} ({'OK' if confidence < threshold else 'NO'})",
                                (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)
                    if confidence < threshold:
                        matched = True
                        break
                cv2.imshow("RGS AI — Face Verification (press Q to abort)", frame)
                if cv2.waitKey(1) & 0xFF in (ord('q'), ord('Q')):
                    cv2.destroyAllWindows()
                    return False
                if matched:
                    break
            cv2.destroyAllWindows()
            if matched:
                logger.info("Face verified.")
                return True
        logger.warn("All face attempts failed — moving to PIN fallback.")
        return False

    # ─────────────────────────────────────────────────────
    #  PIN flow (CLI fallback)
    # ─────────────────────────────────────────────────────
    def pin_flow(self) -> bool:
        if not self.has_pin():
            print("\n[PIN] No PIN set.  Let's set one now.")
            while True:
                p1 = getpass.getpass("  New PIN (min 4 digits): ")
                p2 = getpass.getpass("  Confirm PIN:            ")
                if p1 == p2 and len(p1) >= 4:
                    self.set_pin(p1)
                    print("  ✓ PIN set.\n")
                    break
                print("  ✗ PINs didn't match or too short.  Try again.")
        # Verify
        for attempt in range(1, 4):
            p = getpass.getpass(f"  Enter PIN (attempt {attempt}/3): ")
            if self.verify_pin(p):
                return True
            print("  ✗ Wrong PIN.")
        return False

    # ─────────────────────────────────────────────────────
    #  Full gate
    # ─────────────────────────────────────────────────────
    def run(self) -> bool:
        """Run the full FaceLock gate.  Returns True if access granted."""
        if not ENABLE_FACE_LOCK:
            logger.info("FaceLock disabled by config.")
            return True

        print("\n" + "═" * 60)
        print("  RGS AI  —  FACE LOCK")
        print("═" * 60)

        # Enrollment if first run
        if self.has_camera and self.recognizer is not None and not self.has_face_model():
            print("  First run: enrolling your face.")
            ok = self.enroll_face()
            if not ok:
                print("  Enrollment failed or aborted — switching to PIN-only.")

        # Try face verification
        if self.has_camera and self.has_face_model() and self.recognizer is not None:
            if self.verify_face():
                self._cleanup()
                return True

        # PIN fallback
        ok = self.pin_flow()
        self._cleanup()
        return ok

    def _cleanup(self):
        try:
            if self.cap and self.cap.isOpened():
                self.cap.release()
            if self.cv2:
                self.cv2.destroyAllWindows()
        except Exception:
            pass


# ─────────────────────────────────────────────────────────────
#  GUI version (uses customtkinter)
# ─────────────────────────────────────────────────────────────
def run_gui_face_lock(parent=None) -> bool:
    """Show a GUI FaceLock gate.  Returns True if access granted."""
    try:
        import customtkinter as ctk
        from tkinter import messagebox
    except ImportError:
        # Fallback to CLI flow
        return FaceLock().run()

    granted = [False]
    fl = FaceLock()

    dlg = ctk.CTkToplevel(parent) if parent else ctk.CTk()
    dlg.title("RGS AI — Face Lock")
    dlg.geometry("560x440")
    dlg.configure(fg_color="#1e1e1e")
    if parent:
        dlg.transient(parent)
        dlg.grab_set()

    title = ctk.CTkLabel(dlg, text="🔒  Face Lock",
                         font=ctk.CTkFont(family="Segoe UI", size=26, weight="bold"),
                         text_color="#d4d4d4")
    title.pack(pady=(30, 8))

    sub = ctk.CTkLabel(dlg,
                       text="Look at the camera to unlock.\nIf face fails 3×, you'll be asked for your PIN.",
                       font=ctk.CTkFont(size=12), text_color="#858585", justify="center")
    sub.pack(pady=(0, 20))

    status = ctk.CTkLabel(dlg, text="Initializing camera…",
                          font=ctk.CTkFont(size=13), text_color="#d4d4d4")
    status.pack(pady=10)

    def _face_thread():
        import threading
        def work():
            if not fl.has_camera or not fl.has_face_model():
                status.configure(text="No face model yet — switching to PIN.")
                dlg.after(500, _pin)
                return
            ok = fl.verify_face()
            if ok:
                status.configure(text="✓ Face verified!", text_color="#4ade80")
                granted[0] = True
                dlg.after(800, dlg.destroy)
            else:
                status.configure(text="Face failed — PIN fallback.", text_color="#fbbf24")
                dlg.after(500, _pin)
        threading.Thread(target=work, daemon=True).start()

    def _pin():
        # Simple PIN dialog
        pin_dlg = ctk.CTkToplevel(dlg)
        pin_dlg.title("PIN Fallback")
        pin_dlg.geometry("380x260")
        pin_dlg.configure(fg_color="#1e1e1e")
        pin_dlg.transient(dlg)
        pin_dlg.grab_set()

        ctk.CTkLabel(pin_dlg, text="Enter your PIN",
                     font=ctk.CTkFont(size=16, weight="bold"),
                     text_color="#d4d4d4").pack(pady=20)

        # If no PIN set, ask to set one
        if not fl.has_pin():
            ctk.CTkLabel(pin_dlg, text="First run — set your PIN (min 4 digits)",
                         text_color="#858585").pack()
            e1 = ctk.CTkEntry(pin_dlg, show="•", width=200)
            e1.pack(pady=8)
            e2 = ctk.CTkEntry(pin_dlg, show="•", width=200, placeholder_text="Confirm")
            e2.pack(pady=4)

            def _set():
                if e1.get() == e2.get() and len(e1.get()) >= 4:
                    fl.set_pin(e1.get())
                    granted[0] = True
                    pin_dlg.destroy()
                    dlg.destroy()
                else:
                    messagebox.showerror("Error", "PINs don't match or too short.", parent=pin_dlg)
            ctk.CTkButton(pin_dlg, text="Set PIN", command=_set,
                          fg_color="#10a37f", text_color="white").pack(pady=10)
        else:
            e = ctk.CTkEntry(pin_dlg, show="•", width=220)
            e.pack(pady=20)
            e.focus_set()

            def _verify():
                if fl.verify_pin(e.get()):
                    granted[0] = True
                    pin_dlg.destroy()
                    dlg.destroy()
                else:
                    messagebox.showerror("Wrong PIN", "Try again.", parent=pin_dlg)
            ctk.CTkButton(pin_dlg, text="Unlock", command=_verify,
                          fg_color="#10a37f", text_color="white").pack(pady=10)
            e.bind("<Return>", lambda ev: _verify())

    # Start face thread
    dlg.after(500, _face_thread)
    dlg.protocol("WM_DELETE_WINDOW", lambda: dlg.destroy())
    if parent is None:
        dlg.mainloop()
    return granted[0]


if __name__ == "__main__":
    ok = FaceLock().run()
    sys.exit(0 if ok else 1)
