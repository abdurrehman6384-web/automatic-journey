"""
RASHEED Workflow Engine — Automated cron-like tasks
Example: "Har monday subah 8 baje weather batao"
"""
import time, threading, json
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Callable, List

class WorkflowEngine:
    def __init__(self, data_file="data/workflows.json"):
        self.data_file = Path(data_file)
        self.workflows: List[Dict[str, Any]] = []
        self._running = False
        self._load()

    def _load(self):
        if self.data_file.exists():
            try:
                with open(self.data_file, 'r') as f:
                    self.workflows = json.load(f)
            except: self.workflows = []

    def _save(self):
        self.data_file.parent.mkdir(exist_ok=True)
        with open(self.data_file, 'w') as f:
            json.dump(self.workflows, f, indent=2)

    def add_workflow(self, name: str, time_str: str, days: list, action: str) -> str:
        """
        Add automated workflow.
        time_str: "08:00", days: ["monday", "wednesday"], action: text command
        """
        workflow = {
            "id": len(self.workflows) + 1,
            "name": name,
            "time": time_str,
            "days": days,
            "action": action,
            "enabled": True,
            "last_run": None
        }
        self.workflows.append(workflow)
        self._save()
        return f"✅ Workflow '{name}' added! Runs at {time_str} on {', '.join(days)}"

    def remove_workflow(self, workflow_id: int) -> str:
        self.workflows = [w for w in self.workflows if w["id"] != workflow_id]
        self._save()
        return "✅ Workflow removed"

    def list_workflows(self) -> str:
        if not self.workflows: return "No automated workflows."
        lines = []
        for w in self.workflows:
            status = "🟢" if w["enabled"] else "🔴"
            lines.append(f"{status} [{w['id']}] {w['name']}: {w['action']} at {w['time']} ({', '.join(w['days'])})")
        return "\n".join(lines)

    def start_monitor(self, execute_callback: Callable):
        """Start checking workflows every minute"""
        self._running = True
        def loop():
            while self._running:
                now = datetime.now()
                current_day = now.strftime("%A").lower()
                current_time = now.strftime("%H:%M")
                
                for w in self.workflows:
                    if (w["enabled"] and 
                        current_day in w["days"] and 
                        w["time"] == current_time and
                        w.get("last_run") != current_time):
                        
                        w["last_run"] = current_time
                        self._save()
                        execute_callback(w["action"])
                
                time.sleep(60) # Check every minute
        threading.Thread(target=loop, daemon=True).start()

    def stop_monitor(self):
        self._running = False
