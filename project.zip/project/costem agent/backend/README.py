# 🤖 Rasheed AI

Rasheed AI is an advanced autonomous AI assistant built with Python.

It combines multiple AI agents, memory systems, browser automation, voice interaction, vision processing, and plugin support to create a powerful personal assistant capable of handling complex tasks.

## ✨ Features

- 🧠 Multi-Agent AI Architecture
- 💾 Long-Term Semantic Memory
- 🌐 Browser Automation
- 🎤 Voice Input & Text-to-Speech
- 👁️ Computer Vision Support
- 🔌 Plugin System
- ⚡ Real-Time Communication
- 🖥️ Desktop Automation
- 📚 Context-Aware Conversations

## 📂 Project Structure

```
rasheed-ai/
├── ai/
├── browser/
├── comms/
├── config/
├── core/
├── data/
├── plugins/
├── requirements.txt
└── main.py
```

## 🚀 Installation

### Clone Repository

```bash
git clone https://github.com/yourusername/rasheed-ai.git
cd rasheed-ai
```

### Create Virtual Environment

```bash
python -m venv venv
```

### Activate Environment

Windows:

```bash
venv\Scripts\activate
```

Linux:

```bash
source venv/bin/activate
```

### Install Dependencies

```bash
pip install -r requirements.txt
```

## ⚙️ Configuration

Create a `.env` file:

```env
OPENAI_API_KEY=your_api_key
```

## ▶️ Run

```bash
python main.py
```

## 🛠 Technologies

- Python
- OpenAI API
- ChromaDB
- WebSockets
- PyAutoGUI
- OpenCV
- Speech Recognition
- Text To Speech

## 🔒 Security

Never upload:

- API Keys
- Tokens
- Passwords
- Database Files
- Environment Files

## 🤝 Contributing

Pull requests are welcome.

## 📜 License

MIT License

---
WHATSAPP 03320493334
WEBSITE DEVELOPERAJWAD STORE 
YOUTUBE INSTAGRAM NAME DEVELOPER AJWAD UPCOMING

Built with ❤️ using Python and AI.