# MASTER PROMPT — Port "ULTRON Orb UI" into RGS AI Mobile

Paste this whole file into your AI coding assistant (Claude Code / Cursor / etc.)
inside the RGS AI Mobile repo. It has full context on the source project, an
accurate stack-compatibility analysis, and a concrete step-by-step plan.

---

## 0. Source project

Repo: `SAGAR-TAMANG/ultron-by-sagar-builds` ("ULTRON Orb UI", MIT licensed).
The full source is included alongside this prompt in `source/`.

It's a holographic, Iron-Man/JARVIS-style orb HUD built with:
- **Next.js 16 + React 19** (web, App Router) — just the app shell
- **three.js** — the actual 3D orb (WebGL)
- **@mediapipe/tasks-vision** — webcam hand-gesture control
- Plain CSS — CRT/holographic skin (grain, scanlines, vignette)

Since it's a **plain client-side canvas app** with no server logic, no backend,
and no Next.js-specific APIs beyond the page shell, almost all of the real
value (the 3D scene + interaction model) is framework-agnostic and portable.

### File-by-file breakdown

| File | Role | Portability to Expo/RN |
|---|---|---|
| `lib/orbScene.ts` (859 lines) | The entire three.js scene: layered wireframe shells, spiral inner core, floating "code" text sprites, orbiting debris, dust particles, scan rings, bloom + custom chromatic-aberration/color-grade GLSL shader, and a self-contained camera-control API (`rotateBy`, `zoomBy`, `zoomIn`, `zoomOut`, `resetView`, `dispose`). | **~90% direct copy.** Only 2 spots touch the DOM: creating the `WebGLRenderer` / appending its canvas, and reading `window.devicePixelRatio` on resize. Everything else is pure `three` API calls. |
| `lib/handTracker.ts` (272 lines) | `HandTracker` class wrapping MediaPipe `HandLandmarker`: pinch detection with hysteresis (`PINCH_ON`/`PINCH_OFF`), one-hand-pinch-drag → spin, two-hand-pinch-spread → zoom, plus a 2D canvas overlay drawing the tracked landmarks on the mirrored webcam preview. | **Not portable as-is.** `@mediapipe/tasks-vision` is a web/WASM package and does not run in React Native. See §2 for options. |
| `components/JarvisOrb.tsx` | Glue: mounts the scene into a container div, wires up the video/camera panel, HUD buttons (gestures toggle, zoom +/−, reset), status text, and keyboard shortcuts (`G`/`R`/`+`/`-`). | Rewrite as an RN component — same state machine and same calls into the scene API, different JSX primitives. |
| `app/globals.css` | Amber-on-black CRT skin: SVG-fractal-noise film grain, repeating-gradient scanlines, radial-gradient vignette, monospace HUD, glitchy title underline. | No image/graphic assets are used anywhere — every visual effect is generated procedurally (SVG data-URI noise, CSS gradients, GLSL). That's good news: nothing to "export" as image files, just logic to re-express. |
| `docs/screenshot.png` | README preview image only. | Reference only, not used at runtime. |

**Important realization for the port:** `OrbitControls` (the mouse-drag/scroll library) is used only for the *default* pointer-based input on the DOM canvas. The hand-gesture path already bypasses it completely — `rotateBy(deltaTheta, deltaPhi)` and `zoomBy(factor)` manipulate `camera.position` directly via spherical coordinates around `controls.target`, independent of any pointer events. **This means on mobile you don't need to reimplement `OrbitControls` at all** — drive 100% of touch interaction (pan-to-rotate, pinch-to-zoom) through that exact same `rotateBy`/`zoomBy` API that hand-gestures already use. One interaction model, two possible input sources (touch now, hand-tracking later).

---

## 1. Target stack (RGS AI Mobile)

React Native + Expo (per project constraints: mobile-only dev via Termux,
EAS Build for APKs, on-device-only storage, plugin/tool architecture).

Required new deps:
```
npx expo install expo-gl three react-native-gesture-handler react-native-reanimated expo-font
```
`expo-gl` provides a native WebGL-compatible context (`GLView`) that `three.js`'s
`WebGLRenderer` can bind to directly — this is the standard, well-supported way
to run three.js scenes in Expo apps.

---

## 2. The hand-tracking decision (do this first, it drives everything else)

`@mediapipe/tasks-vision` will not run in RN. Options, cheapest first:

1. **Phase 1 (recommended default): ship without webcam hand-tracking.**
   Touch drag = spin, pinch = zoom, using the exact `rotateBy`/`zoomBy` API
   the source repo already exposes for gestures. This alone gives full
   feature parity with the *mouse/touch* control scheme from the original
   (see the "Mouse / touch" table in the source README) and is a clean,
   self-contained integration.
2. **Phase 2 (stretch goal): add real hand-gesture control later** using
   `react-native-vision-camera` + a native hand-landmark frame-processor
   plugin (e.g. an MLKit or TFLite-based community plugin). The pinch/hysteresis
   math in `handTracker.ts` (lines ~140-218: `PINCH_ON`/`PINCH_OFF` thresholds,
   smoothing, mode switching between `spin`/`zoom`/`idle`) can be reused
   almost verbatim — only the source of the 21 hand landmarks changes from
   MediaPipe-in-browser to whatever native plugin is chosen. Flag this as
   a separate, later task; don't block the core orb integration on it.

Decide which phase you're doing before starting §3 — Phase 1 is a same-day
integration, Phase 2 is a multi-day native-module effort.

---

## 3. Step-by-step task list

1. **Create the feature folder**, e.g. `src/features/ultron-orb/` with:
   - `OrbScene.ts` — ported from `source/lib/orbScene.ts`
   - `OrbView.tsx` — new RN component replacing `source/components/JarvisOrb.tsx`
   - `theme.ts` — colors/fonts pulled from `source/app/globals.css`
   - `handTracking/` — only if doing Phase 2

2. **Port `OrbScene.ts`:**
   - Copy `source/lib/orbScene.ts` in almost unchanged.
   - Replace the renderer setup:
     ```ts
     // web version
     const renderer = new THREE.WebGLRenderer({ antialias: true });
     renderer.setSize(width, height);
     container.appendChild(renderer.domElement);

     // Expo version — pass in the `gl` context from GLView's onContextCreate
     const renderer = new THREE.WebGLRenderer({ canvas: { width, height, style: {}, addEventListener(){}, removeEventListener(){}, clientHeight: height } as any, context: gl });
     renderer.setSize(width, height);
     ```
     (Follow whatever exact bootstrap `expo-gl` + `three` currently recommend —
     confirm the precise `Renderer`/context-binding snippet against the installed
     `expo-gl` version's docs before finalizing, package APIs shift between
     versions.)
   - Replace `window.devicePixelRatio` with a fixed value (RN has no reliable
     equivalent the same way — `PixelRatio.get()` from `react-native` is the
     analogue) and drive resize off the `GLView`'s layout event instead of a
     `window` resize listener.
   - At the end of the `animate()` loop, call `gl.endFrameEXP()` (required by
     `expo-gl` to present each frame) after `composer.render()`.
   - Keep `rotateBy`, `zoomBy`, `zoomIn`, `zoomOut`, `resetView`, `dispose`
     exactly as they are — this is the API surface `OrbView.tsx` will call.

3. **Build `OrbView.tsx`:**
   - `<GLView style={{ flex: 1 }} onContextCreate={...} />` to mount the scene
     (call your ported `createOrbScene`-equivalent inside `onContextCreate`).
   - Wrap it with `react-native-gesture-handler`'s `PanGestureHandler` (feed
     per-frame translation deltas into `scene.rotateBy(dx, dy)`, scaled to
     roughly match the original's feel) and `PinchGestureHandler` (feed scale
     delta into `scene.zoomBy(factor)`).
   - Rebuild the HUD as RN views: title (`U.L.T.R.O.N.` or your own branding),
     hint text, a row of `Pressable` buttons (zoom +/−, reset, and — only in
     Phase 2 — a gestures on/off toggle). No keyboard shortcuts on mobile;
     the buttons already cover the same actions.

4. **Recreate the visual skin in `theme.ts` / styles:**
   - Colors: `#ffaa30` (bright amber), `#dd7700` (mid), `#884400` (dim),
     `#553300` (faint), `#ffcc66` (hot highlight) — same palette as the
     three.js scene so the HUD and orb match.
   - Font: `"Courier New"` isn't guaranteed on Android/iOS the way it is on
     web — bundle a real monospace font via `expo-font` (e.g. Space Mono or
     JetBrains Mono) for the authentic terminal look.
   - **Recommended shortcut for grain/scanlines/vignette:** rather than
     reconstructing three separate CSS effects as RN `View`s/gradients
     (fiddly — RN has no native radial-gradient, `react-native-svg` would be
     needed), fold them straight into the existing chromatic-aberration
     `ShaderPass` GLSL in `orbScene.ts`. GLSL is renderer-target-agnostic, so
     adding vignette darkening, a `fract(sin(...))` noise term, and a
     scanline `mod()` stripe directly into that fragment shader reproduces
     the same look with zero extra RN dependencies.

5. **Wire it into RGS AI Mobile's plugin/tool architecture** as its own
   screen or modal (e.g. an "Orb HUD" visual mode) rather than a global
   background, since it's a full-screen, GPU-heavy view.

6. **Test via EAS Build** (per the existing Termux/EAS-only workflow) —
   the `GLView` + gesture-handler path needs a real device or dev-client
   build to verify; it won't render meaningfully in a plain JS-only preview.

---

## 4. Licensing note

Source repo is MIT licensed — free to reuse/modify commercially, just keep
the copyright notice (`Copyright (c) 2026 Sagar Tamang`) somewhere in your
project's third-party notices if you ship code derived from it.

---

## 5. What's in this zip

```
source/            full original repo (minus .git)
INTEGRATION_PROMPT.md   this file
README.md          quick-start for the zip itself
```
