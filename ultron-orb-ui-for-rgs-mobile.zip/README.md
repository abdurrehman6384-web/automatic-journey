# ULTRON Orb UI — export for RGS AI Mobile

Source: https://github.com/SAGAR-TAMANG/ultron-by-sagar-builds (MIT license)

## What's inside

- `source/` — full original repo (Next.js + three.js + MediaPipe), minus `.git`
- `INTEGRATION_PROMPT.md` — a master prompt to paste into your AI coding
  assistant to port this UI's orb, graphics, and controls into RGS AI Mobile
  (React Native / Expo). Includes an accurate portability analysis of every
  file, a hand-tracking strategy, and a step-by-step task list.

## Fastest path

1. Open `INTEGRATION_PROMPT.md`.
2. Paste its contents into Claude Code / your assistant inside the RGS AI
   Mobile repo, with `source/` available alongside it for reference.
3. Follow the phased plan (touch controls first, webcam hand-tracking later
   as a stretch goal).

## Preview

See `source/docs/screenshot.png` for what the original web UI looks like.
